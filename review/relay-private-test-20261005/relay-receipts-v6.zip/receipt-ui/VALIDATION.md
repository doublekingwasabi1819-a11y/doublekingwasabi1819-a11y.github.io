# Frozen receipt slice validation

2026-10-05: 61 frontend tests passed (44 prior focused, 13 receipt DOM, 4 actual
app/SQL fixture mounts). 11 host tests passed (10 guard/contract regressions and
1 actual DOM → manager route → canonical SQL source → SQLite ledger integration).
Independent review findings corrected: strict boolean enable, stalled request
body cancellation plus abort boundaries, real rejected delivery outcome, and
canonical notification-target correlation with final audience recheck.

The full integration renders separate real queued/sent/service-accepted stages,
then fetch and explicit ACK after refresh. It verifies no manager notification,
no extra ping, unchanged source DM readAt, and no body in ledger/receipt panel.
Production service transport is injected in tests; live Supabase→Lightsail
routing and approved service identity remain unconfigured.

Run the combined host tests from the enclosing package root:

```
RELAY_PACKAGE_ROOT="$PWD" \
RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite \
RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom \
node --experimental-vm-modules --test receipt-ui/event-host/test/*.mjs
```

V5 source remains byte-for-byte unchanged in this new package; the optional UI
patch is additive preparation and must be applied to that proposed frontend.

Baseline revalidation also passed: 183 event tests, 37 sender tests, 15 SQL
contract checks, 13 real handler/SQL roundtrips and 1 full MCP messaging flow.

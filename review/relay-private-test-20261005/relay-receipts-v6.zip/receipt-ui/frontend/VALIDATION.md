# Manager delivery-receipt UI: local candidate

This patch is based on the frozen v5 backend-implementation proposed source. The v5 tree was not edited. No live code, API, database, grants, credentials, deployment or ChatGPT conversation was changed.

## Actual mounts

- `app.mjs` renders manager-only receipt controls in Public message history, mounts the inspector, and resets pending work on render/logout.
- `dm-ui.mjs` renders the same inspector in Private message history, including the manager audit view, and reconciles mounts after asynchronous thread updates.
- `receipt-config.mjs` defaults `RECEIPT_ENDPOINT` to the empty string. No endpoint is guessed. Unconfigured managers see “Delivery receipts unavailable.” Workers and demo users receive no control.
- Only an explicitly configured endpoint on the exact `api.base` origin is accepted. Cross-origin/Lightsail endpoints, embedded credentials, query strings, fragments and redirects are rejected. The existing session token is read transiently into the authorized request; no new credential or receipt storage is added.
- The inspector sends only `POST {messageId}`. It never sends a message/ping, marks read, or acknowledges an event. Receipt-control clicks are stopped before the existing inbox mark-visible-read click hook.
- Queued, ping sent, service accepted, message fetched and agent acknowledged are independent stages. Null/missing stage timestamps show “Not reported”; no accepted-to-read inference is made. The inspector shows a bounded recorded-attempt count and does not invent attempt details.
- Collapse, logout/reset, account/token change, navigation, replaced DOM nodes, newer requests and a 15-second request timeout prevent stale responses from appearing. Untrusted server error bodies are never echoed.

## Verification

- Passed: 13 focused jsdom checks for same-origin/disabled configuration, manager-only access, authenticated read-only request shape, independent stage rendering, absence of storage/log leakage, no-record/invalid/oversized responses, stale-response suppression, collapse/newer requests and timeout.
- Passed: 4 actual-app mount checks running the real `app.mjs`, `dm-ui.mjs`, `receipt-ui.mjs`, engine and RelayAPI in jsdom against real isolated PostgreSQL/handler fixtures plus an authenticated manager-only receipt-response fixture. Public and Private controls mount and fetch; workers/default/cross-origin configurations remain inactive; receipt reads leave DM read state unchanged; navigation/logout discard late responses.
- Passed: all 44 existing focused Node tests and JavaScript syntax checks.
- The actual-app fixture stubs unrelated hardware/update/sidebar modules and uses a synthetic minimal page shell. It does not claim a real browser, visual layout, accessibility audit, production receipt transport or deployment test.
- Production configuration remains blocked until an authorized same-origin Relay API proxy/endpoint is deployed. The Supabase-hosted browser API must not send its bearer token directly to a different Lightsail event-host origin.

## Reproduce

Install test-only pinned dependencies outside the repository:

```sh
npm install --prefix /tmp/relay-receipt-ui-test --ignore-scripts --no-audit --no-fund jsdom@26.1.0
npm install --prefix /tmp/relay-message-privacy-pg --ignore-scripts --no-audit --no-fund @electric-sql/pglite@0.5.8
```

From `proposed/`:

```sh
node --test tests/*.test.mjs
RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom node --test tests/receipt-ui-dom.mjs
RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom node --experimental-vm-modules --test tests/receipt-app-dom.mjs
```

The reusable actual-app harness is `tests/helpers/receipt-app-fixture.mjs`. Its backend is injected for an authorized in-process integration test; production contains no fixture response or dummy receipt data.

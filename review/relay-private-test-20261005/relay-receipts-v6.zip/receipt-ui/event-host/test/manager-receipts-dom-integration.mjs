import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {randomUUID} from 'node:crypto';
import {createManagerReceiptReader,createManagerReceiptRoute} from '../manager-receipts.mjs';
import {mountReceiptApp,apiURL,until} from '../../frontend/proposed/tests/helpers/receipt-app-fixture.mjs';

// Packaged layout: <root>/receipt-ui/event-host/test. The source tree may be
// selected explicitly for local verification; no production origin is assumed.
const packageRoot=process.env.RELAY_PACKAGE_ROOT?pathToFileURL(resolve(process.env.RELAY_PACKAGE_ROOT)+'/'):new URL('../../../',import.meta.url);
const {RelayEvents}=await import(new URL('relay-events/core.mjs',packageRoot));
const {SqliteStore}=await import(new URL('relay-events/store.mjs',packageRoot));
const {createMessageAccess}=await import(new URL('relay-events/message-access.mjs',packageRoot));
const {createMessageFixture}=await import(new URL('backend-implementation/proposed/tests/helpers/message-fixture.mjs',packageRoot));

test('actual manager DOM → authenticated route → real event ledger renders independent receipts without read/ping side effects',{timeout:60000},async t=>{
  const f=await createMessageFixture(),directory=mkdtempSync(join(tmpdir(),'relay-receipt-dom-ledger-'));
  let app,store;
  t.after(async()=>{app?.close();store?.close();await f.close();rmSync(directory,{recursive:true,force:true});});
  const {a,b,manager,capabilities}=f,workspaceId=capabilities.workspaceId;
  const command={clientId:randomUUID(),workspaceId,roomId:capabilities.roomId,visibility:'private',senderId:a.id,
    recipientIds:[b.id],participantIds:[a.id,b.id].sort(),notificationRecipientIds:[b.id],body:'Private SQL fixture for real event receipts',replyToMessageId:null};
  const sent=await f.rpc('messages.send',a.token,{command});assert.equal(sent.status,'persisted');const message=sent.message;
  let now=Date.now()+1000;const pings=[];
  store=new SqliteStore(join(directory,'events.db'));
  const currentManager=async context=>{
    if(context?.identity?.id!==manager.id||context.identity.role!=='manager'||context.identity.workspaceId!==workspaceId)return null;
    const current=await f.rpc('context',manager.token);
    return current.user.id===manager.id&&current.user.role==='manager'?{id:manager.id,role:'manager',workspaceId}:null;
  };
  const engine=new RelayEvents({store,now:()=>now,authorize:async({principal,agent_id})=>{
    if(principal!==b.id||agent_id!==b.agentId)return false;
    const current=await f.rpc('context',b.token);return current.user.id===b.id&&current.actor.session===b.runId;
  },transport:async request=>{
    const body=JSON.parse(request.body);if(body.type==='verification')return {status:200,body:{challenge:body.challenge}};
    now+=20;request.onSent?.();now+=20;pings.push(body);return {status:200,body:{}};
  }});
  const access=createMessageAccess({enabled:true,engine,
    sourcePolicy:async()=>f.rpc('messages.capabilities',b.token),
    authorizeRead:async({principal,agent_id})=>principal===b.id&&agent_id===b.agentId,
    readMessage:async({message:link})=>(await f.rpc('messages.get',b.token,{messageId:link.id})).message,
    authorizeAudit:async({viewer,recipientPrincipal,recipientAgent,message:link,context})=>{
      const managerNow=await currentManager(context);if(!managerNow||viewer!==managerNow.id||recipientPrincipal!==b.id||recipientAgent!==b.agentId)return false;
      const metadata=await f.rpc('messages.metadata',manager.token,{messageIds:[link.id]});
      return metadata.messages.some(row=>row.id===link.id&&row.workspaceId===workspaceId&&row.visibility==='private');
    }
  });
  const readMetadata=async({messageId,viewer})=>{
    assert.equal(viewer.id,manager.id);
    const message=(await f.rpc('messages.get',manager.token,{messageId})).message;
    const {id,workspaceId,visibility,recipientIds,notificationRecipientIds}=message;
    return {id,workspaceId,visibility,recipientIds,notificationRecipientIds};
  };
  const reader=createManagerReceiptReader({enabled:true,engine,messageAccess:access,authorizeManager:currentManager,readMetadata,workspaceId});
  const route=createManagerReceiptRoute({enabled:true,path:'/manager-receipts',allowedOrigins:['https://relay.fixture.invalid'],
    authenticateManager:async request=>{
      const token=request.headers.get('Authorization')?.replace(/^Bearer /,''),current=await f.rawRPC('context',token);
      if(current.error)return null;return {id:current.user.id,role:current.user.role,workspaceId};
    },readReceipt:reader});
  await engine.subscribe(b.id,{name:'relay.work.available',arguments:{agent_id:b.agentId},delivery:{mode:'webhook',url:'https://callback.fixture.invalid/recipient',secret:'whsec_'+Buffer.alloc(32,9).toString('base64')}});
  const work=await engine.enqueue(b.id,{agent_id:b.agentId,source_id:'dm:'+message.id,message:{id:message.id,senderId:a.id,recipientId:b.id,
    visibility:'private',createdAt:message.createdAt,roomId:message.roomId}});
  assert.equal((await engine.tick()).sent,1);assert.equal(pings.length,1);assert.deepEqual(pings[0].data.recipient_ids,[b.id]);
  const beforeLedger=store.read(),beforeUnread=(await f.rpc('dm.notifications',b.token)).unreadDirectMessages;
  let routeCalls=0;
  app=await mountReceiptApp({token:manager.token,hash:'inbox',endpoint:'/manager-receipts',backend:async(url,options)=>{
    if(url===apiURL)return f.handler(new Request(url,options));
    assert.equal(url,'https://relay.fixture.invalid/manager-receipts');routeCalls++;
    // Simulate the permitted fixture browser Origin; it is not production config.
    const headers=new Headers(options.headers);headers.set('Origin','https://relay.fixture.invalid');
    return route(new Request(url,{...options,headers}));
  }});
  await until(()=>app.document.querySelector('[data-dm-thread]'));app.document.querySelector('[data-dm-thread]').click();
  await until(()=>app.document.querySelector(`[data-receipt-message="${message.id}"]`));
  const control=app.document.querySelector(`[data-receipt-message="${message.id}"]`);control.querySelector('[data-receipt-toggle]').click();
  await until(()=>control.querySelector('[data-receipt-stage="queuedAt"] time'));
  const stage=key=>control.querySelector(`[data-receipt-stage="${key}"]`)?.textContent;
  assert.equal(stage('queuedAt'),new Date(beforeLedger.work[work.id].createdAt).toISOString());
  const delivery=Object.values(beforeLedger.deliveries)[0];assert.equal(stage('pingSentAt'),new Date(delivery.sentAt).toISOString());assert.equal(stage('serviceAcceptedAt'),new Date(delivery.serviceAcceptedAt).toISOString());
  assert.equal(stage('messageFetchedAt'),'Not reported');assert.equal(stage('agentAcknowledgedAt'),'Not reported');
  assert.match(control.textContent,/1 recorded attempt/);assert.deepEqual(store.read(),beforeLedger);
  now+=50;const args={agent_id:b.agentId,work_id:work.id,message_id:message.id};
  const fetched=await access.fetch(b.id,args,{});assert.equal(fetched.message.body,command.body);
  control.querySelector('[data-receipt-refresh]').click();await until(()=>stage('messageFetchedAt')===new Date(fetched.fetchedAt).toISOString());
  assert.equal(stage('agentAcknowledgedAt'),'Not reported');
  now+=50;const acknowledged=await access.acknowledge(b.id,{...args,fetch_receipt:fetched.fetch_receipt},{});
  control.querySelector('[data-receipt-refresh]').click();await until(()=>stage('agentAcknowledgedAt')===new Date(acknowledged.agentAcknowledgedAt).toISOString());
  assert.equal(routeCalls,3);assert.equal(pings.length,1);
  assert.ok(Object.values(store.read().work).every(row=>row.owner===b.id));
  assert.equal((await f.rpc('messages.notifications',manager.token)).notifications.length,0);
  assert.equal((await f.rpc('dm.notifications',manager.token)).unreadDirectMessages,0);
  assert.equal((await f.rpc('dm.notifications',b.token)).unreadDirectMessages,beforeUnread);
  assert.equal((await f.rpc('dm.thread',b.token,{participantA:a.id,participantB:b.id})).messages.find(row=>row.id===message.id).readAt,null);
  assert.ok(!JSON.stringify(store.read()).includes(command.body));assert.ok(!JSON.stringify(pings).includes(command.body));
  assert.ok(!control.textContent.includes(command.body));assert.equal(app.logs.length,0);
});

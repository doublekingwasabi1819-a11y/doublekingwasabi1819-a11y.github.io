import {createManagerReceiptRoute} from './manager-receipts.mjs';
/** Deployable handler factory, deliberately inactive without host integration.
 * authenticateRelayManager: authenticate the existing Relay bearer session using
 * the current server-side context operation; return {id,role,workspaceId} only
 * after live validation. Never trust role/workspace claims from request JSON.
 * readThroughAuthorizedService: separately authenticated server-only transport
 * to the event host. It must bind verified manager/workspace/message ID, enforce
 * freshness and deny replay; it must NOT receive/forward the browser bearer.
 * No service credential, grant, URL, or trust relationship is created here.
 */
export function createSameOriginReceiptProxy({enabled=false,allowedOrigins=[],authenticateRelayManager,readThroughAuthorizedService}={}){
 return createManagerReceiptRoute({enabled,path:'/functions/v1/relay-receipts',allowedOrigins,authenticateManager:authenticateRelayManager,
  readReceipt:typeof readThroughAuthorizedService==='function'?({messageId},{identity,signal})=>readThroughAuthorizedService({messageId,managerId:identity.id,workspaceId:identity.workspaceId},{signal}):undefined});
}

// Local opt-in integration. Authentication and source authorization are mandatory
// host hooks, never inferred from client-supplied manager/work/recipient IDs.
const UUID=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const fail=()=>{throw new Error('Receipt access unavailable');};
const iso=value=>value==null?null:Number.isSafeInteger(value)&&value>=0?new Date(value).toISOString():fail();
const audience=source=>{const ids=source?.notificationRecipientIds;if(!Array.isArray(ids)||ids.length>100||ids.some(id=>typeof id!=="string"||!UUID.test(id))||new Set(ids).size!==ids.length)fail();if(source.visibility==="private"&&(ids.length!==1||source.recipientIds?.length!==1||source.recipientIds[0]!==ids[0]))fail();return [...ids].sort();};
const first=values=>values.filter(v=>v!=null).sort((a,b)=>a-b)[0]??null;
export function createManagerReceiptReader({enabled=false,engine,messageAccess,authorizeManager,readMetadata,workspaceId}={}){
 if(enabled===false)return undefined;
 if(enabled!==true)throw new TypeError("Explicit boolean enable required");
 if(!engine?.exclusive||!engine?.store||!messageAccess?.receipts||typeof authorizeManager!=='function'||typeof readMetadata!=='function'||!UUID.test(workspaceId))throw new TypeError('Explicit workspace and manager/source authorization hooks required');
 return async({messageId},context)=>{
  const active=()=>{if(context?.signal?.aborted)fail();};active();
  if(typeof messageId!=='string'||!UUID.test(messageId))fail();messageId=messageId.toLowerCase();
  const viewer=await authorizeManager(context);active();
  if(!viewer||viewer.role!=='manager'||!UUID.test(viewer.id)||viewer.workspaceId!==workspaceId)fail();
  const source=await readMetadata({messageId,viewer,context});active();
  if(source?.id!==messageId||source.workspaceId!==workspaceId||!['public','private'].includes(source.visibility))fail();
  const targets=audience(source);
  const work=await engine.exclusive(()=>Object.values(engine.store.read().work).filter(w=>w.message?.id===messageId).map(w=>({id:w.id,owner:w.owner,agent:w.agent,visibility:w.message.visibility})));
  if(work.length>100)fail();
  const recipients=[],seen=new Set();
  for(const w of work){
   active();
   if(!targets.includes(w.owner)||w.visibility!==source.visibility||seen.has(w.owner)||!UUID.test(w.owner)||!UUID.test(w.agent))fail();seen.add(w.owner);
   // Existing hook independently rechecks manager access for EACH recipient.
   const row=await messageAccess.receipts(viewer.id,{work_id:w.id,message_id:messageId},context);
   if(row.visibility!==source.visibility||row.message_id!==messageId)fail();
   const attempts=row.deliveries.flatMap(d=>(d.attemptLog??[]).map(a=>({eventId:d.eventId,attempt:a.attempt,attemptedAt:iso(a.attemptedAt),sentAt:iso(a.sentAt),completedAt:iso(a.completedAt),serviceAcceptedAt:iso(a.serviceAcceptedAt),outcome:['accepted','rejected','unknown'].includes(a.outcome)?a.outcome:'unknown'})));
   if(attempts.length>100)fail();
   recipients.push({recipientId:w.owner,agentId:w.agent,queuedAt:iso(row.queuedAt),pingSentAt:iso(first(row.deliveries.map(d=>d.sentAt))),serviceAcceptedAt:iso(first(row.deliveries.map(d=>d.serviceAcceptedAt))),messageFetchedAt:iso(row.messageFetchedAt),agentAcknowledgedAt:iso(row.agentAcknowledgedAt),attempts});
  }
  active();const fresh=await authorizeManager(context);active();
  if(fresh?.id!==viewer.id||fresh.role!=='manager'||fresh.workspaceId!==workspaceId)fail();
  // Source visibility is rechecked even when there is no event record.
  const finalSource=await readMetadata({messageId,viewer:fresh,context});active();
  if(finalSource?.id!==messageId||finalSource.workspaceId!==workspaceId||finalSource.visibility!==source.visibility||JSON.stringify(audience(finalSource))!==JSON.stringify(targets))fail();
  return {messageId,visibility:source.visibility,receiptState:recipients.length?'available':'no_event_record',recipients};
 };
}

// Fetch-compatible route usable by a Node host adapter or same-origin Edge proxy.
// A proxy's readReceipt hook MUST use an independently authorized server channel;
// it must never forward the browser credential to another origin.
export function createManagerReceiptRoute({enabled=false,path='/manager-receipts',allowedOrigins=[],authenticateManager,readReceipt,timeoutMs=10000}={}){
 if(enabled===false)return async()=>new Response('Unavailable',{status:404});
 if(enabled!==true)throw new TypeError('Explicit boolean enable required');
 if(typeof authenticateManager!=='function'||typeof readReceipt!=='function'||!path.startsWith('/')||!Number.isSafeInteger(timeoutMs)||timeoutMs<1||timeoutMs>30000||!allowedOrigins.length)throw new TypeError('Explicit route, origins, authentication and receipt reader required');
 const origins=new Set(allowedOrigins.map(v=>{const u=new URL(v);if(u.origin!==v||u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)))throw new TypeError('Exact secure origin required');return v;}));
 return async request=>{
  const headers={'Cache-Control':'no-store','Content-Type':'application/json','Vary':'Origin'};
  const reply=(status,body)=>new Response(JSON.stringify(body),{status,headers});
  if(new URL(request.url).pathname!==path)return reply(404,{error:'Unavailable'});
  const origin=request.headers.get('Origin');if(!origins.has(origin))return reply(403,{error:'Forbidden'});
  headers['Access-Control-Allow-Origin']=origin;
  if(request.method==='OPTIONS'){headers['Access-Control-Allow-Methods']='POST';headers['Access-Control-Allow-Headers']='Authorization, Content-Type';return new Response(null,{status:204,headers});}
  if(request.method!=='POST')return reply(405,{error:'Method not allowed'});
  if(!/^application\/json(?:\s*;|$)/i.test(request.headers.get('Content-Type')??''))return reply(415,{error:'JSON required'});
  let timer,bodyReader;const controller=new AbortController();
  const active=()=>{if(controller.signal.aborted)throw Error("Aborted");};
  controller.signal.addEventListener("abort",()=>{bodyReader?.cancel().catch(()=>{});},{once:true});
  try{return await Promise.race([(async()=>{
   const identity=await authenticateManager(request,{signal:controller.signal});
   active();
   if(!identity)return reply(401,{error:'Unauthorized'});
   if(identity.role!=='manager')return reply(403,{error:'Forbidden'});
   const reader=request.body?.getReader();bodyReader=reader;if(!reader)return reply(400,{error:'Invalid request'});
   let size=0,parts=[];try{while(true){const {value,done}=await reader.read();active();if(done)break;size+=value.byteLength;if(size>1024){await reader.cancel();return reply(413,{error:'Too large'});}parts.push(value);}}finally{bodyReader=undefined;reader.releaseLock();}
   const bytes=new Uint8Array(size);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}
   let body;try{body=JSON.parse(new TextDecoder().decode(bytes));}catch{return reply(400,{error:'Invalid request'});}
   if(!body||Object.keys(body).length!==1||typeof body.messageId!=='string'||!UUID.test(body.messageId))return reply(400,{error:'Invalid request'});
   active();
   const result=await readReceipt({messageId:body.messageId.toLowerCase()},{identity,signal:controller.signal});
   active();
   const fresh=await authenticateManager(request,{signal:controller.signal});
   active();
   if(!fresh||fresh.role!=='manager'||fresh.id!==identity.id||fresh.workspaceId!==identity.workspaceId)return reply(403,{error:'Forbidden'});
   const encoded=JSON.stringify(result);if(new TextEncoder().encode(encoded).length>262144)throw Error('Too large');
   return new Response(encoded,{status:200,headers});
  })(),new Promise(resolve=>{timer=setTimeout(()=>{controller.abort();resolve(reply(504,{error:'Unavailable'}));},timeoutMs);})]);}
  catch{return reply(403,{error:'Receipt access unavailable'});}finally{clearTimeout(timer);controller.abort();}
 };
}

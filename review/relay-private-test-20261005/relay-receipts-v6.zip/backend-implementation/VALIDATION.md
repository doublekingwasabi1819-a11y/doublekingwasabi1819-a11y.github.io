# Frozen local backend validation

Pinned source main: 56c47abe01d807a52cde82ebc46d7038ae36cdcb.

- 44 focused Node tests passed.
- 15 actual disposable PostgreSQL contract checks passed against the real Edge handler and SQL.
- Combined source adapter round trip: 13 checks passed.
- Full MCP → SQL/history/outbox → event/fetch/explicit ACK → reply test passed.
- Backend patch dry-run applies to the recorded base.
- Legacy uppercase UUID normalization is included; six-field dm.* response compatibility is preserved.

Independent source review covered ACLs, transaction locking, durable dedup, atomic reply audience checks, recipient-only outbox, reinstall behavior, tombstones, and legacy response shape. The reported uppercase compatibility issue was fixed and regression-tested. Review also identified the remaining legacy public-web-composer outbox gap, which is explicitly excluded rather than hidden.

No live schema, grant, message, push or deployment was changed. PostgreSQL tests use one isolated PGlite session; independent-session race/load testing and deployed Supabase security verification remain outstanding. Real browser UI checks and the new manager receipt-ledger UI mount are not complete.

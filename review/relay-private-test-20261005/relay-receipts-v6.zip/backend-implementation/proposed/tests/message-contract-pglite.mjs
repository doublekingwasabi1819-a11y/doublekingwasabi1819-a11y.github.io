import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {createMessageFixture} from './helpers/message-fixture.mjs';

const f=await createMessageFixture();
const {a,b,c,manager,capabilities:scope,rpc,rawRPC,sql,db,request}=f;
const command=(sender=a,visibility='private',peer=b,changes={})=>({clientId:randomUUID(),workspaceId:scope.workspaceId,roomId:scope.roomId,
  visibility,senderId:sender.id,recipientIds:visibility==='private'?[peer.id]:[],participantIds:visibility==='private'?[sender.id,peer.id].sort():[],
  notificationRecipientIds:visibility==='private'?[peer.id]:[],body:'  Exact body <literal>  ',replyToMessageId:null,...changes});
const send=(d,user=a)=>rpc('messages.send',user.token,{command:d});
const persisted=r=>{assert.equal(r.status,'persisted',JSON.stringify(r));assert.equal(r.historyStore,'relay-chat');return r.message;};
const rejected=(r,code)=>{assert.deepEqual(r,{status:'rejected',commit:'not_applied',code});};
let checks=0;
const check=async(name,fn)=>{await fn();checks++;console.log('PASS '+name);};
try{
  let privateMessage,publicMessage,privateCommand,publicCommand,reply;
  await check('generated identities and capability receipt are stable, authenticated and real',async()=>{
    assert.match(scope.workspaceId,/^[a-f0-9-]{36}$/);assert.match(scope.roomId,/^[a-f0-9-]{36}$/);
    assert.notEqual(scope.workspaceId,scope.roomId);
    assert.equal(scope.contractVersion,'relay-message-source/1');assert.equal(scope.sourceRevision,'relay-message-contract-v1');
    assert.deepEqual(await rpc('messages.capabilities',b.token),scope);
    assert.equal((await rawRPC('messages.capabilities')).error.code,'SESSION');
  });
  await check('canonical private send appears in existing inbox/thread with legacy six-key shape',async()=>{
    privateCommand=command();privateMessage=persisted(await send(privateCommand));
    for(const [key,value] of Object.entries(privateCommand))assert.deepEqual(privateMessage[key],value);
    for(const user of [a,b,manager])assert.equal((await rpc('messages.get',user.token,{messageId:privateMessage.id})).message.id,privateMessage.id);
    assert.equal((await rpc('messages.get',c.token,{messageId:privateMessage.id})).status,'not_found');
    const thread=await rpc('dm.thread',manager.token,{participantA:a.id,participantB:b.id});
    assert.deepEqual(Object.keys(thread.messages[0]).sort(),['body','createdAt','id','readAt','recipientId','senderId'].sort());
    assert.equal(thread.messages[0].body,privateCommand.body);
    assert.equal((await rawRPC('dm.thread',c.token,{participantA:a.id,participantB:b.id})).error.code,'FORBIDDEN');
  });
  await check('outbox is metadata-only, recipient-only, idempotent, with separate handoff ACK',async()=>{
    const incoming=await rpc('messages.notifications',b.token,{limit:1});assert.equal(incoming.notifications.length,1);
    const n=incoming.notifications[0];assert.deepEqual(Object.keys(n).sort(),['createdAt','id','messageId','recipientId']);
    assert.equal(n.messageId,privateMessage.id);assert.equal(n.recipientId,b.id);
    for(const user of [a,c,manager])assert.equal((await rpc('messages.notifications',user.token)).notifications.length,0);
    assert.equal((await rawRPC('messages.notifications.ack',manager.token,{notificationId:n.id})).error.code,'NOT_FOUND');
    const ack=await rpc('messages.notifications.ack',b.token,{notificationId:n.id});assert.ok(ack.handoffAcknowledgedAt);
    assert.deepEqual(await rpc('messages.notifications.ack',b.token,{notificationId:n.id}),ack);
    assert.equal((await rpc('messages.notifications',b.token)).notifications.length,0);
    assert.equal((await rpc('dm.notifications',b.token)).unreadDirectMessages,1);
    assert.equal((await rpc('dm.thread',b.token,{participantA:a.id,participantB:b.id})).messages[0].readAt,null);
  });
  await check('public send appears in existing shared UI history and every workspace member can read',async()=>{
    publicCommand=command(a,'public',null,{body:'Workspace-public',notificationRecipientIds:[c.id]});
    publicMessage=persisted(await send(publicCommand));
    for(const user of [a,b,c,manager]){
      assert.equal((await rpc('messages.get',user.token,{messageId:publicMessage.id})).message.id,publicMessage.id);
      const state=(await rpc('context',user.token)).state;
      const row=state.messages.find(m=>m.id===publicMessage.id);assert.ok(row);assert.equal(row.from,a.agentId);assert.equal(row.visibility,'public');
      assert.ok(!JSON.stringify(state).includes(privateMessage.body));
    }
    assert.equal((await rpc('messages.notifications',c.token)).notifications[0].messageId,publicMessage.id);
    assert.equal((await rpc('messages.notifications',manager.token)).notifications.length,0);
    assert.equal((await rpc('messages.notifications',b.token)).notifications.length,0);
  });
  await check('durable retry survives rolling-operation eviction and does not duplicate history/outbox',async()=>{
    await sql("update relay_private.studio set state=jsonb_set(state,'{operations}',(select jsonb_agg('unrelated-'||i) from generate_series(1,2500) i))");
    const retry=persisted(await send(publicCommand));assert.equal(retry.id,publicMessage.id);
    assert.equal(Number((await sql('select count(*) as n from relay_private.message_records where sender_id=$1 and client_id=$2',[a.id,publicCommand.clientId])).rows[0].n),1);
    assert.equal(Number((await sql('select count(*) as n from relay_private.message_outbox where message_id=$1',[publicMessage.id])).rows[0].n),1);
    assert.equal((await rpc('context',a.token)).state.messages.filter(m=>m.id===publicMessage.id).length,1);
    // PGlite has one session; these parallel callers test serial retry integration,
    // not an independent PostgreSQL-session race.
    const retries=await Promise.all(Array.from({length:4},()=>send(privateCommand)));
    assert.ok(retries.every(r=>r.message.id===privateMessage.id));
  });
  await check('changed content/audience/notification/reply fingerprint conflicts without mutation',async()=>{
    for(const changes of [{body:'Changed'},{notificationRecipientIds:[]},{replyToMessageId:publicMessage.id}])rejected(await send({...publicCommand,...changes}),'CONFLICT');
    rejected(await send({...privateCommand,recipientIds:[c.id],participantIds:[a.id,c.id].sort(),notificationRecipientIds:[c.id]}),'CONFLICT');
    rejected(await send({...privateCommand,visibility:'public',recipientIds:[],participantIds:[],notificationRecipientIds:[]}),'CONFLICT');
  });
  await check('same-audience replies are persisted and visible as reply metadata in actual history',async()=>{
    reply=persisted(await send(command(b,'private',a,{replyToMessageId:privateMessage.id,body:'Reply in the same private pair'}),b));
    assert.equal(reply.replyToMessageId,privateMessage.id);
    const metadata=await rpc('messages.metadata',a.token,{messageIds:[reply.id]});assert.equal(metadata.messages[0].replyToMessageId,privateMessage.id);
    assert.equal((await rpc('messages.metadata',c.token,{messageIds:[reply.id]})).messages.length,0);
    const publicReply=persisted(await send(command(b,'public',null,{replyToMessageId:publicMessage.id,body:'Public reply'}),b));
    assert.equal((await rpc('context',c.token)).state.messages.find(m=>m.id===publicReply.id).replyToMessageId,publicMessage.id);
  });
  await check('cross-visibility, cross-pair, missing-target and audit-only manager replies reject',async()=>{
    rejected(await send(command(a,'public',null,{replyToMessageId:privateMessage.id})),'REPLY_MISMATCH');
    rejected(await send(command(a,'private',c,{replyToMessageId:privateMessage.id})),'REPLY_MISMATCH');
    rejected(await send(command(a,'private',b,{replyToMessageId:publicMessage.id})),'REPLY_MISMATCH');
    rejected(await send(command(a,'private',b,{replyToMessageId:randomUUID()})),'REPLY_MISMATCH');
    rejected(await send(command(manager,'private',a,{replyToMessageId:privateMessage.id}),manager),'REPLY_MISMATCH');
    rejected(await send(command(a,'private',b,{roomId:randomUUID(),replyToMessageId:privateMessage.id})),'FORBIDDEN');
  });
  await check('forged sender/workspace, widened private notifications and malformed commands reject',async()=>{
    rejected(await send(command(a,'private',b,{senderId:c.id})),'FORBIDDEN');
    rejected(await send(command(a,'public',null,{workspaceId:randomUUID()})),'FORBIDDEN');
    rejected(await send(command(a,'private',b,{notificationRecipientIds:[b.id,manager.id]})),'VALIDATION');
    rejected(await send(command(a,'public',null,{notificationRecipientIds:[b.id,b.id]})),'VALIDATION');
    rejected(await send(command(a,'public',null,{extra:'invalid'})),'VALIDATION');
    for(const body of ['  ','\t\n','\u00a0\u2003\ufeff'])rejected(await send(command(a,'private',b,{body})),'VALIDATION');
    rejected(await send(command(a,'private',b,{body:'x'.repeat(12001)})),'VALIDATION');
    rejected(await send(command(a,'public',null,{notificationRecipientIds:[randomUUID()]})),'NOT_FOUND');
  });
  await check('legacy dm.send shares canonical durable dedup and outbox without response expansion',async()=>{
    const clientId=randomUUID();const legacy=await rpc('dm.send',a.token,{recipientId:b.id,clientId,body:' Legacy body '});
    assert.equal(legacy.message.body,'Legacy body');assert.equal(Object.keys(legacy.message).length,6);
    const record=(await rpc('messages.get',a.token,{messageId:legacy.message.id})).message;
    assert.equal(record.clientId,clientId);assert.equal(record.body,'Legacy body');
    assert.equal((await rpc('dm.send',a.token,{recipientId:b.id.toUpperCase(),clientId:clientId.toUpperCase(),body:'Legacy body'})).message.id,legacy.message.id);
    assert.equal((await rawRPC('dm.send',a.token,{recipientId:b.id,clientId,body:'Changed'})).error.code,'CONFLICT');
  });
  await check('manager audit fetch/read is silent, intended manager recipient is notified',async()=>{
    await rpc('messages.get',manager.token,{messageId:reply.id});
    await rpc('dm.read',manager.token,{messageIds:[privateMessage.id,reply.id]});
    assert.equal((await rpc('messages.notifications',manager.token)).notifications.length,0);
    const addressed=persisted(await send(command(a,'private',manager,{body:'Specifically addressed to manager'})));
    assert.equal((await rpc('messages.notifications',manager.token)).notifications[0].messageId,addressed.id);
  });
  await check('all standalone install paths preserve IDs, dedup, outbox and legacy shape on reinstall',async()=>{
    for(const file of ['private-messages.sql','message-contract.sql','schema.sql']){
      await db.exec(readFileSync(new URL('../backend/'+file,import.meta.url),'utf8'));
      assert.deepEqual(await rpc('messages.capabilities',a.token),scope);
      assert.equal(persisted(await send(publicCommand)).id,publicMessage.id);
      assert.equal(Object.keys((await rpc('dm.thread',a.token,{participantA:a.id,participantB:b.id})).messages[0]).length,6);
    }
  });
  await check('deleted private content is scrubbed and durable tombstone prevents resurrection',async()=>{
    const d=command(a,'private',b,{body:'To be erased'}),m=persisted(await send(d));
    await sql('delete from relay_private.direct_messages where id=$1',[m.id]);
    const record=(await sql('select request,deleted_at from relay_private.message_records where id=$1',[m.id])).rows[0];assert.equal(record.request,null);assert.ok(record.deleted_at);
    assert.equal((await rpc('messages.get',a.token,{messageId:m.id})).status,'not_found');
    rejected(await send(d),'NOT_FOUND');
    assert.equal(Number((await sql('select count(*) as n from relay_private.message_outbox where message_id=$1',[m.id])).rows[0].n),0);
  });
  await check('public DB roles cannot read canonical history/outbox or call privileged RPC',async()=>{
    for(const role of ['anon','authenticated'])for(const query of ["select * from relay_private.message_records","select * from relay_private.message_outbox","select public.relay_message_rpc('messages.capabilities')"]){
      await db.exec('set role '+role);try{await assert.rejects(db.exec(query),/permission denied/);}finally{await db.exec('reset role');}
    }
  });
  await check('HTTP route uses real session checks and disabled recipient/member sends fail',async()=>{
    const http=await request('messages.get',b.token,{messageId:privateMessage.id});assert.equal(http.status,200);assert.equal(http.body.message.id,privateMessage.id);
    assert.equal((await request('messages.capabilities','')).status,401);
    await rpc('workers.update',manager.token,{workerId:c.id,enabled:false});
    rejected(await send(command(a,'public',null,{notificationRecipientIds:[c.id]})),'NOT_FOUND');
    assert.equal((await rawRPC('messages.history',c.token)).error.code,'SESSION');
    assert.equal((await rawRPC('messages.send',c.token,{command:command(c)})).error.code,'SESSION');
  });
  console.log(`${checks} durable-message PostgreSQL checks passed; independent-session races and deployed Supabase remain unverified.`);
}finally{await f.close();}

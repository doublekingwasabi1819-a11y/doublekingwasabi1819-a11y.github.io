import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {createDemoInboxAPI} from '../dm-ui.mjs';

const read=path=>readFileSync(new URL(path,import.meta.url),'utf8');
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Template-unit coverage only; this is not a browser layout/accessibility test.
test('public history labels its actual audience and retains directed recipient',()=>{
  const source=read('../app.mjs');
  const code=source.match(/^function messageMarkup\(m\)\{.*\}$/m)?.[0];
  assert.ok(code);
  const render=vm.runInNewContext(`(${code})`,{h:escape,name:id=>({a:'Alpha <one>',b:'Beta & two'}[id]||id),avatar:()=>'',relative:()=> 'Now'});
  const directed=render({from:'a',to:'b',body:'Safe <body>',createdAt:'2026-10-05'});
  assert.match(directed,/From Alpha &lt;one&gt;/);
  assert.match(directed,/Public · To Beta &amp; two · Visible to all workspace members/);
  assert.match(directed,/Safe &lt;body&gt;/);
  assert.match(render({from:'a',body:'Broadcast'}),/Public · To all workspace members/);
});

test('private history shows sender and recipient without claiming manager exclusion',()=>{
  const source=read('../dm-ui.mjs');
  const code=source.match(/^  function messagesHTML\(\)\{.*\}$/m)?.[0];
  assert.ok(code);
  const render=vm.runInNewContext(`(${code})`,{hasMore:false,messages:[{id:'m',senderId:'a',recipientId:'b',body:'Hidden <content>',createdAt:'2026-10-05'}],esc:escape,label:id=>({a:'Alpha <one>',b:'Beta & two'}[id]),stamp:()=> 'Now',getUser:()=>({id:'owner'})});
  const html=render();
  assert.match(html,/From Alpha &lt;one&gt;/);
  assert.match(html,/Private · To Beta &amp; two/);
  assert.match(html,/Hidden &lt;content&gt;/);
  assert.match(source,/Private · Participants \+ manager/);
  assert.match(source,/Private · Manager audit view/);
  assert.match(source,/Only the intended recipient gets an unread alert/);
});

test('demo keeps manager audit access but only recipients receive unread counts',async()=>{
  const accounts=[{id:'a',name:'Alpha',enabled:true},{id:'b',name:'Beta',enabled:true},{id:'c',name:'Charlie',enabled:true}];
  let user={id:'owner',role:'manager'};
  const api=createDemoInboxAPI(()=>user,()=>accounts);
  const manager=await api.call('dm.inbox');
  assert.equal(manager.threads.length,1);
  assert.equal(manager.unreadCount,0);
  assert.equal(manager.threads[0].unreadCount,0);
  const pair={participantA:'a',participantB:'b'};
  const message=(await api.call('dm.thread',pair)).messages[0];
  await api.call('dm.read',{messageIds:[message.id]});
  assert.equal((await api.call('dm.thread',pair)).messages[0].readAt,null);
  user={id:'c',role:'worker'};
  assert.equal((await api.call('dm.inbox')).threads.length,0);
  assert.equal((await api.call('dm.thread',pair)).messages.length,0);
  user={id:'a',role:'worker'};
  assert.equal((await api.call('dm.inbox')).unreadCount,1);
  await api.call('dm.read',{messageIds:[message.id]});
  assert.equal((await api.call('dm.inbox')).unreadCount,0);
  user={id:'owner',role:'manager'};
  assert.ok((await api.call('dm.thread',pair)).messages[0].readAt);
  assert.equal((await api.call('dm.inbox')).unreadCount,0);
});

test('both install paths retain the same manager-audit and recipient-only logic',()=>{
  const fragment=source=>source.slice(source.indexOf('create or replace function relay_private.dm_json'),source.indexOf('create or replace function public.relay_'));
  const standalone=fragment(read('../backend/private-messages.sql'));
  assert.equal(fragment(read('../backend/schema.sql')),standalone);
  assert.match(standalone,/where u\.role = 'manager' or sender_id = u\.id or recipient_id = u\.id/);
  assert.match(standalone,/u\.role<>'manager' and u\.id not in \(a,b\)/);
  assert.match(standalone,/where recipient_id=u\.id and read_at is null/);
});

-- Local review candidate: durable Relay messaging contract v1.
-- Install only after explicit deployment approval. No remote database is used by tests.
begin;

alter table relay_private.studio add column if not exists workspace_id uuid not null default gen_random_uuid();
alter table relay_private.studio add column if not exists message_room_id uuid not null default gen_random_uuid();

create table if not exists relay_private.message_records (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  room_id uuid not null,
  sender_id uuid not null,
  client_id uuid not null,
  visibility text not null check (visibility in ('public','private')),
  participant_ids uuid[] not null,
  request jsonb,
  fingerprint text not null,
  created_at timestamptz not null default clock_timestamp(),
  deleted_at timestamptz,
  unique(workspace_id,sender_id,client_id),
  check ((deleted_at is null and request is not null) or deleted_at is not null)
);
create index if not exists relay_message_history on relay_private.message_records(workspace_id,created_at desc,id desc) where deleted_at is null;
create table if not exists relay_private.message_outbox (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references relay_private.message_records(id),
  recipient_id uuid not null references relay_private.accounts(id) on delete cascade,
  created_at timestamptz not null default clock_timestamp(),
  handoff_acknowledged_at timestamptz,
  unique(message_id,recipient_id)
);
alter table relay_private.message_records enable row level security;
alter table relay_private.message_outbox enable row level security;

create or replace function relay_private.message_json(m relay_private.message_records)
returns jsonb language sql stable security invoker set search_path=pg_catalog as $$
  select m.request || jsonb_build_object('id',m.id,'createdAt',m.created_at);
$$;
create or replace function relay_private.message_rejected(code text)
returns jsonb language sql immutable security invoker set search_path=pg_catalog as $$
  select jsonb_build_object('status','rejected','commit','not_applied','code',code);
$$;

-- Deletion scrubs content but preserves a dedup tombstone. Retried IDs can never
-- resurrect a deleted message. Private account deletion cascades through DMs.
create or replace function relay_private.message_delete_dm()
returns trigger language plpgsql security invoker set search_path=pg_catalog as $$
begin
  update relay_private.message_records set request=null,deleted_at=clock_timestamp()
    where id=old.id and visibility='private';
  delete from relay_private.message_outbox where message_id=old.id;
  return old;
end;
$$;
drop trigger if exists relay_message_dm_deleted on relay_private.direct_messages;
create trigger relay_message_dm_deleted after delete on relay_private.direct_messages
  for each row execute function relay_private.message_delete_dm();
create or replace function relay_private.message_delete_workspace()
returns trigger language plpgsql security invoker set search_path=pg_catalog as $$
begin
  if new.deleted and not old.deleted then
    update relay_private.message_records set request=null,deleted_at=clock_timestamp() where workspace_id=old.workspace_id;
    delete from relay_private.message_outbox;
  end if;
  return new;
end;
$$;
drop trigger if exists relay_message_workspace_deleted on relay_private.studio;
create trigger relay_message_workspace_deleted after update on relay_private.studio
  for each row execute function relay_private.message_delete_workspace();

-- Import existing DMs without re-notifying anyone. Original IDs, client IDs,
-- bodies, timestamps and read receipts remain unchanged.
insert into relay_private.message_records(id,workspace_id,room_id,sender_id,client_id,visibility,participant_ids,request,fingerprint,created_at)
select d.id,s.workspace_id,s.message_room_id,d.sender_id,d.client_id,'private',array[least(d.sender_id,d.recipient_id),greatest(d.sender_id,d.recipient_id)],
  c.command,encode(extensions.digest(c.command::text,'sha256'),'hex'),d.created_at
from relay_private.direct_messages d cross join relay_private.studio s
cross join lateral (select jsonb_build_object('clientId',d.client_id,'workspaceId',s.workspace_id,'roomId',s.message_room_id,
  'visibility','private','senderId',d.sender_id,'recipientIds',jsonb_build_array(d.recipient_id),
  'participantIds',jsonb_build_array(least(d.sender_id,d.recipient_id),greatest(d.sender_id,d.recipient_id)),
  'notificationRecipientIds',jsonb_build_array(d.recipient_id),'body',d.body,'replyToMessageId',null) as command) c
where not s.deleted on conflict do nothing;

create or replace function relay_private.message_action(u relay_private.accounts,action text,data jsonb)
returns jsonb language plpgsql security invoker set search_path=pg_catalog as $$
declare
  s relay_private.studio%rowtype; m relay_private.message_records%rowtype; original relay_private.message_records%rowtype;
  command jsonb; digest text; peer uuid; participants uuid[]; notifications uuid[]; client uuid; reply uuid;
  next_state jsonb; view_message jsonb; rows jsonb; item jsonb; n integer; notice relay_private.message_outbox%rowtype;
begin
  -- Every call already validated the live session/run and holds this same lock.
  select * into s from relay_private.studio where singleton for update;
  if action='messages.capabilities' then
    return jsonb_build_object('contractVersion','relay-message-source/1','sourceRevision','relay-message-contract-v1',
      'historyDurable',true,'explicitAudienceMetadata',true,'stableClientIdDedup',true,
      'notificationsExplicitRecipientsOnly',true,'publicWorkspaceOnly',true,
      'privateParticipantsAndManagerOnly',true,'atomicSameAudienceReplies',true,
      'workspaceId',s.workspace_id,'roomId',s.message_room_id);
  end if;
  if action='messages.get' then
    if jsonb_typeof(data->'messageId') is distinct from 'string' or coalesce(data->>'messageId','')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' then
      return relay_private.error('VALIDATION','Supply a message ID.',400);
    end if;
    select * into m from relay_private.message_records where id=(data->>'messageId')::uuid and workspace_id=s.workspace_id and deleted_at is null
      and (visibility='public' or u.role='manager' or u.id=any(participant_ids));
    if not found then return jsonb_build_object('status','not_found'); end if;
    return jsonb_build_object('message',relay_private.message_json(m));
  end if;
  if action='messages.metadata' then
    if jsonb_typeof(data->'messageIds') is distinct from 'array' then return relay_private.error('VALIDATION','Supply message IDs.',400); end if;
    if jsonb_array_length(data->'messageIds')>100 or exists(select 1 from jsonb_array_elements(data->'messageIds') x
      where jsonb_typeof(x)<>'string' or (x#>>'{}')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$') then
      return relay_private.error('VALIDATION','Supply at most 100 message IDs.',400);
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',d.id,'visibility',d.visibility,'workspaceId',d.workspace_id,'roomId',d.room_id,
      'replyToMessageId',d.request->'replyToMessageId')),'[]'::jsonb) into rows
      from relay_private.message_records d where d.workspace_id=s.workspace_id and d.deleted_at is null
        and d.id in(select (x#>>'{}')::uuid from jsonb_array_elements(data->'messageIds') x)
        and (d.visibility='public' or u.role='manager' or u.id=any(d.participant_ids));
    return jsonb_build_object('messages',rows);
  end if;
  if action='messages.history' then
    if data ? 'beforeId' then
      if jsonb_typeof(data->'beforeId') is distinct from 'string' or coalesce(data->>'beforeId','')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' then
        return relay_private.error('VALIDATION','Invalid message cursor.',400);
      end if;
      select * into original from relay_private.message_records where id=(data->>'beforeId')::uuid and workspace_id=s.workspace_id and deleted_at is null
        and (visibility='public' or u.role='manager' or u.id=any(participant_ids));
      if not found then return jsonb_build_object('status','not_found'); end if;
    end if;
    select coalesce(jsonb_agg(relay_private.message_json(d) order by d.created_at,d.id),'[]'::jsonb) into rows from (
      select * from relay_private.message_records where workspace_id=s.workspace_id and deleted_at is null
        and (visibility='public' or u.role='manager' or u.id=any(participant_ids))
        and (original.id is null or (created_at,id)<(original.created_at,original.id))
        order by created_at desc,id desc limit 100) d;
    return jsonb_build_object('messages',rows,'hasMore',jsonb_array_length(rows)=100,'workspaceId',s.workspace_id,'roomId',s.message_room_id);
  end if;
  if action='messages.notifications' then
    n:=100;
    if data ? 'limit' then
      if jsonb_typeof(data->'limit') is distinct from 'number' or coalesce(data->>'limit','')!~'^[0-9]{1,3}$' then
        return relay_private.error('VALIDATION','Use a notification limit from 1 to 100.',400);
      end if;
      n:=(data->>'limit')::integer;
      if n not between 1 and 100 then return relay_private.error('VALIDATION','Use a notification limit from 1 to 100.',400); end if;
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'messageId',o.message_id,'recipientId',o.recipient_id,'createdAt',o.created_at) order by o.created_at,o.id),'[]'::jsonb)
      into rows from (select o.* from relay_private.message_outbox o join relay_private.message_records d on d.id=o.message_id
        where o.recipient_id=u.id and o.handoff_acknowledged_at is null and d.deleted_at is null and d.workspace_id=s.workspace_id
        order by o.created_at,o.id limit n) o;
    return jsonb_build_object('notifications',rows,'hasMore',(select count(*)>n from relay_private.message_outbox o
      join relay_private.message_records d on d.id=o.message_id where o.recipient_id=u.id and o.handoff_acknowledged_at is null and d.deleted_at is null and d.workspace_id=s.workspace_id));
  end if;
  if action='messages.notifications.ack' then
    if jsonb_typeof(data->'notificationId') is distinct from 'string' or coalesce(data->>'notificationId','')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' then
      return relay_private.error('VALIDATION','Supply a notification ID.',400);
    end if;
    update relay_private.message_outbox set handoff_acknowledged_at=coalesce(handoff_acknowledged_at,clock_timestamp())
      where recipient_id=u.id and id=(data->>'notificationId')::uuid returning * into notice;
    if not found then return relay_private.error('NOT_FOUND','Notification unavailable.',404); end if;
    return jsonb_build_object('notificationId',notice.id,'handoffAcknowledgedAt',notice.handoff_acknowledged_at);
  end if;
  if action<>'messages.send' then return relay_private.error('UNKNOWN_ACTION','Unknown message action.',400); end if;

  command:=data->'command';
  if jsonb_typeof(command) is distinct from 'object' then return relay_private.message_rejected('VALIDATION'); end if;
  if (select count(*) from jsonb_object_keys(command))<>10 or exists(select 1 from jsonb_object_keys(command) k where k not in
    ('clientId','workspaceId','roomId','visibility','senderId','recipientIds','participantIds','notificationRecipientIds','body','replyToMessageId')) then
    return relay_private.message_rejected('VALIDATION');
  end if;
  if command->>'senderId' is distinct from u.id::text or command->>'workspaceId' is distinct from s.workspace_id::text
    or command->>'roomId' is distinct from s.message_room_id::text then return relay_private.message_rejected('FORBIDDEN'); end if;
  if jsonb_typeof(command->'clientId') is distinct from 'string' or coalesce(command->>'clientId','')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
    or command->>'visibility' not in ('public','private') or jsonb_typeof(command->'visibility') is distinct from 'string'
    or jsonb_typeof(command->'body') is distinct from 'string' or char_length(command->>'body') not between 1 and 12000
    or char_length(btrim(command->>'body',E' \t\n\r\v\f' || U&'\00A0\1680\2000\2001\2002\2003\2004\2005\2006\2007\2008\2009\200A\2028\2029\202F\205F\3000\FEFF'))=0 or octet_length(command->>'body')>48000
    or jsonb_typeof(command->'recipientIds') is distinct from 'array' or jsonb_typeof(command->'participantIds') is distinct from 'array'
    or jsonb_typeof(command->'notificationRecipientIds') is distinct from 'array' then return relay_private.message_rejected('VALIDATION'); end if;
  if jsonb_array_length(command->'notificationRecipientIds')>100 or exists(select 1 from jsonb_array_elements(command->'notificationRecipientIds') x
    where jsonb_typeof(x)<>'string' or (x#>>'{}')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$') then return relay_private.message_rejected('VALIDATION'); end if;
  select coalesce(array_agg((x#>>'{}')::uuid),'{}'::uuid[]) into notifications from jsonb_array_elements(command->'notificationRecipientIds') x;
  if cardinality(notifications)<>(select count(distinct id) from unnest(notifications) id) then return relay_private.message_rejected('VALIDATION'); end if;
  if command->>'visibility'='private' then
    if jsonb_array_length(command->'recipientIds')<>1 or jsonb_typeof(command->'recipientIds'->0) is distinct from 'string'
      or coalesce(command->'recipientIds'->>0,'')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' then return relay_private.message_rejected('VALIDATION'); end if;
    peer:=(command->'recipientIds'->>0)::uuid; participants:=array[least(u.id,peer),greatest(u.id,peer)];
    if peer=u.id or command->'participantIds'<>to_jsonb(participants) or command->'notificationRecipientIds'<>command->'recipientIds' then return relay_private.message_rejected('VALIDATION'); end if;
  else
    participants:='{}'::uuid[];
    if command->'recipientIds'<>'[]'::jsonb or command->'participantIds'<>'[]'::jsonb then return relay_private.message_rejected('VALIDATION'); end if;
  end if;
  if command->'replyToMessageId'<>'null'::jsonb then
    if jsonb_typeof(command->'replyToMessageId') is distinct from 'string' or coalesce(command->>'replyToMessageId','')!~'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' then return relay_private.message_rejected('VALIDATION'); end if;
    reply:=(command->>'replyToMessageId')::uuid;
  end if;
  client:=(command->>'clientId')::uuid; digest:=encode(extensions.digest(command::text,'sha256'),'hex');
  select * into m from relay_private.message_records where workspace_id=s.workspace_id and sender_id=u.id and client_id=client;
  if found then
    if m.fingerprint<>digest then return relay_private.message_rejected('CONFLICT'); end if;
    if m.deleted_at is not null then return relay_private.message_rejected('NOT_FOUND'); end if;
    return jsonb_build_object('status','persisted','historyStore','relay-chat','message',relay_private.message_json(m));
  end if;
  if exists(select 1 from unnest(notifications) as target(recipient_id) where not exists(select 1 from relay_private.accounts a where a.id=target.recipient_id and a.enabled)) then
    return relay_private.message_rejected('NOT_FOUND');
  end if;
  if reply is not null then
    select * into original from relay_private.message_records where id=reply and workspace_id=s.workspace_id and deleted_at is null;
    if not found or original.room_id<>s.message_room_id or original.visibility<>command->>'visibility'
      or (original.visibility='private' and original.participant_ids<>participants) then return relay_private.message_rejected('REPLY_MISMATCH'); end if;
  end if;
  if not relay_private.take_attempt('messages:send:'||u.id::text,120) then return relay_private.message_rejected('RATE_LIMIT'); end if;
  m.id:=gen_random_uuid();m.workspace_id:=s.workspace_id;m.room_id:=s.message_room_id;m.sender_id:=u.id;m.client_id:=client;
  m.visibility:=command->>'visibility';m.participant_ids:=participants;m.request:=command;m.fingerprint:=digest;m.created_at:=clock_timestamp();
  if m.visibility='public' then
    view_message:=jsonb_build_object('id',m.id,'from',case when u.role='manager' then 'owner' else u.agent_id::text end,
      'to',null,'taskId',null,'body',command->>'body','createdAt',m.created_at,'visibility','public','messageId',m.id,
      'senderId',u.id,'recipientIds','[]'::jsonb,'workspaceId',s.workspace_id,'roomId',s.message_room_id,'replyToMessageId',reply,
      'notificationRecipientIds',command->'notificationRecipientIds');
    next_state:=relay_private.bump_state(jsonb_set(s.state,'{messages}',(s.state->'messages')||jsonb_build_array(view_message)),s.revision+1);
    if octet_length(next_state::text)>900000 then return relay_private.message_rejected('CAPACITY'); end if;
  end if;
  insert into relay_private.message_records(id,workspace_id,room_id,sender_id,client_id,visibility,participant_ids,request,fingerprint,created_at)
    values(m.id,m.workspace_id,m.room_id,m.sender_id,m.client_id,m.visibility,m.participant_ids,m.request,m.fingerprint,m.created_at);
  if m.visibility='private' then
    insert into relay_private.direct_messages(id,sender_id,recipient_id,client_id,body,created_at)
      values(m.id,u.id,peer,client,command->>'body',m.created_at);
  else
    update relay_private.studio set state=next_state,revision=revision+1,updated_at=m.created_at where singleton;
  end if;
  insert into relay_private.message_outbox(message_id,recipient_id,created_at) select m.id,id,m.created_at from unnest(notifications) id;
  return jsonb_build_object('status','persisted','historyStore','relay-chat','message',relay_private.message_json(m));
end;
$$;

create or replace function relay_private.message_legacy_dm_send(u relay_private.accounts,data jsonb)
returns jsonb language plpgsql security invoker set search_path=pg_catalog as $$
declare s relay_private.studio%rowtype; result jsonb; peer text; pair jsonb; m relay_private.direct_messages%rowtype;
begin
  select * into s from relay_private.studio where singleton;
  peer:=lower(data->>'recipientId'); pair:=jsonb_build_array(least(u.id::text,peer),greatest(u.id::text,peer));
  result:=relay_private.message_action(u,'messages.send',jsonb_build_object('command',jsonb_build_object(
    'clientId',case when jsonb_typeof(data->'clientId')='string' then to_jsonb(lower(data->>'clientId')) else data->'clientId' end,'workspaceId',s.workspace_id,'roomId',s.message_room_id,'visibility','private','senderId',u.id,
    'recipientIds',jsonb_build_array(peer),'participantIds',pair,'notificationRecipientIds',jsonb_build_array(peer),
    'body',case when jsonb_typeof(data->'body')='string' then to_jsonb(btrim(data->>'body')) else data->'body' end,
    'replyToMessageId',case when jsonb_typeof(data->'replyToMessageId')='string' then to_jsonb(lower(data->>'replyToMessageId')) else coalesce(data->'replyToMessageId','null'::jsonb) end)));
  if result->>'status'='rejected' then
    return relay_private.error(result->>'code','Private message was not sent.',case result->>'code' when 'FORBIDDEN' then 403 when 'NOT_FOUND' then 404 when 'CONFLICT' then 409 when 'RATE_LIMIT' then 429 else 400 end);
  end if;
  select * into m from relay_private.direct_messages where id=(result->'message'->>'id')::uuid;
  return jsonb_build_object('message',relay_private.dm_json(m));
end;
$$;

create or replace function relay_private.dm_json(m relay_private.direct_messages)
returns jsonb language sql stable security invoker set search_path = pg_catalog as $$
  select jsonb_build_object('id',m.id,'senderId',m.sender_id,'recipientId',m.recipient_id,
    'body',m.body,'createdAt',m.created_at,'readAt',m.read_at);
$$;

create or replace function relay_private.dm_action(u relay_private.accounts, action text, data jsonb)
returns jsonb language plpgsql security invoker set search_path = pg_catalog as $$
declare
  a uuid; b uuid; cursor_message relay_private.direct_messages%rowtype;
  m relay_private.direct_messages%rowtype;
  recipient relay_private.accounts%rowtype;
  client uuid; messages jsonb; contacts jsonb; threads jsonb;
  body text; n integer;
begin
  if action = 'dm.notifications' then
    return jsonb_build_object('unreadDirectMessages',
      (select count(*) from relay_private.direct_messages where recipient_id=u.id and read_at is null));
  end if;
  if action = 'dm.inbox' then
    select coalesce(jsonb_agg(jsonb_build_object('id',id,'name',name,'role',role,'enabled',enabled) order by lower(name)), '[]'::jsonb)
      into contacts from relay_private.accounts where id <> u.id;
    with visible as (
      select d.*,least(sender_id,recipient_id) as a,greatest(sender_id,recipient_id) as b
      from relay_private.direct_messages d
      where u.role = 'manager' or sender_id = u.id or recipient_id = u.id
    ), latest as (
      select distinct on (v.a,v.b) v.* from visible v order by v.a,v.b,v.created_at desc,v.id desc
    )
    select coalesce(jsonb_agg(jsonb_build_object('participantA',l.a,'participantB',l.b,
      'lastMessage',relay_private.dm_json(row(l.id,l.sender_id,l.recipient_id,l.client_id,l.body,l.created_at,l.read_at)::relay_private.direct_messages),
      'unreadCount',(select count(*) from visible v where v.a=l.a and v.b=l.b and v.recipient_id=u.id and v.read_at is null))
      order by l.created_at desc,l.id desc),'[]'::jsonb) into threads from latest l;
    return jsonb_build_object('contacts',contacts,'threads',threads,'unreadCount',
      (select count(*) from relay_private.direct_messages where recipient_id=u.id and read_at is null));
  end if;

  if action = 'dm.send' then
    return relay_private.message_legacy_dm_send(u,data);
  end if;

  if action = 'dm.thread' then
    if jsonb_typeof(data->'participantA') is distinct from 'string'
      or coalesce(data->>'participantA','') !~* '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
      or jsonb_typeof(data->'participantB') is distinct from 'string'
      or coalesce(data->>'participantB','') !~* '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' then
      return relay_private.error('VALIDATION','Choose two conversation participants.',400);
    end if;
    a:=(data->>'participantA')::uuid; b:=(data->>'participantB')::uuid;
    if a=b or (u.role<>'manager' and u.id not in (a,b)) then
      return relay_private.error('FORBIDDEN','This conversation is private to its participants and manager.',403);
    end if;
    if data ? 'beforeId' then
      if coalesce(data->>'beforeId','') !~* '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' then
        return relay_private.error('VALIDATION','Invalid message cursor.',400);
      end if;
      select * into cursor_message from relay_private.direct_messages
        where id=(data->>'beforeId')::uuid and ((sender_id=a and recipient_id=b) or (sender_id=b and recipient_id=a));
      if not found then return relay_private.error('NOT_FOUND','Message not found in this conversation.',404); end if;
    end if;
    select coalesce(jsonb_agg(relay_private.dm_json(d) order by d.created_at,d.id),'[]'::jsonb) into messages from (
      select * from relay_private.direct_messages
      where ((sender_id=a and recipient_id=b) or (sender_id=b and recipient_id=a))
        and (cursor_message.id is null or (created_at,id)<(cursor_message.created_at,cursor_message.id))
      order by created_at desc,id desc limit 50
    ) d;
    return jsonb_build_object('messages',messages,'hasMore',jsonb_array_length(messages)=50);
  end if;

  if action = 'dm.read' then
    if jsonb_typeof(data->'messageIds') is distinct from 'array' then
      return relay_private.error('VALIDATION','Supply the IDs of received messages you have read.',400);
    end if;
    if jsonb_array_length(data->'messageIds')>100 or exists(
      select 1 from jsonb_array_elements(data->'messageIds') x where jsonb_typeof(x)<>'string'
        or (x#>>'{}') !~* '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$') then
      return relay_private.error('VALIDATION','Supply at most 100 valid message IDs.',400);
    end if;
    -- Managers inspecting other workers' messages do not consume their unread state.
    update relay_private.direct_messages set read_at=clock_timestamp()
      where recipient_id=u.id and read_at is null and id in (
        select (x#>>'{}')::uuid from jsonb_array_elements(data->'messageIds') x);
    get diagnostics n = row_count;
    return jsonb_build_object('markedRead',n,'unreadCount',
      (select count(*) from relay_private.direct_messages where recipient_id=u.id and read_at is null));
  end if;
  return relay_private.error('UNKNOWN_ACTION','Unknown message action.',400);
end;
$$;

create or replace function public.relay_message_rpc(p_action text,p_token text default '',p_data jsonb default '{}'::jsonb)
returns jsonb language plpgsql security invoker set search_path=pg_catalog as $$
declare context jsonb; u relay_private.accounts%rowtype;
begin
  if p_action is null or p_action not in ('messages.capabilities','messages.get','messages.metadata','messages.history','messages.send','messages.notifications','messages.notifications.ack')
    or jsonb_typeof(p_data) is distinct from 'object' then return relay_private.error('VALIDATION','Invalid message request.',400); end if;
  context:=public.relay_rpc('context',p_token,'{}'::jsonb);
  if context ? 'error' then return context; end if;
  select * into u from relay_private.accounts where id=(context->'user'->>'id')::uuid;
  return relay_private.message_action(u,p_action,p_data);
end;
$$;

revoke all on relay_private.message_records,relay_private.message_outbox from public,anon,authenticated;
grant select,insert,update,delete on relay_private.message_records,relay_private.message_outbox to service_role;
revoke all on function relay_private.message_json(relay_private.message_records),relay_private.message_rejected(text),relay_private.message_delete_dm(),relay_private.message_delete_workspace(),relay_private.message_action(relay_private.accounts,text,jsonb),relay_private.message_legacy_dm_send(relay_private.accounts,jsonb) from public,anon,authenticated;
grant execute on function relay_private.message_json(relay_private.message_records),relay_private.message_rejected(text),relay_private.message_delete_dm(),relay_private.message_delete_workspace(),relay_private.message_action(relay_private.accounts,text,jsonb),relay_private.message_legacy_dm_send(relay_private.accounts,jsonb) to service_role;
revoke all on function public.relay_message_rpc(text,text,jsonb) from public,anon,authenticated;
grant execute on function public.relay_message_rpc(text,text,jsonb) to service_role;
commit;

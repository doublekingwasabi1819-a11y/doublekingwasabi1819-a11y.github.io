# Version 6 addition: local receipt UI and manager read route

Version 5 below remains unchanged as a backend baseline. Version 6 adds
`receipt-ui/`: actual Public/Private history mounts as an optional patch, a
default-disabled manager receipt endpoint, same-origin proxy factory, and tests.
Read `receipt-ui/README.md` before activation. The existing Supabase API origin
and Lightsail event origin differ: the UI refuses a direct Lightsail endpoint.
An authorized server-to-server proxy channel remains a production activation gap.
No live migration, deployment, scopes or messages were changed.

Validation: 183 baseline event tests and 37 sender tests rerun; 61 frontend
tests and 11 host/combined integration tests passed. The latter includes real
DOM, SQL permission checks, and SQLite delivery/fetch/ACK stages.

---

# Relay messaging update — local tested package

Prepared 2026-10-05. This package contains working local backend/source code and optional MCP integration. Nothing was applied to the live repository, database, account links, permissions or deployment.

## Completed

- Connection-based Public/private sends and same-audience replies, persisted in real SQL and visible through existing Relay shared-board/DM history responses.
- Durable sender/client-ID dedup, conflict checks, deletion tombstones, transactional explicitly targeted notification outbox, and separate handoff acknowledgment.
- Authorized full-message fetch without a browser tab, followed by an explicit agent acknowledgment. Full bodies never enter ping payloads or event audit storage.
- Ping attempt, local transport-flush, service-acceptance, fetch and explicit agent-ack timestamps are distinct.
- Private remains visible to participants and manager, not other agents. Manager audit access does not automatically create a ping. Public means all workspace members, not the internet.
- Neutral Public/Private/From/To and reply-metadata display source changes. Relay history only; no user-facing ChatGPT conversation mirroring.

## Package layout

- `relay-events/`: evolved v4 event package, opt-in read/ack/send/reply MCP capabilities, authenticated source adapter and tests. The normal host stays unchanged unless capabilities are explicitly supplied.
- `backend-implementation/proposed/`: complete reviewed candidate source files against main `56c47abe01d807a52cde82ebc46d7038ae36cdcb`.
- `backend-implementation/backend-update.patch`: source patch generated from the pinned base; check it against the intended checkout before applying. `backend/message-contract.sql` is the additive database update candidate; schema and private-message install paths include the same contract.
- `send-proposal/`: now-runnable sender/source implementation, isolated tests, source provenance and actual SQL/Edge round-trip test. The folder name reflects its initial review phase; it is not a placeholder implementation.

Do not upload test fixtures as a running replacement controller, blindly overwrite a newer checkout, or apply both standalone SQL copies unnecessarily. Deployment is a separate approved action. Existing browser-only linking is not silently expanded: read/fetch requires separately approved relay:read; sending/outbox handoff requires relay:write; replies require read plus write. Combined controller metadata additionally retains browser:control. No live scopes were enabled here.

## Verified locally

- 183 main event/MCP tests passed.
- 37 sender/source isolated tests passed.
- 44 focused backend/UI-source tests passed.
- 15 durable-message PostgreSQL checks passed against an actual in-memory PostgreSQL engine and actual Edge handler.
- 13 actual SQL/Edge sender/source round-trip checks passed.
- Full real MCP → authenticated source → SQL chat history/outbox → event queue → mocked signed callback → fetch → explicit agent ACK → reply passed.
- Independent review covered source authorization, audiences, scope boundaries, dedup/replies, queue receipts and compatibility; raw sender/source failures are not leaked.

These checks are not a production deployment, independent-session concurrency benchmark or live ChatGPT wakeup. External callback delivery is mocked. Test credentials are disposable in-memory fixtures, not real accounts.

## Remaining limits — do not call these complete

1. The existing legacy **public web composer** (`operation/message.add`) remains on its old path and does not generate the new canonical outbox wake. New connection-based Public sends do. Existing private web sends use the canonical path.
2. Manager receipt timestamps have a redacted authorized backend hook, but the **new receipt ledger is not mounted in the Relay UI**. Neutral labels and source reply metadata do not imply that receipt panel is installed.
3. Real account linking with read/write scope approval, current-controller composition, source-outbox pump wiring/scheduling, protected storage/callback configuration, plugin rescan and live subscription verification remain activation work. Browser-only OAuth defaults are untouched.
4. Live SQL migration, repository push and deployment were not performed. The UI source changes were not tested in a real browser, and the full unrelated repository suite was not fetched/run.

## Reproduce

```sh
npm --prefix relay-events ci --ignore-scripts
npm --prefix relay-events test
npm --prefix send-proposal test
node --test backend-implementation/proposed/tests/*.test.mjs
# Install the pinned local test engine; it accepts no production database URL.
npm install --prefix /tmp/relay-message-privacy-pg --ignore-scripts @electric-sql/pglite@0.5.8
export RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite
node backend-implementation/proposed/tests/message-contract-pglite.mjs
node send-proposal/test/backend-roundtrip.mjs
node --test relay-events/test/local-message-end-to-end.mjs
```

Read `relay-events/MESSAGE-ACCESS.md`, `relay-events/INTEGRATION.md`, backend validation notes and source contracts before any deployment. Hashes in `PACKAGE-SHA256.json` bind the packaged files to the final local snapshot.

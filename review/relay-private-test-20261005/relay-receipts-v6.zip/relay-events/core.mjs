import {createHash, randomBytes, timingSafeEqual} from 'node:crypto';
import {Webhook} from 'standardwebhooks';
import {messageLink,messageSourceId} from './message-shapes.mjs';
const EVENT = 'relay.work.available';
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const key = (owner, agent) => hash([owner, agent]);
const validId = v => typeof v === 'string' && /^[a-zA-Z0-9_.:@-]{1,160}$/.test(v);
const opaque = () => randomBytes(24).toString('hex');
const equal = (a,b) => typeof a==='string' && typeof b==='string' && Buffer.byteLength(a)===Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a),Buffer.from(b));
export class RelayError extends Error { constructor(code,message,reason) {super(message); this.code=code; this.reason=reason;} }
const invalid = () => {throw new RelayError(-32602,'Invalid parameters');};
const denied = () => {throw new RelayError(-32001,'Not authorized');};
export const eventDefinition = {
 name:EVENT, description:'New or recoverable pending work for one authorized Relay agent.', delivery:['webhook'],
 inputSchema:{type:'object',properties:{agent_id:{type:'string'}},required:['agent_id'],additionalProperties:false},
 payloadSchema:{type:'object',properties:{agent_id:{type:'string'},work_id:{type:'string'},reason:{type:'string',enum:['new','recovery']},priority:{type:'string',enum:['urgent','normal','low']},message_id:{type:'string'},visibility:{type:'string',enum:['private','public']},sender_id:{type:'string'},recipient_ids:{type:'array',items:{type:'string'},minItems:1,maxItems:1},participant_ids:{type:'array',items:{type:'string'},minItems:2,maxItems:2},workspace_id:{type:'string'}},required:['agent_id','work_id','reason','priority'],additionalProperties:false}
};
export class RelayEvents {
 constructor({store,authorize,transport,now=Date.now,recoveryMs=600000,maxRecoveries=3,maxAttempts=5}={}) {
  if(!store || typeof authorize!=='function' || typeof transport!=='function') throw new Error('Store, authorization and secure transport are required');
  if(!Number.isSafeInteger(recoveryMs) || recoveryMs<600000 || recoveryMs>900000 || !Number.isSafeInteger(maxRecoveries) || maxRecoveries<0 || maxRecoveries>10 || !Number.isSafeInteger(maxAttempts) || maxAttempts<1 || maxAttempts>10) throw new Error('Invalid bounded recovery configuration');
  if(typeof now!=='function')throw new Error('A numeric epoch-millisecond clock is required');
  const clock=()=>{const value=now();if(!Number.isSafeInteger(value)||value<0||value>8640000000000000-86400000)throw new Error('Invalid epoch-millisecond clock value');return value;};
  clock();
  Object.assign(this,{store,authorize,transport,now:clock,recoveryMs,maxRecoveries,maxAttempts}); this.chain=Promise.resolve();
 }
 exclusive(fn) {const next=this.chain.then(fn); this.chain=next.catch(()=>{}); return next;}
 async access(owner,agent,action) {if(!validId(owner)||!validId(agent)||await this.authorize({principal:owner,agent_id:agent,action})!==true) denied();}
 scope(p) {if(!p || p.name!==EVENT || !p.arguments || Object.keys(p.arguments).length!==1 || !validId(p.arguments.agent_id)||p.delivery?.mode!=='webhook'||typeof p.delivery.url!=='string') invalid();
  let u;try{u=new URL(p.delivery.url);}catch{invalid();} if(u.protocol!=='https:'||u.username||u.password||u.hash||(u.port&&u.port!=='443'))invalid(); return p.arguments.agent_id;}
 async post(sub,body,id,onSent) {
  const bytes=JSON.stringify(body); if(Buffer.byteLength(bytes)>262144) throw new RelayError(-32602,'Payload too large');
  const at=new Date(this.now()); const keys=[sub.secret,...(sub.oldSecret&&sub.rotationUntil>this.now()?[sub.oldSecret]:[])];
  return this.transport({url:sub.url,body:bytes,...(onSent?{onSent}:{}),headers:{'Content-Type':'application/json','webhook-id':id,'webhook-timestamp':String(Math.floor(at.getTime()/1000)),'webhook-signature':keys.map(s=>new Webhook(s).sign(id,at,bytes)).join(' '),'X-MCP-Subscription-Id':sub.id}});
 }
 async subscribe(owner,p) {return this.exclusive(async()=>{
  const agent=this.scope(p);await this.access(owner,agent,'subscribe');
  const secret=p.delivery.secret; if(typeof secret!=='string'||!/^whsec_[A-Za-z0-9+/]+={0,2}$/.test(secret))invalid();
  const decoded=Buffer.from(secret.slice(6),'base64');if(decoded.length<24||decoded.length>64||decoded.toString('base64')!==secret.slice(6))invalid();
  if(p.cursor!=null) invalid();
  if(p.ttlMs!==undefined&&p.ttlMs!==null&&(!Number.isSafeInteger(p.ttlMs)||p.ttlMs<=0))invalid();
  const s=this.store.read(), id='sub_'+hash([owner,p.delivery.url,EVENT,{agent_id:agent}]);const old=s.subscriptions[id], now=this.now();
  const sub={id,owner,agent,url:p.delivery.url,secret,expires:now+Math.min(p.ttlMs??86400000,86400000),verifiedUntil:old?.verifiedUntil??0};
  if(old?.secret===secret&&old.rotationUntil>now){sub.oldSecret=old.oldSecret;sub.rotationUntil=old.rotationUntil;}
  if(old?.secret && old.secret!==secret){sub.oldSecret=old.secret;sub.rotationUntil=now+300000;}
  // Cache is scoped to owner + URL (and here, stricter, event/agent/secret).
  if(!old||old.secret!==secret||sub.verifiedUntil<=now){
   const challenge=opaque(), started=this.now();let response;
   try{response=await this.post(sub,{type:'verification',challenge},'verify_'+opaque());}
   catch(e){const reason=['timeout','dns_failed','address_blocked','host_not_allowed','invalid_url'].includes(e?.reason)?e.reason:'challenge_failed';throw new RelayError(-32015,'Callback verification failed',reason);}
   let received;try{received=typeof response.body==='string'?JSON.parse(response.body):response.body;}catch{}
   if(response.status<200||response.status>=300||this.now()-started>10000||!equal(challenge,received?.challenge))throw new RelayError(-32015,'Callback verification failed','challenge_failed');
   sub.verifiedUntil=this.now()+300000;
  }
  s.subscriptions[id]=sub;
  for(const work of Object.values(s.work))if(work.owner===owner&&work.agent===agent&&work.status!=='done'){if(work.attentionReason==='route_lost'){delete work.needsAttention;delete work.attentionReason;}if(!work.needsAttention&&['queued','delivered'].includes(work.status))this.queue(s,sub,work,'new');}
  this.store.write(s);return {id,refreshBefore:new Date(sub.expires).toISOString(),cursor:null,truncated:false};
 });}
 async unsubscribe(owner,p){return this.exclusive(async()=>{const agent=this.scope(p);await this.access(owner,agent,'subscribe');const s=this.store.read(),id='sub_'+hash([owner,p.delivery.url,EVENT,{agent_id:agent}]);delete s.subscriptions[id];for(const d of Object.values(s.deliveries))if(d.subscription===id&&d.status==='queued')d.status='cancelled';this.store.write(s);return {};});}
 queue(s,sub,w,reason) {if(Object.values(s.deliveries).some(d=>d.subscription===sub.id&&d.work===w.id&&d.status==='failed'))return;const id='evt_'+hash([sub.id,w.id,w.generation]);if(s.deliveries[id]){if(s.deliveries[id].status==='cancelled'){s.deliveries[id].status='queued';s.deliveries[id].nextAt=this.now();}return;}
  s.deliveries[id]={id,subscription:sub.id,work:w.id,status:'queued',attempts:0,nextAt:this.now(),event:{eventId:id,name:EVENT,timestamp:new Date(this.now()).toISOString(),data:{agent_id:w.agent,work_id:w.id,reason,priority:w.priority,...(w.message?{message_id:w.message.id,visibility:w.message.visibility,sender_id:w.message.senderId,...(w.message.visibility==='private'?{participant_ids:[w.message.senderId,w.message.recipientId],recipient_ids:[w.message.recipientId]}:{workspace_id:w.message.workspaceId})}:{})},cursor:null}};
 }
 async enqueue(owner,{agent_id,source_id,origin='external',priority='normal',notBefore=0,message}={}) {return this.exclusive(async()=>{
  await this.access(owner,agent_id,'enqueue');if(!validId(source_id)||origin!=='external'||!['urgent','normal','low'].includes(priority)||!Number.isSafeInteger(notBefore)||notBefore<0||notBefore>this.now()+86400000)invalid();const s=this.store.read(), id='work_'+hash([owner,agent_id,source_id]);
  let link;try{if(message!==undefined){link=messageLink(message,owner);if(source_id!==messageSourceId(link))invalid();}}catch{invalid();}
  if(s.work[id]){if(JSON.stringify(s.work[id].message??null)!==JSON.stringify(link??null))throw new RelayError(-32005,'Source message linkage conflicts with existing work');return this.publicWork(s.work[id]);}
  if(Object.values(s.work).filter(w=>w.owner===owner&&w.agent===agent_id&&w.status!=='done').length>=1000)throw new RelayError(-32004,'Pending queue full');
  const w={id,owner,agent:agent_id,status:'queued',createdAt:this.now(),updatedAt:this.now(),generation:0,recoveries:0,lastWake:this.now(),priority,notBefore,...(link?{message:link}:{})};s.work[id]=w;
  for(const sub of Object.values(s.subscriptions))if(sub.owner===owner&&sub.agent===agent_id&&sub.expires>this.now())this.queue(s,sub,w,'new');
  this.store.write(s);return this.publicWork(w);
 });}
 publicWork(w){return {id:w.id,agent_id:w.agent,status:w.status,priority:w.priority,notBefore:w.notBefore,createdAt:w.createdAt,updatedAt:w.updatedAt,recoveries:w.recoveries,needsAttention:!!w.needsAttention,...(w.message?{messageId:w.message.id,visibility:w.message.visibility,messageCreatedAt:w.message.createdAt,messageFetchedAt:w.messageFetchedAt??null,agentAcknowledgedAt:w.agentAcknowledgedAt??null}:{})};}
 async status(owner,agent){return this.exclusive(async()=>{await this.access(owner,agent,'read');const s=this.store.read();return {agent_id:agent,paused:!!s.paused[key(owner,agent)],work:Object.values(s.work).filter(w=>w.owner===owner&&w.agent===agent).map(w=>this.publicWork(w)),subscriptions:Object.values(s.subscriptions).filter(x=>x.owner===owner&&x.agent===agent).map(x=>({id:x.id,refreshBefore:new Date(x.expires).toISOString(),expired:x.expires<=this.now()})),deliveries:Object.values(s.deliveries).filter(d=>s.work[d.work]?.owner===owner&&s.work[d.work]?.agent===agent).map(d=>({eventId:d.id,work_id:d.work,status:d.status,attempts:d.attempts,lastStatus:d.lastStatus??null,attemptLog:structuredClone(d.attemptLog??[]),sentAt:d.sentAt??null,serviceAcceptedAt:d.serviceAcceptedAt??null}))};});}
 async pause(owner,agent,paused){return this.exclusive(async()=>{await this.access(owner,agent,'pause');if(typeof paused!=='boolean')invalid();const s=this.store.read();s.paused[key(owner,agent)]=paused;this.store.write(s);return {agent_id:agent,paused};});}
 async transition(owner,{agent_id,work_id,state,claim_token,defer_ms}={}) {return this.exclusive(async()=>{
  await this.access(owner,agent_id,'execute');const s=this.store.read(),w=s.work[work_id];if(!w||w.owner!==owner||w.agent!==agent_id)denied();
  const now=this.now();
  if(state==='deferred'){
   if(!Number.isSafeInteger(defer_ms)||defer_ms<1000||defer_ms>900000||w.status==='done')invalid();
   if(['claimed','running'].includes(w.status)){if(!equal(w.claimToken,claim_token)||w.leaseUntil<=now)denied();w.status='queued';delete w.claimToken;delete w.leaseUntil;}
   w.notBefore=now+defer_ms;w.updatedAt=now;w.lastWake=w.notBefore-this.recoveryMs;this.store.write(s);return this.publicWork(w);
  }
  if(state==='claimed'){
   if(w.notBefore>now)throw new RelayError(-32003,'Work deferred');
   if(Object.values(s.work).some(other=>other.id!==w.id&&other.owner===owner&&other.agent===agent_id&&['claimed','running'].includes(other.status)&&other.leaseUntil>now))throw new RelayError(-32003,'Agent already has active work');
   if(['claimed','running'].includes(w.status)&&w.leaseUntil>now){if(equal(w.claimToken,claim_token))return {...this.publicWork(w),claim_token:w.claimToken};throw new RelayError(-32003,'Work already claimed');}
   if(w.status==='done')return this.publicWork(w);
   // Pause stops new claims, not an existing worker's renewal/completion/checkpoint.
   if(s.paused[key(owner,agent_id)])throw new RelayError(-32002,'Agent paused');
   w.claimToken=opaque();w.leaseUntil=now+this.recoveryMs;w.status='claimed';
  } else {
   if(!equal(w.claimToken,claim_token))denied();
   if(w.status==='done'&&state==='done')return this.publicWork(w);
   if(w.leaseUntil<=now)throw new RelayError(-32003,'Claim expired');
   if(state==='running'&&['claimed','running'].includes(w.status)){w.status='running';w.leaseUntil=now+this.recoveryMs;}
   else if(state==='done'&&['claimed','running'].includes(w.status)){w.status='done';delete w.leaseUntil;}
   else invalid();
  }
  w.updatedAt=now;for(const d of Object.values(s.deliveries))if(d.work===w.id&&d.status==='queued')d.status='cancelled';
  this.store.write(s);return {...this.publicWork(w),...(w.status==='claimed'?{claim_token:w.claimToken}:{})};
 });}
 async tick(){return this.exclusive(async()=>{
  const s=this.store.read(),now=this.now();let sent=0;
  for(const sub of Object.values(s.subscriptions)){
   if(sub.expires<=now)continue;
   try{await this.access(sub.owner,sub.agent,'subscribe');}catch(e){if(e instanceof RelayError&&e.code===-32001)delete s.subscriptions[sub.id];continue;}
   if(s.paused[key(sub.owner,sub.agent)])continue;
   for(const w of Object.values(s.work)){
    if(w.owner!==sub.owner||w.agent!==sub.agent||w.status==='done'||w.needsAttention)continue;
    const pending=Object.values(s.deliveries).some(d=>d.work===w.id&&d.status==='queued');
    const leased=['claimed','running'].includes(w.status)&&w.leaseUntil>now;
    if(w.notBefore<=now&&!pending&&!leased&&now-w.lastWake>=this.recoveryMs){
     const viable=Object.values(s.subscriptions).some(target=>target.owner===w.owner&&target.agent===w.agent&&target.expires>now&&!Object.values(s.deliveries).some(d=>d.subscription===target.id&&d.work===w.id&&d.status==='failed'));
     if(!viable){w.needsAttention=true;w.attentionReason='route_lost';continue;}
     if(w.recoveries>=this.maxRecoveries){w.needsAttention=true;w.attentionReason='recovery_exhausted';continue;}
     w.recoveries++;w.generation++;w.lastWake=now;w.status='queued';delete w.claimToken;delete w.leaseUntil;
     for(const target of Object.values(s.subscriptions))if(target.owner===w.owner&&target.agent===w.agent&&target.expires>now)this.queue(s,target,w,'recovery');
    }
   }
  }
  // Persist recovery IDs before any network side effects. Crash replay uses same IDs.
  this.store.write(s);
  const lastSent=s.lastSent??={};const sentAgents=new Set();
  for(const d of Object.values(s.deliveries).sort((a,b)=>({urgent:0,normal:1,low:2}[s.work[a.work]?.priority]??1)-({urgent:0,normal:1,low:2}[s.work[b.work]?.priority]??1))){
   const sub=s.subscriptions[d.subscription],w=s.work[d.work];
   if(d.status!=='queued'||d.nextAt>now)continue;
   if(!sub||sub.expires<=now||!w||w.status==='done'){d.status='cancelled';continue;}
   const agentKey=key(sub.owner,sub.agent);
   if(s.paused[agentKey]||w.notBefore>now||sentAgents.has(agentKey))continue;
   if(lastSent[agentKey]&&now-lastSent[agentKey]<(w.priority==='urgent'?1000:120000))continue;
   // Fresh authorization per delivery, not just once per recovery scan.
   try{await this.access(sub.owner,sub.agent,'subscribe');}catch(e){if(e instanceof RelayError&&e.code===-32001)d.status='cancelled';continue;}
   if(sub.expires<=this.now()){d.status='cancelled';continue;}
   if(d.attempts>=this.maxAttempts){d.status='failed';continue;}
   for(const old of d.attemptLog??[])if(old.outcome==='in_flight')old.outcome='unknown';
   d.attempts++;const attempt={attempt:d.attempts,attemptedAt:this.now(),sentAt:null,completedAt:null,status:null,serviceAcceptedAt:null,outcome:'in_flight'};(d.attemptLog??=[]).push(attempt);this.store.write(s);let response,activeAttempt=true;
   try{response=await this.post(sub,d.event,d.id,()=>{if(!activeAttempt)return;attempt.sentAt??=this.now();d.sentAt??=attempt.sentAt;this.store.write(s);});}catch{response={status:0};}finally{activeAttempt=false;}
   attempt.completedAt=this.now();attempt.status=response.status;attempt.outcome=response.status>=200&&response.status<300?'accepted':response.status===0?'unknown':'rejected';
   if(attempt.outcome==='accepted'){attempt.serviceAcceptedAt=this.now();d.serviceAcceptedAt??=attempt.serviceAcceptedAt;}
   d.lastStatus=response.status;sent++;sentAgents.add(agentKey);if(response.status>=200&&response.status<300)lastSent[agentKey]=this.now();
   if(response.status>=200&&response.status<300){d.status='delivered';if(w.status==='queued')w.status='delivered';w.updatedAt=this.now();w.lastWake=this.now();}
   else if(response.status===410||response.status===413||(response.status>=400&&response.status<500&&![408,429].includes(response.status))||d.attempts>=this.maxAttempts){d.status='failed';if(response.status===410)delete s.subscriptions[sub.id];}
   else d.nextAt=this.now()+Math.min(60000,1000*2**(d.attempts-1));
   this.store.write(s);
  }
  for(const w of Object.values(s.work)){const ds=Object.values(s.deliveries).filter(d=>d.work===w.id);if(ds.length&&ds.every(d=>['failed','cancelled'].includes(d.status))&&!Object.values(s.subscriptions).some(sub=>sub.owner===w.owner&&sub.agent===w.agent&&sub.expires>now&&!ds.some(d=>d.subscription===sub.id&&d.status==='failed'))){w.needsAttention=true;w.attentionReason='route_lost';}}
  this.store.write(s);return {sent};
 });}
}

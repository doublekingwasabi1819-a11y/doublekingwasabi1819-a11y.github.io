import {createServer} from 'node:http';
import {pathToFileURL} from 'node:url';
import {RelayEvents} from './core.mjs';import {SqliteStore} from './store.mjs';import {createWebhookTransport} from './transport.mjs';import {createDispatcher} from './mcp.mjs';import {createHttpHandler} from './http.mjs';
// A trusted local integration module, never supplied by a remote caller.
if(!process.env.RELAY_EVENTS_CONFIG)throw new Error('Disabled: RELAY_EVENTS_CONFIG must name a host-owned integration module');
const config=await import(pathToFileURL(process.env.RELAY_EVENTS_CONFIG).href);
if(typeof config.authenticate!=='function'||typeof config.authorize!=='function'||!Array.isArray(config.allowedCallbackHosts)||!config.allowedCallbackHosts.length||!config.databasePath)throw new Error('Disabled: verified auth, resource authorization, callback allowlist and durable database path required');
const port=config.port===undefined?8789:config.port;
if(!Number.isSafeInteger(port)||port<1||port>65535)throw new Error('Disabled: port must be an integer from 1 to 65535');
const store=new SqliteStore(config.databasePath);const engine=new RelayEvents({store,authorize:config.authorize,transport:createWebhookTransport({allowedHosts:config.allowedCallbackHosts}),recoveryMs:config.recoveryMs});
const server=createServer(createHttpHandler({dispatch:createDispatcher(engine),authenticate:config.authenticate}));server.requestTimeout=15000;server.headersTimeout=10000;
// No external listening by default. Put behind your existing authenticated TLS gateway.
server.listen(port,'127.0.0.1');
let ticking=false;const timer=setInterval(async()=>{if(ticking)return;ticking=true;try{await engine.tick();}catch{process.stderr.write('Relay event tick failed; inspect private server logs/store health.\n');}finally{ticking=false;}},15000);
// Trusted source adapter must validate upstream authenticity, distinguish incoming work
// from delivery/status/own-agent output, and use a durable source ID/outbox.
if(config.attachSource)await config.attachSource({enqueue:(principal,item)=>engine.enqueue(principal,item)});
async function close(){clearInterval(timer);server.close();await engine.exclusive(async()=>store.close());}process.on('SIGTERM',close);process.on('SIGINT',close);

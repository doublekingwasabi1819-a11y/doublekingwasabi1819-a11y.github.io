import {RelayError,eventDefinition} from './core.mjs';
const schema = (properties,required=Object.keys(properties)) => ({type:'object',properties,required,additionalProperties:false});
const string={type:'string'};
export const tools=[
 {name:'relay_work_status',description:'Read authorized Relay pending work and delivery state. Delivery receipt is not proof of execution.',inputSchema:schema({agent_id:string}),annotations:{readOnlyHint:true}},
 {name:'relay_work_transition',description:'Claim work, report running, or mark done using the current claim token. Only mark done after verifying the requested work succeeded.',inputSchema:schema({agent_id:string,work_id:string,state:{type:'string',enum:['claimed','running','done','deferred']},claim_token:string,defer_ms:{type:'integer',minimum:1000,maximum:900000}},['agent_id','work_id','state']),annotations:{readOnlyHint:false,idempotentHint:true}},
 {name:'relay_work_pause',description:'Pause or resume wake delivery and new work claims for one authorized agent. Pausing does not abort actions already running.',inputSchema:schema({agent_id:string,paused:{type:'boolean'}}),annotations:{readOnlyHint:false,idempotentHint:true}}
];
/** Host must authenticate BEFORE calling. Never derive principal from params. */
export function createDispatcher(engine){return async (principal,request)=>{
 let id=request?.id??null;
 try{
  if(typeof principal!=='string'||!principal)throw new RelayError(-32001,'Not authenticated');
  if(!request||request.jsonrpc!=='2.0'||typeof request.method!=='string'||!('id'in request)||!['string','number'].includes(typeof request.id))throw new RelayError(-32600,'Invalid request');
  const p=request.params??{};let result;
  switch(request.method){
   case 'server/discover':result={resultType:'complete',supportedVersions:['2026-07-28'],capabilities:{tools:{},events:{}}};break;
   case 'events/list':result={events:await engine.authorize({principal,action:'discover'})===true?[eventDefinition]:[]};break;
   case 'events/subscribe':result=await engine.subscribe(principal,p);break;
   case 'events/unsubscribe':result=await engine.unsubscribe(principal,p);break;
   case 'tools/list':result={tools};break;
   case 'tools/call':{
    const tool=tools.find(t=>t.name===p.name),a=p.arguments;
    if(!tool||!a||typeof a!=='object'||Array.isArray(a)||Object.keys(a).some(k=>!(k in tool.inputSchema.properties))||tool.inputSchema.required.some(k=>!(k in a)))throw new RelayError(-32602,'Invalid tool arguments');
    let value;
    if(p.name==='relay_work_status')value=await engine.status(principal,a.agent_id);
    if(p.name==='relay_work_pause')value=await engine.pause(principal,a.agent_id,a.paused);
    if(p.name==='relay_work_transition')value=await engine.transition(principal,a);
    result={content:[{type:'text',text:JSON.stringify(value)}],structuredContent:value};break;
   }
   default:throw new RelayError(-32601,'Method not found');
  }
  return {jsonrpc:'2.0',id,result};
 }catch(e){return {jsonrpc:'2.0',id,error:{code:e instanceof RelayError?e.code:-32603,message:e instanceof RelayError?e.message:'Internal error',...(e instanceof RelayError&&e.reason?{data:{reason:e.reason}}:{})}};}
};}

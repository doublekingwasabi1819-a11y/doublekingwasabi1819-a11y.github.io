import { lookup as systemLookup } from 'node:dns/promises';
import https from 'node:https';
import { validateHeaderName, validateHeaderValue } from 'node:http';
import { isIP } from 'node:net';
import { checkServerIdentity } from 'node:tls';

const TIMEOUT_MS = 10_000;
const MAX_RESPONSE_BYTES = 16 * 1024;
const MAX_REQUEST_BYTES = 256 * 1024;

// Deliberately conservative: special-purpose protocol ranges are denied even
// where IANA lists a more-specific globally reachable exception. Review these
// ranges when deploying, alongside a network-level egress policy.
// https://www.iana.org/assignments/iana-ipv4-special-registry/
const BLOCKED_V4 = [
  ['0.0.0.0', 8], ['10.0.0.0', 8], ['100.64.0.0', 10],
  ['127.0.0.0', 8], ['169.254.0.0', 16], ['172.16.0.0', 12],
  ['192.0.0.0', 24], ['192.0.2.0', 24], ['192.88.99.0', 24],
  ['192.168.0.0', 16], ['198.18.0.0', 15], ['198.51.100.0', 24],
  ['203.0.113.0', 24], ['224.0.0.0', 3],
].map(([address, prefix]) => [v4Number(address), prefix]);

// Only ordinary 2000::/3 global unicast is eligible. This also excludes all
// mapped/compatible IPv4, NAT64, local, multicast and unallocated IPv6 space.
// Teredo, 6to4, retired 6bone, documentation and IETF protocol assignments are
// denied below.
// https://www.iana.org/assignments/iana-ipv6-special-registry/
const BLOCKED_V6 = [
  ['2001::', 23], ['2001:db8::', 32], ['2002::', 16], ['3ffe::', 16], ['3fff::', 20],
].map(([address, prefix]) => [v6Number(address), BigInt(128 - prefix)]);

const FORBIDDEN_HEADERS = new Set([
  'host', 'connection', 'content-length', 'transfer-encoding', 'proxy-connection',
  'proxy-authorization', 'upgrade', 'trailer', 'te', 'expect',
]);

function failure(code, reason, message, cause) {
  const error = new Error(message, cause ? { cause } : undefined);
  error.code = code;
  error.reason = reason;
  return error;
}

function v4Number(address) {
  return address.split('.').reduce((value, octet) => value * 256 + Number(octet), 0);
}

function v6Number(address) {
  // isIP validates untrusted inputs before this parser is called.
  if (address.includes('.')) {
    const lastColon = address.lastIndexOf(':');
    const v4 = v4Number(address.slice(lastColon + 1));
    address = `${address.slice(0, lastColon)}:${Math.floor(v4 / 65536).toString(16)}:${(v4 % 65536).toString(16)}`;
  }
  const halves = address.split('::');
  const left = halves[0] ? halves[0].split(':') : [];
  const right = halves[1] ? halves[1].split(':') : [];
  const words = halves.length === 2
    ? [...left, ...Array(8 - left.length - right.length).fill('0'), ...right]
    : left;
  return words.reduce((value, word) => (value << 16n) + BigInt(`0x${word}`), 0n);
}

function isPublicAddress(address) {
  if (typeof address !== 'string' || address.includes('%')) return false;
  const family = isIP(address);
  if (family === 4) {
    const value = v4Number(address);
    return !BLOCKED_V4.some(([network, prefix]) =>
      Math.floor(value / 2 ** (32 - prefix)) === Math.floor(network / 2 ** (32 - prefix)));
  }
  if (family === 6) {
    const value = v6Number(address);
    if ((value >> 125n) !== 1n) return false; // 2000::/3
    return !BLOCKED_V6.some(([network, shift]) => (value >> shift) === (network >> shift));
  }
  return false;
}

function canonicalHost(value) {
  if (typeof value !== 'string' || !value || value !== value.trim()) {
    throw failure('CALLBACK_URL_INVALID', 'invalid_url', 'Expected an exact callback hostname');
  }
  const host = value.toLowerCase();
  const literal = host.startsWith('[') && host.endsWith(']') ? host.slice(1, -1) : host;
  if (isIP(literal)) {
    if (literal.includes('%')) throw failure('CALLBACK_URL_INVALID', 'invalid_url', 'Scoped IP addresses are not allowed');
    return isIP(literal) === 6
      ? new URL(`https://[${literal}]/`).hostname.slice(1, -1)
      : literal;
  }
  if (host.length > 253 || !host.includes('.') || !host.split('.').every(label =>
    /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))) {
    throw failure('CALLBACK_URL_INVALID', 'invalid_url', 'Expected an exact DNS hostname without a wildcard, scheme or port');
  }
  if (/(^|\.)(localhost|local|localdomain|internal)$/.test(host) || /(^|\.)home\.arpa$/.test(host)) {
    throw failure('CALLBACK_ADDRESS_BLOCKED', 'address_blocked', 'Local callback hostnames are not allowed');
  }
  return host;
}

function callbackUrl(raw, allowedHosts) {
  if (typeof raw !== 'string' || /[\u0000-\u0020\u007f\\#]/.test(raw)) {
    throw failure('CALLBACK_URL_INVALID', 'invalid_url', 'Callback URL must be a clean HTTPS URL without a fragment');
  }
  let url;
  try { url = new URL(raw); } catch {
    throw failure('CALLBACK_URL_INVALID', 'invalid_url', 'Invalid callback URL');
  }
  const authority = /^[a-z][a-z\d+.-]*:\/\/([^/?#]*)/i.exec(raw)?.[1];
  if (url.protocol !== 'https:' || !authority || authority.includes('@') ||
      url.username || url.password || (url.port && url.port !== '443') || url.hash) {
    throw failure('CALLBACK_URL_INVALID', 'invalid_url', 'Callback URL requires HTTPS on port 443 with no credentials or fragment');
  }
  const hostname = canonicalHost(url.hostname);
  if (!allowedHosts.has(hostname)) {
    throw failure('CALLBACK_NOT_ALLOWED', 'host_not_allowed', 'Callback hostname is not in the configured allowlist');
  }
  return { url, hostname };
}

function requestBytes(body) {
  if (typeof body !== 'string' && !Buffer.isBuffer(body) && !(body instanceof Uint8Array)) {
    throw failure('CALLBACK_BODY_INVALID', 'invalid_body', 'Callback body must be serialized text or bytes');
  }
  const bytes = Buffer.from(body);
  if (bytes.length > MAX_REQUEST_BYTES) {
    throw failure('CALLBACK_BODY_TOO_LARGE', 'payload_too_large', 'Callback body exceeds 256 KiB');
  }
  return bytes;
}

function requestHeaders(headers, host, byteLength) {
  if (!headers || typeof headers !== 'object' || Array.isArray(headers)) {
    throw failure('CALLBACK_HEADERS_INVALID', 'invalid_headers', 'Callback headers must be an object');
  }
  const normalized = Object.create(null);
  for (const [name, value] of Object.entries(headers)) {
    const lower = name.toLowerCase();
    if (FORBIDDEN_HEADERS.has(lower) || Object.hasOwn(normalized, lower) || typeof value !== 'string') {
      throw failure('CALLBACK_HEADERS_INVALID', 'invalid_headers', 'Callback header is duplicated, reserved or not text');
    }
    try { validateHeaderName(name); validateHeaderValue(name, value); } catch {
      throw failure('CALLBACK_HEADERS_INVALID', 'invalid_headers', 'Invalid callback header');
    }
    normalized[lower] = value;
  }
  normalized.host = isIP(host) === 6 ? `[${host}]` : host;
  normalized['content-length'] = String(byteLength);
  normalized.connection = 'close';
  return normalized;
}

/**
 * Send already-signed MCP Events bytes. This transport does not create a
 * signature or retry: the caller must re-sign each attempt using the same body.
 *
 * allowedHosts is an array or Set of exact ASCII/punycode DNS names or IPs.
 * Omitted/empty means deny all; there are no inferred or wildcard destinations.
 * lookup is a trusted test seam with the dns.promises.lookup interface:
 *   async (hostname, { all: true, verbatim: true }) => [{ address, family }]
 * Every result must be public. A fresh connection is used for every call and
 * its lookup is pinned to one validated result, preventing DNS rebinding.
 * Resolves { status, body }, where body is bounded UTF-8 response text.
 */
export function createWebhookTransport({ allowedHosts = [], lookup = systemLookup } = {}) {
  if (!Array.isArray(allowedHosts) && !(allowedHosts instanceof Set)) {
    throw new TypeError('allowedHosts must be an array or Set of exact hostnames');
  }
  if (typeof lookup !== 'function') throw new TypeError('lookup must be a function');
  const allowlist = new Set([...allowedHosts].map(canonicalHost));

  return async function sendWebhook({ url: raw, headers = {}, body, onSent }) {
    if(onSent!==undefined&&typeof onSent!=='function')throw new TypeError('onSent must be a trusted callback');
    const { url, hostname } = callbackUrl(raw, allowlist);
    const bytes = requestBytes(body);
    const outgoingHeaders = requestHeaders(headers, hostname, bytes.length);

    return new Promise((resolve, reject) => {
      let settled = false;
      let request;
      let response;
      const finish = (error, result) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (error) {
          response?.destroy();
          request?.destroy();
          reject(error);
        } else {
          resolve(result);
        }
      };
      // Starts before DNS, and also bounds TLS, headers and the entire body.
      const timer = setTimeout(() => finish(failure(
        'CALLBACK_TIMEOUT', 'timeout', 'Callback exceeded its 10-second deadline',
      )), TIMEOUT_MS);

      (async () => {
        let records;
        if (isIP(hostname)) {
          records = [{ address: hostname, family: isIP(hostname) }];
        } else {
          try {
            records = await lookup(hostname, { all: true, verbatim: true });
          } catch (cause) {
            throw failure('CALLBACK_DNS_FAILED', 'dns_failed', 'Callback hostname lookup failed', cause);
          }
        }
        if (settled) return; // A late DNS answer must never trigger a request.
        if (!Array.isArray(records) || records.length === 0) {
          throw failure('CALLBACK_DNS_FAILED', 'dns_failed', 'Callback lookup returned no addresses');
        }
        if (records.some(record => !record || !isPublicAddress(record.address) ||
            record.family !== isIP(record.address))) {
          throw failure('CALLBACK_ADDRESS_BLOCKED', 'address_blocked', 'Callback resolved to a non-public or invalid address');
        }
        const { address, family } = records[0];
        request = https.request({
          protocol: 'https:',
          hostname,
          port: 443,
          method: 'POST',
          path: `${url.pathname}${url.search}`,
          headers: outgoingHeaders,
          agent: false, // No connection reuse or environmental proxy agent.
          family,
          autoSelectFamily: false,
          lookup: (_host, options, callback) => {
            // Never ask DNS again: this exact connection uses the checked IP.
            if (options.all) callback(null, [{ address, family }]);
            else callback(null, address, family);
          },
          servername: isIP(hostname) ? '' : hostname,
          rejectUnauthorized: true,
          checkServerIdentity: (_name, cert) => checkServerIdentity(hostname, cert),
          minVersion: 'TLSv1.2',
          maxHeaderSize: MAX_RESPONSE_BYTES,
        }, incoming => {
          response = incoming;
          if (settled) { incoming.destroy(); return; }
          // https.request never follows redirects; fail explicitly, too.
          if (incoming.statusCode >= 300 && incoming.statusCode < 400) {
            finish(failure('CALLBACK_REDIRECT_BLOCKED', 'redirect_blocked', 'Callback redirects are not allowed'));
            return;
          }
          const length = incoming.headers['content-length'];
          if (length !== undefined && (!/^\d+$/.test(length) || Number(length) > MAX_RESPONSE_BYTES)) {
            finish(failure('CALLBACK_RESPONSE_TOO_LARGE', 'response_too_large', 'Callback response exceeds 16 KiB'));
            return;
          }
          const chunks = [];
          let received = 0;
          incoming.on('data', chunk => {
            if (settled) return;
            received += chunk.length;
            if (received > MAX_RESPONSE_BYTES) {
              finish(failure('CALLBACK_RESPONSE_TOO_LARGE', 'response_too_large', 'Callback response exceeds 16 KiB'));
              return;
            }
            chunks.push(chunk);
          });
          incoming.once('end', () => {
            if (settled) return;
            if (!incoming.complete) {
              finish(failure('CALLBACK_RESPONSE_INCOMPLETE', 'response_incomplete', 'Callback response ended prematurely'));
              return;
            }
            finish(null, { status: incoming.statusCode, body: Buffer.concat(chunks, received).toString('utf8') });
          });
          incoming.once('error', cause => finish(failure('CALLBACK_REQUEST_FAILED', 'request_failed', 'Callback response failed', cause)));
          incoming.once('aborted', () => finish(failure('CALLBACK_RESPONSE_INCOMPLETE', 'response_incomplete', 'Callback response was aborted')));
          incoming.once('close', () => {
            if (!incoming.complete) finish(failure('CALLBACK_RESPONSE_INCOMPLETE', 'response_incomplete', 'Callback response closed prematurely'));
          });
        });
        request.once('error', cause => finish(failure('CALLBACK_REQUEST_FAILED', 'request_failed', 'Callback HTTPS request failed', cause)));
        request.once('finish',()=>{if(settled)return;try{onSent?.();}catch(cause){finish(failure('CALLBACK_AUDIT_FAILED','audit_failed','Callback send audit failed',cause));}});
        request.end(bytes);
      })().catch(error => finish(error));
    });
  };
}

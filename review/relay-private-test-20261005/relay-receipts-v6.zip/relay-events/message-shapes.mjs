const UUID=/^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$/;
export const isMessageId=value=>typeof value==='string'&&UUID.test(value);
const roomId=value=>typeof value==='string'&&/^[A-Za-z0-9._:-]{1,128}$/.test(value);
const scopeId=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,80}$/.test(value);
export function messageLink(value,owner){
 if(!value||typeof value!=='object'||Array.isArray(value)||!['private','public'].includes(value.visibility)||!isMessageId(value.id)||!isMessageId(value.senderId))throw new TypeError('Invalid message linkage');
 const keys=value.visibility==='private'?'createdAt,id,recipientId,senderId,visibility':'createdAt,id,senderId,visibility,workspaceId';
 if(Object.keys(value).filter(k=>k!=='roomId').sort().join(',')!==keys||(value.roomId!==undefined&&!roomId(value.roomId)))throw new TypeError('Unexpected message linkage fields');
 if(value.visibility==='private'&&(!isMessageId(value.recipientId)||value.senderId.toLowerCase()===value.recipientId.toLowerCase()||value.recipientId.toLowerCase()!==owner))throw new TypeError('Message is not addressed to this recipient');
 if(value.visibility==='public'&&!scopeId(value.workspaceId))throw new TypeError('Invalid workspace audience');
 if(typeof value.createdAt!=='string'||!/(?:Z|[+-]\d{2}:\d{2})$/.test(value.createdAt)||!Number.isFinite(Date.parse(value.createdAt)))throw new TypeError('Invalid source message timestamp');
 return {id:value.id.toLowerCase(),senderId:value.senderId.toLowerCase(),visibility:value.visibility,...(value.visibility==='private'?{recipientId:value.recipientId.toLowerCase()}:{workspaceId:value.workspaceId}),createdAt:new Date(value.createdAt).toISOString(),...(value.roomId!==undefined?{roomId:value.roomId}:{})};
}
export const messageSourceId=link=>link.visibility==='private'?'dm:'+link.id:'public:'+link.workspaceId+':'+link.id;
export function checkedMessage(value,link){
 if(!value||typeof value!=='object'||typeof value.id!=='string'||typeof value.senderId!=='string'||value.id.toLowerCase()!==link.id||value.senderId.toLowerCase()!==link.senderId||typeof value.body!=='string'||!value.body.trim()||[...value.body].length>12000||Buffer.byteLength(value.body)>48000||typeof value.createdAt!=='string'||Date.parse(value.createdAt)!==Date.parse(link.createdAt))throw new TypeError('Message does not match the authorized source linkage');
 const recipient=value.recipientId??(Array.isArray(value.recipientIds)&&value.recipientIds.length===1?value.recipientIds[0]:undefined);
 if(link.visibility==='private'&&(value.visibility!=='private'||typeof recipient!=='string'||recipient.toLowerCase()!==link.recipientId))throw new TypeError('Message recipient mismatch');
 if(link.visibility==='public'&&(value.visibility!=='public'||value.workspaceId!==link.workspaceId))throw new TypeError('Message workspace mismatch');
 if((value.roomId!==undefined&&!roomId(value.roomId))||(link.roomId!==undefined&&value.roomId!==link.roomId)||(value.replyToMessageId!==undefined&&value.replyToMessageId!==null&&!isMessageId(value.replyToMessageId)))throw new TypeError('Invalid source reply context');
 return {...link,...(value.roomId!==undefined?{roomId:value.roomId}:{}),...(value.replyToMessageId!==undefined?{replyToMessageId:value.replyToMessageId}:{}),body:value.body,audience:link.visibility==='private'?{kind:'participants',participantIds:[link.senderId,link.recipientId],managerAuditAccess:true}:{kind:'workspace',workspaceId:link.workspaceId}};
}

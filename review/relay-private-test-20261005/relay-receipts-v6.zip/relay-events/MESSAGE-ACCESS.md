# Message fetch, receipts and audience preparation

This is a local, disabled-by-default enhancement of the previously validated v4 source. It creates no account link, token, grant, backend schema, deployment, live subscription, external message, or ChatGPT conversation mirror. Relay chat history remains in Relay only.

## Current source facts and boundaries

Reviewed current repository main `56c47abe01d807a52cde82ebc46d7038ae36cdcb` on 2026-10-05. `backend/handler.mjs` exposes `dm.thread` with `participantA`, `participantB`, optional `beforeId`; `dm.read` is a separate mutation. The SQL returns up to 50 thread messages in oldest-first order within each page. The v4 direct MCP contract exposes the equivalent `relay_fast_thread(recipient_id,before_id?)`. There is no current single-message-by-ID backend endpoint, so `createRelayThreadMessageReader` performs a bounded authorized thread lookup and never marks read.

Private conversations retain the current rule: their two participants and the manager may inspect them; other agents may not. The latest user clarification explicitly preserves manager audit access. The manager is not added to ping recipients merely because they can audit. Workspace-public messages are visible to all workspace members; visibility and notification targeting are separate. Nothing here makes data public on the internet.

Browser-only account linking is a separate preparation pinned by its owner to controller `b568da1ce0fde90d49a51e73f3ae90cc23c0732a`. This package's existing integration tests remain pinned to the v4 controller fixture base `7d646385...`; no compatibility with the new linking slice is claimed. Its browser:control token cannot be reused as a message credential. A separate explicitly authorized `relay:read` capability and current source authorization must be linked before message tools are enabled. Sending/replying separately requires `relay:write` (and read for reply target validation).

## Stored message correlation and event metadata

The trusted incoming-message source adapter may pass `message` to `engine.enqueue`:

- Private: `{id,senderId,recipientId,visibility:'private',createdAt}`. Work owner must equal the actual recipient. Source ID must be `dm:<message UUID>`.
- Public: `{id,senderId,workspaceId,visibility:'public',createdAt}`. Source ID must be `public:<workspaceId>:<message UUID>`. Source authorization must validate the explicitly targeted agent's membership. Enqueue one work item only for each explicitly intended wake target; do not derive targets from visibility.

IDs and source timestamp are persisted atomically with work in the existing reference store. Duplicate source IDs return the same work; changed linkage under an existing ID conflicts. Source IDs, recipients and visibility come from trusted persistent source records, never an incoming webhook body alone.

Events carry message/work IDs, Public/Private visibility, sender ID and either separate private participant IDs and the sole notification recipient ID, or the workspace ID. `participant_ids` is visibility metadata; `recipient_ids` contains only the intended private ping recipient, never the sender or manager merely for auditing. They never carry the full body, fetch receipt, signing secret or credential. The event's agent filter still controls the sole target connection. Public visibility adds no implicit broadcast or manager wake.

## Timestamp semantics

`relay_work_status` delivery entries now contain a bounded `attemptLog`:

- `attemptedAt`: server started that delivery attempt.
- `sentAt`: HTTPS request emitted its local `finish` event, meaning request bytes were handed off to the local transport. This is not remote receipt. Null means the transport did not confirm that stage.
- `completedAt` and `status`: server observed the HTTP outcome. A network/timeout/crash remains `unknown`; it is not fabricated as received.
- `serviceAcceptedAt`: server observed a 2xx acceptance response. This is the sender-side observation time, not a signed remote clock timestamp or proof an agent read anything.
- `agentAcknowledgedAt`: separately recorded when the authorized agent explicitly acknowledges a recently fetched message.

Delivery-level `sentAt` and `serviceAcceptedAt` are first observed timestamps for that event generation; the per-attempt log retains retries. Retry event IDs are unchanged; recovery generations get their own IDs. An interrupted in-flight record becomes unknown on retry. Late transport callbacks cannot overwrite newer queue state. All times are server epoch milliseconds; source `messageCreatedAt` is ISO 8601. Clock skew between source and receiver is possible.

`messageFetchedAt` means the server prepared the authorized source result, not that a human read it. Fetching, webhook acceptance, acknowledging, claiming, running and finishing are distinct. Acknowledgment neither marks the Relay DM read nor changes work to done.

## Explicit opt-in fetch and acknowledgment

`createMessageAccess()` returns undefined by default. With `enabled:true`, it requires:

- `engine`: same durable event engine.
- `authorizeRead({principal,agent_id,message,context,scope:'relay:read'})`: verifies the live separate read capability, exact account/agent binding and recipient/workspace membership. It must return exactly true and is rechecked after source fetch.
- `sourcePolicy({principal,agent_id,context})`: trusted attestation of the reviewed, deployed source contract. It must declare `contractVersion:'relay-message-source/1'`, a nonempty `sourceRevision`, `historyDurable:true`, `explicitAudienceMetadata:true`, and the applicable `privateParticipantsAndManagerOnly:true` or `publicWorkspaceOnly:true`. This is not a caller-set flag and cannot replace real backend enforcement.
- `readMessage({principal,agent_id,message,context})`: an already-authorized source reader. It receives only IDs/linkage and trusted host context, never a supplied URL or credential. It must enforce its own timeout/cancellation and source session checks.

Pass the returned capability as `messageAccess` to `installControllerEvents`. Only then are two extra tools registered:

- `relay_message_fetch({agent_id,work_id,message_id})` returns the validated full message, explicit audience, `fetchedAt` and an opaque `fetch_receipt`.
- `relay_message_acknowledge({agent_id,work_id,message_id,fetch_receipt})` records a separate explicit agent receipt and returns its timestamp. The receipt is bound to the exact owner/agent/work/message and expires after ten minutes by default. Only its hash is stored. A repeated successful acknowledgment with its original proof returns the same timestamp.

The standard v4 tools remain unchanged; default count stays 13, explicit message capability raises it to 15. Both new tools advertise browser:control plus relay:read when mounted in the controller host. The acknowledgment writes only this local receipt ledger and does not invoke `dm.read` or require an unapproved source write scope.

Private fetch is for the actual message recipient, not an arbitrary account named in a ping. Source output is checked against the correlated message ID, sender, recipient/workspace and timestamp. Bodies are bounded and treated as untrusted data. No body is retained in the event database or callback payload. A returned proof must not be placed in DOM, browser storage, logs or public history.

## Manager receipt view without manager pings

The optional `authorizeAudit` hook enables the capability's trusted `receipts(viewer,{work_id,message_id},context)` method. A Relay backend manager-view route must derive `viewer` from its own authenticated session, verify current manager role and workspace/message access, and then call this method. There is no worker MCP audit tool and no caller-selectable manager override.

It returns redacted linkage, queue/source/fetch/ack timestamps and delivery attempt status only. It returns no body, callback URL, signing secret, claim token or fetch proof. It performs no enqueue, send, acknowledgment or notification. The method is denied if the audit hook is absent. Reading receipts is not evidence the intended recipient acknowledged.

## Sending, replies and Relay UI labels

The sibling backend implementation now supplies real messages.* SQL/Edge routes, durable audience/reply/dedup guarantees and an explicitly targeted outbox. The authenticated source adapter and send/reply capabilities pass real local round trips. They are not silently installed live. Legacy public web-composer posts remain on their old path; new connection-originated Public sends and private web sends use the canonical source. Actual account linking and deployment remain required.

The existing manager read policy is preserved. Any earlier participant-only-manager-exclusion draft was superseded by the user's clarification and must not be applied. No new message is copied into the user's ChatGPT conversation.

## Tests and activation gaps

Run `npm ci --ignore-scripts` and `npm test` in this directory. Tests cover recipient/correlation authorization, forged or expired receipts, revocation during fetch, no body persistence, public workspace bounds, no implicit manager wake, timestamp/retry/crash states, separate manager audit, bounded thread pagination, transport flush callbacks, and default-disabled/explicitly enabled MCP tools.

Still unimplemented/unverified live: source outbox pump wiring/scheduling, an actual separately linked Relay read/write grant, deployed source-policy attestation, manager receipt UI mount, legacy public-web outbox integration, patch application, current-controller integration, and live ChatGPT wake/fetch/ack. Public/full-message reads and send/reply source implementation are complete locally and tested against the SQL/Edge fixture. No database, account link, grant or remote deployment was changed.

Optional `messageSend` installs the fixed send/reply capability descriptors; when both read and send capabilities are supplied the combined host has 17 tools, while omission preserves the 13-tool default. No grant is created by installation.

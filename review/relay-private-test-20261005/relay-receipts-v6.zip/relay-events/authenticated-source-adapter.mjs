import {SOURCE_CONTRACT, checkedSourceRecord} from './send-capability.mjs';

const UUID = /^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$/;
const ID = /^[A-Za-z0-9._:-]{1,128}$/;
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
const sameBinding = (left, right) => ['workspaceId', 'accountId', 'agentId', 'runId'].every(key => left?.[key] === right?.[key]);
const clone = value => structuredClone(value);
function fail() { throw new Error('The authenticated Relay source request could not be authorized or verified.'); }
function normalizeBinding(value) {
  if (!plain(value) || Object.keys(value).sort().join(',') !== 'accountId,agentId,runId,workspaceId' ||
    typeof value.workspaceId !== 'string' || !ID.test(value.workspaceId) || typeof value.runId !== 'string' || !ID.test(value.runId) ||
    typeof value.accountId !== 'string' || !UUID.test(value.accountId) || typeof value.agentId !== 'string' || !UUID.test(value.agentId)) fail();
  return Object.freeze({...value, accountId: value.accountId.toLowerCase(), agentId: value.agentId.toLowerCase()});
}

/**
 * Concrete source bridge for the additive local backend API. The host injects
 * withAuthorizedRelay; no browser storage, session import, login, URL, token,
 * grant creation, or implicit authorization exists here.
 *
 * withAuthorizedRelay(context, {scopes,binding}, callback) must resolve the SAME
 * already-authorized Relay connection and check its live grant/run. It invokes
 * callback({binding, scopes, call}), where call is the bound Relay API method.
 * The callback facade contains no credential and is never exposed to a model.
 */
export function createAuthenticatedRelaySource({binding, withAuthorizedRelay} = {}) {
  const bound = normalizeBinding(binding);
  if (typeof withAuthorizedRelay !== 'function') throw new TypeError('An explicit authorized Relay connection hook is required.');
  async function request(context, scopes, action, data) {
    if (!Array.isArray(scopes) || scopes.length < 1 || scopes.some(scope => !['relay:read', 'relay:write'].includes(scope))) fail();
    let callbackCount = 0;
    try {
      const result = await withAuthorizedRelay(context, {scopes: [...scopes], binding: clone(bound)}, async authorized => {
        if (++callbackCount !== 1 || !plain(authorized) || typeof authorized.call !== 'function' ||
          !Array.isArray(authorized.scopes) || !scopes.every(scope => authorized.scopes.includes(scope)) ||
          !sameBinding(normalizeBinding(authorized.binding), bound)) fail();
        return await authorized.call(action, clone(data));
      });
      if (callbackCount !== 1) fail();
      return result;
    } catch { fail(); }
  }
  async function sourcePolicy(context, {scopes = ['relay:read']} = {}) {
    const result = await request(context, scopes, 'messages.capabilities', {});
    const fields = ['contractVersion', 'sourceRevision', 'historyDurable', 'explicitAudienceMetadata', 'stableClientIdDedup',
      'notificationsExplicitRecipientsOnly', 'publicWorkspaceOnly', 'privateParticipantsAndManagerOnly', 'atomicSameAudienceReplies'];
    if (!plain(result) || result.contractVersion !== SOURCE_CONTRACT || typeof result.sourceRevision !== 'string' ||
      !ID.test(result.sourceRevision) || fields.slice(2).some(key => typeof result[key] !== 'boolean')) fail();
    if (result.workspaceId !== bound.workspaceId || typeof result.roomId !== 'string' || !ID.test(result.roomId)) fail();
    return {...Object.fromEntries(fields.map(key => [key, result[key]])),
      workspaceId: result.workspaceId, roomId: result.roomId};
  }
  async function callSource(context, input) {
    if (!plain(input) || !sameBinding(normalizeBinding(input.binding), bound)) fail();
    if (input.action === 'getMessage') {
      if (Object.keys(input).sort().join(',') !== 'action,binding,messageId' || typeof input.messageId !== 'string' || !UUID.test(input.messageId)) fail();
      const result = await request(context, ['relay:read'], 'messages.get', {messageId: input.messageId.toLowerCase()});
      if (result?.status === 'not_found') return {status: 'not_found'};
      const message = checkedSourceRecord(result?.message, bound);
      if (message.id !== input.messageId.toLowerCase()) fail();
      return {message};
    }
    if (input.action === 'sendMessage') {
      if (Object.keys(input).sort().join(',') !== 'action,binding,command' || !plain(input.command) ||
        input.command.senderId !== bound.accountId || input.command.workspaceId !== bound.workspaceId) fail();
      // The capability validates the command before entering this bridge. The
      // backend repeats complete input, identity, audience, dedup and reply checks.
      return request(context, input.command.replyToMessageId === null ? ['relay:write'] : ['relay:read', 'relay:write'],
        'messages.send', {command: clone(input.command)});
    }
    fail();
  }
  async function readMessage({principal, agent_id, message, context} = {}) {
    if (principal !== bound.accountId || agent_id !== bound.agentId || !plain(message) || typeof message.id !== 'string') fail();
    const result = await callSource(context, {action: 'getMessage', binding: clone(bound), messageId: message.id});
    const record = result?.message;
    if (!record) fail();
    // Preserve source-verified room/reply/audience metadata so the authorized
    // caller can compose a reply without a browser or guessed room identifier.
    return clone(record);
  }
  async function listNotifications(context, {limit = 100} = {}) {
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) fail();
    const result = await request(context, ['relay:read'], 'messages.notifications', {limit});
    if (!plain(result) || !Array.isArray(result.notifications) || result.notifications.length > limit || typeof result.hasMore !== 'boolean') fail();
    const seen = new Set();
    const notifications = result.notifications.map(value => {
      if (!plain(value) || !['id', 'messageId', 'recipientId'].every(key => typeof value[key] === 'string' && UUID.test(value[key])) ||
        value.recipientId.toLowerCase() !== bound.accountId || typeof value.createdAt !== 'string' ||
        !/(?:Z|[+-]\d{2}:\d{2})$/.test(value.createdAt) || !Number.isFinite(Date.parse(value.createdAt))) fail();
      const id = value.id.toLowerCase(); if (seen.has(id)) fail(); seen.add(id);
      // Deliberately project no body, credential, display name, or arbitrary
      // source extension into the handoff outbox result.
      return {id, messageId: value.messageId.toLowerCase(), recipientId: bound.accountId, createdAt: value.createdAt};
    });
    return {notifications, hasMore: result.hasMore};
  }
  async function acknowledgeNotificationHandoff(context, {notificationId} = {}) {
    if (typeof notificationId !== 'string' || !UUID.test(notificationId)) fail();
    const normalizedId = notificationId.toLowerCase();
    const result = await request(context, ['relay:write'], 'messages.notifications.ack', {notificationId: normalizedId});
    if (!plain(result) || typeof result.notificationId !== 'string' || result.notificationId.toLowerCase() !== normalizedId || typeof result.handoffAcknowledgedAt !== 'string' ||
      !/(?:Z|[+-]\d{2}:\d{2})$/.test(result.handoffAcknowledgedAt) || !Number.isFinite(Date.parse(result.handoffAcknowledgedAt))) fail();
    // This acknowledges only durable engine handoff. Never infer message read,
    // an agent's fetch receipt, or an agent's explicit acknowledgment from it.
    return {notificationId: normalizedId, handoffAcknowledgedAt: result.handoffAcknowledgedAt};
  }
  return Object.freeze({sourcePolicy, callSource, readMessage, listNotifications, acknowledgeNotificationHandoff});
}

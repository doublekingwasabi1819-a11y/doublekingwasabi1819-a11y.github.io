/** Framework-free authenticated JSON-RPC handler. No CORS/browser credentials enabled.
 * authenticate must verify OAuth issuer/audience/expiry/revocation and return a stable principal.
 * Trusted reverse proxy must enforce TLS, Host/Origin rules, request timeouts, rate limits.
 */
export function createHttpHandler({dispatch,authenticate}={}) {
 if(typeof dispatch!=='function'||typeof authenticate!=='function')throw new Error('Authentication and dispatch required');
 return async (req,res)=>{
  const send=(status,value)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value));};
  if(req.method!=='POST'||req.url!=='/mcp')return send(404,{error:'Not found'});
  let principal;try{principal=await authenticate(req);}catch{}
  if(typeof principal!=='string'||!principal){res.setHeader('WWW-Authenticate','Bearer');return send(401,{error:'Unauthorized'});}
  if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']??''))return send(415,{error:'JSON required'});
  let bytes=0,chunks=[];
  try {for await (const chunk of req){bytes+=chunk.length;if(bytes>262144){send(413,{error:'Request too large'});return;}chunks.push(chunk);}
   let request;try{request=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{return send(400,{error:'Invalid JSON'});}
   send(200,await dispatch(principal,request));
  }catch{if(!res.headersSent)send(500,{error:'Request failed'});else res.destroy();}
 };
}

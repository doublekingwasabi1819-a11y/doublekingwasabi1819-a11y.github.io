import test from 'node:test';
import assert from 'node:assert/strict';
import {Client,StreamableHTTPClientTransport,fromJsonSchema} from '@modelcontextprotocol/client';
import {fromJsonSchema as serverSchema} from '@modelcontextprotocol/server';
import {createControllerHttp} from './fixtures/controller/http-server.mjs';
import {createControllerMcp} from './fixtures/controller/mcp-adapter.mjs';
import {createBrowserController} from './fixtures/controller/core.mjs';
import {relayBrowserToolDescriptors,relayDirectToolDescriptors,installRelayToolMetadata} from './fixtures/controller/mcp-tool-metadata.mjs';
import {installControllerEvents} from '../controller-adapter.mjs';
import {RelayEvents} from '../core.mjs';
import {createMessageAccess} from '../message-access.mjs';
import {createRelayMessageCapability} from '../send-capability.mjs';
const owner='45b9d8ad-9609-458e-8c41-c6ec715ff50b',agent='e9d7b623-9dab-4f45-885a-24c38f5a5a49',other='bf907836-128a-4e94-ae6a-1b360a9b65bf';
const secret='whsec_'+Buffer.alloc(32,7).toString('base64');
const resultSchema=fromJsonSchema({type:'object',additionalProperties:true});

async function fixture(t,{enabled=true,identityOverride,messageReader,messageSender}={}) {
 let state={subscriptions:{},work:{},deliveries:{},paused:{}},revoked=false,scopes=true,cacheId='lease_first',clock=Date.now();
 const context=Object.freeze({reference:'host-owned'}),binding={workspaceId:'integration-fixture',accountId:owner,agentId:agent,runId:'fixture-run'},directCalls=[],callbackCalls=[],requestAuth=[],wire=[];
 const core=createBrowserController({authorize:async c=>{if(c!==context||revoked)throw new Error('private-auth-fault');return binding;},authorizeAction:async()=>true,createDriver:async()=>({
  async observe(){return {title:'Controller integration fixture',status:'Ready',targets:[{id:'nav',role:'button',name:'Fixture navigation'}]};},
  async click(){},async fill(){},async screenshot(){return {mimeType:'image/png',data:'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='};},async close(){}
 })});
 const engine=new RelayEvents({store:{read:()=>structuredClone(state),write:s=>{state=structuredClone(s);}},now:()=>clock,authorize:async({principal,agent_id})=>!revoked&&principal===owner&&agent_id===agent,transport:async request=>{callbackCalls.push(request);const body=JSON.parse(request.body);return {status:200,body:body.type==='verification'?{challenge:body.challenge}:{}};}});
 const host=createControllerHttp({controller:core,enableEvents:enabled,authenticate:async request=>{if(request.headers.get('authorization')!=='Bearer fixture-only'||revoked)throw new Error('private-token');return {principalId:cacheId,requestContext:context};},serverFactory:requestContext=>{
  const server=createControllerMcp({controller:core,requestContext,target:'relay'});
  for(const descriptor of relayDirectToolDescriptors)server.registerTool(descriptor.name,{...descriptor,inputSchema:serverSchema(descriptor.inputSchema)},async args=>{directCalls.push({name:descriptor.name,args,context:requestContext});return {content:[{type:'text',text:descriptor.name}],structuredContent:{fixtureTool:descriptor.name}};});
  const existingTools=[...relayBrowserToolDescriptors,...relayDirectToolDescriptors];installRelayToolMetadata(server,existingTools);
  if(enabled)installControllerEvents({server,engine,existingTools,...(messageSender?{messageSend:messageSender}:{}),...(messageReader?{messageAccess:createMessageAccess({enabled:true,engine,sourcePolicy:async()=>({contractVersion:'relay-message-source/1',sourceRevision:'fixture-v1',historyDurable:true,explicitAudienceMetadata:true,privateParticipantsAndManagerOnly:true}),authorizeRead:async()=>scopes&&!revoked,readMessage:messageReader})}:{}),withRequestContext:async callback=>{if(revoked)throw new Error('private-revocation');const value=await callback(context,identityOverride??binding);if(revoked)throw new Error('private-revocation');return value;},authorizeRequest:async data=>{requestAuth.push(data);return scopes;}});
  return server;
 }});
 const {url}=await host.listen();const clients=[];
 t.after(async()=>{await Promise.all(clients.map(c=>c.close()));await host.close();await core.shutdown();});
 async function connect(legacy=false){const c=new Client({name:'relay-events-integration-test',version:'1'},{versionNegotiation:{mode:legacy?'legacy':{pin:'2026-07-28'}}});clients.push(c);await c.connect(new StreamableHTTPClientTransport(new URL(url),{requestInit:{headers:{authorization:'Bearer fixture-only'}},fetch:async(input,init)=>{let request;try{request=await new Request(input,init).clone().json();}catch{}const response=await fetch(input,init);try{const raw=await response.clone().text();const json=response.headers.get('content-type')?.includes('text/event-stream')?raw.split('\n').filter(l=>l.startsWith('data: ')).map(l=>JSON.parse(l.slice(6))).at(-1):JSON.parse(raw);wire.push({request,response:json});}catch{}return response;}}),legacy?{prior:{kind:'legacy'}}:undefined);return c;}
 return {engine,host,url,connect,directCalls,callbackCalls,requestAuth,wire,revoke:()=>{revoked=true;},denyScopes:()=>{scopes=false;},rotateGrant:()=>{cacheId='lease_replacement';},advance:ms=>{clock+=ms;},state:()=>structuredClone(state)};
}
const subscription={name:'relay.work.available',arguments:{agent_id:agent},delivery:{mode:'webhook',url:'https://callback.example/events',secret}};
const eventRequest=(client,method,params={})=>client.request({method,params},resultSchema);

for(const legacy of [false,true])test(`${legacy?'legacy':'modern'} SDK client retains every existing tool plus work tools`,async t=>{
 const f=await fixture(t),client=await f.connect(legacy),list=await client.listTools();
 assert.equal(list.tools.length,13);const rawList=f.wire.findLast(x=>x.request?.method==='tools/list').response.result;for(const descriptor of [...relayBrowserToolDescriptors,...relayDirectToolDescriptors])assert.deepEqual(rawList.tools.find(t=>t.name===descriptor.name).securitySchemes,descriptor.securitySchemes);for(const descriptor of [...relayBrowserToolDescriptors,...relayDirectToolDescriptors]){const actual=list.tools.find(d=>d.name===descriptor.name);assert.deepEqual(actual._meta.securitySchemes,descriptor._meta.securitySchemes);assert.deepEqual(actual.inputSchema,descriptor.inputSchema);}
 const opened=await client.callTool({name:'browser_open',arguments:{}});assert.equal(opened.isError,undefined,JSON.stringify(opened));const sessionId=opened.structuredContent.sessionId;
 const observed=await client.callTool({name:'browser_observe',arguments:{session_id:sessionId}});assert.equal(observed.isError,undefined);
 const clicked=await client.callTool({name:'browser_click',arguments:{session_id:sessionId,observation_id:observed.structuredContent.observation.id,target_id:'nav'}});assert.equal(clicked.isError,undefined);
 const screenshot=await client.callTool({name:'browser_screenshot',arguments:{session_id:sessionId,observation_id:clicked.structuredContent.observation.id}});assert.equal(screenshot.content[0].type,'image');
 assert.deepEqual((await client.callTool({name:'browser_close',arguments:{session_id:sessionId}})).structuredContent,{closed:true});
 const inputs={relay_fast_identity:{},relay_fast_inbox:{},relay_fast_thread:{recipient_id:other},relay_fast_send:{recipient_id:other,body:'Fixture only',client_id:'9c9d0f4e-cf5b-4f0b-b760-1cb256fd1b34'},relay_fast_mark_read:{message_ids:[]}};
 for(const [name,args]of Object.entries(inputs))assert.equal((await client.callTool({name,arguments:args})).structuredContent.fixtureTool,name);
 assert.equal(f.directCalls.length,5);
 const work=await f.engine.enqueue(owner,{agent_id:agent,source_id:'fixture-message'});
 const status=await client.callTool({name:'relay_work_status',arguments:{agent_id:agent}});assert.equal(status.structuredContent.work[0].id,work.id);
 const claimed=await client.callTool({name:'relay_work_transition',arguments:{agent_id:agent,work_id:work.id,state:'claimed'}});assert.equal(claimed.structuredContent.status,'claimed');
 assert.equal((await client.callTool({name:'relay_work_pause',arguments:{agent_id:agent,paused:true}})).structuredContent.paused,true);
 assert.equal((await client.callTool({name:'relay_work_transition',arguments:{agent_id:agent,work_id:work.id,state:'done',claim_token:claimed.structuredContent.claim_token}})).structuredContent.status,'done');
});

test('modern discovery and same authenticated endpoint subscription lifecycle use stable owner',async t=>{
 const f=await fixture(t),client=await f.connect();
 assert.ok(f.wire.find(x=>x.request.method==='server/discover')?.response.result.capabilities.events,JSON.stringify(f.wire));
 const catalog=await eventRequest(client,'events/list');assert.equal(catalog.events[0].name,'relay.work.available');
 const sub=await eventRequest(client,'events/subscribe',subscription);assert.match(sub.id,/^sub_/);
 assert.equal(Object.values(f.state().subscriptions)[0].owner,owner);
 const work=await f.engine.enqueue(owner,{agent_id:agent,source_id:'incoming-message'});assert.equal((await f.engine.tick()).sent,1);
 assert.equal(JSON.parse(f.callbackCalls.at(-1).body).data.work_id,work.id);
 f.rotateGrant();const refreshed=await f.connect();assert.equal((await eventRequest(refreshed,'events/subscribe',subscription)).id,sub.id);
 await eventRequest(refreshed,'events/unsubscribe',{...subscription,delivery:{mode:'webhook',url:subscription.delivery.url}});
 assert.equal(Object.keys(f.state().subscriptions).length,0);
});

test('legacy tools remain available while event subscription is rejected',async t=>{const f=await fixture(t),client=await f.connect(true);await assert.rejects(eventRequest(client,'events/subscribe',subscription),/2026-07-28/);assert.equal(Object.keys(f.state().subscriptions).length,0);});

test('unauthenticated, wrong-agent, unscoped and revoked calls fail closed',async t=>{
 const f=await fixture(t);
 for(const method of ['events/list','events/subscribe','tools/list']){const response=await fetch(f.url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params:method==='events/subscribe'?subscription:{}})});assert.equal(response.status,401);}
 const client=await f.connect();await assert.rejects(eventRequest(client,'events/subscribe',{...subscription,arguments:{agent_id:other}}));assert.equal(f.callbackCalls.length,0);
 assert.equal((await client.callTool({name:'relay_work_status',arguments:{agent_id:other}})).isError,true);
 const bad=await client.callTool({name:'relay_work_status',arguments:{agent_id:agent,principalId:owner}});assert.equal(bad.isError,true);
 f.denyScopes();await assert.rejects(eventRequest(client,'events/subscribe',subscription));assert.equal((await client.callTool({name:'relay_work_pause',arguments:{agent_id:agent,paused:true}})).isError,true);assert.equal(f.callbackCalls.length,0);
 f.revoke();await assert.rejects(client.listTools(),/Authentication is required/);
});

test('lease/cache hashes cannot substitute for stable anchored account UUID',async t=>{const f=await fixture(t,{identityOverride:{accountId:'oauth_lease_hash',agentId:agent}}),client=await f.connect();await assert.rejects(eventRequest(client,'events/subscribe',subscription));assert.equal(f.callbackCalls.length,0);});

test('opt-in disabled leaves ten tools and rejects event routes',async t=>{const f=await fixture(t,{enabled:false}),client=await f.connect();assert.equal((await client.listTools()).tools.length,10);assert.equal(client.getServerCapabilities().events,undefined);await assert.rejects(eventRequest(client,'events/list'),/Unsupported MCP request/);});

test('trusted server from a separate SDK installation is accepted without constructor coupling',async t=>{
 const {mkdtempSync,cpSync,rmSync}=await import('node:fs');const {dirname,join}=await import('node:path');const {fileURLToPath,pathToFileURL}=await import('node:url');
 const dir=mkdtempSync(join(dirname(fileURLToPath(import.meta.url)),'.sdk-copy-'));t.after(()=>rmSync(dir,{recursive:true,force:true}));
 const source=dirname(dirname(fileURLToPath(import.meta.resolve('@modelcontextprotocol/server'))));cpSync(source,dir,{recursive:true});
 const {McpServer:OtherServer,fromJsonSchema:otherSchema}=await import(pathToFileURL(join(dir,'dist/index.mjs')).href);
 const server=new OtherServer({name:'separate-sdk-fixture',version:'1'});
 const descriptors=[...relayBrowserToolDescriptors,...relayDirectToolDescriptors];for(const d of descriptors)server.registerTool(d.name,{inputSchema:otherSchema(d.inputSchema)},async()=>({content:[]}));
 const f=await fixture(t);
 const installed=installControllerEvents({server,engine:f.engine,existingTools:descriptors,withRequestContext:callback=>callback({}, {accountId:owner,agentId:agent}),authorizeRequest:async()=>true});
 assert.equal(installed.toolNames.length,3);assert.throws(()=>installControllerEvents({server,engine:f.engine,existingTools:descriptors,withRequestContext:async()=>{},authorizeRequest:async()=>true}),/once before/);
 await server.close();
});

test('separate authorized message capability adds fetch/ack without using browser or marking source read',async t=>{
 let reads=0;const message={id:'9c9d0f4e-cf5b-4f0b-b760-1cb256fd1b34',senderId:other,recipientId:owner,visibility:'private',createdAt:'2026-10-05T01:00:00Z'},text='Fixture private message';
 const f=await fixture(t,{messageReader:async({context})=>{reads++;assert.ok(context.reference);assert.equal(context.binding.accountId,owner);return {...message,body:text};}}),client=await f.connect();
 const tools=(await client.listTools()).tools;assert.equal(tools.length,15);for(const name of ['relay_message_fetch','relay_message_acknowledge'])assert.deepEqual(tools.find(t=>t.name===name)._meta.securitySchemes,[{type:'oauth2',scopes:['browser:control','relay:read']}]);
 const w=await f.engine.enqueue(owner,{agent_id:agent,source_id:'dm:'+message.id,message});const a={agent_id:agent,work_id:w.id,message_id:message.id};
 const fetched=await client.callTool({name:'relay_message_fetch',arguments:a});assert.equal(fetched.structuredContent.message.body,text);assert.equal(fetched.structuredContent.message.audience.managerAuditAccess,true);assert.equal(f.state().work[w.id].agentAcknowledgedAt,undefined);
 const receipt=await client.callTool({name:'relay_message_acknowledge',arguments:{...a,fetch_receipt:fetched.structuredContent.fetch_receipt}});assert.equal(typeof receipt.structuredContent.agentAcknowledgedAt,'number');assert.equal(reads,1);assert.equal(f.directCalls.length,0);
 f.denyScopes();assert.equal((await client.callTool({name:'relay_message_fetch',arguments:a})).isError,true);assert.equal(reads,1);
});
test('message fetch and ack tools stay absent without explicit message capability',async t=>{const f=await fixture(t),client=await f.connect();assert.equal((await client.listTools()).tools.some(t=>t.name.startsWith('relay_message_')),false);await assert.rejects(client.callTool({name:'relay_message_fetch',arguments:{agent_id:agent,work_id:'fake',message_id:other}}),/not found/);});

test('optional send/reply MCP tools preserve sender binding, scopes and uncertain outcomes',async t=>{
 const binding={workspaceId:'integration-fixture',accountId:owner,agentId:agent,runId:'fixture-run'},id='9c9d0f4e-cf5b-4f0b-b760-1cb256fd1b34';let writes=0,uncertain=false;
 const policy={contractVersion:'relay-message-source/1',sourceRevision:'fixture-ready',historyDurable:true,explicitAudienceMetadata:true,stableClientIdDedup:true,notificationsExplicitRecipientsOnly:true,privateParticipantsAndManagerOnly:true,publicWorkspaceOnly:true,atomicSameAudienceReplies:true};
 const sender=createRelayMessageCapability({enabled:true,binding,authorizeRelay:async(context,{scopes})=>{assert.equal(context.binding.accountId,owner);return {binding,scopes};},sourcePolicy:async()=>policy,callSource:async(_context,input)=>{if(input.action==='getMessage')return {message:{id,clientId:id,workspaceId:binding.workspaceId,roomId:'fixture-room',visibility:'public',senderId:other,recipientIds:[],notificationRecipientIds:[],participantIds:[],body:'Original',replyToMessageId:null,createdAt:'2026-10-05T01:00:00Z'}};writes++;if(uncertain)throw new Error('private-source-error');return {status:'persisted',historyStore:'relay-chat',message:{...input.command,id,createdAt:'2026-10-05T02:00:00Z'}};}});
 const f=await fixture(t,{messageSender:sender}),client=await f.connect(),tools=(await client.listTools()).tools;assert.equal(tools.length,15);assert.deepEqual(tools.find(t=>t.name==='relay_message_send')._meta.securitySchemes,[{type:'oauth2',scopes:['browser:control','relay:write']}]);assert.deepEqual(tools.find(t=>t.name==='relay_message_reply')._meta.securitySchemes,[{type:'oauth2',scopes:['browser:control','relay:read','relay:write']}]);
 const a={visibility:'private',room_id:'fixture-room',recipient_ids:[other],body:'Private fixture send',client_id:id};const sent=await client.callTool({name:'relay_message_send',arguments:a});assert.equal(sent.structuredContent.message.senderId,owner);assert.equal(sent.structuredContent.history.store,'relay-chat');assert.equal(writes,1);
 const conflict=await client.callTool({name:'relay_message_send',arguments:{...a,body:'Changed'}});assert.equal(conflict.isError,true);assert.equal(conflict.structuredContent.error.data.reason,'CONFLICT');
 const reply=await client.callTool({name:'relay_message_reply',arguments:{visibility:'public',room_id:'fixture-room',recipient_ids:[],body:'Public fixture reply',client_id:'7c9d0f4e-cf5b-4f0b-b760-1cb256fd1b34',reply_to_message_id:id}});assert.equal(reply.structuredContent.message.replyToMessageId,id);assert.deepEqual(reply.structuredContent.message.notificationRecipientIds,[]);
 uncertain=true;const result=await client.callTool({name:'relay_message_send',arguments:{...a,client_id:'6c9d0f4e-cf5b-4f0b-b760-1cb256fd1b34'}});assert.equal(result.isError,true);assert.equal(result.structuredContent.status,'uncertain');assert.ok(!JSON.stringify(result).includes('private-source-error'));assert.equal(writes,3);
});

import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import https from 'node:https';
import { isIP } from 'node:net';
import { PassThrough } from 'node:stream';
import test from 'node:test';
import { createWebhookTransport } from '../transport.mjs';

const HOST = 'callbacks.example.com';
const URL = `https://${HOST}/mcp-events/callback?tenant=one`;
const PUBLIC_V4 = '93.184.216.34';
const PUBLIC_V6 = '2606:4700:4700::1111';
const BODY = '{"type":"verification","challenge":"test-value"}';
const record = address => ({ address, family: isIP(address) });
const send = (transport, overrides = {}) => transport({ url: URL, body: BODY, ...overrides });
const config = (lookup = async () => [record(PUBLIC_V4)]) => ({ allowedHosts: [HOST], lookup });

// No test opens a socket or makes an actual callback. We exercise the exact
// https.request options and responses with the native test runner's mock seam.
function mockHttps(t, handle = ({ respond }) => respond(200, '{}')) {
  const requests = [];
  t.mock.method(https, 'request', (options, onResponse) => {
    const request = new EventEmitter();
    request.destroyed = false;
    request.destroy = () => { request.destroyed = true; return request; };
    request.end = bytes => {
      const call = {
        options, request, bytes,
        respond(status, body, headers = {}) {
          const response = new PassThrough();
          response.statusCode = status;
          response.headers = headers;
          response.complete = false;
          call.response = response;
          onResponse(response);
          if (body !== undefined && !response.destroyed) {
            response.complete = true;
            response.end(body);
          }
          return response;
        },
      };
      requests.push(call);
      queueMicrotask(() => handle(call));
    };
    return request;
  });
  return requests;
}

function forbidHttps(t) {
  return t.mock.method(https, 'request', () => { throw new Error('Unexpected network request'); });
}

const code = expected => error => error.code === expected;
const flush = async () => { for (let i = 0; i < 8; i += 1) await Promise.resolve(); };

test('omitted and empty allowlists deny every callback before DNS or HTTPS', async t => {
  const network = forbidHttps(t);
  let lookedUp = false;
  for (const options of [undefined, {}, { allowedHosts: [] }, { allowedHosts: new Set() }]) {
    const transport = createWebhookTransport({ ...options, lookup: async () => { lookedUp = true; return [record(PUBLIC_V4)]; } });
    await assert.rejects(send(transport), code('CALLBACK_NOT_ALLOWED'));
  }
  assert.equal(lookedUp, false);
  assert.equal(network.mock.callCount(), 0);
});

test('allowlist accepts exact hostnames only and snapshots the configuration', async t => {
  const requests = mockHttps(t);
  for (const allowedHosts of ['callbacks.example.com', ['*.example.com'], ['https://callbacks.example.com'], ['callbacks.example.com:443'], ['callbacks.example.com.'], [' callbacks.example.com']]) {
    assert.throws(() => createWebhookTransport({ allowedHosts }));
  }
  const allowedHosts = new Set(['CALLBACKS.EXAMPLE.COM']);
  const transport = createWebhookTransport({ ...config(), allowedHosts });
  allowedHosts.add('other.example.com');
  await assert.rejects(send(transport, { url: 'https://other.example.com/x' }), code('CALLBACK_NOT_ALLOWED'));
  await assert.rejects(send(transport, { url: 'https://sub.callbacks.example.com/x' }), code('CALLBACK_NOT_ALLOWED'));
  await assert.rejects(send(transport, { url: 'https://callbacks.example.com.evil.example/x' }), code('CALLBACK_NOT_ALLOWED'));
  await send(transport, { url: 'https://CALLBACKS.EXAMPLE.COM:443/path' });
  assert.equal(requests.length, 1);
});

test('rejects unsafe URL shapes without DNS or HTTPS', async t => {
  const network = forbidHttps(t);
  let lookups = 0;
  const transport = createWebhookTransport(config(async () => { lookups += 1; return [record(PUBLIC_V4)]; }));
  for (const url of [
    'http://callbacks.example.com/x', 'https://callbacks.example.com:444/x',
    'https://user:pass@callbacks.example.com/x', 'https://@callbacks.example.com/x',
    'https://callbacks.example.com/x#fragment', 'https://callbacks.example.com/x#',
    ' https://callbacks.example.com/x', 'https://call\tbacks.example.com/x',
    'https://callbacks.example.com\\evil/x', '//callbacks.example.com/x',
    'https:callbacks.example.com/x', 'https://callbacks.example.com./x',
    'https://[fe80::1%25eth0]/x', '', null,
  ]) {
    await assert.rejects(send(transport, { url }), undefined, String(url));
  }
  assert.equal(lookups, 0);
  assert.equal(network.mock.callCount(), 0);
});

test('local hostname aliases cannot be configured', () => {
  for (const host of ['localhost', 'api.localhost', 'printer.local', 'api.localdomain', 'service.internal', 'home.arpa', 'service.home.arpa']) {
    assert.throws(() => createWebhookTransport({ allowedHosts: [host] }), undefined, host);
  }
});

const NON_PUBLIC = [
  '0.0.0.0', '0.255.255.255', '10.0.0.0', '10.255.255.255',
  '100.64.0.0', '100.127.255.255', '127.0.0.1', '127.255.255.255',
  '169.254.0.0', '169.254.169.254', '169.254.255.255',
  '172.16.0.0', '172.31.255.255', '192.0.0.8', '192.0.0.9',
  '192.0.2.1', '192.88.99.1', '192.168.0.1', '192.168.255.255',
  '198.18.0.0', '198.19.255.255', '198.51.100.20', '203.0.113.8',
  '224.0.0.0', '239.255.255.255', '240.0.0.0', '255.255.255.255',
  '::', '::1', '::127.0.0.1', '::7f00:1',
  '::ffff:127.0.0.1', '::FFFF:7F00:1', '0:0:0:0:0:ffff:0a00:0001',
  '::ffff:169.254.169.254', '::ffff:192.168.1.2', '::ffff:8.8.8.8',
  '64:ff9b::7f00:1', '64:ff9b:1::a00:1', '100::1', '100:0:0:1::1',
  '2001::1', '2001:2::1', '2001:10::1', '2001:1ff:ffff::1',
  '2001:db8::1', '2002:7f00:1::', '2002:0808:0808::1',
  '3ffe::1', '3fff::1', '3fff:fff:ffff::1', '4000::1', '5f00::1',
  'fc00::1', 'fdff::1', 'fe80::1', 'fe80::1%eth0', 'fec0::1', 'ff02::1',
  '127.1', '2130706433', '0x7f000001', '0177.0.0.1', 'not-an-ip',
];

for (const address of NON_PUBLIC) {
  test(`blocks non-public or ambiguous DNS address ${address}`, async t => {
    const network = forbidHttps(t);
    const transport = createWebhookTransport(config(async () => [record(address)]));
    await assert.rejects(send(transport), code('CALLBACK_ADDRESS_BLOCKED'));
    assert.equal(network.mock.callCount(), 0);
  });
}

test('valid public address boundaries pass the connection checks', async t => {
  const requests = mockHttps(t);
  for (const address of [
    PUBLIC_V4, PUBLIC_V6, '1.1.1.1', '100.63.255.255', '100.128.0.0',
    '172.15.255.255', '172.32.0.0', '192.169.0.0', '198.17.255.255',
    '198.20.0.0', '223.255.255.255', '2001:200::1', '2001:4860:4860::8888',
    '2606:4700:4700:0:0:0:0:1111', '2a00:1450:4001::1',
  ]) {
    await send(createWebhookTransport(config(async () => [record(address)])));
  }
  assert.equal(requests.length, 15);
});

test('rejects mixed public/private DNS answers and invalid DNS records', async t => {
  const network = forbidHttps(t);
  for (const records of [
    [record(PUBLIC_V4), record('127.0.0.1')],
    [record(PUBLIC_V6), record('::ffff:10.0.0.1')],
    [{ address: PUBLIC_V4, family: 6 }], [{ address: PUBLIC_V6, family: 4 }],
    [null], [{ address: PUBLIC_V4, family: '4' }],
  ]) {
    await assert.rejects(send(createWebhookTransport(config(async () => records))), code('CALLBACK_ADDRESS_BLOCKED'));
  }
  for (const records of [[], null, record(PUBLIC_V4)]) {
    await assert.rejects(send(createWebhookTransport(config(async () => records))), code('CALLBACK_DNS_FAILED'));
  }
  assert.equal(network.mock.callCount(), 0);
});

test('DNS failure is categorized without making a request', async t => {
  const network = forbidHttps(t);
  const cause = new Error('ENOTFOUND');
  await assert.rejects(send(createWebhookTransport(config(async () => { throw cause; }))), error =>
    error.code === 'CALLBACK_DNS_FAILED' && error.reason === 'dns_failed' && error.cause === cause);
  assert.equal(network.mock.callCount(), 0);
});

test('pins validated DNS answer, preserves TLS identity, headers and exact signed body', async t => {
  const requests = mockHttps(t, ({ respond }) => respond(201, '{"challenge":"test-value"}'));
  const lookupCalls = [];
  const transport = createWebhookTransport(config(async (...args) => {
    lookupCalls.push(args);
    return [record(PUBLIC_V4), record(PUBLIC_V6)];
  }));
  const headers = { 'Content-Type': 'application/json', 'webhook-id': 'event_1', 'webhook-timestamp': '123', 'webhook-signature': 'v1,signature', 'X-MCP-Subscription-Id': 'sub_1' };
  assert.deepEqual(await send(transport, { headers }), { status: 201, body: '{"challenge":"test-value"}' });
  assert.deepEqual(lookupCalls, [[HOST, { all: true, verbatim: true }]]);
  const { options, bytes } = requests[0];
  assert.equal(bytes.toString('utf8'), BODY);
  assert.equal(options.hostname, HOST);
  assert.equal(options.servername, HOST);
  assert.equal(options.port, 443);
  assert.equal(options.method, 'POST');
  assert.equal(options.path, '/mcp-events/callback?tenant=one');
  assert.equal(options.rejectUnauthorized, true);
  assert.equal(options.agent, false);
  assert.equal(options.autoSelectFamily, false);
  assert.equal(options.maxHeaderSize, 16 * 1024);
  assert.equal(options.headers.host, HOST);
  assert.equal(options.headers['content-length'], String(Buffer.byteLength(BODY)));
  assert.equal(options.headers['webhook-signature'], headers['webhook-signature']);
  assert.equal(options.headers['x-mcp-subscription-id'], 'sub_1');
  options.lookup(HOST, {}, (error, address, family) => {
    assert.equal(error, null); assert.equal(address, PUBLIC_V4); assert.equal(family, 4);
  });
  options.lookup(HOST, { all: true }, (error, records) => {
    assert.equal(error, null); assert.deepEqual(records, [record(PUBLIC_V4)]);
  });
  assert.equal(lookupCalls.length, 1);
  const cert = { subjectaltname: `DNS:${HOST}` };
  assert.equal(options.checkServerIdentity(PUBLIC_V4, cert), undefined);
  assert.ok(options.checkServerIdentity(HOST, { subjectaltname: 'DNS:other.example.com' }));
});

test('each attempt re-resolves; a rebound private destination cannot reuse a connection', async t => {
  const requests = mockHttps(t);
  let lookups = 0;
  const transport = createWebhookTransport(config(async () => [record(++lookups === 1 ? PUBLIC_V4 : '127.0.0.1')]));
  await send(transport);
  await assert.rejects(send(transport), code('CALLBACK_ADDRESS_BLOCKED'));
  assert.equal(lookups, 2);
  assert.equal(requests.length, 1);
});

test('literal IPs are validated directly, including URL-normalized numeric forms', async t => {
  const requests = mockHttps(t);
  let lookups = 0;
  const lookup = async () => { lookups += 1; throw new Error('Literals must not use DNS'); };
  for (const [host, url] of [
    ['127.0.0.1', 'https://0x7f000001/x'], ['127.0.0.1', 'https://2130706433/x'],
    ['127.0.0.1', 'https://127.1/x'], ['127.0.0.1', 'https://0177.0.0.1/x'],
    ['::ffff:127.0.0.1', 'https://[::ffff:127.0.0.1]/x'],
  ]) {
    await assert.rejects(send(createWebhookTransport({ allowedHosts: [host], lookup }), { url }), code('CALLBACK_ADDRESS_BLOCKED'));
  }
  for (const host of [PUBLIC_V4, PUBLIC_V6]) {
    const url = isIP(host) === 6 ? `https://[${host}]/x` : `https://${host}/x`;
    await send(createWebhookTransport({ allowedHosts: [host], lookup }), { url });
  }
  assert.equal(lookups, 0);
  assert.equal(requests.length, 2);
  assert.equal(requests[1].options.headers.host, `[${PUBLIC_V6}]`);
  assert.equal(requests[1].options.servername, '');
  assert.equal(requests[0].options.checkServerIdentity('ignored', { subjectaltname: `IP Address:${PUBLIC_V4}` }), undefined);
});

test('request header injection and routing/framing overrides are rejected', async t => {
  const network = forbidHttps(t);
  const transport = createWebhookTransport(config());
  for (const headers of [
    { Host: '127.0.0.1' }, { 'Content-Length': '1' }, { 'Transfer-Encoding': 'chunked' },
    { Connection: 'keep-alive' }, { 'Proxy-Authorization': 'secret' }, { Upgrade: 'h2c' },
    { Expect: '100-continue' }, { 'webhook-id': 'one', 'Webhook-Id': 'two' },
    { 'webhook-id': 'one\r\nHost: local' }, { 'bad\nname': 'value' },
    { 'webhook-id': ['one', 'two'] }, null, [],
  ]) {
    await assert.rejects(send(transport, { headers }), code('CALLBACK_HEADERS_INVALID'));
  }
  assert.equal(network.mock.callCount(), 0);
});

test('requires serialized request bytes and enforces the 256 KiB cap', async t => {
  const requests = mockHttps(t);
  const transport = createWebhookTransport(config());
  for (const body of [{ challenge: 'x' }, null, undefined, 1, Buffer.alloc(256 * 1024 + 1)]) {
    await assert.rejects(send(transport, { body }));
  }
  await send(transport, { body: Buffer.alloc(256 * 1024, 'a') });
  assert.equal(requests.length, 1);
});

test('snapshots mutable signed bytes and headers before waiting for DNS', async t => {
  const requests = mockHttps(t);
  let completeLookup;
  const transport = createWebhookTransport(config(() => new Promise(resolve => { completeLookup = resolve; })));
  const body = Buffer.from('signed bytes');
  const headers = { 'webhook-signature': 'original' };
  const result = send(transport, { body, headers });
  body.fill(0);
  headers['webhook-signature'] = 'modified';
  completeLookup([record(PUBLIC_V4)]);
  await result;
  assert.equal(requests[0].bytes.toString(), 'signed bytes');
  assert.equal(requests[0].options.headers['webhook-signature'], 'original');
});

test('redirects fail without following Location or sending a second request', async t => {
  const requests = mockHttps(t, ({ respond }) => respond(302, '', { location: 'http://127.0.0.1/private' }));
  await assert.rejects(send(createWebhookTransport(config())), code('CALLBACK_REDIRECT_BLOCKED'));
  assert.equal(requests.length, 1);
  assert.equal(requests[0].request.destroyed, true);
  assert.equal(requests[0].response.destroyed, true);
});

test('nonredirect statuses are returned unchanged for caller retry decisions', async t => {
  let status = 410;
  mockHttps(t, ({ respond }) => respond(status, 'response'));
  const transport = createWebhookTransport(config());
  for (status of [200, 204, 400, 410, 413, 429, 500, 503]) {
    assert.deepEqual(await send(transport), { status, body: 'response' });
  }
});

test('response size cap checks both Content-Length and streamed bytes', async t => {
  let handle;
  const requests = mockHttps(t, call => handle(call));
  const transport = createWebhookTransport(config());
  handle = ({ respond }) => respond(200, '', { 'content-length': '16385' });
  await assert.rejects(send(transport), code('CALLBACK_RESPONSE_TOO_LARGE'));
  handle = ({ respond }) => {
    const response = respond(200);
    response.write(Buffer.alloc(16 * 1024));
    response.end(Buffer.from('x'));
  };
  await assert.rejects(send(transport), code('CALLBACK_RESPONSE_TOO_LARGE'));
  handle = ({ respond }) => respond(200, Buffer.alloc(16 * 1024, 'a'));
  assert.equal((await send(transport)).body.length, 16 * 1024);
  assert.equal(requests.length, 3);
  assert.equal(requests[0].request.destroyed, true);
  assert.equal(requests[1].request.destroyed, true);
});

test('response limit counts bytes rather than decoded characters', async t => {
  mockHttps(t, ({ respond }) => respond(200, Buffer.from('€'.repeat(6000))));
  await assert.rejects(send(createWebhookTransport(config())), code('CALLBACK_RESPONSE_TOO_LARGE'));
});

test('request errors, incomplete bodies and aborted responses reject cleanly', async t => {
  let handle;
  mockHttps(t, call => handle(call));
  const transport = createWebhookTransport(config());
  handle = ({ request }) => request.emit('error', new Error('TLS handshake failed'));
  await assert.rejects(send(transport), code('CALLBACK_REQUEST_FAILED'));
  handle = ({ respond }) => { const response = respond(200); response.end('incomplete'); };
  await assert.rejects(send(transport), code('CALLBACK_RESPONSE_INCOMPLETE'));
  handle = ({ respond }) => respond(200).emit('aborted');
  await assert.rejects(send(transport), code('CALLBACK_RESPONSE_INCOMPLETE'));
  handle = ({ respond }) => respond(200).emit('error', new Error('reset'));
  await assert.rejects(send(transport), code('CALLBACK_REQUEST_FAILED'));
});

test('10-second deadline includes hung DNS and ignores its late result', async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const network = forbidHttps(t);
  let completeLookup;
  const transport = createWebhookTransport(config(() => new Promise(resolve => { completeLookup = resolve; })));
  const result = send(transport);
  const rejected = assert.rejects(result, error => error.code === 'CALLBACK_TIMEOUT' && error.reason === 'timeout');
  t.mock.timers.tick(10_000);
  await rejected;
  completeLookup([record(PUBLIC_V4)]);
  await flush();
  assert.equal(network.mock.callCount(), 0);
});

test('the same deadline spans DNS, connection and response body', async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const requests = mockHttps(t, ({ respond }) => respond(200));
  const transport = createWebhookTransport(config(() => new Promise(resolve => setTimeout(() => resolve([record(PUBLIC_V4)]), 5000))));
  const result = send(transport);
  const rejected = assert.rejects(result, code('CALLBACK_TIMEOUT'));
  t.mock.timers.tick(5000);
  await flush();
  assert.equal(requests.length, 1);
  assert.equal(requests[0].request.destroyed, false);
  t.mock.timers.tick(4999);
  assert.equal(requests[0].request.destroyed, false);
  t.mock.timers.tick(1);
  await rejected;
  assert.equal(requests[0].request.destroyed, true);
  assert.equal(requests[0].response.destroyed, true);
});

test('send timestamp callback fires once only after request flush',async t=>{
 let count=0;
 mockHttps(t,({request,respond})=>{assert.equal(count,0);request.emit('finish');request.emit('finish');assert.equal(count,1);respond(200,'{}');});
 await send(createWebhookTransport(config()),{onSent:()=>{count++;}});assert.equal(count,1);
});
test('invalid send audit callback is rejected before connecting',async t=>{const network=forbidHttps(t);await assert.rejects(send(createWebhookTransport(config()),{onSent:'wrong'}));assert.equal(network.mock.callCount(),0);});
test('failed send audit rejects without treating a later response as accepted',async t=>{const calls=mockHttps(t,({request,respond})=>{request.emit('finish');respond(200,'{}');});await assert.rejects(send(createWebhookTransport(config()),{onSent:()=>{throw new Error('storage unavailable');}}),code('CALLBACK_AUDIT_FAILED'));assert.equal(calls[0].request.destroyed,true);});

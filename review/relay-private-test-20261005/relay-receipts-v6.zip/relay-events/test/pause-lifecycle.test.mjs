import test from 'node:test';
import assert from 'node:assert/strict';
import {RelayEvents} from '../core.mjs';

function fixture() {
  let state = {subscriptions: {}, work: {}, deliveries: {}, paused: {}};
  let now = 1_000_000, status = 200;
  const engine = new RelayEvents({
    store: {read: () => structuredClone(state), write: next => {state = structuredClone(next);}},
    authorize: async ({principal, agent_id, action}) => principal === 'owner' && (action === 'discover' || agent_id === 'atlas'),
    now: () => now,
    transport: async ({body}) => {
      const data = JSON.parse(body);
      return data.type === 'verification' ? {status: 200, body: {challenge: data.challenge}} : {status};
    },
  });
  const params = {name: 'relay.work.available', arguments: {agent_id: 'atlas'}, delivery: {mode: 'webhook', url: 'https://callback.example/event', secret: 'whsec_' + Buffer.alloc(32, 4).toString('base64')}};
  return {engine, params, advance: ms => {now += ms;}, setStatus: value => {status = value;}};
}
async function claimed(f, source_id = 'existing') {
  const work = await f.engine.enqueue('owner', {agent_id: 'atlas', source_id});
  const claim = await f.engine.transition('owner', {agent_id: 'atlas', work_id: work.id, state: 'claimed'});
  return {agent_id: 'atlas', work_id: work.id, claim_token: claim.claim_token};
}

test('paused existing claim can renew running and finish, including idempotent receipts', async () => {
  const f = fixture(), claim = await claimed(f);
  await f.engine.pause('owner', 'atlas', true);
  assert.equal((await f.engine.transition('owner', {...claim, state: 'claimed'})).claim_token, claim.claim_token);
  f.advance(300000);
  assert.equal((await f.engine.transition('owner', {...claim, state: 'running'})).status, 'running');
  f.advance(400000); // Past original lease, still within renewed lease.
  assert.equal((await f.engine.transition('owner', {...claim, state: 'done'})).status, 'done');
  assert.equal((await f.engine.transition('owner', {...claim, state: 'done'})).status, 'done');
});

for (const current of ['claimed', 'running']) {
  test(`paused ${current} work can defer at a safe checkpoint without enabling new claims`, async () => {
    const f = fixture(), claim = await claimed(f);
    if (current === 'running') await f.engine.transition('owner', {...claim, state: 'running'});
    await f.engine.pause('owner', 'atlas', true);
    const deferred = await f.engine.transition('owner', {...claim, state: 'deferred', defer_ms: 120000});
    assert.equal(deferred.status, 'queued');
    assert.equal(deferred.notBefore, 1_120_000);
    f.advance(120000);
    await assert.rejects(f.engine.transition('owner', {...claim, state: 'claimed'}), e => e.code === -32002);
    await assert.rejects(f.engine.transition('owner', {...claim, state: 'done'}));
  });
}

test('pause still rejects invalid and expired claim tokens and cross-owner access', async () => {
  const f = fixture(), claim = await claimed(f);
  await f.engine.pause('owner', 'atlas', true);
  for (const state of ['claimed', 'running', 'done', 'deferred']) {
    await assert.rejects(f.engine.transition('owner', {...claim, claim_token: 'invalid', state, defer_ms: 120000}));
  }
  await assert.rejects(f.engine.transition('other', {...claim, state: 'done'}));
  f.advance(600001);
  for (const state of ['running', 'done', 'deferred']) {
    await assert.rejects(f.engine.transition('owner', {...claim, state, defer_ms: 120000}));
  }
});

test('pause blocks new deliveries and new claims, resume releases pending delivery', async () => {
  const f = fixture();
  await f.engine.subscribe('owner', f.params);
  const claim = await claimed(f);
  const incoming = await f.engine.enqueue('owner', {agent_id: 'atlas', source_id: 'incoming', priority: 'urgent'});
  await f.engine.pause('owner', 'atlas', true);
  assert.equal((await f.engine.tick()).sent, 0);
  await f.engine.transition('owner', {...claim, state: 'done'});
  await assert.rejects(f.engine.transition('owner', {agent_id: 'atlas', work_id: incoming.id, state: 'claimed'}), e => e.code === -32002);
  await f.engine.pause('owner', 'atlas', false);
  assert.equal((await f.engine.tick()).sent, 1);
});

test('historical delivered receipts do not relabel recovered queued work', async () => {
  const f = fixture();
  await f.engine.subscribe('owner', f.params);
  const work = await f.engine.enqueue('owner', {agent_id: 'atlas', source_id: 'recovery'});
  await f.engine.tick();
  assert.equal((await f.engine.status('owner', 'atlas')).work[0].status, 'delivered');
  f.advance(600001);
  f.setStatus(503);
  await f.engine.tick();
  const result = await f.engine.status('owner', 'atlas');
  assert.equal(result.work.find(w => w.id === work.id).status, 'queued');
  assert.ok(result.deliveries.some(d => d.work_id === work.id && d.status === 'delivered'));
  assert.ok(result.deliveries.some(d => d.work_id === work.id && d.status === 'queued'));
});

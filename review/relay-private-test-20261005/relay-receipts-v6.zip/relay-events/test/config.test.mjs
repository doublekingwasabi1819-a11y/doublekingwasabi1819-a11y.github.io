import test from 'node:test';
import assert from 'node:assert/strict';
import {RelayEvents} from '../core.mjs';
const defaults = () => ({store: {read: () => ({subscriptions:{},work:{},deliveries:{},paused:{}}),write(){}},authorize:async()=>true,transport:async()=>({status:200}),now:()=>1_000_000});
for (const value of ['600000',NaN,600000.5,Infinity,-Infinity,null,true,{},[],599999,900001,Number.MAX_SAFE_INTEGER]) {
  test(`recoveryMs rejects invalid ${String(value)} (${typeof value})`, () => {
    assert.throws(()=>new RelayEvents({...defaults(),recoveryMs:value}));
  });
}
test('recovery interval accepts numeric integer boundaries and computes numeric lease',async()=>{
 for(const recoveryMs of [600000,750000,900000]) {
  let state={subscriptions:{},work:{},deliveries:{},paused:{}};
  const engine=new RelayEvents({...defaults(),recoveryMs,store:{read:()=>structuredClone(state),write:s=>{state=s;}}});
  const work=await engine.enqueue('owner',{agent_id:'atlas',source_id:'item'});
  await engine.transition('owner',{agent_id:'atlas',work_id:work.id,state:'claimed'});
  assert.equal(state.work[work.id].leaseUntil,1_000_000+recoveryMs);
  assert.equal(typeof state.work[work.id].leaseUntil,'number');
 }
});
for (const field of ['maxRecoveries','maxAttempts']) {
 test(`${field} rejects coerced and noninteger limits`,()=>{
  for(const value of ['3',NaN,3.5,Infinity,null,true,{},[],Number.MAX_SAFE_INTEGER])assert.throws(()=>new RelayEvents({...defaults(),[field]:value}));
 });
}
test('clock rejects invalid hook and unsafe epoch values',()=>{
 for(const now of [null,'clock',123])assert.throws(()=>new RelayEvents({...defaults(),now}));
 for(const value of ['1000000',NaN,1.5,Infinity,-1,null,Number.MAX_SAFE_INTEGER])assert.throws(()=>new RelayEvents({...defaults(),now:()=>value}));
});
test('clock fails closed if a formerly valid provider becomes invalid',async()=>{
 let current=1_000_000;const engine=new RelayEvents({...defaults(),now:()=>current});current='1000000';
 await assert.rejects(engine.enqueue('owner',{agent_id:'atlas',source_id:'badclock'}));
});

test('optional host rejects nonnumeric ports and null recovery instead of coercing/defaulting', async t => {
 const {mkdtempSync,writeFileSync,rmSync}=await import('node:fs');
 const {tmpdir}=await import('node:os');
 const {join}=await import('node:path');
 const {fileURLToPath}=await import('node:url');
 const {spawnSync}=await import('node:child_process');
 const dir=mkdtempSync(join(tmpdir(),'relay-host-config-'));
 t.after(()=>rmSync(dir,{recursive:true,force:true}));
 const file=join(dir,'config.mjs');
 for(const [field,literal,error] of [['port','"8789"','port must be an integer'],['port','null','port must be an integer'],['port','NaN','port must be an integer'],['port','8789.5','port must be an integer'],['port','Infinity','port must be an integer'],['port','0','port must be an integer'],['port','65536','port must be an integer'],['recoveryMs','null','Invalid bounded recovery configuration'],['recoveryMs','"600000"','Invalid bounded recovery configuration']]) {
  writeFileSync(file,`export const authenticate=async()=>null; export const authorize=async()=>false; export const allowedCallbackHosts=['callback.example']; export const databasePath=${JSON.stringify(join(dir,'state.db'))}; export const ${field}=${literal};`);
  const child=spawnSync(process.execPath,[fileURLToPath(new URL('../run.mjs',import.meta.url))],{encoding:'utf8',timeout:3000,env:{...process.env,RELAY_EVENTS_CONFIG:file}});
  assert.equal(child.status,1,`${field}=${literal} should fail before listening: ${child.stderr}`);
  assert.ok(child.stderr.includes(error),child.stderr);
 }
});

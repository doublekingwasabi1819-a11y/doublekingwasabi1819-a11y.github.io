import test from 'node:test';
import assert from 'node:assert/strict';
import {Client,StreamableHTTPClientTransport,fromJsonSchema} from '@modelcontextprotocol/client';
import {createRelayBrowserHost} from './fixtures/controller/relay-host.mjs';
import {relayDirectToolDescriptors} from './fixtures/controller/mcp-tool-metadata.mjs';
import {RelayEvents} from '../core.mjs';
import {installControllerEvents} from '../controller-adapter.mjs';
const accountId='45b9d8ad-9609-458e-8c41-c6ec715ff50b',agentId='e9d7b623-9dab-4f45-885a-24c38f5a5a49';
const resultSchema=fromJsonSchema({type:'object',additionalProperties:true});

test('actual frozen Relay host and grants retain tools, route events, refresh identity and revoke background consent',async t=>{
 const reference=Object.freeze({fixture:'no-live-account'}),binding={workspaceId:'fixture',accountId,agentId,runId:'one'};
 let state={subscriptions:{},work:{},deliveries:{},paused:{}},consent=true,callbackCount=0,scopeChecks=0;
 const engine=new RelayEvents({store:{read:()=>structuredClone(state),write:next=>{state=structuredClone(next);}},authorize:async({principal,agent_id})=>consent&&principal===accountId&&agent_id===agentId,transport:async({body})=>{callbackCount++;const value=JSON.parse(body);return {status:200,body:value.type==='verification'?{challenge:value.challenge}:{}};}});
 const adapter={tools:relayDirectToolDescriptors.map(({_meta,...d})=>({...structuredClone(d),securitySchemes:[{type:'oauth2',scopes:[d.annotations.readOnlyHint?'relay:read':'relay:write']}]})),callTool:async({name},ref)=>{
  assert.equal(ref,reference);assert.equal(name,'relay_fast_identity');return {structuredContent:{user:{id:accountId,name:'Fixture worker',role:'worker',agentId},unreadDirectMessages:0}};
 }};
 const host=createRelayBrowserHost({resolveBinding:async ref=>{assert.equal(ref,reference);return binding;},resolveWorkerSession:async()=>{throw new Error('No live browser session should be requested');},authorizeAction:async()=>true,relayAdapter:adapter,
  createDriver:async()=>({observe:async()=>({title:'Real host fixture',status:'Ready',targets:[]}),click:async()=>{},fill:async()=>{},screenshot:async()=>({mimeType:'image/png',data:'AA=='}),close:async()=>{}}),
  installEvents:options=>installControllerEvents({...options,engine,authorizeRequest:async({reference:ref,binding:anchored})=>{scopeChecks++;assert.equal(ref,reference);assert.deepEqual(anchored,binding);return consent;}})
 });
 // Public deterministic, in-memory test credentials. No real account or OAuth grant.
 const first=host.issueGrant({requestContext:reference,token:'A'.repeat(40),ttlMs:60000});const {url}=await host.listen();const clients=[];
 t.after(async()=>{await Promise.all(clients.map(c=>c.close()));await host.close();});
 async function connect(token,legacy=false){const client=new Client({name:'actual-host-fixture',version:'1'},{versionNegotiation:{mode:legacy?'legacy':{pin:'2026-07-28'}}});clients.push(client);await client.connect(new StreamableHTTPClientTransport(new URL(url),{requestInit:{headers:{authorization:`Bearer ${token}`}}}));return client;}
 const client=await connect(first.token);assert.equal((await client.listTools()).tools.length,13);
 assert.equal((await client.callTool({name:'relay_fast_identity',arguments:{}})).structuredContent.user.id,accountId);
 assert.equal((await client.callTool({name:'browser_open',arguments:{}})).isError,undefined);
 const params={name:'relay.work.available',arguments:{agent_id:agentId},delivery:{mode:'webhook',url:'https://callback.example/actual-host',secret:'whsec_'+Buffer.alloc(32,8).toString('base64')}};
 const subscription=await client.request({method:'events/subscribe',params},resultSchema);assert.equal(Object.values(state.subscriptions)[0].owner,accountId);
 assert.notEqual(Object.values(state.subscriptions)[0].owner,first.grantId);
 const work=await engine.enqueue(accountId,{agent_id:agentId,source_id:'durable-message-1'});assert.equal((await engine.tick()).sent,1);
 const claim=(await client.callTool({name:'relay_work_transition',arguments:{agent_id:agentId,work_id:work.id,state:'claimed'}})).structuredContent;
 assert.equal(claim.status,'claimed');
 await client.callTool({name:'relay_work_pause',arguments:{agent_id:agentId,paused:true}});
 assert.equal((await client.callTool({name:'relay_work_transition',arguments:{agent_id:agentId,work_id:work.id,state:'done',claim_token:claim.claim_token}})).structuredContent.status,'done');
 const second=host.issueGrant({requestContext:reference,token:'B'.repeat(40),ttlMs:60000});const renewed=await connect(second.token);
 assert.equal((await renewed.request({method:'events/subscribe',params},resultSchema)).id,subscription.id);
 await host.revokeGrant(first.grantId);await assert.rejects(client.listTools());
 const legacy=await connect(second.token,true);assert.equal((await legacy.listTools()).tools.length,13);assert.equal((await legacy.callTool({name:'relay_fast_identity',arguments:{}})).structuredContent.user.id,accountId);
 await assert.rejects(legacy.request({method:'events/subscribe',params},resultSchema),/2026-07-28/);
 await renewed.callTool({name:'relay_work_pause',arguments:{agent_id:agentId,paused:false}});
 await engine.enqueue(accountId,{agent_id:agentId,source_id:'durable-message-2'});const before=callbackCount;consent=false;
 assert.equal((await engine.tick()).sent,0);assert.equal(callbackCount,before);assert.equal(Object.keys(state.subscriptions).length,0);assert.ok(scopeChecks>0);
});

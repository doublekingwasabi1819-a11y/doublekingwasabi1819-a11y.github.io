import {fromJsonSchema, ProtocolError, PROTOCOL_VERSION_META_KEY} from '@modelcontextprotocol/server';
import {RelayError, eventDefinition} from './core.mjs';
import {tools as workTools} from './mcp.mjs';
import {messageTools} from './message-access.mjs';
import {relayMessageToolDescriptors,RelaySendError} from './send-capability.mjs';

const UUID=/^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$/;
const existingNames=Object.freeze(['browser_open','browser_observe','browser_click','browser_screenshot','browser_close','relay_fast_identity','relay_fast_inbox','relay_fast_thread','relay_fast_send','relay_fast_mark_read']);
const installed=new WeakSet();
const object=(properties={},required=[])=>({type:'object',properties,required,additionalProperties:false});
const str={type:'string'};
const delivery=secret=>object({mode:{const:'webhook'},url:str,...(secret?{secret:str}:{})},['mode','url',...(secret?['secret']:[])]);
const subscription=secret=>object({name:{const:'relay.work.available'},arguments:eventDefinition.inputSchema,delivery:delivery(secret),...(secret?{cursor:{type:'null'},ttlMs:{type:['integer','null'],minimum:1}}:{})},['name','arguments','delivery']);
const safeError=error=>error instanceof RelaySendError?new ProtocolError(-32007,error.message,{reason:error.code}):error instanceof RelayError?new ProtocolError(error.code,error.message,error.reason?{reason:error.reason}:undefined):new ProtocolError(-32603,'Relay event request failed');

/** Install once, before connection, AFTER the existing fixed ten-tool metadata.
 * Trusted withRequestContext(callback) supplies (reference, anchoredBinding) and
 * performs live grant checks before/after. authorizeRequest must separately
 * enforce current OAuth scopes and event/resource permission on this request.
 * Engine authorization must independently recheck durable ownership at delivery.
 * Neither hook is derived from a tool argument, header, token hash or grant ID.
 */
export function installControllerEvents({server,engine,withRequestContext,authorizeRequest,existingTools,messageAccess,messageSend}={}) {
  if(!server||typeof server.registerTool!=='function'||typeof server.server?.setRequestHandler!=='function'||typeof server.server?.registerCapabilities!=='function'||typeof server.server?.getNegotiatedProtocolVersion!=='function'||!engine||typeof withRequestContext!=='function'||typeof authorizeRequest!=='function'||!Array.isArray(existingTools)||existingTools.length!==10||new Set(existingTools.map(t=>t?.name)).size!==10||existingNames.some(name=>!existingTools.some(t=>t?.name===name)))throw new TypeError('Explicit event authority hooks and the existing ten-tool registry are required');
  if(messageAccess!==undefined&&(messageAccess?.enabled!==true||typeof messageAccess.fetch!=='function'||typeof messageAccess.acknowledge!=='function'))throw new TypeError('Message access must be an explicitly enabled separate capability');
  if(messageSend!==undefined&&(!Array.isArray(messageSend?.tools)||messageSend.tools.length!==2||!['relay_message_send','relay_message_reply'].every(name=>messageSend.tools.some(t=>t.name===name))||typeof messageSend.callTool!=='function'))throw new TypeError('Message send/reply must be an explicit separately authorized capability');
  if(messageSend!==undefined){const canonical=value=>Array.isArray(value)?value.map(canonical):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])])):value;for(const fixed of relayMessageToolDescriptors){const given=messageSend.tools.find(t=>t.name===fixed.name);if(JSON.stringify(canonical(given))!==JSON.stringify(canonical(fixed)))throw new TypeError('Only the fixed message sender descriptors are supported');}}
  const sendCall=messageSend?.callTool.bind(messageSend);
  if(installed.has(server)||server.server.transport)throw new TypeError('Install event integration once before connecting');
  // Controller and this additive package may resolve separate SDK installations.
  // Validate the host-owned public API, not constructor identity across copies.
  const original=structuredClone(existingTools);
  const scopesFor=name=>name==='relay_message_send'?['browser:control','relay:write']:name==='relay_message_reply'?['browser:control','relay:read','relay:write']:['browser:control',(name==='relay_work_status'||name.startsWith('relay_message_'))?'relay:read':'relay:write'];
  const descriptors=[...workTools,...(messageAccess?messageTools:[]),...(messageSend?relayMessageToolDescriptors:[])].map(tool=>({...structuredClone(tool),annotations:{...structuredClone(tool.annotations),destructiveHint:false,openWorldHint:false},securitySchemes:[{type:'oauth2',scopes:scopesFor(tool.name)}],_meta:{securitySchemes:[{type:'oauth2',scopes:scopesFor(tool.name)}]}}));

  async function withIdentity(action,agent,operation) {
    return withRequestContext(async(reference,binding)=>{
      if(!binding||!UUID.test(binding.accountId??'')||!UUID.test(binding.agentId??''))throw new RelayError(-32001,'Invalid trusted event identity');
      const principal=binding.accountId.toLowerCase(),agentId=binding.agentId.toLowerCase();
      if(agent!==undefined&&agent!==agentId)throw new RelayError(-32001,'Agent is not bound to this connection');
      if(await authorizeRequest({reference,binding,principalId:principal,agentId,action})!==true)throw new RelayError(-32001,'Event operation is not authorized');
      return operation(principal,agentId,{reference,binding});
    });
  }
  for(const descriptor of descriptors)server.registerTool(descriptor.name,{description:descriptor.description,inputSchema:fromJsonSchema(descriptor.inputSchema),annotations:descriptor.annotations,_meta:descriptor._meta},async args=>{
    try{
      const action=descriptor.name==='relay_message_send'?'send':descriptor.name==='relay_message_reply'?'reply':(descriptor.name==='relay_work_status'||descriptor.name.startsWith('relay_message_'))?'read':descriptor.name==='relay_work_pause'?'pause':'execute';
      const value=await withIdentity(action,args.agent_id,(owner,agent,context)=>(descriptor.name==='relay_message_send'||descriptor.name==='relay_message_reply')?sendCall({name:descriptor.name,arguments:args},context):descriptor.name==='relay_message_fetch'?messageAccess.fetch(owner,args,context):descriptor.name==='relay_message_acknowledge'?messageAccess.acknowledge(owner,args,context):descriptor.name==='relay_work_status'?engine.status(owner,agent):descriptor.name==='relay_work_pause'?engine.pause(owner,agent,args.paused):engine.transition(owner,args));
      return {...(value?.status==='uncertain'?{isError:true}:{}),content:[{type:'text',text:JSON.stringify(value)}],structuredContent:value};
    }catch(error){const e=safeError(error);return {isError:true,content:[{type:'text',text:e.message}],structuredContent:{error:{code:e.code,message:e.message,...(e.data?{data:e.data}:{})}}};}
  });
  // Preserve the fixed host's descriptors verbatim, including top-level OAuth
  // metadata, and leave its original tools/call handlers/schema checks intact.
  server.server.setRequestHandler('tools/list',()=>({tools:structuredClone([...original,...descriptors])}));
  server.server.registerCapabilities({events:{}});
  for(const method of ['events/list','events/subscribe','events/unsubscribe']) {
    const schema=method==='events/list'?object({cursor:{type:'null'}}):subscription(method==='events/subscribe');
    server.server.setRequestHandler(method,{params:fromJsonSchema(schema)},async(params,ctx)=>{
      try{
        const version=ctx?.mcpReq?.envelope?.[PROTOCOL_VERSION_META_KEY]??server.server.getNegotiatedProtocolVersion();
        if(version!=='2026-07-28')throw new RelayError(-32601,'MCP Events requires protocol 2026-07-28');
        return await withIdentity(method==='events/list'?'read':'subscribe',params.arguments?.agent_id,async(owner,agent)=>{
          if(method==='events/list'){await engine.access(owner,agent,'read');return {events:[structuredClone(eventDefinition)]};}
          return method==='events/subscribe'?engine.subscribe(owner,params):engine.unsubscribe(owner,params);
        });
      }catch(error){throw safeError(error);}
    });
  }
  installed.add(server);
  return Object.freeze({eventMethods:Object.freeze(['events/list','events/subscribe','events/unsubscribe']),toolNames:Object.freeze(descriptors.map(t=>t.name))});
}

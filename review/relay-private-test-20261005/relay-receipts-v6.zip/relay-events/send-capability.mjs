import {createHash} from 'node:crypto';

// This is a proposed source contract, not an API implemented by current main.
export const SOURCE_CONTRACT = 'relay-message-source/1';
export const LEGACY_SOURCE_REVISION = '56c47abe01d807a52cde82ebc46d7038ae36cdcb';
const UUID = /^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$/;
const ID = /^[A-Za-z0-9._:-]{1,128}$/;
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
const id = value => typeof value === 'string' && ID.test(value);
const uuid = value => typeof value === 'string' && UUID.test(value);
const freeze = value => {
  if (value && typeof value === 'object') { for (const child of Object.values(value)) freeze(child); Object.freeze(value); }
  return value;
};
const errors = {
  DISABLED: 'Relay message sending is not enabled.',
  VALIDATION: 'Invalid Relay message destination or content.',
  AUTH_REQUIRED: 'A live authorized Relay connection is required.',
  FORBIDDEN: 'This connection cannot send as that account or use those Relay scopes.',
  SOURCE_NOT_READY: 'The Relay source has not verified this messaging and history contract.',
  CONFLICT: 'This client message ID is already reserved for different content or a different destination.',
  IN_PROGRESS: 'This client message ID is already being submitted. Check its outcome before retrying.',
  CAPACITY: 'This Relay connection has reached its local request journal limit. Preserve any unresolved client IDs.',
  SOURCE_CAPACITY: 'Relay chat history cannot accept more messages. This message was not sent.',
  REPLY_MISMATCH: 'A reply must stay in the original Relay workspace, room, and audience.',
  NOT_FOUND: 'The Relay message or recipient is unavailable.',
  RATE_LIMIT: 'Relay rate limit reached. Preserve the client message ID and retry later.',
  UNCERTAIN: 'The send outcome is uncertain. Preserve this client message ID and the exact request; do not create a replacement ID.',
  INTERNAL: 'Relay could not safely validate this request.'
};
export class RelaySendError extends Error {
  constructor(code) { super(errors[code] || errors.INTERNAL); this.code = Object.hasOwn(errors, code) ? code : 'INTERNAL'; }
}
const fail = code => { throw new RelaySendError(code); };
function exact(value, keys, required = keys) {
  if (!plain(value) || Reflect.ownKeys(value).some(key => typeof key !== 'string' || !keys.includes(key) ||
    !Object.hasOwn(Object.getOwnPropertyDescriptor(value, key), 'value')) || required.some(key => !Object.hasOwn(value, key))) fail('VALIDATION');
}
function bindingFor(value) {
  exact(value, ['workspaceId', 'accountId', 'agentId', 'runId']);
  if (!id(value.workspaceId) || !uuid(value.accountId) || !uuid(value.agentId) || !id(value.runId)) fail('FORBIDDEN');
  return {...value, accountId: value.accountId.toLowerCase(), agentId: value.agentId.toLowerCase()};
}
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const sameBinding = (a, b) => ['workspaceId', 'accountId', 'agentId', 'runId'].every(key => a[key] === b[key]);
function argsFor(args, reply, binding) {
  const fields = ['visibility', 'room_id', 'recipient_ids', 'body', 'client_id', ...(reply ? ['reply_to_message_id'] : [])];
  exact(args, [...fields, 'notify_recipient_ids'], fields);
  if (!['public', 'private'].includes(args.visibility) || !id(args.room_id) || !uuid(args.client_id) ||
    typeof args.body !== 'string' || !args.body.trim() || [...args.body].length > 12000 || Buffer.byteLength(args.body) > 48000 ||
    !Array.isArray(args.recipient_ids) || !args.recipient_ids.every(uuid) || (reply && !uuid(args.reply_to_message_id))) fail('VALIDATION');
  const recipientIds = args.recipient_ids.map(value => value.toLowerCase());
  const notifications = Object.hasOwn(args, 'notify_recipient_ids') ? args.notify_recipient_ids : (args.visibility === 'private' ? recipientIds : []);
  if (!Array.isArray(notifications) || notifications.length > 100 || !notifications.every(uuid)) fail('VALIDATION');
  const notificationRecipientIds = notifications.map(value => value.toLowerCase());
  if (new Set(notificationRecipientIds).size !== notificationRecipientIds.length ||
    (args.visibility === 'private' && !same(notificationRecipientIds, recipientIds))) fail('VALIDATION');
  if (args.visibility === 'public' ? recipientIds.length !== 0 : recipientIds.length !== 1 || recipientIds[0] === binding.accountId) fail('VALIDATION');
  return {
    clientId: args.client_id.toLowerCase(), workspaceId: binding.workspaceId, roomId: args.room_id,
    visibility: args.visibility, senderId: binding.accountId, recipientIds, notificationRecipientIds,
    participantIds: args.visibility === 'private' ? [binding.accountId, ...recipientIds].sort() : [],
    body: args.body, replyToMessageId: reply ? args.reply_to_message_id.toLowerCase() : null
  };
}
export function checkedSourceRecord(value, binding) {
  exact(value, ['id', 'clientId', 'workspaceId', 'roomId', 'visibility', 'senderId', 'recipientIds', 'notificationRecipientIds', 'participantIds', 'body', 'replyToMessageId', 'createdAt']);
  if (!uuid(value.id) || !uuid(value.clientId) || value.workspaceId !== binding.workspaceId || !id(value.roomId) ||
    !['public', 'private'].includes(value.visibility) || !uuid(value.senderId) || !Array.isArray(value.recipientIds) ||
    !value.recipientIds.every(uuid) || !Array.isArray(value.notificationRecipientIds) || value.notificationRecipientIds.length > 100 ||
    !value.notificationRecipientIds.every(uuid) || !Array.isArray(value.participantIds) || !value.participantIds.every(uuid) ||
    typeof value.body !== 'string' || !value.body.trim() || [...value.body].length > 12000 || Buffer.byteLength(value.body) > 48000 ||
    !(value.replyToMessageId === null || uuid(value.replyToMessageId)) || typeof value.createdAt !== 'string' ||
    !/(?:Z|[+-]\d{2}:\d{2})$/.test(value.createdAt) || !Number.isFinite(Date.parse(value.createdAt))) fail('INTERNAL');
  const result = {...value, id: value.id.toLowerCase(), clientId: value.clientId.toLowerCase(), senderId: value.senderId.toLowerCase(),
    recipientIds: value.recipientIds.map(x => x.toLowerCase()), notificationRecipientIds: value.notificationRecipientIds.map(x => x.toLowerCase()), participantIds: value.participantIds.map(x => x.toLowerCase()).sort(),
    replyToMessageId: value.replyToMessageId?.toLowerCase() || null};
  if (new Set(result.notificationRecipientIds).size !== result.notificationRecipientIds.length) fail('INTERNAL');
  if (result.visibility === 'public') {
    if (result.recipientIds.length || result.participantIds.length) fail('INTERNAL');
  } else {
    if (result.recipientIds.length !== 1 || result.recipientIds[0] === result.senderId || !same(result.notificationRecipientIds, result.recipientIds) ||
      !same(result.participantIds, [result.senderId, ...result.recipientIds].sort()) || !result.participantIds.includes(binding.accountId)) fail('INTERNAL');
  }
  return result;
}

/** Display text derives only from server-persisted fields; no inferred privacy. */
export function historyLabels(record) {
  return {
    audience: record.visibility === 'public' ? 'Public' : 'Private',
    auditAccess: record.visibility === 'private' ? 'Conversation participants and manager may read' : 'All workspace members may read',
    sender: `From ${record.senderId}`,
    recipients: record.visibility === 'public' ? `To all members of workspace ${record.workspaceId}` : `To ${record.recipientIds.join(', ')}`
  };
}
const uuidSchema = {type: 'string', pattern: UUID.source};
const properties = {
  visibility: {type: 'string', enum: ['public', 'private']}, room_id: {type: 'string', pattern: ID.source},
  recipient_ids: {type: 'array', items: uuidSchema, maxItems: 1, uniqueItems: true},
  body: {type: 'string', minLength: 1, maxLength: 12000}, client_id: uuidSchema
};
export const relayMessageToolDescriptors = freeze([
  ['relay_message_send', false], ['relay_message_reply', true]
].map(([name, reply]) => {
  const scopes = reply ? ['relay:read', 'relay:write'] : ['relay:write'];
  const required = [...Object.keys(properties), ...(reply ? ['reply_to_message_id'] : [])];
  const props = {...properties, notify_recipient_ids: {type: 'array', items: uuidSchema, maxItems: 100, uniqueItems: true}, ...(reply ? {reply_to_message_id: uuidSchema} : {})};
  return {
    name,
    description: `${reply ? 'Reply in the original audience of' : 'Send'} Relay chat history using the already-authorized bound account. Public means all workspace members; Private means two conversation participants plus manager audit access. Manager audit visibility never adds a notification recipient. Private requires one recipient ID; Public requires an empty recipient list; notify_recipient_ids optionally names the public wake targets (default none). Preserve client_id and the exact request after an uncertain outcome.`,
    inputSchema: {type: 'object', properties: props, required, additionalProperties: false},
    annotations: {readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false},
    securitySchemes: [{type: 'oauth2', scopes}], _meta: {securitySchemes: [{type: 'oauth2', scopes}]}
  };
}));

/**
 * Local-only opt-in proposal. Import and construction perform no network I/O.
 * All hooks are trusted server code and are captured at construction. Tool args
 * cannot select a host, token, account, grant, scope, source policy, or browser.
 * authorizeRelay must verify the actual Relay grant, not browser-only access.
 * sourcePolicy must attest the actual deployed backend's enforcement. It is not
 * a user-set flag and cannot replace database/transport authorization.
 */
export function createRelayMessageCapability({enabled = false, binding, authorizeRelay, sourcePolicy, callSource, maxJournalEntries = 1000} = {}) {
  if (typeof enabled !== 'boolean') throw new TypeError('Message opt-in must be explicit.');
  if (!enabled) return Object.freeze({tools: [], callTool: async () => { fail('DISABLED'); }});
  if (!Number.isInteger(maxJournalEntries) || maxJournalEntries < 1 || maxJournalEntries > 10000) throw new TypeError('A bounded request journal is required.');
  if (![authorizeRelay, sourcePolicy, callSource].every(value => typeof value === 'function')) throw new TypeError('Trusted Relay authorization, policy, and source hooks are required.');
  const bound = freeze(bindingFor(binding));
  const journal = new Map(); // Optimization only: source-side durable dedup is mandatory.
  async function authorize(context, scopes, command, reply) {
    let result;
    try { result = await authorizeRelay(context, {scopes: [...scopes], binding: structuredClone(bound), action: reply ? 'reply' : 'send'}); }
    catch { fail('AUTH_REQUIRED'); }
    if (!plain(result) || !Array.isArray(result.scopes) || !scopes.every(scope => result.scopes.includes(scope))) fail('FORBIDDEN');
    let live; try { live = bindingFor(result.binding); } catch { fail('FORBIDDEN'); }
    if (!sameBinding(live, bound)) fail('FORBIDDEN');
    let policy; try { policy = await sourcePolicy(context, {scopes: [...scopes]}); } catch { fail('SOURCE_NOT_READY'); }
    if (!plain(policy) || policy.contractVersion !== SOURCE_CONTRACT || !id(policy.sourceRevision) || policy.sourceRevision === LEGACY_SOURCE_REVISION ||
      policy.historyDurable !== true || policy.explicitAudienceMetadata !== true || policy.stableClientIdDedup !== true || policy.notificationsExplicitRecipientsOnly !== true ||
      policy[command.visibility === 'public' ? 'publicWorkspaceOnly' : 'privateParticipantsAndManagerOnly'] !== true ||
      (reply && policy.atomicSameAudienceReplies !== true)) fail('SOURCE_NOT_READY');
  }
  const fingerprint = command => createHash('sha256').update(JSON.stringify(command)).digest('hex');
  const uncertain = clientId => ({status: 'uncertain', clientId, retry: 'explicit-same-request-only', error: {code: 'UNCERTAIN', message: errors.UNCERTAIN}});
  function success(record) {
    return {status: 'persisted', message: record, history: {store: 'relay-chat', persisted: true, ...historyLabels(record)}};
  }
  async function callTool(request, context) {
    exact(request, ['name', 'arguments']);
    if (!relayMessageToolDescriptors.some(tool => tool.name === request.name)) fail('VALIDATION');
    const reply = request.name === 'relay_message_reply';
    const command = freeze(argsFor(request.arguments, reply, bound));
    const scopes = reply ? ['relay:read', 'relay:write'] : ['relay:write'];
    // Scope/identity/source checks also apply to every explicit retry.
    await authorize(context, scopes, command, reply);
    const key = `${bound.workspaceId}:${bound.accountId}:${command.clientId}`;
    const hash = fingerprint(command), prior = journal.get(key);
    if (prior && prior.hash !== hash) fail('CONFLICT');
    if (prior?.state === 'sending') fail('IN_PROGRESS');
    if (!prior && journal.size >= maxJournalEntries) fail('CAPACITY');
    const entry = {hash, state: 'sending'}; journal.set(key, entry);
    let mutationStarted = false;
    try {
      if (reply) {
        // Source reads must not mark a message read or acknowledge a wake event.
        const target = await callSource(context, {action: 'getMessage', binding: structuredClone(bound), messageId: command.replyToMessageId});
        if (target?.status === 'not_found') fail('NOT_FOUND');
        const original = checkedSourceRecord(target?.message, bound);
        if (original.id !== command.replyToMessageId || original.visibility !== command.visibility || original.roomId !== command.roomId ||
          !same(original.participantIds, command.participantIds)) fail('REPLY_MISMATCH');
      }
      // Recheck after asynchronous target reads and immediately before the write.
      await authorize(context, scopes, command, reply);
      mutationStarted = true;
      // sendMessage is the proposed injected source function, not a current
      // Relay HTTP action. The source atomically validates replies and audience.
      const result = await callSource(context, {action: 'sendMessage', binding: structuredClone(bound), command: structuredClone(command)});
      if (result?.status === 'rejected' && result.commit === 'not_applied' && ['FORBIDDEN', 'CONFLICT', 'NOT_FOUND', 'RATE_LIMIT', 'REPLY_MISMATCH', 'VALIDATION', 'CAPACITY'].includes(result.code)) {
        mutationStarted = false; fail(result.code === 'CAPACITY' ? 'SOURCE_CAPACITY' : result.code);
      }
      if (result?.status !== 'persisted' || result.historyStore !== 'relay-chat') fail('INTERNAL');
      const message = checkedSourceRecord(result.message, bound);
      if (!Object.keys(command).every(key => same(message[key], command[key]))) fail('INTERNAL');
      // Do not disclose private history if the grant was revoked mid-flight.
      await authorize(context, scopes, command, reply);
      entry.state = 'persisted';
      // Keep no message body or canonical record in the bounded local journal.
      // Every exact retry consults the source's durable dedup authority, so a
      // deleted message cannot be resurrected from a cached successful receipt.
      return success(message);
    } catch (error) {
      if (mutationStarted) { entry.state = 'uncertain'; return uncertain(command.clientId); }
      entry.state = 'not_sent';
      throw error instanceof RelaySendError ? error : new RelaySendError('INTERNAL');
    }
  }
  return Object.freeze({tools: relayMessageToolDescriptors, callTool});
}

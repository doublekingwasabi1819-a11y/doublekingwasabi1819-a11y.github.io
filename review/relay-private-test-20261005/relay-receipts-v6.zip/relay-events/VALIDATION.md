## Messaging extension validation — 2026-10-05

183 main tests pass, plus the separate real MCP/SQL end-to-end test. See root DELIVERY.md for backend/source counts and live/UI exclusions. The remainder documents inherited v4 coverage.

# Validation and activation boundaries

**Final automated result for this integration slice: 183 tests passed, 0 failed, 0 skipped.**

Validated in an isolated cloud workspace on 2026-10-03 using Node 24.19.0. Run `npm ci --ignore-scripts` and `npm test` to reproduce. The lockfile pins Standard Webhooks 1.0.0, MCP server/client 2.3.0 and test-only Playwright 1.62.1. The latter is imported by frozen controller fixtures; no browser binary is downloaded or launched. Dependency audit results are time-specific, not a security guarantee.

The suite retains all v3 core/security/pause/numeric-config regressions. New tests use actual MCP SDK clients with explicit 2026-07-28 negotiation and legacy negotiation over the same HTTP endpoint. They retain and exercise all ten original controller/Relay handlers plus three work tools; check raw-wire scope metadata; validate modern-only Events, denial boundaries, stable owner identity across replaced HTTP/grant identifiers, and compatibility with separate SDK installations.

The full-composition test executes the frozen Relay host, private host and grant implementation with controlled driver/Relay data hooks. It tests subscription refresh, replacement grants, revoked grants and continuing-consent revocation for background delivery. These are real local code paths with public deterministic in-memory test credentials, not real account or OAuth grants. Callback HTTPS remains mocked and no external callback is contacted.

`test/fixtures/SOURCE.json` records byte hashes for the fixed controller base 7d646385028ee44d2482d1c712fcd3836a5d0982 and tested fixtures. Only the HTTP/Relay host fixture copies include the proposed opt-in patch; the other frozen sources are unchanged. A dry run of `git apply --check` against the exact original files passes. The delivered patch remains a proposal for Atlas; no original controller/Atlas/Bob files or remote branch were edited.

Independent review covers authentication boundaries, stable binding identity, metadata preservation, method routing, SDK protocol handling and documented consent requirements. Source syntax checks pass. The standalone harness still fails closed without explicit host configuration. Existing pause and duration bugs remain fixed and covered.

Not completed: production OAuth issuer/scope integration; real continuing-consent storage; real Relay incoming-message outbox/listener; downstream consequential-action claim fencing; Bob UI mounting; Atlas's application of proposed hooks; protected hosted TLS/store deployment; plugin rescan; actual ChatGPT subscription/callback/agent execution. No deployment, persistent account grant, security setting, external callback registration or spending was performed.

A delivery receipt is not execution. Local integrated tests do not prove live ChatGPT wakeup or exact two-minute interruption. Activation requires Atlas's host/backend wiring, the user's authorized subscription, and verification that the intended agent actually claims and completes permitted work.

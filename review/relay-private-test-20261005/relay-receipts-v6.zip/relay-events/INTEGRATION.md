# Same-endpoint controller integration (opt-in)

Frozen controller base: `7d646385028ee44d2482d1c712fcd3836a5d0982` in `doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io`.

All delivered additions live under `relay-events/`. No controller, application, backend, Atlas branch, or Bob UI file was changed. `patches/controller-events-opt-in.patch` is a **proposal for Atlas to review/apply**, not an applied repository change. It applies cleanly to the exact frozen base. Changes on a newer base must be reconciled and retested rather than blindly applied.

## Host integration API

Import `installControllerEvents` from `relay-events/controller-adapter.mjs`. The host invokes it synchronously once, before connecting the SDK server, after registering all ten existing tools and installing their fixed metadata:

```js
installControllerEvents({
  server,                 // Existing host-owned MCP server, not a new endpoint
  engine,                 // Durable RelayEvents engine
  withRequestContext,     // Existing trusted grant hook from the private host
  authorizeRequest,       // REQUIRED live event/scope authorization, see below
  existingTools,          // Existing ten source-owned tool descriptors
});
```

The installer preserves the original ten tool descriptors, their input schemas, OAuth metadata, and existing `tools/call` handlers. It appends `relay_work_status`, `relay_work_transition`, and `relay_work_pause`, registers `events/list`, `events/subscribe`, `events/unsubscribe`, and merges `events:{}` into discovery. It does not replace server identity, existing capabilities, or controller authorization. It uses the public SDK API across separately installed SDK copies.

The proposed patch adds:

1. `enableEvents:false` to `createControllerHttp`; only the three fixed event methods become allowed when explicitly enabled. Existing authentication, Host/Origin checks, method/content/body limits, context pinning, and concurrency bounds remain in force. It adds no streaming endpoint, arbitrary-method bypass, or public route.
2. `installEvents` to `createRelayBrowserHost`; when explicitly supplied, it enables those methods and invokes the installer after existing tool metadata registration.

After Atlas reviews the patch, his composition can use this shape:

```js
const host = createRelayBrowserHost({
  // Keep the existing approved Relay/controller hooks unchanged.
  ...existingHostOptions,
  installEvents: options => installControllerEvents({
    ...options,
    engine,
    authorizeRequest,
  }),
});
```

`engine` and `authorizeRequest` are mandatory host-owned integration objects, not globals or tool arguments. The example does not supply permissive implementations. Configure the full five-tool Relay adapter so that the installer receives the complete existing ten-tool registry. There is no fallback identity, manager account, inferred credential, or automatic grant creation.

## Stable identity and authorization

For every event/work operation, `withRequestContext` supplies the original trusted reference and freshly anchored binding. The adapter derives the durable principal from lowercased `binding.accountId` and the allowed agent from lowercased `binding.agentId`, both UUIDs. A supplied `agent_id` must match the anchored agent exactly. Browser/OAuth grant IDs and HTTP `principalId` cache keys are explicitly **not** the event owner. Replacement grants for the same account/agent preserve subscription IDs. A remapped binding is rejected by the existing grant hook. Keep each event database scoped to one Relay deployment/identity realm.

`authorizeRequest({reference,binding,principalId,agentId,action})` must return exactly true only after checking the current request's verified credentials, delegation, account/agent access, and scopes. Map the action to required scopes:

| Action | Required scopes |
|---|---|
| read, subscribe (including unsubscribe) | browser:control + relay:read |
| pause, execute | browser:control + relay:write |

The adapter advertises these scopes on work tools; metadata is not enforcement. The host must implement the actual scope decision from verified authority, never a header or model-provided identity. The three event methods are usable only over protocol `2026-07-28`. Existing tools remain available to legacy clients, including the three work tools where supported. Legacy event requests fail without creating subscriptions.

Separately, the engine's durable `authorize({principal,agent_id,action})` must check **continuing subscription consent and connection/resource access** on every delivery, not merely that the account still owns the agent. OAuth disconnection, revoked event consent, disabled agent or removed resource access must deny future callbacks. An old short-lived grant expiring during legitimate grant rotation is not automatically the same as the underlying subscription consent being revoked. The host must define and persist this distinction. An authorization backend outage must throw (temporarily skip); an explicit denial returns false (stop the subscription). The same stable identity mapping must be used by source ingestion and work reads.

## Callback and work lifecycle

ChatGPT supplies the callback URL and signing secret in authenticated `events/subscribe`. The configured exact host allowlist, public-address DNS pinning, TLS identity checks, signed challenge and constant-time echo verification apply before activation. Durable subscription refresh replaces signing keys with a short dual-signature rotation interval. Expiry, explicit unsubscribe and durable consent revocation stop delivery. HTTP receipt is distinct from claim/running/done.

Use real incoming Relay message IDs for ingestion, not local timestamps or generated notification IDs. The trusted source adapter should:

1. Authenticate the upstream event and resolve the destination worker/account/agent from the source's durable records.
2. Commit a durable outbox entry in the source transaction with a stable key such as `dm:<message-uuid>` (within the core source_id format/length).
3. Call `engine.enqueue(accountId,{agent_id:agentId,source_id:'dm:<message-uuid>',priority:'normal'})` and durably mark the outbox delivery after success. Repeating the same account/agent/source ID returns the same work ID. Retry rejected queue-capacity or temporary failures without dropping the source message.
4. Exclude the agent's own output, delivery acknowledgments, status writes and queue mutations. The core's `origin:'external'` field is a trusted adapter assertion, not authentication.
5. Store the work-to-message mapping in the source adapter so existing authorized Relay read tools can retrieve the actual content. Event bodies contain IDs and priority only. Do not expose a manager credential or private message body through the UI status route.

The source transaction/outbox and actual Relay backend listener are **not implemented by this routing slice**. They remain Atlas's host/backend integration work against the reviewed contract. No source scanner, cron database migration, external webhook registration or background account grant was installed.

## Downstream action fencing

A queue claim token guards queue transitions; it does not stop a process or revoke external side effects. Atlas's action adapter must bind worker runs to their current claim internally and atomically check that claim/lease and an idempotency/fencing key before consequential downstream operations. Do not put claim tokens into a viewer, URL, browser storage, logs or message body. Existing ten-tool argument schemas are intentionally unchanged; any claim association belongs in the trusted host request context, not a new caller-selectable principal field. This action-fencing integration is still required before unattended consequential work.

Pause blocks new delivery/claims while allowing an existing valid claim to renew, finish or save a checkpoint and defer. A two-minute defer is earliest eligibility, not a forced interruption. `work[].status` is authoritative; old delivered event receipts never promote newly recovered queued work.

## Bob UI integration boundary

Inject an authenticated adapter that unwraps MCP `result.structuredContent`. Status and pause return their documented direct records; transitions return a direct work record, not `{work:...}`. The actual UI mount and source listener are separate reviewed slices. Do not wire a browser-supplied principal directly into `createDispatcher`; use this anchored host installer. No Bob files were modified here.

## Reproduce tests and proposed patch check

From the repository root after placing this directory:

```sh
npm --prefix relay-events ci --ignore-scripts
npm --prefix relay-events test
node --test relay-events/test/controller-integration.test.mjs relay-events/test/relay-host-integration.test.mjs
# From an exact frozen-base checkout; dry-run only until Atlas approves:
git apply --check relay-events/patches/controller-events-opt-in.patch
```

The test-only fixtures under `test/fixtures/controller/` are copies of the frozen controller source, with only the proposed opt-in changes applied to the HTTP and Relay host fixtures. `SOURCE.json` records base and tested-fixture hashes. They are not an alternate production controller. Tests use actual SDK 2.3.0 clients with explicit modern pinning and explicit legacy negotiation. SDK clients default to legacy unless modern negotiation is requested. Raw wire metadata is checked because typed client schemas may omit extension fields while `_meta` remains available.

Component integration tests execute all original five browser tools with a controlled driver and all five direct Relay handlers with fixture data, plus all three work tools. The additional full-composition test executes the actual `relay-host.mjs`, `serve.mjs`, grant lifecycle, scope hook, subscription/refresh paths, modern and legacy tool discovery, grant replacement/revocation, and continuing-consent revocation with in-memory test credentials. Callback HTTPS is mocked. No real browser account, external callback, OAuth issuer or ChatGPT subscription is used. Playwright is a pinned dev dependency needed to import the frozen host modules; no browser is downloaded/launched by these tests.

## Remaining activation checks

Atlas must review/apply or adapt the proposed hooks, connect real per-request OAuth scopes and continuing-consent authorization, choose the protected durable store and approved callback hosts, implement source outbox ingestion and downstream action fencing, connect Bob's authenticated adapter/mount, then rescan the plugin and test an explicitly authorized subscription in the intended Work/Cloud chat or dot. Verify an actual event triggers the intended agent, is claimed, and completes the permitted work. Neither this bundle nor successful local integration tests prove a live ChatGPT wakeup or exact two-minute handling.

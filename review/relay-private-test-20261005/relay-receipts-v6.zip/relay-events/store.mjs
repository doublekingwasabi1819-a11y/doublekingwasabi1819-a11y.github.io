import {DatabaseSync} from 'node:sqlite';
import {lstatSync,chmodSync} from 'node:fs';
import {dirname,isAbsolute} from 'node:path';
/** Store interface: read() returns an isolated JSON state; write(state) commits atomically.
 * One RelayEvents instance owns this store. No multi-process writers supported.
 * Replace with a transactional DB adapter + distributed lock before scaling. */
export class SqliteStore {
  constructor(path) {
    if(typeof path!=='string'||!isAbsolute(path))throw new Error('Use an absolute private database path');
    const directory=lstatSync(dirname(path));
    if(!directory.isDirectory()||directory.isSymbolicLink()||(directory.mode&0o077)!==0)throw new Error('Database parent directory must be private (0700)');
    try{const file=lstatSync(path);if(!file.isFile()||file.isSymbolicLink())throw new Error('Database must be a regular file');}catch(e){if(e.code!=='ENOENT')throw e;}
    this.db = new DatabaseSync(path);
    chmodSync(path,0o600);
    this.db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS relay_state (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL)');
  }
  read() { const row = this.db.prepare('SELECT body FROM relay_state WHERE id=1').get(); return row ? JSON.parse(row.body) : {subscriptions:{},work:{},deliveries:{},paused:{}}; }
  write(state) { this.db.prepare('INSERT INTO relay_state(id,body) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body').run(JSON.stringify(state)); }
  close() { this.db.close(); }
}

# Verified current backend and activation gaps

Inspected repository:
`doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io`
at `56c47abe01d807a52cde82ebc46d7038ae36cdcb` on 2026-10-05.
Exact source snapshots, blob hashes, and URLs are in `reference/SOURCE.json`.

Local implementation update: the sibling `backend-implementation` candidate now
implements the additive message contract. This directory's concrete adapter
passes 13 real local Edge handler/PGlite checks against that candidate, including
both Public and Private sends/replies. The gaps below describe the unchanged
pinned main commit, which is still rejected for the new contract. No live backend
or repository was changed by this local validation.

## What exists

- `api.mjs` provides `RelayAPI.call(action,data)` with a configured API endpoint
  and current token. Its default storage is browser sessionStorage. The new
  source hook must not import that browser session or use browser-only grants.
- `backend/handler.mjs` permits `operation`, `dm.inbox`, `dm.thread`, `dm.send`
  and `dm.read`. It derives authorization from the Bearer session. DM send
  allowed fields are only recipientId, body and clientId. Unsupported fields
  are picked away, not persisted or validated as new capabilities.
- `engine.mjs` `message.add` persists id, from, to, taskId, body and createdAt.
  Shared messages are workspace-readable; `to` is routing, not privacy.
- Public operation dedup is an in-board operations array, trimmed to the last
  2,000 IDs. A matching ID returns unchanged state without comparing payload.
- `backend/private-messages.sql` and the embedded version in `schema.sql`
  implement a private direct_messages table with sender, recipient, client ID,
  body, timestamps, and unique(sender_id, client_id). Existing DM send rejects
  different body or recipient on reuse and returns the existing row on replay.
- DM inbox/thread reads deliberately allow manager audit access. Other workers
  are restricted to their own conversations. This matches the latest direction;
  no participant-only restriction should be applied.
- Existing DM notifications count only rows whose recipient_id is the current
  account. Manager inspection does not mark another recipient's messages read.
- `bridge.mjs` exposes `relay_message` for shared posts and `relay_dm_send` for
  DMs, but neither persists the complete new room/audience/reply contract.

## What cannot yet be truthfully activated

1. Canonical room, visibility, full audience/recipient metadata and reply links
   are not accepted/persisted by these source paths. A label added by MCP alone
   cannot make those fields part of Relay history.
2. Public sending lacks durable complete-payload idempotency. Wrapping
   `message.add` without a backend change can duplicate after ID eviction or
   conceal a content mismatch on ID reuse.
3. Private DM idempotency is useful, but its current fingerprint contains no
   room, notification targets or reply linkage because those features are absent.
4. There is no verified atomic same-audience reply API or transactional
   exactly-once explicit-target notification outbox for the proposed messages.
5. Current v4 fixture metadata permits an exact fixed 5/10-tool controller
   registry. Its existing direct sender is private-only. Descriptors or labels
   are not credentials and cannot establish a Relay source grant.

Therefore this proposal intentionally rejects current main as a ready source.
Both Public and Private send/reply activation require a separately authorized
backend/host integration implementing and verifying the full source contract.
The current manager audit behavior is not a blocker under the latest request.
The earlier suggestion to remove manager inspection is superseded.

## Pinned links

- [API client](https://github.com/doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io/blob/56c47abe01d807a52cde82ebc46d7038ae36cdcb/api.mjs)
- [Backend action allowlist](https://github.com/doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io/blob/56c47abe01d807a52cde82ebc46d7038ae36cdcb/backend/handler.mjs)
- [Public operation engine](https://github.com/doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io/blob/56c47abe01d807a52cde82ebc46d7038ae36cdcb/engine.mjs)
- [Direct-message SQL](https://github.com/doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io/blob/56c47abe01d807a52cde82ebc46d7038ae36cdcb/backend/private-messages.sql)
- [Embedded direct-message SQL](https://github.com/doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io/blob/56c47abe01d807a52cde82ebc46d7038ae36cdcb/backend/schema.sql)
- [Current MCP bridge](https://github.com/doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io/blob/56c47abe01d807a52cde82ebc46d7038ae36cdcb/bridge.mjs)

import test from 'node:test';
import assert from 'node:assert/strict';
import {createAuthenticatedRelaySource} from '../authenticated-source-adapter.mjs';
import {createRelayMessageCapability, SOURCE_CONTRACT} from '../send-capability.mjs';

const ME = '11111111-1111-4111-8111-111111111111', PEER = '22222222-2222-4222-8222-222222222222';
const AGENT = '33333333-3333-4333-8333-333333333333', CLIENT = '44444444-4444-4444-8444-444444444444';
const MESSAGE = '55555555-5555-4555-8555-555555555555', ORIGINAL = '66666666-6666-4666-8666-666666666666';
const binding = {workspaceId: 'verified-source-workspace', accountId: ME, agentId: AGENT, runId: 'run-a'};
const policy = {contractVersion: SOURCE_CONTRACT, sourceRevision: 'relay-messages-v1', workspaceId: binding.workspaceId, roomId: 'verified-source-room',
  historyDurable: true, explicitAudienceMetadata: true, stableClientIdDedup: true, notificationsExplicitRecipientsOnly: true,
  publicWorkspaceOnly: true, privateParticipantsAndManagerOnly: true, atomicSameAudienceReplies: true};
const command = {clientId: CLIENT, workspaceId: binding.workspaceId, roomId: policy.roomId, visibility: 'private', senderId: ME,
  recipientIds: [PEER], participantIds: [ME, PEER], notificationRecipientIds: [PEER], body: 'Local fixture only', replyToMessageId: null};
const record = {...command, id: MESSAGE, createdAt: '2026-10-05T02:00:00Z'};
const context = Object.freeze({reference: 'already-authorized-fixture'});
function fixture(extra = {}) {
  const checks = [], calls = [];
  const source = createAuthenticatedRelaySource({binding, withAuthorizedRelay: async (ctx, required, callback) => {
    assert.equal(ctx, context); checks.push(required);
    return callback({binding, scopes: ['relay:read', 'relay:write'], call: async (action, data) => {
      calls.push({action, data});
      if (action === 'messages.capabilities') return policy;
      if (action === 'messages.get') return {message: {...record, id: data.messageId}};
      if (action === 'messages.send') return {status: 'persisted', historyStore: 'relay-chat', message: {...record, ...data.command}};
      throw new Error('Unknown action');
    }});
  }, ...extra});
  return {source, checks, calls};
}

test('concrete adapter is inert until explicitly called and discovers verified source routing', async () => {
  const {source, checks, calls} = fixture();
  assert.equal(checks.length, 0); assert.equal(calls.length, 0);
  assert.deepEqual(await source.sourcePolicy(context), policy);
  assert.deepEqual(checks[0].scopes, ['relay:read']);
  assert.deepEqual(calls, [{action: 'messages.capabilities', data: {}}]);
});

test('write-only send can verify policy using write scope without acquiring relay:read', async () => {
  const {source, checks, calls} = fixture({withAuthorizedRelay: async (_ctx, required, callback) => {
    checks.push(required);
    return callback({binding, scopes: ['relay:write'], call: async action => {
      calls.push(action);
      if (action === 'messages.capabilities') return policy;
      return {status: 'persisted', historyStore: 'relay-chat', message: record};
    }});
  }});
  const capability = createRelayMessageCapability({enabled: true, binding, ...source,
    authorizeRelay: async () => ({binding, scopes: ['relay:write']})});
  const result = await capability.callTool({name: 'relay_message_send', arguments: {
    visibility: 'private', room_id: policy.roomId, recipient_ids: [PEER], body: command.body, client_id: CLIENT
  }}, context);
  assert.equal(result.status, 'persisted');
  assert.ok(checks.every(check => check.scopes.includes('relay:write') && !check.scopes.includes('relay:read')));
  assert.equal(calls.filter(action => action === 'messages.send').length, 1);
});

test('direct read and reply writes request their exact approved scopes and preserve canonical metadata', async () => {
  const {source, calls, checks} = fixture();
  const message = await source.readMessage({principal: ME, agent_id: AGENT, message: {id: MESSAGE}, context});
  assert.deepEqual(message, record); assert.equal(message.roomId, policy.roomId); assert.equal(message.replyToMessageId, null);
  await source.callSource(context, {action: 'sendMessage', binding, command: {...command, replyToMessageId: ORIGINAL}});
  assert.deepEqual(calls.map(x => x.action), ['messages.get', 'messages.send']);
  assert.deepEqual(checks.map(x => x.scopes), [['relay:read'], ['relay:read', 'relay:write']]);
});

test('browser-only or differently bound authorization never reaches API.call', async () => {
  let calls = 0;
  for (const authorized of [{binding, scopes: ['browser:control']}, {binding: {...binding, accountId: PEER}, scopes: ['relay:read']},
    {binding: {...binding, workspaceId: 'elsewhere'}, scopes: ['relay:read']}, {binding: {...binding, runId: 'run-b'}, scopes: ['relay:read']}]) {
    const {source} = fixture({withAuthorizedRelay: async (_ctx, _required, callback) => callback({...authorized, call: async () => { calls++; return policy; }})});
    await assert.rejects(source.sourcePolicy(context));
  }
  assert.equal(calls, 0);
});

test('source policy rejects a different source workspace and strips unknown transport fields', async () => {
  const build = result => fixture({withAuthorizedRelay: async (_ctx, _required, callback) => callback({binding, scopes: ['relay:read'], call: async () => result})}).source;
  await assert.rejects(build({...policy, workspaceId: 'other'}).sourcePolicy(context));
  await assert.rejects(build({...policy, workspaceId: undefined}).sourcePolicy(context));
  await assert.rejects(build({...policy, roomId: undefined}).sourcePolicy(context));
  assert.deepEqual(await build({...policy, unusedTransportField: 'do not expose'}).sourcePolicy(context), policy);
});

test('caller cannot select arbitrary actions, destinations, identities or source bindings', async () => {
  const {source, calls} = fixture();
  for (const input of [{action: 'workers.create', binding}, {action: 'getMessage', binding, messageId: MESSAGE, url: 'https://example.com'},
    {action: 'getMessage', binding: {...binding, accountId: PEER}, messageId: MESSAGE},
    {action: 'sendMessage', binding, command: {...command, senderId: PEER}},
    {action: 'sendMessage', binding, command: {...command, workspaceId: 'other'}}]) await assert.rejects(source.callSource(context, input));
  await assert.rejects(source.readMessage({principal: PEER, agent_id: AGENT, message: {id: MESSAGE}, context}));
  assert.equal(calls.length, 0);
});

test('unknown API failures are redacted and become uncertain after a write without an automatic retry', async () => {
  let writes = 0;
  const {source} = fixture({withAuthorizedRelay: async (_ctx, _required, callback) => callback({binding, scopes: ['relay:write'], call: async action => {
    if (action === 'messages.capabilities') return policy;
    writes++; throw new Error('secret-token-fixture');
  }})});
  const capability = createRelayMessageCapability({enabled: true, binding, ...source, authorizeRelay: async () => ({binding, scopes: ['relay:write']})});
  const result = await capability.callTool({name: 'relay_message_send', arguments: {
    visibility: 'private', room_id: policy.roomId, recipient_ids: [PEER], body: command.body, client_id: CLIENT
  }}, context);
  assert.equal(result.status, 'uncertain'); assert.equal(writes, 1); assert.equal(JSON.stringify(result).includes('secret-token'), false);
});

test('source callbacks cannot execute a second mutation through one invocation', async () => {
  let writes = 0;
  const {source} = fixture({withAuthorizedRelay: async (_ctx, _required, callback) => {
    const authorized = {binding, scopes: ['relay:write'], call: async () => { writes++; return {status: 'persisted', historyStore: 'relay-chat', message: record}; }};
    await callback(authorized); return callback(authorized);
  }});
  await assert.rejects(source.callSource(context, {action: 'sendMessage', binding, command})); assert.equal(writes, 1);
});

test('recipient outbox uses read scope, strips body, and never acknowledges on fetch', async () => {
  const calls = [], checks = [];
  const source = createAuthenticatedRelaySource({binding, withAuthorizedRelay: async (_ctx, required, callback) => {
    checks.push(required.scopes);
    return callback({binding, scopes: ['relay:read'], call: async (action, data) => {
      calls.push({action, data});
      return {notifications: [{id: ORIGINAL, messageId: MESSAGE, recipientId: ME, createdAt: record.createdAt, body: 'must not leak'}], hasMore: false};
    }});
  }});
  assert.deepEqual(await source.listNotifications(context, {limit: 20}), {
    notifications: [{id: ORIGINAL, messageId: MESSAGE, recipientId: ME, createdAt: record.createdAt}], hasMore: false
  });
  assert.deepEqual(checks, [['relay:read']]);
  assert.deepEqual(calls, [{action: 'messages.notifications', data: {limit: 20}}]);
});

test('outbox rejects foreign recipients and duplicate IDs without treating audit visibility as delivery', async () => {
  const own = {id: ORIGINAL, messageId: MESSAGE, recipientId: ME, createdAt: record.createdAt};
  for (const notifications of [[{...own, recipientId: PEER}], [own, own], [{...own, id: 'arbitrary'}]]) {
    const source = createAuthenticatedRelaySource({binding, withAuthorizedRelay: async (_ctx, _required, callback) =>
      callback({binding, scopes: ['relay:read'], call: async () => ({notifications, hasMore: false})})});
    await assert.rejects(source.listNotifications(context));
  }
});

test('outbox ACK requires write scope and reports handoff only, distinct from read or agent acknowledgment', async () => {
  const calls = [], checks = [];
  const source = createAuthenticatedRelaySource({binding, withAuthorizedRelay: async (_ctx, required, callback) => {
    checks.push(required.scopes);
    return callback({binding, scopes: ['relay:write'], call: async (action, data) => {
      calls.push({action, data});
      return {notificationId: ORIGINAL, handoffAcknowledgedAt: record.createdAt, readAt: 'must not propagate', agentAcknowledgedAt: 'must not propagate'};
    }});
  }});
  assert.deepEqual(await source.acknowledgeNotificationHandoff(context, {notificationId: ORIGINAL}), {
    notificationId: ORIGINAL, handoffAcknowledgedAt: record.createdAt
  });
  assert.deepEqual(checks, [['relay:write']]);
  assert.deepEqual(calls, [{action: 'messages.notifications.ack', data: {notificationId: ORIGINAL}}]);
});

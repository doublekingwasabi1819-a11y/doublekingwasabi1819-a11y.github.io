import test from 'node:test';
import assert from 'node:assert/strict';
import {createRelayMessageCapability, relayMessageToolDescriptors, SOURCE_CONTRACT, LEGACY_SOURCE_REVISION} from '../send-capability.mjs';

const ME = '11111111-1111-4111-8111-111111111111';
const PEER = '22222222-2222-4222-8222-222222222222';
const OTHER = '33333333-3333-4333-8333-333333333333';
const CLIENT = '44444444-4444-4444-8444-444444444444';
const MESSAGE = '55555555-5555-4555-8555-555555555555';
const ORIGINAL = '66666666-6666-4666-8666-666666666666';
const binding = {workspaceId: 'studio-a', accountId: ME, agentId: OTHER, runId: 'run-a'};
const policy = {contractVersion: SOURCE_CONTRACT, sourceRevision: 'fixture-proposed-v1', historyDurable: true,
  explicitAudienceMetadata: true, stableClientIdDedup: true, notificationsExplicitRecipientsOnly: true, privateParticipantsAndManagerOnly: true, publicWorkspaceOnly: true,
  atomicSameAudienceReplies: true};
const args = (extra = {}) => ({visibility: 'private', room_id: 'room-a', recipient_ids: [PEER], body: 'A persisted message.', client_id: CLIENT, ...extra});
const request = extra => ({name: 'relay_message_send', arguments: args(extra)});
const reply = extra => ({name: 'relay_message_reply', arguments: args({reply_to_message_id: ORIGINAL, ...extra})});
const row = (extra = {}) => ({id: MESSAGE, clientId: CLIENT, workspaceId: 'studio-a', roomId: 'room-a', visibility: 'private',
  senderId: ME, recipientIds: [PEER], notificationRecipientIds: [PEER], participantIds: [ME, PEER], body: 'A persisted message.', replyToMessageId: null,
  createdAt: '2026-10-05T02:00:00Z', ...extra});
function fixture(overrides = {}) {
  const calls = [], checks = [], persisted = new Map();
  const options = {enabled: true, binding,
    authorizeRelay: async (_context, needed) => { checks.push(needed); return {binding, scopes: ['relay:read', 'relay:write']}; },
    sourcePolicy: async () => policy,
    callSource: async (_context, call) => {
      calls.push(structuredClone(call));
      if (call.action === 'getMessage') return {message: row({id: ORIGINAL, senderId: PEER, recipientIds: [ME], notificationRecipientIds: [ME]})};
      const prior = persisted.get(call.command.clientId);
      if (prior && JSON.stringify(prior.command) !== JSON.stringify(call.command)) return {status: 'rejected', commit: 'not_applied', code: 'CONFLICT'};
      if (prior) return prior.result;
      const result = {status: 'persisted', historyStore: 'relay-chat', message: row(call.command)};
      persisted.set(call.command.clientId, {command: call.command, result});
      return result;
    }, ...overrides};
  return {capability: createRelayMessageCapability(options), calls, checks, persisted, options};
}
const rejects = (promise, code) => assert.rejects(promise, error => error.code === code);

test('disabled by default: no descriptors, source hooks, browser, or external side effect', async () => {
  let called = false;
  const capability = createRelayMessageCapability({callSource: () => { called = true; }});
  assert.deepEqual(capability.tools, []);
  await rejects(capability.callTool(request()), 'DISABLED');
  assert.equal(called, false);
});

test('strict fixed descriptors request Relay scopes without browser:control', () => {
  assert.deepEqual(relayMessageToolDescriptors.map(x => x.name), ['relay_message_send', 'relay_message_reply']);
  assert.deepEqual(relayMessageToolDescriptors[0].securitySchemes, [{type: 'oauth2', scopes: ['relay:write']}]);
  assert.deepEqual(relayMessageToolDescriptors[1].securitySchemes, [{type: 'oauth2', scopes: ['relay:read', 'relay:write']}]);
  for (const tool of relayMessageToolDescriptors) {
    assert.deepEqual(tool.securitySchemes, tool._meta.securitySchemes);
    assert.equal(tool.annotations.idempotentHint, true);
    assert.equal(tool.inputSchema.additionalProperties, false);
    for (const forbidden of ['sender_id', 'account_id', 'workspace_id', 'token', 'url', 'scope', 'sourcePolicy']) assert.equal(forbidden in tool.inputSchema.properties, false);
  }
  assert.ok(Object.isFrozen(relayMessageToolDescriptors[0].inputSchema));
});

test('private send binds sender and persists explicit audience/recipients before claiming success', async () => {
  const {capability, calls, checks} = fixture();
  const result = await capability.callTool(request(), {opaqueConnection: 'test'});
  assert.equal(result.status, 'persisted');
  assert.deepEqual(result.message.participantIds, [ME, PEER]);
  assert.deepEqual(result.history, {store: 'relay-chat', persisted: true, audience: 'Private', auditAccess: 'Conversation participants and manager may read', sender: `From ${ME}`, recipients: `To ${PEER}`});
  assert.equal(calls.length, 1);
  assert.equal(calls[0].command.senderId, ME);
  assert.deepEqual(calls[0].binding, binding);
  assert.equal(checks.length, 3);
});

test('workspace-public send has an explicit Public label and workspace-wide recipients', async () => {
  const {capability} = fixture();
  const result = await capability.callTool(request({visibility: 'public', recipient_ids: []}));
  assert.equal(result.status, 'persisted');
  assert.deepEqual(result.message.recipientIds, []);
  assert.deepEqual(result.message.participantIds, []);
  assert.equal(result.history.audience, 'Public');
  assert.equal(result.history.recipients, 'To all members of workspace studio-a');
  assert.deepEqual(result.message.notificationRecipientIds, []);
});

test('manager audit access does not create a ping; an explicit manager recipient still can receive one', async () => {
  const {capability} = fixture();
  const regular = await capability.callTool(request());
  assert.deepEqual(regular.message.notificationRecipientIds, [PEER]);
  assert.equal(regular.message.notificationRecipientIds.includes(OTHER), false);
  // OTHER is the fixture manager for this assertion. Roles are source-owned;
  // the capability never enumerates or auto-adds audit viewers.
  const manager = await capability.callTool(request({recipient_ids: [OTHER], client_id: ORIGINAL}));
  assert.deepEqual(manager.message.notificationRecipientIds, [OTHER]);
  assert.deepEqual(manager.message.participantIds, [ME, OTHER]);
});

test('public wake recipients are separate explicit targets, with no manager or workspace fan-out default', async () => {
  const {capability} = fixture();
  const result = await capability.callTool(request({visibility: 'public', recipient_ids: [], notify_recipient_ids: [PEER]}));
  assert.deepEqual(result.message.notificationRecipientIds, [PEER]);
  assert.deepEqual(result.message.recipientIds, []);
  assert.equal(result.history.recipients, 'To all members of workspace studio-a');
  await rejects(capability.callTool(request({visibility: 'public', recipient_ids: [], notify_recipient_ids: [OTHER]})), 'CONFLICT');
});

test('invalid audience, recipients, identity injection, and IDs never reach source', async () => {
  const cases = [
    {visibility: 'friends'}, {visibility: 'Public'}, {recipient_ids: []}, {recipient_ids: [ME]}, {recipient_ids: [PEER, OTHER]},
    {recipient_ids: [PEER, PEER]}, {recipient_ids: ['owner']}, {visibility: 'public', recipient_ids: [PEER]},
    {body: '   '}, {body: 'a'.repeat(12001)}, {client_id: 'new'}, {room_id: '../other'},
    {sender_id: OTHER}, {scope: 'relay:write'}, {token: 'not-a-token'}, {workspace_id: 'other'},
    {notify_recipient_ids: [OTHER]}, {notify_recipient_ids: [PEER, OTHER]}, {notify_recipient_ids: null},
    {visibility: 'public', recipient_ids: [], notify_recipient_ids: [PEER, PEER]},
    {visibility: 'public', recipient_ids: [], notify_recipient_ids: ['manager']}
  ];
  for (const invalid of cases) {
    const {capability, calls} = fixture();
    await rejects(capability.callTool(request(invalid)), 'VALIDATION'); assert.equal(calls.length, 0);
  }
});

test('requires the actual Relay grant; browser-only, read-only, and other binding are rejected', async () => {
  for (const scopes of [[], ['browser:control'], ['relay:read']]) {
    const {capability, calls} = fixture({authorizeRelay: async () => ({binding, scopes})});
    await rejects(capability.callTool(request()), 'FORBIDDEN'); assert.equal(calls.length, 0);
  }
  for (const changed of [{accountId: PEER}, {agentId: ME}, {workspaceId: 'studio-b'}, {runId: 'run-b'}]) {
    const {capability, calls} = fixture({authorizeRelay: async () => ({binding: {...binding, ...changed}, scopes: ['relay:read', 'relay:write']})});
    await rejects(capability.callTool(request()), 'FORBIDDEN'); assert.equal(calls.length, 0);
  }
});

test('source readiness is fail-closed, including truthful legacy revision and missing durable dedup', async () => {
  for (const incomplete of [null, {}, {...policy, sourceRevision: LEGACY_SOURCE_REVISION}, {...policy, contractVersion: 'legacy-dm'},
    ...['historyDurable', 'explicitAudienceMetadata', 'stableClientIdDedup', 'notificationsExplicitRecipientsOnly', 'privateParticipantsAndManagerOnly'].map(key => ({...policy, [key]: false}))]) {
    const {capability, calls} = fixture({sourcePolicy: async () => incomplete});
    await rejects(capability.callTool(request()), 'SOURCE_NOT_READY'); assert.equal(calls.length, 0);
  }
  const {capability, calls} = fixture({sourcePolicy: async () => ({...policy, publicWorkspaceOnly: false})});
  await rejects(capability.callTool(request({visibility: 'public', recipient_ids: []})), 'SOURCE_NOT_READY'); assert.equal(calls.length, 0);
});

test('stable client ID reconciles with source and rejects changed body, audience, or target', async () => {
  const {capability, calls} = fixture();
  const first = await capability.callTool(request());
  assert.deepEqual(await capability.callTool(request()), first);
  assert.equal(calls.length, 2);
  for (const changed of [{body: 'Changed'}, {recipient_ids: [OTHER]}, {room_id: 'room-b'}, {visibility: 'public', recipient_ids: []}]) await rejects(capability.callTool(request(changed)), 'CONFLICT');
  assert.equal(calls.length, 2);
});

test('transport failure is uncertain, never auto-retried; explicit retry preserves full command', async () => {
  const sent = []; let attempt = 0;
  const {capability} = fixture({callSource: async (_context, call) => {
    sent.push(structuredClone(call));
    if (++attempt === 1) throw new Error('Private token and credential path must not leak');
    return {status: 'persisted', historyStore: 'relay-chat', message: row(call.command)};
  }});
  const first = await capability.callTool(request());
  assert.equal(first.status, 'uncertain'); assert.equal(first.clientId, CLIENT); assert.equal(sent.length, 1);
  assert.equal(JSON.stringify(first).includes('credential'), false);
  await rejects(capability.callTool(request({body: 'Changed after timeout'})), 'CONFLICT');
  const retry = await capability.callTool(request());
  assert.equal(retry.status, 'persisted'); assert.equal(sent.length, 2); assert.deepEqual(sent[0], sent[1]);
});

test('source-side durable dedup survives capability restart with the same client ID', async () => {
  const {capability, options, persisted, calls} = fixture();
  const first = await capability.callTool(request());
  const restarted = createRelayMessageCapability(options);
  assert.deepEqual(await restarted.callTool(request()), first);
  assert.equal(calls.length, 2); assert.equal(persisted.size, 1);
  await rejects(restarted.callTool(request({body: 'Different'})), 'CONFLICT');
});

test('concurrent repeat cannot start a second mutation', async () => {
  let release, started;
  const gate = new Promise(resolve => { release = resolve; });
  const didStart = new Promise(resolve => { started = resolve; });
  let calls = 0;
  const {capability} = fixture({callSource: async (_context, call) => { calls++; started(); await gate; return {status: 'persisted', historyStore: 'relay-chat', message: row(call.command)}; }});
  const first = capability.callTool(request()); await didStart;
  await rejects(capability.callTool(request()), 'IN_PROGRESS');
  release(); assert.equal((await first).status, 'persisted'); assert.equal(calls, 1);
});

test('private reply validates original audience, persists reply target, and never marks read', async () => {
  const {capability, calls} = fixture();
  const result = await capability.callTool(reply());
  assert.equal(result.status, 'persisted'); assert.equal(result.message.replyToMessageId, ORIGINAL);
  assert.deepEqual(calls.map(x => x.action), ['getMessage', 'sendMessage']);
  assert.deepEqual(calls[1].command.participantIds, [ME, PEER]);
});

test('public replies stay in source workspace and room with all-workspace audience', async () => {
  const calls = [];
  const {capability} = fixture({callSource: async (_context, call) => {
    calls.push(call);
    return call.action === 'getMessage' ? {message: row({id: ORIGINAL, senderId: PEER, recipientIds: [], participantIds: [], visibility: 'public'})} :
      {status: 'persisted', historyStore: 'relay-chat', message: row(call.command)};
  }});
  const result = await capability.callTool(reply({visibility: 'public', recipient_ids: []}));
  assert.equal(result.status, 'persisted'); assert.equal(result.history.audience, 'Public'); assert.equal(calls.length, 2);
});

test('reply requires relay:read plus relay:write and source atomic audience enforcement', async () => {
  for (const overrides of [
    {authorizeRelay: async () => ({binding, scopes: ['relay:write']})},
    {sourcePolicy: async () => ({...policy, atomicSameAudienceReplies: false})}
  ]) {
    const {capability, calls} = fixture(overrides);
    await assert.rejects(capability.callTool(reply())); assert.equal(calls.length, 0);
  }
});

test('reply rejects cross-audience, cross-room, cross-workspace, and third-party thread targets', async () => {
  for (const changed of [{visibility: 'public', recipientIds: [], participantIds: []}, {roomId: 'room-b'}, {workspaceId: 'studio-b'},
    {senderId: OTHER, recipientIds: [PEER], participantIds: [PEER, OTHER]}, {id: MESSAGE}]) {
    const calls = [];
    const {capability} = fixture({callSource: async (_context, call) => { calls.push(call); return {message: row({id: ORIGINAL, ...changed})}; }});
    await assert.rejects(capability.callTool(reply())); assert.deepEqual(calls.map(x => x.action), ['getMessage']);
  }
});

test('scope revocation after reply lookup prevents mutation', async () => {
  let authCalls = 0;
  const {capability, calls} = fixture({authorizeRelay: async () => ({binding, scopes: ++authCalls === 1 ? ['relay:read', 'relay:write'] : []})});
  await rejects(capability.callTool(reply()), 'FORBIDDEN'); assert.deepEqual(calls.map(x => x.action), ['getMessage']);
});

test('revocation after an accepted write yields uncertainty without leaking source history', async () => {
  let authCalls = 0;
  const {capability, calls} = fixture({authorizeRelay: async () => ({binding, scopes: ++authCalls < 3 ? ['relay:write'] : []})});
  const result = await capability.callTool(request());
  assert.equal(result.status, 'uncertain'); assert.equal('message' in result, false); assert.equal(calls.length, 1);
});

test('noncanonical or unpersisted responses never manufacture a successful history receipt', async () => {
  for (const result of [undefined, {status: 'accepted'}, {status: 'persisted', historyStore: 'chatgpt', message: row()},
    {status: 'persisted', historyStore: 'relay-chat', message: row({senderId: OTHER})},
    {status: 'persisted', historyStore: 'relay-chat', message: row({recipientIds: [OTHER], participantIds: [ME, OTHER]})},
    {status: 'persisted', historyStore: 'relay-chat', message: row({visibility: 'public', recipientIds: [], participantIds: []})},
    {status: 'persisted', historyStore: 'relay-chat', message: row({body: 'Source changed body'})},
    {status: 'persisted', historyStore: 'relay-chat', message: row({replyToMessageId: ORIGINAL})}]) {
    const {capability} = fixture({callSource: async () => result});
    const outcome = await capability.callTool(request()); assert.equal(outcome.status, 'uncertain'); assert.equal('message' in outcome, false);
  }
});

test('explicit known source rejection is not misreported as delivered or automatically retried', async () => {
  let calls = 0;
  const {capability} = fixture({callSource: async () => { calls++; return {status: 'rejected', commit: 'not_applied', code: 'NOT_FOUND'}; }});
  await rejects(capability.callTool(request()), 'NOT_FOUND'); assert.equal(calls, 1);
});

test('source history capacity is a definite rejection distinct from local journal capacity', async () => {
  const {capability} = fixture({callSource: async () => ({status: 'rejected', commit: 'not_applied', code: 'CAPACITY'})});
  await rejects(capability.callTool(request()), 'SOURCE_CAPACITY');
});

test('a repeated successful send cannot bypass fresh revoked connection checks', async () => {
  let revoked = false;
  const {capability} = fixture({authorizeRelay: async () => ({binding, scopes: revoked ? [] : ['relay:write']})});
  await capability.callTool(request()); revoked = true;
  await rejects(capability.callTool(request()), 'FORBIDDEN');
});

test('repeated send consults source tombstone rather than returning a cached history receipt', async () => {
  let deleted = false;
  const {capability} = fixture({callSource: async (_ctx, call) => deleted ? {status: 'rejected', commit: 'not_applied', code: 'NOT_FOUND'} :
    {status: 'persisted', historyStore: 'relay-chat', message: row(call.command)}});
  assert.equal((await capability.callTool(request())).status, 'persisted');
  deleted = true;
  await rejects(capability.callTool(request()), 'NOT_FOUND');
});

test('bounded journal refuses new IDs without evicting an uncertain request', async () => {
  let calls = 0;
  const {capability} = fixture({maxJournalEntries: 1, callSource: async () => { calls++; throw new Error('timeout'); }});
  assert.equal((await capability.callTool(request())).status, 'uncertain');
  await rejects(capability.callTool(request({client_id: ORIGINAL})), 'CAPACITY');
  assert.equal(calls, 1);
  assert.equal((await capability.callTool(request())).status, 'uncertain');
  assert.equal(calls, 2);
});

// Real local Edge handler + disposable PGlite. No network, browser, or live credentials.
// Run with RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite
// from send-proposal: node test/backend-roundtrip.mjs
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createAuthenticatedRelaySource} from '../authenticated-source-adapter.mjs';
import {createRelayMessageCapability} from '../send-capability.mjs';
import {createMessageFixture} from '../../backend-implementation/proposed/tests/helpers/message-fixture.mjs';

const fixture = await createMessageFixture();
let checks = 0;
const check = async (name, operation) => { await operation(); checks++; console.log(`PASS ${name}`); };
function linked(actor) {
  const binding = {workspaceId: fixture.capabilities.workspaceId, accountId: actor.id, agentId: actor.agentId, runId: actor.runId};
  const context = Object.freeze({fixtureActor: actor.id});
  let scopes = ['relay:read', 'relay:write'];
  let loseResponse = false;
  async function live() {
    const current = await fixture.rpc('context', actor.token);
    assert.equal(current.user.id, binding.accountId);
    assert.equal(current.actor.id, binding.agentId);
    assert.equal(current.actor.session, binding.runId);
    return {binding, scopes};
  }
  const source = createAuthenticatedRelaySource({binding, withAuthorizedRelay: async (received, required, callback) => {
    assert.equal(received, context);
    const authority = await live();
    assert.ok(required.scopes.every(scope => authority.scopes.includes(scope)));
    const result = await callback({...authority, call: async (action, data) => {
      const response = await fixture.request(action, actor.token, data);
      if (response.status !== 200) throw new Error('Local backend rejected the API request.');
      if (action === 'messages.send' && loseResponse) { loseResponse = false; throw new Error('Simulated lost response after commit'); }
      return response.body;
    }});
    await live();
    return result;
  }});
  const makeCapability = () => createRelayMessageCapability({enabled: true, binding, ...source,
    authorizeRelay: async received => { assert.equal(received, context); return live(); }});
  return {binding, context, source, capability: makeCapability(), makeCapability,
    scopes: next => { scopes = next; }, loseResponse: () => { loseResponse = true; }};
}
const a = linked(fixture.a), b = linked(fixture.b), c = linked(fixture.c);
const args = (extra = {}) => ({visibility: 'private', room_id: fixture.capabilities.roomId,
  recipient_ids: [fixture.b.id], body: '  Local private body preserved exactly.\n', client_id: randomUUID(), ...extra});
const invoke = (who, values, reply = false) => who.capability.callTool({name: reply ? 'relay_message_reply' : 'relay_message_send', arguments: values}, who.context);
let privateRequest, privateReceipt, replyReceipt, publicReceipt;
try {
  await check('actual capabilities discover the database workspace and room', async () => {
    const receipt = await a.source.sourcePolicy(a.context);
    assert.equal(receipt.workspaceId, a.binding.workspaceId);
    assert.equal(receipt.roomId, fixture.capabilities.roomId);
    assert.equal(receipt.privateParticipantsAndManagerOnly, true);
  });
  await check('real private send persists exact body, sender, audience, and recipient', async () => {
    privateRequest = args(); privateReceipt = await invoke(a, privateRequest);
    assert.equal(privateReceipt.status, 'persisted');
    assert.equal(privateReceipt.message.body, privateRequest.body);
    assert.equal(privateReceipt.message.senderId, fixture.a.id);
    assert.deepEqual(privateReceipt.message.recipientIds, [fixture.b.id]);
    assert.equal(privateReceipt.history.audience, 'Private');
    const dbRecord = (await fixture.request('messages.get', fixture.b.token, {messageId: privateReceipt.message.id})).body.message;
    assert.deepEqual(dbRecord, privateReceipt.message);
  });
  await check('exact retry and restarted capability reconcile one durable row and outbox entry', async () => {
    assert.deepEqual(await invoke(a, privateRequest), privateReceipt);
    assert.deepEqual(await a.makeCapability().callTool({name: 'relay_message_send', arguments: privateRequest}, a.context), privateReceipt);
    assert.equal((await fixture.sql('select count(*)::int as n from relay_private.message_records where id=$1', [privateReceipt.message.id])).rows[0].n, 1);
    assert.equal((await fixture.sql('select count(*)::int as n from relay_private.message_outbox where message_id=$1', [privateReceipt.message.id])).rows[0].n, 1);
    await assert.rejects(invoke(a, {...privateRequest, body: 'Changed'}), error => error.code === 'CONFLICT');
  });
  await check('private audience permits both participants and manager, but no unrelated worker', async () => {
    for (const actor of [fixture.a, fixture.b, fixture.manager]) assert.equal((await fixture.request('messages.get', actor.token, {messageId: privateReceipt.message.id})).body.message.id, privateReceipt.message.id);
    assert.equal((await fixture.request('messages.get', fixture.c.token, {messageId: privateReceipt.message.id})).body.status, 'not_found');
  });
  await check('recipient outbox excludes manager audit and keeps handoff distinct from read/agent ACK', async () => {
    const pending = await b.source.listNotifications(b.context);
    assert.equal(pending.notifications.length, 1);
    const notification = pending.notifications[0];
    assert.equal(notification.messageId, privateReceipt.message.id);
    assert.equal(notification.recipientId, fixture.b.id);
    assert.equal((await fixture.request('messages.notifications', fixture.manager.token, {limit: 100})).body.notifications.length, 0);
    assert.equal((await c.source.listNotifications(c.context)).notifications.length, 0);
    const ack = await b.source.acknowledgeNotificationHandoff(b.context, {notificationId: notification.id});
    assert.ok(ack.handoffAcknowledgedAt);
    assert.deepEqual(await b.source.acknowledgeNotificationHandoff(b.context, {notificationId: notification.id}), ack);
    assert.equal((await b.source.listNotifications(b.context)).notifications.length, 0);
    assert.equal((await fixture.rpc('dm.notifications', fixture.b.token)).unreadDirectMessages, 1);
  });
  await check('canonical authorized read retains actual room and reply metadata', async () => {
    const message = await b.source.readMessage({principal: fixture.b.id, agent_id: fixture.b.agentId, message: {id: privateReceipt.message.id}, context: b.context});
    assert.equal(message.body, privateRequest.body);
    assert.equal(message.roomId, fixture.capabilities.roomId);
    assert.equal(message.replyToMessageId, null);
  });
  await check('actual private reply persists the source link and pings only the original sender', async () => {
    replyReceipt = await invoke(b, args({recipient_ids: [fixture.a.id], body: 'Private reply', reply_to_message_id: privateReceipt.message.id}), true);
    assert.equal(replyReceipt.status, 'persisted');
    assert.equal(replyReceipt.message.replyToMessageId, privateReceipt.message.id);
    assert.deepEqual(replyReceipt.message.notificationRecipientIds, [fixture.a.id]);
    assert.equal((await a.source.listNotifications(a.context)).notifications[0].messageId, replyReceipt.message.id);
    assert.equal((await fixture.request('messages.notifications', fixture.manager.token, {limit: 100})).body.notifications.length, 0);
  });
  await check('actual public message is workspace-readable with only explicit notification targets', async () => {
    a.scopes(['relay:write']);
    publicReceipt = await invoke(a, args({visibility: 'public', recipient_ids: [], notify_recipient_ids: [fixture.b.id], body: 'Workspace public fixture'}));
    a.scopes(['relay:read', 'relay:write']);
    assert.equal(publicReceipt.status, 'persisted'); assert.equal(publicReceipt.history.audience, 'Public');
    for (const actor of [...fixture.users, fixture.manager]) assert.equal((await fixture.request('messages.get', actor.token, {messageId: publicReceipt.message.id})).body.message.id, publicReceipt.message.id);
    assert.equal((await b.source.listNotifications(b.context)).notifications.some(value => value.messageId === publicReceipt.message.id), true);
    assert.equal((await c.source.listNotifications(c.context)).notifications.length, 0);
    assert.equal((await fixture.request('messages.notifications', fixture.manager.token, {limit: 100})).body.notifications.length, 0);
  });
  await check('actual public reply preserves workspace audience and the original reply link', async () => {
    const result = await invoke(c, args({visibility: 'public', recipient_ids: [], notify_recipient_ids: [fixture.a.id],
      body: 'Public reply from third workspace member', reply_to_message_id: publicReceipt.message.id}), true);
    assert.equal(result.status, 'persisted');
    assert.equal(result.message.replyToMessageId, publicReceipt.message.id);
    assert.equal(result.message.visibility, 'public');
    assert.deepEqual(result.message.notificationRecipientIds, [fixture.a.id]);
    for (const actor of [...fixture.users, fixture.manager]) assert.equal((await fixture.request('messages.get', actor.token, {messageId: result.message.id})).body.message.id, result.message.id);
    assert.equal((await fixture.request('messages.notifications', fixture.manager.token, {limit: 100})).body.notifications.length, 0);
  });
  await check('real source rejects reply visibility changes without another row', async () => {
    await assert.rejects(invoke(b, args({visibility: 'public', recipient_ids: [], body: 'Invalid public reply', reply_to_message_id: privateReceipt.message.id}), true), error => error.code === 'REPLY_MISMATCH');
  });
  await check('lost real commit response remains uncertain and exact retry returns one message', async () => {
    const values = args({body: 'Response-loss fixture'}); a.loseResponse();
    const uncertain = await invoke(a, values); assert.equal(uncertain.status, 'uncertain');
    const reconciled = await invoke(a, values); assert.equal(reconciled.status, 'persisted');
    assert.equal((await fixture.sql('select count(*)::int as n from relay_private.message_records where sender_id=$1 and client_id=$2', [fixture.a.id, values.client_id])).rows[0].n, 1);
    assert.equal((await fixture.sql('select count(*)::int as n from relay_private.message_outbox where message_id=$1', [reconciled.message.id])).rows[0].n, 1);
  });
  await check('browser-only scope cannot send via the concrete authorized adapter', async () => {
    a.scopes(['browser:control']); await assert.rejects(invoke(a, args()), error => error.code === 'FORBIDDEN');
    a.scopes(['relay:read', 'relay:write']);
  });
  await check('actual deleted private message stays deleted on retry using source tombstone', async () => {
    await fixture.sql('delete from relay_private.direct_messages where id=$1', [privateReceipt.message.id]);
    await assert.rejects(invoke(a, privateRequest), error => error.code === 'NOT_FOUND');
  });
  console.log(`PASS ${checks} real local handler/SQL adapter checks`);
} finally { await fixture.close(); }

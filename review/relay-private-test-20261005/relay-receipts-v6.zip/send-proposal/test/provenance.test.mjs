import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';

test('pinned current-main source snapshots match recorded Git blob SHA exactly', async () => {
  const root = new URL('../', import.meta.url);
  const provenance = JSON.parse(await readFile(new URL('reference/SOURCE.json', root), 'utf8'));
  assert.equal(provenance.ref, '56c47abe01d807a52cde82ebc46d7038ae36cdcb');
  for (const source of provenance.files) {
    const bytes = await readFile(new URL(source.local, root));
    const actual = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
    assert.equal(actual, source.sha, source.path);
  }
});

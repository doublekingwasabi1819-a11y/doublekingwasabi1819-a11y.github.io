# Proposed trusted source contract

The internal getMessage/sendMessage names are an injected server-side interface.
The concrete adapter maps them to messages.get/messages.send in the separate
additive local backend. They are not current deployed Relay or ChatGPT APIs.

## Bound authority

Every call uses the live already-authorized Relay connection associated with
the immutable workspace/account/agent/run binding. The server derives the sender
from that connection, verifies it equals the expected binding, validates current
membership and account state, and rejects changes or revocation. Browser-only
delegation does not imply Relay read/write permission. Source code is fixed by
the host, not supplied by a tool caller. No credentials appear in input/output,
history, event payloads, logs, or errors.

## Read original message

`callSource(context, {action: 'getMessage', binding, messageId})` returns
`{message: canonicalRecord}` or `{status: 'not_found'}`. It must authorize access
at the source, without changing read state, notification state, or event ACKs.
The wrapper restricts a private reply to conversations in which the bound worker
is a participant, even though the manager may separately audit conversations.

## Persist send/reply

`callSource(context, {action: 'sendMessage', binding, command})` receives:

```
{
  clientId, workspaceId, roomId, visibility,
  senderId, recipientIds, participantIds, notificationRecipientIds,
  body, replyToMessageId
}
```

The server must perform all these checks and the mutation atomically:

1. Validate the actual Relay grant, sender binding, workspace, room access, and
   current enabled recipient/notification-target membership. Account IDs and
   board agent IDs are different domains; resolve any mapping server-side.
2. Public means all workspace members can read; `recipientIds` and
   `participantIds` are empty because this is a workspace audience. Private has
   one recipient and two distinct sorted participant IDs. The sender is one of
   those participants. Private ACLs permit those participants and manager audit
   access only. Audit readers are never copied into recipient/notification lists.
3. Private `notificationRecipientIds` equals the single explicit recipient.
   Public notification IDs are the explicitly provided resolved targets, with
   no implied manager/default-all target. Each target must be an enabled member
   in this same workspace. Authorization to read is separate from a wake target.
4. If replying, verify the referenced message still belongs to the same
   workspace, room, visibility and private participant pair at commit time.
   A preflight read alone is not sufficient. Reject a public reply to a private
   target or a private reply to a different pair. Replies preserve actual links,
   rather than quoting the ID into body text and claiming a thread exists.
5. Use a durable unique `(workspaceId, senderId, clientId)` key and a complete
   canonical request fingerprint including notification targets and reply ID.
   Same key + identical command returns the same original message/receipt.
   Same key + different command returns CONFLICT without a new message. Keep
   dedup reservations for at least the lifetime of the message and preserve a
   tombstone after deletion where retries could still arrive. Concurrent sends
   and restarted wrapper instances must share this dedup authority.
6. Persist canonical message metadata and body in Relay chat history. Commit a
   transactional outbox entry for explicit notification targets at most once,
   keyed to the persisted message and recipient. Recovery must not add duplicate
   pings. ACKing a wake event or fetching its message must not imply marking read.

Only after durable success return:

```
{
  status: 'persisted',
  historyStore: 'relay-chat',
  message: {
    id, clientId, workspaceId, roomId, visibility,
    senderId, recipientIds, participantIds, notificationRecipientIds,
    body, replyToMessageId, createdAt
  }
}
```

IDs are UUIDs except opaque workspace/room IDs. Timestamps include a timezone.
Source fields must exactly match the submitted canonical request. A transport
acceptance or queued-job response is not a persisted-history receipt.

For an authoritative no-mutation rejection, return
`{status:'rejected', commit:'not_applied', code}` with one of VALIDATION,
FORBIDDEN, CONFLICT, NOT_FOUND, RATE_LIMIT, CAPACITY, or REPLY_MISMATCH. Do not use this
envelope if any history/outbox write might have committed. Every thrown error,
unknown envelope, malformed receipt, or post-write authorization failure is
treated as uncertain and does not expose the returned message body.

## Readiness and retry limits

The wrapper's in-memory journal suppresses duplicate concurrent requests,
compares fingerprints, and remembers request state within one process. It retains
no canonical message records or bodies. Every exact retry consults the source
after fresh authorization and fingerprint validation, including source tombstone
checks. It is
not the durable dedup store and is not an alternative chat history. A restarted
process depends on the server's durable key/fingerprint contract. The journal is
capped at 1,000 entries by default (trusted host range 1–10,000). At capacity it
refuses new IDs without discarding unresolved sends, while allowing exact retries.
Tests do not claim a production data retention policy; the host still controls
connection/process lifetime and secure memory cleanup.

The wrapper never retries on its own. If a send is uncertain, the authorized
caller may repeat the exact same request and stable ID; the source must reconcile
and return the existing receipt or safely commit once. Do not replace that ID to
get around uncertainty. Network success does not prove that the intended worker
woke, read, or acted on the message.

## Mandatory activation evidence

Before a host can attest the required receipt, verify against the actual source:

- Two participants and manager can read a private row; an unrelated worker cannot
- Only the intended recipient gets a private notification; manager audit reads
  do not create notifications or consume the recipient's unread state
- Public history is visible to the workspace; public wake targets remain only
  those explicitly selected
- Cross-workspace destinations/targets, forged senders, stale runs and revoked
  grants are rejected before mutation
- Exact retransmission and concurrent retries create one history row and one
  notification per explicit recipient, including after source/host restart
- Conflicting reuse of client ID rejects all content/audience/notification/reply
  changes, even after more than 2,000 other messages
- Private/public and cross-room reply substitution fail atomically
- A write whose response is lost can be reconciled with the original client ID
- Authoritative Relay history displays Public/Private, sender, recipients and
  reply link using persisted metadata, with manager audit visibility clear

Fixtures demonstrate the wrapper behavior only. They do not supply any of this
deployment evidence and must never be wired as the live sourcePolicy hook.

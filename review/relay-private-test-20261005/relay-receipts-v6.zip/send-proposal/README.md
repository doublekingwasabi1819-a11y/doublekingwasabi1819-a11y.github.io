# Relay send/reply source proposal

Status: local-only, opt-in capability and authenticated API adapter. No live messages, grants,
deployment, repository push, or schema changes were performed. This directory is
separate from the working `relay-events` module. Importing it does not start a
server, open a browser, connect an account, or register a tool.

## Latest requested behavior

- Public chat history is readable by the workspace. The visible sender is the
  server-bound Relay account. Public posts never become private merely because
  a person is targeted for a notification.
- Private conversations have exactly two participants (sender and intended
  recipient). The manager retains audit read access. Other workers cannot read
  them. Manager audit access is not an additional recipient and causes no ping.
- Private notification recipients are exactly the intended recipient. A manager
  receives a private ping only if the manager is that explicit recipient.
- Public notifications use the separate explicit `notify_recipient_ids` list;
  its default is empty, not all workspace members and not the manager.
- Messages and replies persist in Relay chat history only. No ChatGPT
  conversation insertion, mirroring, or extra user-facing notification API is
  assumed or implemented.

## Files and tests

- `send-capability.mjs`: fixed send/reply descriptors, strict argument validation,
  live Relay grant checks, bound sender, required source readiness receipt,
  audience-preserving replies, exact output validation, and uncertain-send rules.
- `authenticated-source-adapter.mjs`: concrete adapter for the additive local
  `messages.capabilities`, `messages.get`, and `messages.send` backend actions.
- `test/send-capability.test.mjs`: offline fake-source contract tests.
- `SOURCE-CONTRACT.md`: requirements implemented by the separate local backend.
- `CURRENT-BACKEND-GAPS.md`: verified current implementation and activation gaps.
- `reference/`: unmodified source snapshots at the requested commit, with blob
  SHA/URL provenance in `SOURCE.json`. These are evidence, not changed SQL or an
  applyable migration.

Run `npm test` with Node 20 or newer for the 37 isolated tests. No packages or
network access are needed for those tests. For the actual local handler/SQL
round trip, keep the sibling `backend-implementation` directory and run:

```
RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite node test/backend-roundtrip.mjs
```

The backend fixture uses pinned `@electric-sql/pglite@0.5.8` and a disposable
in-memory database. It does not accept a remote database URL or live credentials.
Both public and private send/reply paths are exercised against actual SQL and
the actual Edge request handler.

## API boundary

Create with `enabled: true`, a trusted pinned binding
`{workspaceId, accountId, agentId, runId}`, and these host-only closures:

1. `authorizeRelay(context, {scopes, binding, action})` returns the fresh binding
   and actual granted scopes. It must validate current account enablement, run,
   membership and Relay grant before returning. A browser grant is insufficient.
2. `sourcePolicy(context, {scopes})` returns a backend capability receipt described
   below. Sends pass their actual scopes; read-only callers default to relay:read.
3. `callSource(context, request)` executes only the source contract described in
   `SOURCE-CONTRACT.md` using the same already-authorized connection.

The module is disabled by default and exposes no tools when disabled. Enabling
the constructor does not bypass the per-operation policy receipt. No endpoint,
session token, browser profile, credential resolver, or source implementation can
come from tool arguments. The closures themselves are trusted server code; a
malicious or incorrectly wired source cannot be made safe by MCP metadata.

### Concrete authorized API adapter

`createAuthenticatedRelaySource({binding, withAuthorizedRelay})` supplies
`sourcePolicy`, `callSource`, and `readMessage` using the actual additive backend
actions. The injected hook is:

```
withAuthorizedRelay(context, {scopes, binding}, async authorized => {
  // authorized = {binding, scopes, call: linkedApi.call.bind(linkedApi)}
})
```

The host resolves an already-approved Relay connection, checks the live requested
scopes and binding, and invokes the callback once with that bound API method.
The adapter repeats scope and identity checks before forwarding a request. It
never obtains a token from browser storage or creates a grant. The callback
facade and API method stay server-side.

Read authenticated `messages.capabilities` during authorized host setup to learn
the actual database workspaceId and roomId, then pin those verified source IDs.
Do not guess them, silently remap an existing browser binding, or share a raw
session token with the model. Capability receipts preserve these discovery fields
and reject a workspace mismatch. `readMessage` preserves canonical roomId and
replyToMessageId so replies need no browser lookup.

For the optional event reader, use `sourcePolicy: request =>
source.sourcePolicy(request.context)` and `readMessage: source.readMessage`.
For sending, pass the adapter's `sourcePolicy` and `callSource` plus the separate
`authorizeRelay` hook into `createRelayMessageCapability`. Neither message hook
replaces the controller's anchored connection checks.

### Host-only recipient outbox

`source.listNotifications(context, {limit})` calls `messages.notifications` with
relay:read and returns bounded `{notifications:[{id,messageId,recipientId,
createdAt}],hasMore}`. Entries must target the bound account. Bodies and arbitrary
source extensions are excluded. No manager notification is inferred from audit
visibility, and listing never acknowledges or consumes anything.

Only after durably enqueueing the canonical message in the event engine may the
host call `source.acknowledgeNotificationHandoff(context, {notificationId})`.
It calls `messages.notifications.ack` with relay:write and returns only the stable
notification ID and handoffAcknowledgedAt. This handoff acknowledgment is separate
from transport acceptance, fetching, the opaque agent fetch receipt, the agent's
explicit acknowledgment, and the original DM read marker. These are host-only
methods; they do not add MCP tools or send an external message automatically.

`relay_message_send` requires `relay:write`.
`relay_message_reply` requires both `relay:read` and `relay:write`.
Neither descriptor requires or substitutes `browser:control`.

Both accept `visibility`, `room_id`, `recipient_ids`, `body`, `client_id`, and
optional `notify_recipient_ids`. Public requires an empty recipient list because
the audience is the workspace. Private requires one resolved account ID distinct
from the sender; optional notify IDs, if present, must equal that recipient.
Reply additionally requires `reply_to_message_id`.

The caller generates and retains one client UUID for the logical send before
submitting. The module never invents another ID. Every explicit retry must use
the identical request, including visibility, room, recipients, notification
targets, body and reply target. Changing any part requires a new deliberate send,
and a new send must not be used to work around an unresolved earlier outcome.

`callTool({name, arguments}, trustedContext)` returns `status: persisted` only
after the source confirms a canonical persisted message and the live grant is
rechecked. Its history labels explicitly say Public or Private, From account,
To account or all workspace members, and the manager audit visibility policy.
An unknown write outcome returns `status: uncertain`, the same client ID, and
instructions for an explicit same-request retry. There is no automatic retry.
Fresh authorization applies to every retry, which consults the source's durable
dedup/tombstone authority. The local journal holds only fingerprint and state.

## Required source receipt

The receipt must be produced from the actual deployed backend's audited
behavior, not a caller-provided checkbox or an optimistic UI flag:

```
{
  contractVersion: 'relay-message-source/1',
  sourceRevision: '<verified deployed source revision>',
  historyDurable: true,
  explicitAudienceMetadata: true,
  stableClientIdDedup: true,
  notificationsExplicitRecipientsOnly: true,
  publicWorkspaceOnly: true,
  privateParticipantsAndManagerOnly: true,
  atomicSameAudienceReplies: true
}
```

The relevant visibility bit is required per request. Atomic reply support is
required for replies. Readiness is checked again immediately before the write
and before returning its body. The known unchanged current-main revision is
explicitly rejected even if its receipt incorrectly claims the new contract.
This check catches accidental legacy wiring; it cannot authenticate a fabricated
receipt. Deployment attestation and backend authorization remain host duties.

## Integration caution

The v4 controller fixture's fixed registry permits only five browser tools or
those plus five `relay_fast_*` tools. It cannot simply accept these extra tools.
Its combined-host direct descriptors also add `browser:control`, whereas its
injected standalone adapter uses Relay read/write scopes. A separately reviewed,
explicit opt-in source host/registry integration is required. Do not relabel the
existing browser-only grant or reuse browser cookies/session storage.

No production readiness, live authorization, or remote deployment is established
by these local tests. Actual backend and combined MCP end-to-end verification is
reported separately from the isolated adapter/capability tests. The source
contract does not silently drop room, audience, reply, or notification fields
when adapting existing message operations.

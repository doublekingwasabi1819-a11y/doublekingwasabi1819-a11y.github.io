# Local validation

Validated 2026-10-05, using only offline fixtures and pinned read-only repository
snapshots. No live Relay requests, messages, credentials, account grants,
production schema mutations, pushes, or deployments were made.

- `npm test`: 37 isolated tests pass, 0 fail
- `node --check send-capability.mjs`: pass
- `node --check authenticated-source-adapter.mjs`: pass
- All 8 pinned source snapshots match their recorded Git blob SHA exactly
- `RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite node test/backend-roundtrip.mjs`:
  13 real local Edge handler + PGlite adapter checks pass

Coverage includes explicit opt-in, strict schemas, pinned sender/workspace/run,
Relay scope enforcement, browser-only rejection, readiness receipts, Public and
Private history labels, manager audit versus notifications, explicit public
notification targets, reply audience validation, stable client IDs, mismatched
request conflicts, uncertain sends without automatic retries, source-side dedup
after restart, concurrent requests, mid-flight grant revocation, invalid source
receipts, bounded journal capacity, and frozen source provenance.

The journal is bounded and retains only request hash/state. Exact retries
reconcile with the real source's dedup/tombstone authority after fresh
authorization and fingerprint validation. No message records/bodies are cached.

The concrete adapter's isolated tests additionally cover source-discovered
workspace/room IDs, strict authorized read/write hooks, body-free recipient-only
outbox reads, and handoff acknowledgments distinct from message reads/agent ACKs.
The actual SQL/handler round trip covers both public and private send/reply,
body-preserving persistence, dynamic source namespaces, exact replay/restart
dedup, manager audit with no implicit ping, explicit public notification targets,
recipient outbox and handoff-only ACK, invalid cross-visibility replies, a lost
committed response, browser-only scope rejection, and source deletion tombstones.
Combined MCP wire/event-engine end-to-end tests are reported separately.
No live grant exchange, deployment, production availability, or actual remote
worker wake/reading/execution is claimed.

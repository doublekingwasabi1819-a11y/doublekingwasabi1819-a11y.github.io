import {lstat, realpath} from 'node:fs/promises';
import {isAbsolute, dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRelayProductionHost} from './host.mjs';
import {createLoopbackEntry} from './http-entry.mjs';

/** The file is executable operator configuration, not a secret/identity import.
 * Require administrator-owned, non-service-writable configuration and ancestors.
 * No user-controlled URL, package name or environment module path is imported.
 */
async function checkedConfiguration(path) {
  if (typeof path !== 'string' || !isAbsolute(path) || !path.endsWith('.mjs') || await realpath(path) !== path) {
    throw new TypeError('An administrator-owned configuration module is required.');
  }
  let current = path;
  while (true) {
    const stat = await lstat(current);
    if (stat.isSymbolicLink() || stat.uid !== 0 || (stat.mode & 0o022) ||
        (current === path ? !stat.isFile() : !stat.isDirectory())) throw new TypeError('Configuration must not be service-writable.');
    if (current === '/') break;
    current = dirname(current);
  }
  return (await import(pathToFileURL(path).href)).default;
}

export async function startProductionCli({args = process.argv.slice(2), env = process.env,
  output = process.stdout} = {}) {
  if (args.length !== 3 || args[0] !== '--serve' || args[1] !== '--config' ||
      typeof process.getuid !== 'function' || process.getuid() === 0 ||
      ['NODE_OPTIONS', 'NODE_PATH', 'RELAY_FIXTURE_MCP_TOKEN'].some(name => env[name])) {
    throw new TypeError('Explicit non-root production configuration is required.');
  }
  const configuration = await checkedConfiguration(args[2]);
  if (!configuration || Object.getPrototypeOf(configuration) !== Object.prototype ||
      Object.keys(configuration).some(name => !['origin', 'issuers', 'profileRoot', 'hooks', 'port'].includes(name)) ||
      (configuration.port !== undefined && (!Number.isInteger(configuration.port) || configuration.port < 1 || configuration.port > 65535))) {
    throw new TypeError('A reviewed production configuration is required.');
  }
  const {port, ...options} = configuration;
  const application = await createRelayProductionHost(options);
  const entry = createLoopbackEntry({origin: options.origin, application, port});
  try {
    const address = await entry.listen();
    output.write(`Relay browser loopback ingress: 127.0.0.1:${address.port}\n`);
    return entry;
  } catch (error) {await entry.close().catch(() => {}); throw error;}
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  let entry;
  try {entry = await startProductionCli();}
  catch {process.stderr.write('Relay production startup failed. Review the required configuration and hooks.\n'); process.exitCode = 1;}
  if (entry) {
    // Spontaneous authorization-channel loss also shuts ingress and reaches the
    // supervisor. Failed bounded cleanup must not leave a healthy-looking main
    // process supervising a hung browser; systemd then tears down its cgroup.
    void entry.completion.then(outcome => {
      if (!outcome.ok) {
        process.stderr.write('Relay production stopped after authorization or cleanup failure.\n', () => process.exit(1));
      }
    });
    let stopping = false;
    for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => {
      if (stopping) return; stopping = true;
      void entry.close().catch(() => {});
    });
  }
}

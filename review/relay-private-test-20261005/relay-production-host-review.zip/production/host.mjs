import {lstat, realpath} from 'node:fs/promises';
import {isAbsolute, parse, resolve} from 'node:path';
import {createRelayBrowserHost} from '../controller/relay-host.mjs';
import {createOAuthGrantBridge} from '../controller/oauth-bridge.mjs';

export const LIMITS = Object.freeze({maxSessions: 2, maxRequests: 8, maxContexts: 8,
  maxGrants: 8, maxBodyBytes: 65536, maxGrantTTL: 900000, hookTimeout: 5000});
const hookNames = ['verifyAccessToken', 'resolveHostReference', 'resolveBinding',
  'resolveWorkerSession', 'authorizeAction', 'subscribeRevocations'];
const plain = value => value && Object.getPrototypeOf(value) === Object.prototype;
const denied = () => Object.assign(new Error('Production authorization is unavailable.'), {code: 'AUTH_REQUIRED'});

export function canonicalOrigin(value) {
  let url;
  try {url = new URL(value);} catch {throw new TypeError('An explicit canonical HTTPS origin is required.');}
  if (typeof value !== 'string' || value.length > 2048 || url.protocol !== 'https:' ||
      url.origin !== value || url.username || url.password || url.search || url.hash) {
    throw new TypeError('An explicit canonical HTTPS origin is required.');
  }
  return url.origin;
}

/**
 * Browser-only composition, deliberately without an OAuth provider or account
 * selection. Hooks are trusted, read-only authority checks with cancellation.
 * This factory never listens or imports a human/manager session. There is no
 * createDriver, relayAdapter, host option or default identity in this API.
 */
export async function createRelayProductionHost(options = {}) {
  if (!plain(options) || Object.keys(options).some(key =>
    !['origin', 'issuers', 'profileRoot', 'hooks'].includes(key))) throw new TypeError('Explicit production configuration is required.');
  const origin = canonicalOrigin(options.origin), hooks = options.hooks;
  if (!plain(hooks) || hookNames.some(name => typeof hooks[name] !== 'function') ||
      Object.keys(hooks).some(name => !hookNames.includes(name))) throw new TypeError('All reviewed production authority and revocation hooks are required.');
  const root = options.profileRoot;
  if (typeof root !== 'string' || !isAbsolute(root) || resolve(root) !== root || root === parse(root).root) {
    throw new TypeError('A canonical host-owned private profile root is required.');
  }
  const stat = await lstat(root);
  if (!stat.isDirectory() || stat.isSymbolicLink() || (stat.mode & 0o777) !== 0o700 ||
      typeof process.getuid !== 'function' || process.getuid() === 0 || stat.uid !== process.getuid() || await realpath(root) !== root) {
    throw new TypeError('A canonical host-owned private profile root is required.');
  }
  // Capture methods now. Later mutation of a configuration object cannot swap
  // the verifier or a live delegation resolver beneath existing grants.
  const trusted = Object.fromEntries(hookNames.map(name => [name, hooks[name].bind(hooks)]));
  const shutdown = new AbortController();
  let closed = false, closing, unsubscribe, unavailable = false, finish;
  const completion = new Promise(resolve => {finish = resolve;});
  function bounded(operation, externalSignal) {
    const abort = new AbortController(); let timer;
    const cancel = () => abort.abort();
    shutdown.signal.addEventListener('abort', cancel, {once: true});
    externalSignal?.addEventListener('abort', cancel, {once: true});
    if (closed || externalSignal?.aborted) abort.abort();
    return Promise.race([
      Promise.resolve().then(() => {if (abort.signal.aborted) throw denied(); return operation(abort.signal);}),
      new Promise((_, reject) => {
        abort.signal.addEventListener('abort', () => reject(denied()), {once: true});
        timer = setTimeout(() => abort.abort(), LIMITS.hookTimeout);
        if (abort.signal.aborted) reject(denied());
      })
    ]).finally(() => {
      clearTimeout(timer);
      shutdown.signal.removeEventListener('abort', cancel);
      externalSignal?.removeEventListener('abort', cancel);
    });
  }
  const host = createRelayBrowserHost({profileRoot: options.profileRoot,
    resolveBinding: reference => bounded(signal => trusted.resolveBinding(reference, {signal})),
    resolveWorkerSession: binding => bounded(signal => trusted.resolveWorkerSession(binding, {signal})),
    authorizeAction: (action, reference) => bounded(signal => trusted.authorizeAction(action, reference, {signal})),
    controllerOptions: {maxSessions: LIMITS.maxSessions},
    httpOptions: {allowedHostnames: [new URL(origin).hostname], allowedOrigins: [origin],
      maxRequests: LIMITS.maxRequests, maxContexts: LIMITS.maxContexts, maxBodyBytes: LIMITS.maxBodyBytes}
  });
  let bridge;
  try {
    bridge = createOAuthGrantBridge({host, resource: `${origin}/mcp`, issuers: options.issuers,
      verifyAccessToken: (token, policy) => bounded(signal => trusted.verifyAccessToken(token, {...policy, signal}), policy.signal),
      resolveHostReference: (identity, policy) => bounded(signal => trusted.resolveHostReference(
        Object.freeze({...identity, scopes: Object.freeze(['browser:control'])}), {signal}), policy.signal),
      maxGrants: LIMITS.maxGrants, maxRequests: LIMITS.maxRequests, maxBodyBytes: LIMITS.maxBodyBytes,
      maxGrantTTL: LIMITS.maxGrantTTL, verificationTimeout: LIMITS.hookTimeout,
      mapTimeout: LIMITS.hookTimeout, cleanupTimeout: LIMITS.hookTimeout, forwardTimeout: 30000
    });
    // Provider/delegation revocation must reach the exact stable OAuth context
    // even when there is no later HTTP request. No tokens cross this callback.
    unsubscribe = await bounded(signal => trusted.subscribeRevocations(
      context => bridge.revokeContext(context), {signal, shutdownSignal: shutdown.signal,
        onUnavailable: () => {
          if (closed) return; unavailable = true; void close().catch(() => {});
        }}));
    if (closed || typeof unsubscribe !== 'function') throw new TypeError('A revocation unsubscribe hook is required.');
  } catch (error) {
    closed = true; shutdown.abort();
    await (bridge ? bridge.close() : host.close()).catch(() => {});
    throw error;
  }
  async function fetch(request) {
    if (closed) return new Response('{"error":"This endpoint is unavailable."}', {status: 503,
      headers: {'content-type': 'application/json', 'cache-control': 'no-store'}});
    const response = await bridge.fetch(request);
    // The generic bridge supports optional direct Relay tools. This composition
    // registers none; advertise only the browser scope actually enabled here.
    if (request.method === 'GET' && request.url === bridge.metadataUrl && response.status === 200) {
      const metadata = await response.json(); metadata.scopes_supported = ['browser:control'];
      return new Response(JSON.stringify(metadata), {status: 200, headers: response.headers});
    }
    return response;
  }
  function close() {
    if (closing) return closing;
    closed = true;
    // Memoize before dispatching abort: a subscriber may synchronously report
    // its channel unavailable from a shutdown listener and re-enter close().
    closing = Promise.resolve().then(async () => {
      shutdown.abort();
      let timer;
      const cleanup = Promise.allSettled([bridge.close(), Promise.resolve().then(() => unsubscribe?.())]);
      try {
        const results = await Promise.race([cleanup, new Promise((_, reject) => {
          timer = setTimeout(() => reject(new Error('Production cleanup timed out.')), 10000);
        })]);
        if (results.some(result => result.status === 'rejected')) throw new Error('Production cleanup failed.');
      } finally {clearTimeout(timer);}
    });
    closing.then(() => finish(Object.freeze({ok: true, reason: unavailable ? 'channel-unavailable' : 'shutdown'})),
      () => finish(Object.freeze({ok: false, reason: unavailable ? 'channel-unavailable' : 'shutdown'})));
    return closing;
  }
  return Object.freeze({fetch, close, completion, resource: `${origin}/mcp`, metadataUrl: bridge.metadataUrl});
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, chmod, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createRelayProductionHost, canonicalOrigin, LIMITS} from '../host.mjs';
import {request as httpRequest} from 'node:http';
import {createLoopbackEntry} from '../http-entry.mjs';
import {startProductionCli} from '../serve.mjs';
import example from '../host-config.example.mjs';

const origin = 'https://relay-browser.production-test.invalid';
const issuer = 'https://issuer.production-test.invalid';
const context = Object.freeze({grantId: 'controlled-oauth-context'});
const reference = Object.freeze({delegation: 'controlled-browser-only'});
const binding = Object.freeze({workspaceId: 'controlled-workspace', accountId: '11111111-1111-4111-8111-111111111111',
  agentId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', runId: 'controlled-run'});
const req = (method = 'tools/list', params, token = 'controlled-oauth') => new Request(`${origin}/mcp`, {
  method: 'POST', headers: {host: new URL(origin).host, authorization: `Bearer ${token}`,
    'content-type': 'application/json', 'mcp-protocol-version': '2025-11-25', accept: 'application/json, text/event-stream'},
  body: JSON.stringify({jsonrpc: '2.0', id: 1, method, ...(params ? {params} : {})})
});
async function result(response) {
  const text = await response.text();
  return JSON.parse(text.startsWith('event:') ? text.split('\n').find(line => line.startsWith('data: ')).slice(6) : text);
}
async function setup(t, changes = {}) {
  const root = await mkdtemp(join(tmpdir(), 'relay-production-contract-')); await chmod(root, 0o700);
  t.after(() => rm(root, {recursive: true, force: true}));
  const calls = {verified: 0, mapped: [], actions: [], bindings: 0, sessions: 0, unsubscribed: 0};
  let onRevoke, policy, valid = true;
  const hooks = {
    async verifyAccessToken(token, options) {
      assert.equal(options.resource, `${origin}/mcp`); assert.ok(options.signal instanceof AbortSignal);
      calls.verified++; if (!valid || token !== 'controlled-oauth') throw new Error('private-provider-detail');
      return {claims: {iss: issuer, sub: 'controlled-subject', aud: `${origin}/mcp`, exp: Math.floor(Date.now() / 1000) + 600,
        scope: 'browser:control relay:read relay:write', jti: 'controlled-lease'}, principalId: 'controlled-principal', requestContext: context};
    },
    async resolveHostReference(identity, options) {assert.ok(options.signal instanceof AbortSignal); calls.mapped.push(identity); return reference;},
    async resolveBinding(ref) {assert.equal(ref, reference); calls.bindings++; return binding;},
    async resolveWorkerSession() {calls.sessions++; throw new Error('Real browser access is not part of this test.');},
    async authorizeAction(action, ref) {assert.equal(ref, reference); calls.actions.push(action); return false;},
    async subscribeRevocations(callback, options) {onRevoke = callback; policy = options; return async () => {calls.unsubscribed++;};},
    ...changes
  };
  return {root, hooks, calls, get onRevoke() {return onRevoke;}, get policy() {return policy;}, setInvalid() {valid = false;},
    async create(extra = {}) {
      const app = await createRelayProductionHost({origin, issuers: [issuer], profileRoot: root, hooks, ...extra});
      t.after(() => app.close()); return app;
    }};
}

test('configuration rejects absent hooks, authority overrides and noncanonical HTTP origins', async t => {
  for (const value of ['http://example.invalid', 'https://example.invalid/', 'https://x@example.invalid', 'https://example.invalid/path', 'https://example.invalid?x=1']) assert.throws(() => canonicalOrigin(value));
  const f = await setup(t);
  for (const name of Object.keys(f.hooks)) {
    const hooks = {...f.hooks}; delete hooks[name];
    await assert.rejects(f.create({hooks}), /hooks are required/);
  }
  for (const key of ['relayAdapter', 'createDriver', 'httpOptions', 'controllerOptions']) await assert.rejects(f.create({[key]: {}}), /configuration is required/);
  assert.equal(LIMITS.maxSessions, 2); assert.equal(LIMITS.maxRequests, 8);
});

test('private profile root must exist, be canonical, owner-controlled and 0700 before serving', async t => {
  const f = await setup(t);
  await assert.rejects(f.create({profileRoot: `${f.root}/missing`}));
  await assert.rejects(f.create({profileRoot: `${f.root}/../${f.root.split('/').at(-1)}`}));
  await chmod(f.root, 0o755); await assert.rejects(f.create(), /private profile root/);
});

test('factory requires working revocation subscription before returning and sanitizes no provider failures into HTTP', async t => {
  const f = await setup(t, {subscribeRevocations: async () => {throw new Error('Provider integration is absent.');}});
  await assert.rejects(f.create(), /Provider integration is absent/);
  const invalid = await setup(t, {subscribeRevocations: async () => ({})});
  await assert.rejects(invalid.create(), /unsubscribe/);
});

test('five browser-only tools advertise browser scope, map down-scoped references and never launch a browser on discovery', async t => {
  const f = await setup(t), app = await f.create();
  assert.deepEqual(Object.keys(app).sort(), ['close', 'completion', 'fetch', 'metadataUrl', 'resource']);
  const response = await app.fetch(req()); assert.equal(response.status, 200);
  const data = await result(response);
  const tools = data.result.tools;
  assert.deepEqual(tools.map(tool => tool.name).sort(), ['browser_click', 'browser_close', 'browser_observe', 'browser_open', 'browser_screenshot']);
  assert.equal(f.calls.sessions, 0); assert.equal(f.calls.mapped.length, 1);
  assert.deepEqual(f.calls.mapped[0].scopes, ['browser:control']); assert.equal(Object.isFrozen(f.calls.mapped[0].scopes), true);
  const metadata = await app.fetch(new Request(app.metadataUrl, {headers: {host: new URL(origin).host}}));
  assert.equal(metadata.status, 200); assert.deepEqual((await metadata.json()).scopes_supported, ['browser:control']);
  assert.equal(f.calls.verified, 1);
});

test('missing/invalid OAuth never maps a worker and private verifier diagnostics stay private', async t => {
  const f = await setup(t), app = await f.create();
  const response = await app.fetch(req('tools/list', undefined, 'not-authorized'));
  assert.equal(response.status, 401); assert.match(response.headers.get('www-authenticate'), /oauth-protected-resource/);
  assert.doesNotMatch(await response.text(), /private-provider-detail/); assert.equal(f.calls.mapped.length, 0);
});

test('live binding and payload-bound action policy run before browser creation; no direct DM tool is registered', async t => {
  const f = await setup(t), app = await f.create();
  const opened = await result(await app.fetch(req('tools/call', {name: 'browser_open', arguments: {}})));
  assert.equal(opened.result.isError, true); assert.equal(opened.result.structuredContent.error.code, 'FORBIDDEN');
  assert.equal(f.calls.actions[0].name, 'browser_open'); assert.ok(f.calls.bindings > 0); assert.equal(f.calls.sessions, 0);
  const dm = await result(await app.fetch(req('tools/call', {name: 'relay_fast_send', arguments: {body: 'Never sent'}})));
  assert.ok(dm.error || dm.result?.isError); assert.equal(f.calls.sessions, 0);
});

test('provider/delegation revocation rejects the exact context without waiting for token expiry', async t => {
  const f = await setup(t), app = await f.create();
  assert.equal((await app.fetch(req())).status, 200);
  assert.deepEqual(await f.onRevoke(context), {closed: true});
  assert.equal((await app.fetch(req())).status, 401);
  await app.close(); await app.close();
  assert.equal(f.calls.unsubscribed, 1); assert.equal(f.policy.shutdownSignal.aborted, true);
  assert.equal((await app.fetch(req())).status, 503);
});

test('configuration method mutation cannot replace captured live authority hooks', async t => {
  const f = await setup(t), app = await f.create();
  f.hooks.verifyAccessToken = async () => {throw new Error('Mutated.');};
  assert.equal((await app.fetch(req())).status, 200); assert.equal(f.calls.verified, 1);
});

test('private viewer and alternate origins stay unavailable through the production resource', async t => {
  const f = await setup(t), app = await f.create();
  const viewer = await app.fetch(new Request(`${origin}/viewer`, {headers: {host: new URL(origin).host}})); assert.equal(viewer.status, 404);
  const request = req(); request.headers.set('host', 'evil.invalid'); assert.equal((await app.fetch(request)).status, 403);
  assert.equal(f.calls.verified, 0);
});

test('example remains fail-closed and CLI rejects fixture/default/relative/module-url startup', async () => {
  for (const fn of Object.values(example.hooks)) await assert.rejects(fn(), /not configured/);
  for (const args of [[], ['--fixture'], ['--serve'], ['--serve', '--config', './host-config.example.mjs'], ['--serve', '--config', 'https://evil.invalid/config.mjs']]) {
    await assert.rejects(startProductionCli({args, env: {}, output: {write() {assert.fail('Must not announce startup.');}}}));
  }
  await assert.rejects(startProductionCli({args: ['--serve', '--config', '/tmp/not-read.mjs'], env: {NODE_OPTIONS: '--inspect'}}));
});


test('lost revocation-channel integrity closes all future access without a new OAuth request', async t => {
  const f = await setup(t), app = await f.create();
  assert.equal((await app.fetch(req())).status, 200);
  f.policy.onUnavailable();
  assert.equal((await app.fetch(req())).status, 503);
  await app.close(); assert.equal(f.calls.unsubscribed, 1);
});


test('real loopback ingress carries discovery through the actual OAuth bridge and production host', async t => {
  const f = await setup(t), app = await f.create();
  const entry = createLoopbackEntry({origin, application: app, port: 0});
  const address = await entry.listen(); t.after(() => entry.close());
  async function post(token) {
    return new Promise((resolve, reject) => {
      const r = httpRequest({hostname: '127.0.0.1', port: address.port, path: '/mcp', method: 'POST', headers: {
        host: new URL(origin).host, authorization: `Bearer ${token}`, 'content-type': 'application/json',
        accept: 'application/json, text/event-stream', 'mcp-protocol-version': '2025-11-25'}}, response => {
        const parts = []; response.on('data', part => parts.push(part)); response.on('end', () => resolve(new Response(Buffer.concat(parts), {status: response.statusCode, headers: response.headers})));
      });
      r.on('error', reject); r.end(JSON.stringify({jsonrpc: '2.0', id: 7, method: 'tools/list'}));
    });
  }
  assert.equal((await post('invalid-controlled-oauth')).status, 401);
  const response = await post('controlled-oauth'); assert.equal(response.status, 200);
  assert.equal((await result(response)).result.tools.length, 5); assert.equal(f.calls.mapped.length, 1);
  await entry.close(); assert.equal(f.calls.unsubscribed, 1);
});

test('a hung verifier is aborted at the hook deadline and cannot map a worker after returning late', async t => {
  let signal, release;
  const pendingProvider = new Promise(resolve => {release = resolve;});
  const f = await setup(t, {async verifyAccessToken(_token, options) {signal = options.signal; return pendingProvider;}}), app = await f.create();
  t.mock.timers.enable({apis: ['setTimeout']});
  const pending = app.fetch(req());
  while (!signal) await new Promise(resolve => setImmediate(resolve));
  t.mock.timers.tick(5001);
  assert.equal((await pending).status, 401); assert.equal(signal.aborted, true);
  release({claims: {iss: issuer, sub: 'late', aud: `${origin}/mcp`, exp: Math.floor(Date.now() / 1000) + 600, scope: 'browser:control'},
    principalId: 'late-principal', requestContext: context});
  await new Promise(resolve => setImmediate(resolve)); assert.equal(f.calls.mapped.length, 0);
  t.mock.timers.reset();
});


test('shutdown-triggered channel-unavailable callbacks cannot re-enter cleanup or unsubscribe twice', async t => {
  let unsubscribed = 0;
  const f = await setup(t, {async subscribeRevocations(_callback, {shutdownSignal, onUnavailable}) {
    shutdownSignal.addEventListener('abort', onUnavailable, {once: true});
    return async () => {unsubscribed++;};
  }}), app = await f.create();
  await app.close(); await app.close(); assert.equal(unsubscribed, 1);
});


test('event-driven cleanup failure is observable through the terminal lifecycle without an explicit close call', async t => {
  let policy;
  const f = await setup(t, {async subscribeRevocations(_callback, options) {
    policy = options; return async () => {throw new Error('Private cleanup failure.');};
  }});
  // setup registers an after hook for successful cleanup; this case intentionally
  // fails it, so create directly and assert the bounded terminal outcome instead.
  const app = await createRelayProductionHost({origin, issuers: [issuer], profileRoot: f.root, hooks: f.hooks});
  policy.onUnavailable();
  assert.deepEqual(await app.completion, {ok: false, reason: 'channel-unavailable'});
  assert.equal((await app.fetch(req())).status, 503);
  await assert.rejects(app.close(), /cleanup failed/);
});

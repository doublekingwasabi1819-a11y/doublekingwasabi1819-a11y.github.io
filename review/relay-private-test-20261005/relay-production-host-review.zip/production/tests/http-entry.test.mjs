import test from 'node:test';
import assert from 'node:assert/strict';
import {request as httpRequest} from 'node:http';
import {connect} from 'node:net';
import {createLoopbackEntry} from '../http-entry.mjs';

const origin = 'https://relay-browser.ingress-test.invalid', authority = new URL(origin).host;
const deferred = () => {let resolve; const promise = new Promise(r => {resolve = r;}); return {promise, resolve};};
async function setup(t, overrides = {}) {
  const requests = []; let closeCalls = 0;
  const application = {async fetch(request) {requests.push(request); return new Response('{"controlled":"ok"}', {
    headers: {'content-type': 'application/json', 'set-cookie': 'never-forward=this'}});}, async close() {closeCalls++;}, ...overrides};
  const entry = createLoopbackEntry({origin, application, port: 0}); const address = await entry.listen();
  t.after(() => entry.close());
  return {entry, address, requests, get closeCalls() {return closeCalls;}};
}
function send(port, {path = '/mcp', method = 'POST', headers = {}, body = '{}'} = {}) {
  return new Promise((resolve, reject) => {
    const req = httpRequest({hostname: '127.0.0.1', port, path, method, headers: {host: authority,
      'content-type': 'application/json', ...headers}}, res => {
      const parts = []; res.on('data', chunk => parts.push(chunk));
      res.on('end', () => resolve({status: res.statusCode, headers: res.headers, body: Buffer.concat(parts).toString()}));
    });
    req.on('error', reject); req.end(body);
  });
}
function raw(port, data) {
  return new Promise((resolve, reject) => {
    const socket = connect({host: '127.0.0.1', port}, () => socket.end(data)); const pieces = [];
    socket.setTimeout(3000, () => {socket.destroy(); reject(new Error('Controlled raw request timed out.'));});
    socket.on('data', chunk => pieces.push(chunk)); socket.on('end', () => resolve(Buffer.concat(pieces).toString()));
    socket.on('error', reject);
  });
}

test('only explicit HTTPS origin and valid application capabilities are accepted', () => {
  assert.throws(() => createLoopbackEntry(), TypeError);
  assert.throws(() => createLoopbackEntry({origin, application: {fetch() {}}}), TypeError);
  assert.throws(() => createLoopbackEntry({origin, application: {fetch() {}, close() {}}, port: -1}), TypeError);
});

test('entry binds only IPv4 loopback and constructs HTTPS URL from fixed config, not the HTTP socket', async t => {
  const f = await setup(t); assert.equal(f.address.address, '127.0.0.1'); assert.equal(f.address.resource, `${origin}/mcp`);
  const response = await send(f.address.port, {headers: {authorization: 'Bearer controlled-oauth'}});
  assert.equal(response.status, 200); assert.equal(f.requests[0].url, `${origin}/mcp`);
  assert.equal(f.requests[0].headers.get('host'), authority); assert.equal(f.requests[0].headers.get('authorization'), 'Bearer controlled-oauth');
  assert.equal(f.requests[0].headers.has('transfer-encoding'), false);
  assert.equal(response.headers['set-cookie'], undefined); assert.equal(response.headers['cache-control'], 'no-store');
  await assert.rejects(f.entry.listen(), /unavailable/);
});

test('mismatched Host and Origin are rejected before application authentication', async t => {
  const f = await setup(t);
  for (const headers of [{host: 'evil.invalid'}, {host: '127.0.0.1'}, {origin: 'https://evil.invalid'}, {host: `${authority}:443`}]) {
    assert.equal((await send(f.address.port, {headers})).status, 403);
  }
  assert.equal(f.requests.length, 0);
});

test('all forwarded-header claims are rejected even when their values look correct', async t => {
  const f = await setup(t);
  for (const name of ['Forwarded', 'X-Forwarded-Host', 'X-Forwarded-Proto', 'X-Forwarded-For', 'X-Forwarded-Anything', 'X-Real-IP', 'X-Original-URL', 'X-Rewrite-URL']) {
    assert.equal((await send(f.address.port, {headers: {[name]: 'https'}})).status, 400);
  }
  assert.equal(f.requests.length, 0);
});

test('absolute, authority-form, encoded, query and normalized paths cannot change the resource target', async t => {
  const f = await setup(t);
  for (const path of ['https://evil.invalid/mcp', '//evil.invalid/mcp', '/mcp?token=secret', '/x/../mcp', '/%6dcp', '/mcp#x', '/./mcp']) {
    assert.equal((await send(f.address.port, {path})).status, 400);
  }
  assert.equal(f.requests.length, 0);
});

test('duplicate authority/credential headers and HTTP header overflows cannot reach the application', async t => {
  const f = await setup(t);
  for (const additional of [`Host: ${authority}`, 'Authorization: second-controlled-token', `X-Large: ${'x'.repeat(9000)}`]) {
    const response = await raw(f.address.port, `POST /mcp HTTP/1.1\r\nHost: ${authority}\r\nAuthorization: first-controlled-token\r\n${additional}\r\nContent-Type: application/json\r\nContent-Length: 2\r\nConnection: close\r\n\r\n{}`);
    assert.match(response, /^HTTP\/1\.1 400/);
  }
  assert.equal(f.requests.length, 0);
});

test('oversized declared bodies and GET bodies are rejected before forwarding', async t => {
  const f = await setup(t);
  assert.equal((await send(f.address.port, {headers: {'content-length': '65537'}, body: ''})).status, 413);
  assert.equal((await send(f.address.port, {method: 'GET', headers: {'content-length': '2'}, body: '{}'})).status, 400);
  assert.equal(f.requests.length, 0);
});

test('oversized chunked bodies terminate safely without forwarding', async t => {
  const f = await setup(t);
  const response = await send(f.address.port, {headers: {'transfer-encoding': 'chunked'}, body: 'x'.repeat(65537)}).catch(error => ({reset: error.code}));
  assert.ok(response.status === 413 || ['ECONNRESET', 'EPIPE'].includes(response.reset)); assert.equal(f.requests.length, 0);
});

test('eight active requests bound ingress before application work and slots recover', async t => {
  const finish = deferred(), started = deferred(); let count = 0;
  const f = await setup(t, {async fetch() {if (++count === 8) started.resolve(); await finish.promise; return new Response('{}');}});
  const pending = Array.from({length: 8}, () => send(f.address.port)); await started.promise;
  assert.equal((await send(f.address.port)).status, 429); assert.equal(count, 8);
  finish.resolve(); assert.deepEqual((await Promise.all(pending)).map(value => value.status), Array(8).fill(200));
  assert.equal((await send(f.address.port)).status, 200);
});

test('response size is bounded and private failure content is never emitted', async t => {
  const f = await setup(t, {async fetch() {return new Response('private-detail'.repeat(1100000));}});
  const response = await send(f.address.port); assert.equal(response.status, 502); assert.doesNotMatch(response.body, /private-detail/);
});

test('close is idempotent, closes incomplete sockets and calls application cleanup once', async t => {
  const f = await setup(t);
  const socket = connect({host: '127.0.0.1', port: f.address.port}); await new Promise(resolve => socket.once('connect', resolve));
  socket.write(`POST /mcp HTTP/1.1\r\nHost: ${authority}\r\nContent-Length: 10\r\n\r\n{`);
  // Let Node dispatch the request and enter the incomplete-body reader first.
  await new Promise(resolve => setTimeout(resolve, 30));
  const ended = new Promise(resolve => {socket.once('close', resolve); socket.on('error', () => {});});
  await f.entry.close(); await f.entry.close(); await ended; assert.equal(f.closeCalls, 1);
  await assert.rejects(send(f.address.port)); await assert.rejects(f.entry.listen(), /unavailable/);
});

test('close during startup rejects startup rather than retaining a hidden listener', async () => {
  let closes = 0;
  const entry = createLoopbackEntry({origin, port: 0, application: {async fetch() {assert.fail();}, async close() {closes++;}}});
  const startup = entry.listen(); const stopped = entry.close();
  await assert.rejects(startup, /cancelled/); await stopped; assert.equal(closes, 1);
});


test('spontaneous application teardown closes ingress and surfaces failure to its supervisor', async () => {
  const terminal = deferred();
  const entry = createLoopbackEntry({origin, port: 0, application: {
    completion: terminal.promise, async fetch() {return new Response('{}');},
    async close() {throw new Error('Private application cleanup failure.');}
  }});
  const address = await entry.listen();
  terminal.resolve({ok: false, reason: 'channel-unavailable'});
  assert.deepEqual(await entry.completion, {ok: false});
  await assert.rejects(send(address.port)); await assert.rejects(entry.close(), /cleanup failed/);
});

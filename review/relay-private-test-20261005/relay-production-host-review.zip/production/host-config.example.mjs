// NON-OPERATIONAL CONTRACT EXAMPLE. Copying this file cannot authorize anyone.
// No domain/provider/delegation store has been selected or provisioned.
// Replace each TODO with a separately reviewed implementation before approval
// to install/run. Never replace these checks with a fixture or default worker.
const unavailable = async () => {throw new Error('Live provider and Relay delegation integration is not configured.');};
export default Object.freeze({
  origin: 'https://relay-browser.example.invalid',
  issuers: ['https://identity.example.invalid'],
  port: 8788,
  profileRoot: '/var/lib/relay-browser/profiles',
  hooks: Object.freeze({
    // TODO verifyAccessToken(token, {resource, issuers, signal})
    // Cryptographic verification or secure introspection on EVERY request;
    // verify algorithm/signature/key rotation, exact issuer/audience, expiry,
    // nbf and scopes. Return the oauth-resource.mjs contract: verified claims,
    // host-owned principalId and one stable Object.freeze({grantId}) context.
    // No JWT decode-only verification, invented identity or Relay bearer reuse.
    verifyAccessToken: unavailable,

    // TODO resolveHostReference(verifiedIdentity, {signal})
    // Require explicit current user consent/delegation to one enabled worker,
    // workspace, agent and run. Persistently intersect ['browser:control'] with
    // the allowed delegation. Return a frozen opaque server reference pinned to
    // that exact worker/run/permission. Never mutate/remap it after reconnect.
    resolveHostReference: unavailable,

    // TODO resolveBinding(reference, {signal})
    // Recheck stored delegation, current worker role/enabled/run/expiry on every
    // call. Return {workspaceId, accountId, agentId, runId}; deny missing/stale.
    resolveBinding: unavailable,

    // TODO resolveWorkerSession(binding, {signal})
    // Resolve only the same live, explicitly delegated worker session. Return
    // {binding, role:'worker', enabled:true, token, expiresAt, scopes} from the
    // existing custom Relay opaque-session model, NOT Supabase Auth. Never use
    // a manager session, human browser profile or incoming OAuth bearer.
    resolveWorkerSession: unavailable,

    // TODO authorizeAction(action, reference, {signal})
    // Payload-bound policy/consent for browser_open/browser_click/browser_close.
    // Return true only for the specific approved action on this worker/run.
    // Check expiry/revocation and the immutable browser-only permission. The
    // driver allows fixed read-navigation controls; arbitrary fill/DM writes
    // are not enabled by this composition.
    authorizeAction: unavailable,

    // TODO subscribeRevocations(onRevoke, {signal, shutdownSignal, onUnavailable})
    // Subscribe to provider AND delegation/run revocation before returning.
    // Call/await onRevoke(the exact stable OAuth requestContext) when revoked;
    // a cleanup error requires retry/quarantine, never reauthorization.
    // Return an async unsubscribe function. Honor cancellation if registration
    // times out and shutdownSignal during process teardown. Call onUnavailable()
    // immediately if this event channel loses integrity/connectivity; the whole
    // composition then fails closed and revokes its grants. No next request is
    // needed for cleanup. Token/grant expiry is already scheduled by the bridge.
    subscribeRevocations: unavailable
  })
});

# Relay production-host foundation (review only)

This is an **unpublished, uninstalled integration foundation**, not a live Relay
browser or a working ChatGPT connection. It composes the reviewed controller at
`b568da1ce0fde90d49a51e73f3ae90cc23c0732a`; it deliberately does not supply an
OAuth authorization server, real clients/keys, a worker-delegation database,
account login, DNS, certificates, public ports, a tunnel, or a provider account.
The example configuration refuses every authorization and cannot serve users.

All additions are under top-level `production/`. No original controller file,
lockfile, preparation script, 34-file checksum manifest, or 244-test gate is
changed. Apply/review this directory beside `controller/`, not inside it. The
existing fixture CLI remains a fixture and must never be reverse-proxied as live.

## Included behavior

- `host.mjs` calls `createRelayBrowserHost` and `createOAuthGrantBridge`. It requires
  six explicit trusted hooks, captures their methods, validates existing private
  profile storage, and supplies no default identity or fixture driver.
- Five tools only: `browser_open`, `browser_observe`, `browser_click`,
  `browser_screenshot`, `browser_close`. No `browser_fill` or direct Relay/DM
  adapter is configured. Metadata advertises only `browser:control`; even an
  OAuth token carrying more scopes maps to a browser-only host reference.
- Every request is cryptographically verified or securely introspected by the
  required provider hook. Live binding and payload-bound action hooks are still
  necessary. Incoming OAuth credentials never become Relay session credentials.
- The bridge schedules internal-grant/token expiry. The required revocation
  subscription must close exact stable contexts on provider, delegation or run
  revocation, even without a subsequent request. Loss of the revocation channel
  calls `onUnavailable()` to fail closed for the entire composition.
- `http-entry.mjs` listens only on `127.0.0.1`. It always calls the OAuth
  composition's `fetch`; it never exposes `host.listen`, grant issuance or the
  private viewer. Configured HTTPS origin supplies the Request URL; incoming
  Host must match it exactly. Forwarded headers are rejected, not trusted.
- Input: 64 KiB body, 8 KiB headers, 8 active requests, 16 sockets, fixed
  request/header/deadline timers. Output: 12 MiB maximum. No automatic retry of
  actions, SSE subscriptions, raw request/error logging or HTTP cookies.
- Conservative initial capacity: 2 browser sessions, 8 OAuth grants/contexts,
  15-minute maximum internal grants. A grant that expires requires a fresh,
  separately authorized OAuth context; it is not silently remapped or renewed.
- Closing ingress cuts incomplete sockets and invokes bridge/controller cleanup.
  A terminal lifecycle promise also propagates spontaneous revocation-channel
  shutdown to ingress and the CLI; failed/channel-lost teardown exits nonzero
  so the configured supervisor can terminate the remaining control group.
  Hook deadlines deny access and preserve cleanup errors. An uncooperative native
  process still requires the supervisor's bounded control-group teardown; a
  JavaScript timeout is not proof that the browser process was killed.

The plain loopback transport is only for a reviewed local TLS reverse proxy on a
trusted dedicated host. Local untrusted processes are outside that trust boundary;
loopback alone is not application authentication. They still need a verified OAuth
bearer and live worker delegation. The front end must fix Host and strip forwarding
headers. The draft nginx template whitelists request headers, disables upstream
retries and exposes exactly MCP plus protected-resource metadata. Public exposure
is a separate approval and host review; no such operation is performed here.

## Required integration contracts

`host-config.example.mjs` documents every interface. The operator-owned live
module must export `{origin, issuers, profileRoot, port?, hooks}`.

1. `verifyAccessToken(token, {resource, issuers, signal})`: return independently
   verified claims with issuer, subject, exact resource audience, expiry and
   scopes, a host-owned principal ID and one stable frozen `{grantId}` object.
   Reconstructing that object or altering claims on each request breaks binding.
   JWT decoding alone is never verification. Provider algorithms/keys, discovery,
   PKCE and client registration require a separate implementation and review.
2. `resolveHostReference(identity, {signal})`: after verification/scoping, require
   explicit current delegation to one worker, workspace, agent and run. Return a
   permanently pinned, frozen opaque reference with browser-only permission.
   Reconnection must create a new reference/context; never select a fallback user.
3. `resolveBinding(reference, {signal})`: recheck live delegation/role/enabled/run
   and expiry, returning the same authorized binding every time or denying it.
4. `resolveWorkerSession(binding, {signal})`: resolve the same currently delegated
   worker's existing Relay opaque session. Relay's present backend is custom
   session authentication; this is not a Supabase Auth token integration. Never
   use a manager credential, human browser profile or the incoming OAuth token.
5. `authorizeAction(action, reference, {signal})`: return true only for the actual
   permitted payload/action on this worker/run. It is not blanket browser access.
6. `subscribeRevocations(onRevoke, {signal, shutdownSignal, onUnavailable})`:
   establish provider plus delegation/run events before returning an unsubscribe
   function. Await revocation cleanup; retry/quarantine reported cleanup failures.
   On connection/integrity loss immediately call `onUnavailable`. Honor registration
   cancellation and the lifetime shutdown signal; no background work may survive
   failed startup. The example throws, so missing infrastructure fails startup.

Authority hooks must be read-only checks/resolvers, honor abort/deadlines, and
avoid side effects after timeout. Do not log tokens, claims, profile contents or
private account details. Never store these in repository files or test artifacts.
Persistent browser storage requires a separate retention/disk-capacity policy.

## Local review and validation

From a reviewed checkout with the pinned controller dependencies installed:

```sh
(cd controller && sha256sum --check hosting/ubuntu-x64/controller-sha256.txt)
node --check production/host.mjs
node --check production/http-entry.mjs
node --check production/serve.mjs
node --test production/tests/*.test.mjs
(cd controller && npm test)
```

The new tests use invented in-memory verifiers/references, a real local Node HTTP
listener and the real source composition. They do not contact Relay, issue live
OAuth credentials or launch Chromium. They cover five-tool discovery through the
actual HTTP/OAuth/host stack, scope narrowing, action denial, live revocation,
revocation-channel failure, missing hooks, profile privacy, forged forwarding,
Host/Origin/path/duplicate-header rejection, byte/concurrency limits, hook timeout/late-result denial and cleanup.

Validation on 2026-10-05 in the development workspace:

- 28 new tests passed, zero failures/skips/cancellations/todos.
- Original 34-file controller SHA256 manifest passes unchanged; all 41 retrieved
  controller/AGENTS files match their Git blob hashes at the pinned commit.
- Baseline suite: 244 cases, 242 passed, 2 Chromium cases skipped because the
  pinned browser binary is absent here. This is not a fresh 244/244 browser pass.
  The server's separately reported earlier 244/244 run covers its pinned fixture
  source; it does not validate these new files or a live service.
- Node 24.19.0; existing dependencies report exact direct versions from the lock:
  MCP server/client 2.3.0, Playwright 1.62.1, Zod 4.6.5. Reused local dependencies;
  this check was not a fresh locked dependency installation.
- nginx is absent here. Systemd validation cannot run because `/run/systemd` is
  read-only. Templates have not been installed, started or validated on the VM.
- No real provider flow, TLS, server process supervision, egress policy, delegated
  account, Chromium-through-production action, or ChatGPT invocation was tested.

## Before a separately approved deployment

Choose the hostname or alternative HTTPS front end, provider, audience, real
worker and delegation lifecycle first. An established provider may be self-hosted
or external, but this foundation does not select or deploy one. No new paid
service is required by this code. Keep all placeholders until those decisions
and the relevant access/security actions have approval.

Review the completed hooks and source; install a read-only administrator-owned
runtime/source/browser distribution outside the service-writable tree. The CLI
requires a non-root user and an absolute `.mjs` configuration path whose file and
ancestors are root-owned and not group/world-writable. Apply the same provenance
and ownership rules to everything the configuration imports. Browser profiles
must be an existing canonical 0700 directory owned by the service user.

The `.disabled` templates are examples only. No script copies/enables them. The
systemd template additionally requires an operator-created approval marker and
has no `[Install]` section. Its initial 3 GiB/150% CPU/256-task limits leave some
headroom on the 2-vCPU/4-GiB machine but need measurement under the final stack.
A same-host identity provider also consumes that budget. Test Chromium's sandbox
under the exact final unit; do not weaken sandbox, AppArmor, kernel, firewall or
network settings to make it pass. Approve/review OS egress independently.

Before claiming readiness: rerun the exact-source 244/244 mandatory Chromium gate
and the separate production tests on the VM; validate final nginx/systemd configs;
exercise real provider PKCE/discovery/audience/revocation and actual delegated
worker read-navigation; verify expiry and stop/restart cleanup, blocked DM writes,
resource/CPU/memory/disk limits and the approved HTTPS route; then prove real
ChatGPT linking and tool invocation. Keep public access disabled until complete.

References for the transport/template details:

- [Node HTTP server limits](https://nodejs.org/api/http.html#serverrequesttimeout)
- [nginx proxy header controls](https://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_pass_request_headers)
- [nginx retry control](https://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_next_upstream)
- Existing controller [deployment contract](../controller/DEPLOYMENT.md) and
  [Ubuntu fixture preparation](../controller/hosting/ubuntu-x64/README.md)

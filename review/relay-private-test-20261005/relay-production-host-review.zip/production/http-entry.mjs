import {createServer} from 'node:http';
import {canonicalOrigin, LIMITS} from './host.mjs';

const MAX_RESPONSE = 12 * 1024 * 1024;
const singleHeaders = new Set(['host', 'authorization', 'content-type', 'content-length',
  'origin', 'transfer-encoding', 'mcp-protocol-version']);
const blockedHeader = name => name === 'forwarded' || name.startsWith('x-forwarded-') ||
  ['x-real-ip', 'x-original-url', 'x-rewrite-url', 'expect', 'upgrade'].includes(name);
const error = status => Object.assign(new Error('The HTTP request could not be completed.'), {status});
const isPort = port => Number.isInteger(port) && port >= 0 && port <= 65535;

/** Fixed loopback ingress for a reviewed local HTTPS proxy. It never calls the
 * private host listener: EVERY request goes to the OAuth composition's fetch.
 * The configured origin, never Host/Forwarded input, constructs the URL.
 */
export function createLoopbackEntry({origin, application, port = 8788} = {}) {
  origin = canonicalOrigin(origin);
  if (!application || typeof application.fetch !== 'function' || typeof application.close !== 'function' ||
      !isPort(port)) throw new TypeError('A reviewed application and loopback port are required.');
  const authority = new URL(origin).host;
  const forward = application.fetch.bind(application), cleanup = application.close.bind(application);
  let closed = false, started = false, active = 0, closing, cancelStartup, upstreamFailed = false, finish;
  const completion = new Promise(resolve => {finish = resolve;});
  const sockets = new Set();
  const inFlight = new Set();
  function reject(res, status) {
    if (res.destroyed) return;
    if (res.headersSent) {res.destroy(); return;}
    res.writeHead(status, {'content-type': 'application/json', 'cache-control': 'no-store',
      'x-content-type-options': 'nosniff', 'connection': 'close',
      'content-security-policy': "default-src 'none'; frame-ancestors 'none'; base-uri 'none'"});
    res.end('{"error":"The HTTP request could not be completed."}');
  }
  async function serve(req, res) {
    if (closed) return reject(res, 503);
    if (active >= LIMITS.maxRequests) return reject(res, 429);
    active++;
    let timer;
    try {
      if (req.socket.remoteAddress !== '127.0.0.1' || !['GET', 'POST'].includes(req.method) ||
          typeof req.url !== 'string' || req.url.length > 2048 ||
          !/^\/[A-Za-z0-9_/.\-]*$/.test(req.url) || req.url.startsWith('//') || req.url.includes('/../') ||
          req.url.endsWith('/..') || req.url.includes('/./') || req.url.endsWith('/.')) throw error(400);
      const names = new Set(), headers = new Headers();
      for (let index = 0; index < req.rawHeaders.length; index += 2) {
        const name = req.rawHeaders[index].toLowerCase(), value = req.rawHeaders[index + 1];
        if (blockedHeader(name) || (singleHeaders.has(name) && names.has(name))) throw error(400);
        names.add(name); headers.append(name, value);
      }
      if (headers.get('host') !== authority || (headers.has('origin') && headers.get('origin') !== origin)) throw error(403);
      const length = headers.get('content-length'), transfer = headers.get('transfer-encoding');
      if ((length !== null && (!/^\d+$/.test(length) || Number(length) > LIMITS.maxBodyBytes)) ||
          (transfer !== null && transfer.toLowerCase() !== 'chunked')) throw error(413);
      if (req.method === 'GET' && ((length !== null && Number(length) !== 0) || transfer !== null)) throw error(400);
      const operation = (async () => {
        const chunks = []; let bytes = 0;
        for await (const chunk of req) {
          bytes += chunk.byteLength;
          if (bytes > LIMITS.maxBodyBytes) throw error(413);
          chunks.push(chunk);
        }
        if (closed || res.destroyed) throw error(503);
        // Incoming framing is terminated here, never copied into the Fetch API.
        headers.delete('transfer-encoding'); headers.delete('connection'); headers.delete('content-length');
        const body = Buffer.concat(chunks);
        const request = new Request(`${origin}${req.url}`, {method: req.method, headers,
          ...(req.method === 'POST' ? {body} : {})});
        const response = await forward(request);
        if (!(response instanceof Response)) throw error(500);
        const reader = response.body?.getReader(), parts = []; let size = 0;
        if (reader) try {
          while (true) {
            const part = await reader.read(); if (part.done) break;
            size += part.value.byteLength;
            if (size > MAX_RESPONSE) {await reader.cancel(); throw error(502);}
            parts.push(Buffer.from(part.value));
          }
        } finally {reader.releaseLock();}
        if (closed || res.destroyed) return;
        const output = new Headers(response.headers);
        for (const name of ['connection', 'transfer-encoding', 'content-length', 'set-cookie']) output.delete(name);
        output.set('cache-control', 'no-store'); output.set('x-content-type-options', 'nosniff');
        output.set('content-length', String(size));
        res.writeHead(response.status, Object.fromEntries(output)); res.end(Buffer.concat(parts));
      })();
      // Keep the capacity slot occupied until the underlying work settles, even
      // after a deadline. A timed-out hook cannot admit unbounded replacement work.
      inFlight.add(operation); operation.finally(() => inFlight.delete(operation)).catch(() => {});
      timer = setTimeout(() => {reject(res, 408); req.destroy();}, 45000);
      await operation;
    } catch (failure) {reject(res, [400, 403, 408, 413, 500, 502, 503].includes(failure.status) ? failure.status : 400);}
    finally {clearTimeout(timer); active--;}
  }
  const server = createServer({maxHeaderSize: 8192, headersTimeout: 10000, requestTimeout: 15000,
    keepAliveTimeout: 1000, connectionsCheckingInterval: 1000}, (req, res) => {void serve(req, res);});
  server.maxConnections = 16; server.maxRequestsPerSocket = 100;
  server.on('connection', socket => {sockets.add(socket); socket.once('close', () => sockets.delete(socket));});
  server.on('clientError', (_failure, socket) => {if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\nContent-Length: 0\r\n\r\n'); else socket.destroy();});
  server.on('checkContinue', (_req, res) => reject(res, 417));
  server.on('upgrade', (_req, socket) => socket.destroy());
  server.on('error', () => {}); // Startup rejects below; never log request details.
  async function listen() {
    if (closed || started) throw new TypeError('The loopback entry is unavailable.');
    started = true;
    await new Promise((resolve, reject) => {
      const finish = failure => {server.off('error', onError); server.off('listening', onListening); cancelStartup = undefined; failure ? reject(failure) : resolve();};
      const onError = () => finish(new Error('Loopback startup failed.')), onListening = () => finish();
      cancelStartup = () => finish(new Error('Loopback startup was cancelled.'));
      server.once('error', onError); server.once('listening', onListening); server.listen(port, '127.0.0.1');
    });
    if (closed) throw new Error('Loopback startup was cancelled.');
    return Object.freeze({address: '127.0.0.1', port: server.address().port, resource: `${origin}/mcp`});
  }
  function close() {
    if (closing) return closing;
    closed = true; cancelStartup?.();
    closing = Promise.resolve().then(async () => {
      let timer;
      const stop = new Promise(resolve => {server.close(resolve); server.closeIdleConnections();});
      // Close ingress immediately, including incomplete request bodies; grant
      // revocation and controller teardown are owned by the application.
      for (const socket of sockets) socket.destroy();
      try {
        const results = await Promise.race([Promise.allSettled([stop, cleanup(), Promise.allSettled([...inFlight])]),
          new Promise((_, reject) => {timer = setTimeout(() => reject(new Error('Loopback cleanup timed out.')), 12000);})]);
        if (results.some(result => result.status === 'rejected')) throw new Error('Loopback cleanup failed.');
      } finally {clearTimeout(timer);}
    });
    closing.then(() => finish(Object.freeze({ok: !upstreamFailed})),
      () => finish(Object.freeze({ok: false})));
    return closing;
  }
  if (application.completion instanceof Promise) application.completion.then(outcome => {
    upstreamFailed = outcome?.ok !== true || outcome.reason === 'channel-unavailable';
    void close().catch(() => {});
  }, () => {upstreamFailed = true; void close().catch(() => {});});
  return Object.freeze({listen, close, completion});
}

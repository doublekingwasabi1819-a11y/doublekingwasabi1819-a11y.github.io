// Disposable in-memory PostgreSQL only. Never uses network/database credentials.
// Install pinned @electric-sql/pglite@0.5.8 outside the repository, then set
// RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite
// before running: node tests/message-audience-pglite.mjs
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {randomBytes,randomUUID,createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {emptyState} from '../engine.mjs';
import {createHandler} from '../backend/handler.mjs';

const root=process.env.RELAY_PGLITE_ROOT;
if(!root?.startsWith('/tmp/'))throw Error('Use a pinned local /tmp PGlite package; remote databases are not supported.');
const {PGlite}=await import(pathToFileURL(root+'/dist/index.js'));
const {pgcrypto}=await import(pathToFileURL(root+'/dist/contrib/pgcrypto.js'));
const db=new PGlite({extensions:{pgcrypto}});
const sql=(query,params=[])=>db.query(query,params);
const rpc=async(action,token='',data={})=>{
  await db.exec('set role service_role');
  try{
    const name=action.startsWith('messages.')?'relay_message_rpc':action.startsWith('dm.')?'relay_dm_rpc':'relay_rpc';
    const result=await sql(`select public.${name}($1,$2,$3::jsonb) as value`,[action,token,JSON.stringify(data)]);
    return result.rows[0].value;
  }finally{await db.exec('reset role');}
};
const ok=result=>{assert.equal(result.error,undefined,JSON.stringify(result));return result;};
const handler=createHandler({rpc:async(...args)=>{const r=await rpc(...args);if(r.error)throw Object.assign(new Error(r.error.message),r.error);return r;}});
const request=async(action,token,data={})=>{
  const response=await handler(new Request('https://fixture.invalid',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({action,data})}));
  return {status:response.status,body:await response.json()};
};
let checks=0;
const check=async(name,fn)=>{await fn();checks++;console.log('PASS '+name);};
try{
  await db.exec('create role anon; create role authenticated; create role service_role bypassrls;');
  await db.exec(readFileSync(new URL('../backend/schema.sql',import.meta.url),'utf8'));
  const before=(await sql("select pg_get_functiondef('relay_private.dm_action(relay_private.accounts,text,jsonb)'::regprocedure) as value")).rows[0].value;
  await db.exec(readFileSync(new URL('../backend/private-messages.sql',import.meta.url),'utf8'));
  const after=(await sql("select pg_get_functiondef('relay_private.dm_action(relay_private.accounts,text,jsonb)'::regprocedure) as value")).rows[0].value;
  await check('base and additive schema install the identical DM authorization function',async()=>assert.equal(before,after));

  const setupCode=randomBytes(32).toString('hex'),password='Test-only! '+randomBytes(16).toString('hex');
  await sql('update relay_private.studio set setup_hash=$1',[createHash('sha256').update(setupCode).digest('hex')]);
  const manager=ok(await rpc('setup','',{setupCode,name:'Manager',username:'manager',password,state:emptyState()}));
  manager.id=ok(await rpc('context',manager.token)).user.id;
  const users=[];
  for(const name of ['alpha','beta','charlie']){
    const user=ok(await rpc('workers.create',manager.token,{name,username:name,password}));
    const login=ok(await rpc('login','',{role:'worker',username:name,password}));
    users.push({...user,token:login.token});
  }
  const [a,b,c]=users,pair={participantA:a.id,participantB:b.id};
  let first;
  await check('private sends use authenticated identity and allow participants plus manager only',async()=>{
    const r=await request('dm.send',a.token,{recipientId:b.id,clientId:randomUUID(),body:'Private A to B',senderId:c.id,role:'manager'});
    assert.equal(r.status,200);first=r.body.message;assert.equal(first.senderId,a.id);
    for(const token of [a.token,b.token,manager.token])assert.equal(ok(await rpc('dm.thread',token,pair)).messages[0].id,first.id);
    assert.equal((await rpc('dm.thread',c.token,pair)).error.code,'FORBIDDEN');
    assert.equal((await rpc('dm.thread',c.token,{...pair,beforeId:first.id})).error.code,'FORBIDDEN');
    const third=ok(await rpc('dm.inbox',c.token));assert.equal(third.threads.length,0);assert.ok(!JSON.stringify(third).includes(first.body));
  });
  await check('only intended recipient gets unread totals; nonrecipient manager receives no ping count',async()=>{
    for(const [user,count] of [[a,0],[b,1],[c,0],[manager,0]]){
      const inbox=ok(await rpc('dm.inbox',user.token));assert.equal(inbox.unreadCount,count);
      assert.equal(ok(await rpc('dm.notifications',user.token)).unreadDirectMessages,count);
      const context=await request('context',user.token);assert.equal(context.status,200);assert.equal(context.body.notifications.unreadDirectMessages,count);
      assert.ok(!JSON.stringify(context.body).includes(first.body));
    }
    const audit=ok(await rpc('dm.inbox',manager.token));assert.equal(audit.threads.length,1);assert.equal(audit.threads[0].unreadCount,0);
  });
  await check('manager audit reads never consume recipient unread state and receipts stay visible',async()=>{
    for(const token of [a.token,c.token,manager.token])assert.equal(ok(await rpc('dm.read',token,{messageIds:[first.id]})).markedRead,0);
    assert.equal(ok(await rpc('dm.notifications',b.token)).unreadDirectMessages,1);
    assert.equal(ok(await rpc('dm.thread',manager.token,pair)).messages[0].readAt,null);
    assert.equal(ok(await rpc('dm.read',b.token,{messageIds:[first.id]})).markedRead,1);
    assert.ok(ok(await rpc('dm.thread',manager.token,pair)).messages[0].readAt);
    assert.equal(ok(await rpc('dm.notifications',manager.token)).unreadDirectMessages,0);
  });
  await check('manager receives unread alert when manager is the intended recipient',async()=>{
    const sent=ok(await rpc('dm.send',a.token,{recipientId:manager.id,clientId:randomUUID(),body:'Addressed to manager'})).message;
    assert.equal(ok(await rpc('dm.notifications',manager.token)).unreadDirectMessages,1);
    assert.equal(ok(await rpc('dm.read',manager.token,{messageIds:[sent.id]})).markedRead,1);
    assert.equal(ok(await rpc('dm.notifications',manager.token)).unreadDirectMessages,0);
  });
  await check('directed Public board messages are visible to every enabled workspace member',async()=>{
    const id=randomUUID(),result=await request('operation',a.token,{op:{id,type:'message.add',payload:{to:b.agentId,body:'Workspace-public directed message'}}});
    assert.equal(result.status,200);
    for(const user of [a,b,c,manager]){
      const state=ok(await rpc('context',user.token)).state;
      const m=state.messages.find(m=>m.operationId===id);assert.ok(m);assert.equal(m.from,a.agentId);assert.equal(m.to,b.agentId);
      assert.ok(!JSON.stringify(state).includes(first.body));
    }
  });
  await check('private table and RPC remain unavailable to anonymous and authenticated DB roles',async()=>{
    for(const role of ['anon','authenticated'])for(const query of ["select * from relay_private.direct_messages","select public.relay_dm_rpc('dm.inbox')"]){
      await db.exec('set role '+role);
      try{await assert.rejects(db.exec(query),/permission denied/);}finally{await db.exec('reset role');}
    }
    assert.equal((await sql("select relrowsecurity from pg_class where oid='relay_private.direct_messages'::regclass")).rows[0].relrowsecurity,true);
  });
  await check('missing and disabled sessions are rejected before message reads',async()=>{
    for(const action of ['dm.inbox','dm.thread','dm.notifications','dm.read','dm.send'])assert.equal((await rpc(action)).error.code,'SESSION');
    ok(await rpc('workers.update',manager.token,{workerId:c.id,enabled:false}));
    for(const action of ['dm.inbox','dm.thread','dm.notifications','dm.read','dm.send'])assert.equal((await rpc(action,c.token)).error.code,'SESSION');
  });
  console.log(`${checks} disposable PGlite SQL checks passed. No deployed/Supabase or independent-session concurrency verification.`);
}finally{await db.close();}

# Public composer → canonical messaging integration

Local functional implementation only. No live deployment, credentials, grants,
external publishing, backend schema application, or provider activation occurred.
This is not a retry/replacement/clearance of the blocked independent security review.

## Behavior

The existing public `operation/message.add` endpoint now routes through the
existing live-session-checked message RPC, rather than `board.commit`. One SQL
transaction calls the same canonical `message_action(messages.send)` as agent
messages and commits durable message history, public board projection, and the
intended recipients' notification outbox. Private `dm.send` remains on its
existing canonical adapter. Full bodies remain in Relay.

Public visibility and notification recipients are separate:

- General web composer: visibly labeled “Post & notify workers” with notice that
  enabled workers other than the sender are notified, while the manager stays
  quiet. It submits explicit `notifyWorkspace: true`.
- Directed public channel: workspace-readable, notifies its selected account
  only. “To manager” deliberately includes the manager as that recipient.
- Task note: workspace-readable, retains task association, visibly explains that
  no notifications are sent. No automatic task-note broadcast.
- Older API `message.add` calls without a selected recipient or explicit broadcast
  remain quiet. Setting `notifyWorkspace: true` with a task or directed recipient
  is rejected to avoid ambiguous notification intent.
- Private sends: participants plus manager audit access; only intended recipient
  receives the outbox/unread notification. This path is unchanged.

The canonical ten-field command and agent message schema are unchanged. UI-only
operation/channel/task metadata is stored in a new nullable `composer_context`
column and included in deduplication. Original non-UUID operation IDs are mapped
to deterministic sender-scoped client UUIDs. The board's message ID is now the
canonical message ID (also used by receipt controls); original operation ID is
retained separately as `operationId`. Sender, public audience, reply metadata,
channel/task association, board activity and sender lastSeen are preserved.

Same-operation retries return the original message without additional outbox
rows. Reusing the operation for changed content, target, task, reply, or broadcast
intent conflicts. Broadcast retries retain the originally committed recipient
set even if membership later changes. Projection capacity failure rolls back the
canonical message and outbox as well. Reapplying the proposed installer preserves
history/dedup state and sends no repeated notifications.

The actual web app retains an in-memory operation ID across an ambiguous send or
context-refresh failure, channel navigation, and manual retry. Simultaneous
submit events reuse it. Successful completion clears it; sign-out clears pending
operations. Changed draft content gets a distinct operation.

## Changed source locations

Applied equivalently to `backend-implementation/proposed/` and
`receipt-ui/frontend/proposed/`:

- `backend/handler.mjs`: compatibility routing and bounded same-operation network retry.
- `backend/message-contract.sql`: atomic public-composer compatibility adapter.
- `backend/schema.sql`, `backend/private-messages.sql`: identical embedded contract.
- `app.mjs`: retained retry ID and visible notification intent.
- `tests/accounts.test.mjs`: RPC fixture and routing expectations.
- `tests/message-audience-pglite.mjs`: canonical RPC routing/operationId expectation.
- `tests/composer-integration-pglite.mjs`: new real SQL functional regression cases.

Additionally `receipt-ui/frontend/proposed/tests/composer-app-dom.mjs` covers the
actual app/Edge/SQL submit path with jsdom. Receipt adapter and receipt source
modules are untouched. Historical `base/` snapshots are untouched.

## Verified on the final source

Using existing local fixture packages, no new package installation:

- 44 existing Node tests in each proposed tree, 88 executed total (same suite in
  both copies), all pass.
- 10 new Edge/PGlite composer functional checks, all pass.
- 3 new actual-app composer DOM tests plus 17 existing app/receipt DOM checks,
  20 executed total, all pass.
- JavaScript syntax checks for changed source and test files pass.

Commands from the root:

    node --test backend-implementation/proposed/tests/*.test.mjs receipt-ui/frontend/proposed/tests/*.test.mjs
    RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite node backend-implementation/proposed/tests/composer-integration-pglite.mjs
    RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom node --experimental-vm-modules --test receipt-ui/frontend/proposed/tests/composer-app-dom.mjs receipt-ui/frontend/proposed/tests/receipt-app-dom.mjs receipt-ui/frontend/proposed/tests/receipt-ui-dom.mjs

Logs are in `validation/composer/`.

## Remaining limits and integration notes

- No Chromium/layout QA, independent-session PostgreSQL concurrency/load testing,
  real delivery/model wakeup, or live deployment validation was performed.
- The previously blocked independent authentication/grant/security review remains
  blocked. These functional tests do not clear it.
- The existing canonical notification limit of 100 applies to explicit broadcasts;
  a larger worker audience is rejected atomically, not truncated.
- Legacy public board rows predating canonical storage are not backfilled or
  re-notified. Retrying an already recorded old board operation returns a conflict
  rather than silently duplicating it into canonical history.
- Browser pending-operation retention is in-memory, not durable over full reload.
  New caller IDs after reload are distinct sends; no cross-reload exactly-once
  claim is made.
- The new nullable composer column/function additions are proposed SQL only and
  require the same review/authorization gates as other backend changes.
- Supabase documentation fetches were attempted but unavailable (Markdown content
  unsupported and reference page 503); this change uses existing RPC conventions
  and ordinary PostgreSQL, without new Supabase APIs.
- Parent packaging must regenerate the final bundle's SHA256/provenance manifests
  and accumulated patch artifacts after merging all workers. This focused patch
  deliberately does not rewrite historical provenance or validation records.

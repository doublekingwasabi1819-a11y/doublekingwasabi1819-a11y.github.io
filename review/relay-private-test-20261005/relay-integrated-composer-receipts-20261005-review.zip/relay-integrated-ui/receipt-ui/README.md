# Optional manager delivery-receipt inspector (local preparation)

This additive slice follows frozen message backend v5. It includes actual Public
and Private chat-history mounts, a read-only event-ledger reader, and an opt-in
Fetch-compatible manager HTTP handler. It does not deploy routes or create grants.

## What is implemented

`frontend/receipt-ui.patch` applies to the v5 backend proposed tree. The complete
candidate is in `frontend/proposed`. Managers can expand each message's receipt
panel. Workers have no control; server authorization is independently mandatory.
Configuration exports `RECEIPT_ENDPOINT=''`, so the current default truthfully
shows receipts unavailable. No placeholder success or fabricated timestamps.

The response has separate queued, ping sent, service accepted, message fetched,
and explicit agent-acknowledged timestamps. A callback 2xx does not prove that an
agent read anything. Fetch does not mark a source DM read. Manager receipt
inspection is read-only, produces no notification, and never changes DM readAt.
Only actual targeted recipients with event records appear. Untargeted public
workspace members are not implicitly listed. No record means unknown/unavailable,
including messages sent by the legacy public browser composer (which v5 does not
route through the new canonical outbox).

## Required topology integration: not currently configured

The existing browser API is
`https://mukbnmewwoeweogmcuno.supabase.co/functions/v1/relay`.
The event ledger is on a different Lightsail host. The frontend deliberately
rejects a Lightsail URL and will not forward the browser's Relay bearer there.
Setting RECEIPT_ENDPOINT to Lightsail therefore CANNOT activate this feature.

The smallest supported topology is an authenticated Supabase Edge route at
`/functions/v1/relay-receipts`, on the existing API origin, proxying over an
independently authorized server-to-server channel to the event host.
`event-host/same-origin-proxy-template.mjs` provides the actual handler factory
but deliberately leaves both security-sensitive host hooks unset:
1. authenticateRelayManager must validate the existing live Relay session and
   return its server-derived manager ID, role, and workspace.
2. readThroughAuthorizedService must use a separately approved authenticated
   service transport, bind the verified manager/workspace/message ID, enforce
   freshness/replay controls, and never forward the browser bearer.

On the event host, createManagerReceiptReader requires the existing engine,
messageAccess.receipts capability, configured workspace UUID, fresh manager
authorization, and an authorized canonical source metadata reader. The metadata
reader must enforce current workspace/private permissions; UUID possession is
not permission. Existing messageAccess authorizeAudit remains a second per-target
check. Mount createManagerReceiptRoute only with those approved hooks and explicit
frontend allowedOrigins. OPTIONS permits only POST/Authorization/Content-Type.
No wildcard origin, credential creation, automatic external fetch, or route
registration occurs. The injected hooks should honor AbortSignal for resource
cleanup. Errors are redacted and all replies are no-store.

This production proxy/service trust integration is a real remaining activation
gap. This package is not a claim that a supported live receipt endpoint exists.
The browser-only account-linking slice is unchanged and grants no message scope.

## Local tests

Run from the enclosing delivered package root (Node 22+):

```
node --test receipt-ui/event-host/test/manager-receipts.test.mjs
RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom \
 node --experimental-vm-modules --test receipt-ui/frontend/proposed/tests/receipt-ui-dom.mjs
```

See frontend/VALIDATION.md for full DOM/SQL fixture commands and required official
npm jsdom and @electric-sql/pglite dependencies. The integration test exercises
the real UI, route, SQL authorization, event ledger and existing receipt hook
locally. It substitutes only the not-yet-authorized production service transport.
No browser layout or live delivery claim is made.

Source reader detail: current `messages.metadata` omits notification targets.
The required readMetadata hook must therefore use authorized `messages.get` and
immediately project only id, workspaceId, visibility, recipientIds and
notificationRecipientIds, discarding its body. Missing target metadata fails
closed. Every ledger recipient must match the canonical intended notification
audience; the source audience is rechecked before returning.

## Concrete same-origin adapter addition

`backend/relay-receipts.mjs` now implements live Relay manager authentication,
workspace/canonical-source checks, safe receipt response projection and explicit
backend composition. See `backend/README.md` for its tested integration and exact
dependencies. This removes the unspecified manager-authentication implementation
gap; the separately authorized cross-host service channel and live deployment
remain absent. The original proxy template remains available but is not a claim
that production service trust has been configured.

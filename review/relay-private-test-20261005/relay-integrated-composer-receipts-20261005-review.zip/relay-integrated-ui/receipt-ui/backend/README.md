# Concrete same-origin manager receipt adapter

This local source addition replaces the previously unspecified browser-manager
authentication hook with existing Relay SQL session authority. It does not create
a new identity, OAuth scope, credential, subscription, listener, or deployment.

`createRelayReceiptDeployment` is a Fetch-compatible handler for
`/functions/v1/relay-receipts`. `composeRelayReceiptBackend` explicitly combines it
with an existing Relay handler without changing normal action dispatch. Both are
inactive by default. An enabled deployment requires all of:

- The exact existing Relay API HTTPS origin and canonical workspace UUID.
- Explicit browser frontend allowed origins.
- The existing server-side `rpc(action, token, data)` dependency, such as the
  backend's existing `createDatabaseRPC` instance. Keep it on its authorized
  database origin; do not point it at Lightsail or forward the browser token there.
- An independently approved `readThroughAuthorizedService(payload, {signal})`
  transport. Payload is exactly `{messageId, managerId, workspaceId}`. The event
  host must authenticate that service, bind those identifiers to its trusted
  manager/source hooks, enforce freshness and replay protection, and return the
  existing `createManagerReceiptReader` result. This adapter does not implement
  or assume that presently missing production trust relationship.

Each request validates the live Relay session through `context`, verifies the
server-provided message capabilities and workspace, retrieves the authorized
canonical source, requests receipt metadata, rechecks source audience, and
revalidates manager authority. No user-editable role claim is trusted. Source
`messages.get` does not mark a DM read. Its body is immediately discarded and is
never supplied to the service channel. The response is rebuilt from an explicit
receipt-field allowlist; injected body/token fields are discarded, and wrong
message, audience, timestamps or response shape fail closed. The existing event
reader retains its second per-recipient audit. Manager inspection creates no
notification subscription and sends no manager ping.

## Remaining deployment dependencies

1. Supply the separately approved server-to-server authentication/transport and
   event-host verifier using existing approved trust, or obtain that approval.
   Merely implementing or injecting a function does not establish trust.
2. Mount the handler on the existing Relay API origin, with the existing RPC
   dependency, exact workspace and frontend origin. Keep the worker OAuth resource
   and browser credential implementation unchanged. No Supabase gateway auth or
   permission configuration has been changed here.
3. After authorized deployment verification, set the frontend receipt endpoint
   to `/functions/v1/relay-receipts`. It remains empty in this package.
4. The previously blocked independent security review remains outstanding. These
   functional tests are not a substitute, and no review was retried.

## Local validation

Node 22+; use the already installed official PGlite and jsdom packages:

```
RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite \
RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom \
node --experimental-vm-modules --test \
  receipt-ui/backend/test/relay-receipts.test.mjs \
  receipt-ui/backend/test/relay-receipts-dom-integration.mjs \
  receipt-ui/event-host/test/manager-receipts.test.mjs
```

14 tests passed. The DOM integration uses actual UI, SQL session/message policy,
SQLite event ledger, and existing per-recipient receipt reader. Only the service
transport is an explicit in-process fixture. SQL fixture schema setup and test
sessions are local and ephemeral; no remote migration or real identity creation
occurs. There is no live transport, deployment or browser layout claim.

Documentation consulted: Supabase routing
https://supabase.com/docs/guides/functions/routing and changelog
https://supabase.com/changelog (2026-10-05). No SDK or database API changed.

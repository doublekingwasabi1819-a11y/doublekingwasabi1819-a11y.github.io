import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createRelayReceiptDeployment,composeRelayReceiptBackend} from '../relay-receipts.mjs';
import {createMessageFixture} from '../../../backend-implementation/proposed/tests/helpers/message-fixture.mjs';
const origin='https://relay.fixture.invalid',frontend='https://frontend.fixture.invalid';
const request=(token,messageId,extra={})=>new Request(origin+'/functions/v1/relay-receipts',{method:'POST',headers:{Origin:frontend,'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({messageId,...extra})});

test('disabled deployment is unavailable; enabling requires approved dependencies',async()=>{
 assert.equal((await createRelayReceiptDeployment()(request('x',randomUUID()))).status,404);
 assert.throws(()=>createRelayReceiptDeployment({enabled:true}),/approved service channel/);
 const handler=composeRelayReceiptBackend({relayHandler:async()=>new Response('existing')});
 assert.equal(await (await handler(new Request(origin+'/functions/v1/relay'))).text(),'existing');
 assert.equal((await handler(request('x',randomUUID()))).status,404);
});

test('live SQL manager authority and source checks protect server-only transport and sanitize receipts',{timeout:60000},async t=>{
 const f=await createMessageFixture();t.after(()=>f.close());
 const {manager,a,b,capabilities}=f;
 const command={clientId:randomUUID(),workspaceId:capabilities.workspaceId,roomId:capabilities.roomId,visibility:'private',senderId:a.id,
  recipientIds:[b.id],participantIds:[a.id,b.id].sort(),notificationRecipientIds:[b.id],body:'Private body must never cross service boundary',replyToMessageId:null};
 const {message}=await f.rpc('messages.send',a.token,{command});
 const seen=[];let result={messageId:message.id,visibility:'private',receiptState:'available',body:'unexpected upstream body',recipients:[{recipientId:b.id,agentId:b.agentId,queuedAt:new Date().toISOString(),pingSentAt:null,serviceAcceptedAt:null,messageFetchedAt:null,agentAcknowledgedAt:null,attempts:[],token:'unexpected upstream secret'}]};
 let callback;
 const handler=createRelayReceiptDeployment({enabled:true,apiOrigin:origin,workspaceId:capabilities.workspaceId,allowedOrigins:[frontend],rpc:f.rpc,
  readThroughAuthorizedService:async(payload,context)=>{seen.push(payload);assert.ok(context.signal instanceof AbortSignal);await callback?.();return result;}});
 const before=(await f.rpc('dm.notifications',b.token)).unreadDirectMessages;
 let response=await handler(request(manager.token,message.id));assert.equal(response.status,200);
 const body=await response.json();assert.equal(body.recipients.length,1);assert.equal(body.body,undefined);assert.equal(body.recipients[0].token,undefined);
 assert.deepEqual(seen,[{messageId:message.id,managerId:manager.id,workspaceId:capabilities.workspaceId}]);
 assert.ok(!JSON.stringify(seen).includes(manager.token));assert.ok(!JSON.stringify(seen).includes(command.body));
 assert.equal((await f.rpc('dm.notifications',b.token)).unreadDirectMessages,before);
 assert.equal((await f.rpc('messages.notifications',manager.token)).notifications.length,0);
 assert.equal((await handler(request(a.token,message.id))).status,403);assert.equal(seen.length,1);
 assert.equal((await handler(request('invalid',message.id))).status,403);assert.equal(seen.length,1);
 assert.equal((await handler(request(manager.token,randomUUID()))).status,403);assert.equal(seen.length,1);
 assert.equal((await handler(request(manager.token,message.id,{managerId:a.id}))).status,400);assert.equal(seen.length,1);
 result={...result,recipients:[{...result.recipients[0],recipientId:a.id}]};assert.equal((await handler(request(manager.token,message.id))).status,403);
 result={messageId:message.id,visibility:'private',receiptState:'no_event_record',recipients:[]};
 callback=()=>f.rpc('logout',manager.token);
 response=await handler(request(manager.token,message.id));assert.equal(response.status,403);assert.equal((await response.json()).error,'Receipt access unavailable');
});

test('origin binding, worker denial, timeout and capability mismatch fail closed without transport',async()=>{
 const id=randomUUID(),workspaceId=randomUUID();let calls=0;
 const rpc=async action=>action==='context'?{user:{id,role:'manager'}}:{workspaceId:randomUUID()};
 const handler=createRelayReceiptDeployment({enabled:true,apiOrigin:origin,workspaceId,allowedOrigins:[frontend],rpc,readThroughAuthorizedService:async()=>{calls++;}});
 assert.equal((await handler(request('token',randomUUID()))).status,403);
 assert.equal((await handler(new Request('https://other.invalid/functions/v1/relay-receipts'))).status,400);
 assert.equal(calls,0);
 const slow=createRelayReceiptDeployment({enabled:true,apiOrigin:origin,workspaceId,allowedOrigins:[frontend],timeoutMs:5,rpc:()=>new Promise(()=>{}),readThroughAuthorizedService:async()=>{calls++;}});
 assert.equal((await slow(request('token',randomUUID()))).status,504);assert.equal(calls,0);
});

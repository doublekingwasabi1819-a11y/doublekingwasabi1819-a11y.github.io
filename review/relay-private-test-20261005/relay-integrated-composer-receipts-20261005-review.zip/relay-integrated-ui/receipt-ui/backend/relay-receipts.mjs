import {createManagerReceiptRoute} from '../event-host/manager-receipts.mjs';

const UUID = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
const deny = () => {throw new Error('Receipt access unavailable');};
const active = signal => {if (signal?.aborted) deny();};
const timestamp = value => {
  if (value === null) return null;
  if (typeof value !== 'string' || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value) deny();
  return value;
};
function sourceMetadata(value, messageId, workspaceId) {
  const m = value?.message;
  if (m?.id !== messageId || m.workspaceId !== workspaceId || !['public','private'].includes(m.visibility) ||
      !Array.isArray(m.notificationRecipientIds) || m.notificationRecipientIds.length > 100 ||
      m.notificationRecipientIds.some(id => typeof id !== 'string' || !UUID.test(id)) ||
      new Set(m.notificationRecipientIds).size !== m.notificationRecipientIds.length ||
      (m.visibility === 'private' && (m.notificationRecipientIds.length !== 1 || m.recipientIds?.length !== 1 || m.recipientIds[0] !== m.notificationRecipientIds[0]))) deny();
  // Project immediately. Never pass the source body to the event host.
  return {messageId, workspaceId, visibility:m.visibility, targets:[...m.notificationRecipientIds].sort()};
}
function receiptProjection(value, source) {
  if (value?.messageId !== source.messageId || value.visibility !== source.visibility ||
      !['available','no_event_record'].includes(value.receiptState) || !Array.isArray(value.recipients) ||
      value.recipients.length > 100 || (value.receiptState === 'available') !== (value.recipients.length > 0)) deny();
  const seen = new Set();
  const recipients = value.recipients.map(row => {
    if (!source.targets.includes(row?.recipientId) || seen.has(row.recipientId) || typeof row.agentId !== 'string' || !UUID.test(row.agentId) ||
        !Array.isArray(row.attempts) || row.attempts.length > 100) deny();
    seen.add(row.recipientId);
    const attempts = row.attempts.map(a => {
      if (typeof a?.eventId !== 'string' || !/^[A-Za-z0-9._:-]{1,128}$/.test(a.eventId) || !Number.isSafeInteger(a.attempt) || a.attempt < 1 ||
          !['accepted','rejected','unknown'].includes(a.outcome)) deny();
      return {eventId:a.eventId, attempt:a.attempt, attemptedAt:timestamp(a.attemptedAt), sentAt:timestamp(a.sentAt),
        completedAt:timestamp(a.completedAt), serviceAcceptedAt:timestamp(a.serviceAcceptedAt), outcome:a.outcome};
    });
    return {recipientId:row.recipientId,agentId:row.agentId,queuedAt:timestamp(row.queuedAt),pingSentAt:timestamp(row.pingSentAt),
      serviceAcceptedAt:timestamp(row.serviceAcceptedAt),messageFetchedAt:timestamp(row.messageFetchedAt),agentAcknowledgedAt:timestamp(row.agentAcknowledgedAt),attempts};
  });
  return {messageId:source.messageId,visibility:source.visibility,receiptState:value.receiptState,recipients};
}

/** Same-origin Fetch handler. rpc is the EXISTING server-side Relay database RPC,
 * not an HTTP client pointed at the event host. No service credential is created.
 * readThroughAuthorizedService is an independently approved server-only channel:
 * it must authenticate the caller and bind manager/workspace/message, freshness,
 * and replay protection at the event host. It receives no browser credential.
 * This module never registers/listens, provisions credentials or enables grants.
 */
export function createRelayReceiptDeployment({enabled=false,apiOrigin,workspaceId,allowedOrigins=[],rpc,readThroughAuthorizedService,timeoutMs=10000}={}) {
  if (enabled === false) return createManagerReceiptRoute();
  if (enabled !== true || typeof rpc !== 'function' || typeof readThroughAuthorizedService !== 'function' ||
      typeof workspaceId !== 'string' || !UUID.test(workspaceId)) throw new TypeError('Existing Relay RPC, workspace and approved service channel required');
  const url = new URL(apiOrigin);
  if (url.origin !== apiOrigin || url.protocol !== 'https:') throw new TypeError('Exact Relay HTTPS API origin required');
  const sessions = new WeakMap();
  async function authenticateManager(request,{signal}) {
    active(signal);
    const header = request.headers.get('Authorization') ?? '';
    if (!/^Bearer [^\s]{1,512}$/.test(header)) return null;
    const token = header.slice(7);
    const context = await rpc('context',token,{}); active(signal);
    if (typeof context?.user?.id !== 'string' || !UUID.test(context.user.id)) return null;
    if (context.user.role !== 'manager') return {id:context.user.id,role:context.user.role};
    const policy = await rpc('messages.capabilities',token,{}); active(signal);
    if (policy?.workspaceId !== workspaceId || policy.contractVersion !== 'relay-message-source/1' ||
        policy.explicitAudienceMetadata !== true || policy.privateParticipantsAndManagerOnly !== true || policy.publicWorkspaceOnly !== true || policy.historyDurable !== true) deny();
    const identity = Object.freeze({id:context.user.id,role:'manager',workspaceId});
    sessions.set(identity,token);
    return identity;
  }
  const route = createManagerReceiptRoute({enabled:true,path:'/functions/v1/relay-receipts',allowedOrigins,timeoutMs,authenticateManager,
    async readReceipt({messageId},{identity,signal}) {
      const token = sessions.get(identity); if (!token) deny();
      try {
        const source = sourceMetadata(await rpc('messages.get',token,{messageId}),messageId,workspaceId); active(signal);
        const value = await readThroughAuthorizedService(Object.freeze({messageId,managerId:identity.id,workspaceId}),{signal}); active(signal);
        const result = receiptProjection(value,source);
        const fresh = sourceMetadata(await rpc('messages.get',token,{messageId}),messageId,workspaceId); active(signal);
        if (JSON.stringify(fresh) !== JSON.stringify(source)) deny();
        return result;
      } finally {sessions.delete(identity);}
    }
  });
  return request => {
    const target = new URL(request.url);
    if (target.origin !== apiOrigin || target.search || target.hash || request.headers.has('cookie'))
      return new Response(JSON.stringify({error:'Invalid request'}),{status:400,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
    return route(request);
  };
}

/** Explicit composition only: normal Relay actions continue to their existing
 * handler. The receipt route has a distinct path and is disabled by default. */
export function composeRelayReceiptBackend({relayHandler,receipts}={}) {
  if (typeof relayHandler !== 'function') throw new TypeError('Existing Relay handler required');
  const receiptHandler = createRelayReceiptDeployment(receipts);
  return request => new URL(request.url).pathname === '/functions/v1/relay-receipts' ? receiptHandler(request) : relayHandler(request);
}

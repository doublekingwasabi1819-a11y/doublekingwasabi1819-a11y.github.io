# Integrated composer, receipts and messaging runtime: local validation

2026-10-05 UTC. Functional candidate only. The previously blocked independent
security review remains unresolved; it was not rerun, replaced or cleared.
No live accounts, schema migrations, routes, grants, deployment or external
repository publication occurred. Base input remains untouched.

## Fresh checks against this integrated copy

- Runtime: 115 passed.
- Components: 313 passed (87 account-linking, 28 production, 188 events/messages,
  10 manager-receipt reader/route checks).
- Proposed source: 88 executions passed, representing the same 44 tests in each
  of the backend and frontend proposed trees. Do not count these as 88 distinct tests.
- New composer SQL: 10 functional checks passed using actual local Edge/PGlite.
- Composer/receipt DOM: 20 passed (3 composer, 4 actual receipt app, 13 receipt UI).
- Receipt adapter: 14 passed; 10 repeat the component manager-receipt tests,
  with 4 additional concrete-adapter/DOM integration tests. Do not add all 14
  to component totals as distinct coverage.
- Existing audience SQL regression: 8 functional checks passed.
- Fresh controller: 243 passed, 0 failed, 2 skipped from 245 declarations.
  This initial run skipped both real Chromium tests because the pinned binary
  was absent. A later required-mode attempt is recorded below; browser/layout
  verification remains blocked.
- All 154 packaged executable JavaScript files pass node --check.
- Regenerated 34-file controller manifest passes. Both cumulative proposed-tree
  patches pass a dry-run against their bundled base snapshots.

Separate suite counts above are deliberate; repeats and older evidence are not
presented as additional distinct coverage. Logs are under validation/integrated.
Earlier validation/provenance is retained there as INPUT-* historical evidence.

## Compatibility scope

The controller static asset map adds only /receipt-ui.mjs and
/receipt-config.mjs as exact same-origin scripts. Existing origin, method,
resource-type, query, navigation, redirect and clean-header rules are unchanged.
Positive and negative mocked route checks cover both modules. Receipt API requests
remain blocked from this worker-only read-only browser controller. No send,
receipt-manager access, broader route or browser account permission is added.
The earlier controller baseline no longer describes the modified driver.

## Reproduce

Use Node 24 and the existing pinned local dependencies. A later official pinned
Chromium installation attempt failed as recorded below. No dependency update or
vulnerability audit was performed. From package root:

    RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite node --test runtime/test/*.test.mjs
    node --test production/tests/*.test.mjs account-linking/tests/*.test.mjs relay-events/test/*.test.mjs receipt-ui/event-host/test/*.test.mjs
    node --test backend-implementation/proposed/tests/*.test.mjs receipt-ui/frontend/proposed/tests/*.test.mjs
    RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite node backend-implementation/proposed/tests/composer-integration-pglite.mjs
    RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite node backend-implementation/proposed/tests/message-audience-pglite.mjs
    RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom node --experimental-vm-modules --test receipt-ui/frontend/proposed/tests/composer-app-dom.mjs receipt-ui/frontend/proposed/tests/receipt-app-dom.mjs receipt-ui/frontend/proposed/tests/receipt-ui-dom.mjs
    RELAY_PGLITE_ROOT=/tmp/relay-message-privacy-pg/node_modules/@electric-sql/pglite RELAY_RECEIPT_JSDOM_ROOT=/tmp/relay-receipt-ui-test/node_modules/jsdom node --experimental-vm-modules --test receipt-ui/backend/test/*.mjs receipt-ui/event-host/test/*.test.mjs
    node --test controller/tests/*.test.mjs
    (cd controller && sha256sum --check hosting/ubuntu-x64/controller-sha256.txt)

The /tmp dependency paths identify the existing disposable test environment;
they are not deployed database or account configuration.

## Remaining limits and gates

- Approved authenticated cross-host receipt service transport is unconfigured;
  no service trust, credentials or keys were invented. Frontend receipt endpoint
  stays empty/disabled pending authorized deployment and verification.
- No live delivery, actual ChatGPT wake/tool invocation, account linking,
  independent PostgreSQL concurrency/load testing or real browser QA.
- Proposed SQL additions still require authorized migration/deployment.
- The original independent review block remains unchanged.
- Existing single-worker pilot boundary and maximum 15-minute consent remain;
  no automatic renewal, refresh token or unattended lifetime extension.
- Public broadcast explicitly notifies enabled workers excluding sender/manager;
  directed public only notifies its target; task notes stay quiet. Private content
  remains participants-plus-manager visible; only its recipient is notified.
- Composer retry IDs persist in memory only; full reload is not exactly-once.

PACKAGE-SHA256.json covers every payload file except itself and dependency
folders. SOURCE-PROVENANCE.json records exact changes against the untouched
messaging-login input and preserves its earlier provenance separately.

## Required Chromium attempt, 2026-10-05 08:26 UTC

With Node 24.19.0 and existing Playwright 1.62.1, the official installer attempted
Chromium revision 1234 / Chrome for Testing 151.0.7922.34 in a separate test cache.
Its pinned download URL was:
https://cdn.playwright.dev/builds/cft/151.0.7922.34/linux64/chrome-linux64.zip
The response was HTTP 200, text/html, 195 bytes, with “Site Unavailable” and
“Unable to access this site.” The installer rejected the non-ZIP response and
exited 1 after its automatic retries. No binary was installed; no alternate
source, unpinned browser, sandbox bypass or security-setting change was used.

A fresh full controller run with RELAY_REQUIRE_CHROMIUM=1 and
RELAY_TEST_ARTIFACTS=1 declared 245 tests: 243 passed, 2 failed, 0 skipped,
0 cancelled, 0 todo (exit 1). Both failures were the explicit pinned-binary
missing assertions in tests/chromium.test.mjs and tests/chromium-host.test.mjs.
No Chromium process launched. Actual receipt-module browser loading, layout,
masked viewer rendering and real browser fixture acceptance remain unverified.
The earlier non-browser and mocked route results are not real-browser evidence.

The browser cache and test profiles are not bundled. No executable source was
changed for this attempt. The original independent review block is unchanged.
For a later authorized server check, verify the already-installed exact pinned
browser first and invoke the controller tests directly with Chromium required.
Do not invoke hosting/ubuntu-x64/prepare.sh for a no-install check: it downloads
packages/browser and retains a historical 244-test gate, whereas this integrated
copy declares 245 tests. No server check has been performed for this report.

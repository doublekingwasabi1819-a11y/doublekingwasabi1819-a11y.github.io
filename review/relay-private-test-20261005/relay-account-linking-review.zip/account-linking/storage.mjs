import { createCipheriv, createDecipheriv, createHmac, hkdfSync, randomBytes, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';

/**
 * Same-host, bounded, encrypted storage for oidc-provider 9.12.2.
 * Contract: https://github.com/panva/node-oidc-provider/blob/v9.12.2/example/my_adapter.js
 * Atomic consume is stricter than the example adapter: the tagged token endpoint
 * awaits consume before token issuance; a duplicate MUST reject, not just return.
 * No import side effects, DB opening, listeners, key generation, or live setup.
 * Caller owns DB lifecycle, private file permissions, durable backup and key custody.
 * One DB uses one fixed key/keyId/config. Key rotation needs a separate reviewed
 * migration of ciphertext AND keyed indexes/tombstones; changing keyId isn't rotation.
 * SQLite transactions serialize writes across processes on one local host. Do not
 * put the DB on NFS or share its connection with unrelated transactions. File
 * stores must keep a durable journal and synchronous FULL/EXTRA for their entire
 * lifetime; a busy timeout is recommended for multi-process connections. Expired
 * grants and delegations become permanent tombstones. The cap intentionally
 * requires operator intervention rather than unsafe tombstone eviction. Restoring
 * an older DB snapshot can undo revocation: revoke external access before restore.
 */
export const ALLOWED_MODELS = Object.freeze([
  'Grant', 'Session', 'Interaction', 'AccessToken', 'AuthorizationCode', 'ReplayDetection',
]);
const MODELS = new Set(ALLOWED_MODELS);
const STATES = new Set(['login', 'consent', 'account']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const OPAQUE_ID = /^[A-Za-z0-9_-]{1,128}$/;
const RELAY_TOKEN = /^[a-f0-9]{64}$/;
const MAX_TTL_SECONDS = 30 * 24 * 60 * 60;

export class StorageError extends Error {
  constructor(code, message = 'Encrypted account-linking storage operation failed') {
    super(message);
    this.name = 'StorageError';
    this.code = code;
  }
}

/** Explicit schema application; never called on import or by the factory. */
export function initializeStorage(db) {
  assertDb(db);
  if (db.isTransaction) throw new StorageError('TRANSACTION_ACTIVE');
  db.exec(readFileSync(new URL('./storage.sql', import.meta.url), 'utf8'));
}

function assertDb(db) {
  if (!db || db.isOpen !== true || typeof db.prepare !== 'function' || typeof db.exec !== 'function') {
    throw new TypeError('An already-open node:sqlite DatabaseSync is required');
  }
}
function textId(value, label = 'identifier', max = 2048) {
  if (typeof value !== 'string' || value.length === 0 || Buffer.byteLength(value) > max || /[\x00-\x1f\x7f]/.test(value)) {
    throw new TypeError(`Invalid ${label}`);
  }
  return value;
}
function integer(value, min, max, label) {
  if (!Number.isSafeInteger(value) || value < min || value > max) throw new TypeError(`Invalid ${label}`);
  return value;
}
function object(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
    throw new TypeError('Payload must be a plain JSON object');
  }
  return value;
}
function grantError() {
  const error = new StorageError('INVALID_GRANT', 'invalid_grant');
  Object.assign(error, { error: 'invalid_grant', error_description: 'grant request is invalid', status: 400, statusCode: 400, expose: true });
  return error;
}

export function createEncryptedStore({
  db, key, keyId, now = Date.now, maxRows = 10000, maxTtlSeconds = 900,
  maxPayloadBytes = 65536, invalidGrant = grantError,
} = {}) {
  assertDb(db);
  const fileBacked = Boolean(db.prepare('PRAGMA database_list').all().find((entry) => entry.name === 'main')?.file);
  if (fileBacked) {
    const mode = db.prepare('PRAGMA journal_mode').get().journal_mode;
    const synchronous = db.prepare('PRAGMA synchronous').get().synchronous;
    if (!['delete', 'truncate', 'persist', 'wal'].includes(mode) || synchronous < 2) {
      throw new StorageError('NON_DURABLE_DATABASE', 'File-backed storage requires a durable journal and synchronous FULL or EXTRA');
    }
  }
  if (!(key instanceof Uint8Array) || key.byteLength !== 32) throw new TypeError('A caller-supplied 32-byte key is required');
  textId(keyId, 'keyId', 128);
  integer(maxRows, 1, 1000000, 'maxRows');
  integer(maxTtlSeconds, 1, MAX_TTL_SECONDS, 'maxTtlSeconds');
  integer(maxPayloadBytes, 256, 262144, 'maxPayloadBytes');
  if (typeof now !== 'function' || typeof invalidGrant !== 'function') throw new TypeError('Invalid storage callback');
  // Distinct derived keys protect encryption and low-entropy identifier indexes.
  const encryptionKey = Buffer.from(hkdfSync('sha256', key, 'relay-link-storage-v1', 'encryption', 32));
  const indexKey = Buffer.from(hkdfSync('sha256', key, 'relay-link-storage-v1', 'indexes', 32));
  const clock = () => integer(now(), 1, Number.MAX_SAFE_INTEGER - MAX_TTL_SECONDS * 1000, 'clock');
  const digest = (domain, value) => createHmac('sha256', indexKey).update(JSON.stringify([domain, textId(value)])).digest('hex');
  const idHash = (namespace, id) => digest(`id:${namespace}`, id);
  const grantHash = (id) => digest('grant', id);
  const failGrant = () => {
    const error = invalidGrant();
    if (!(error instanceof Error)) throw new TypeError('invalidGrant must return an Error');
    throw error;
  };
  const transaction = (fn) => {
    if (db.isTransaction) throw new StorageError('TRANSACTION_ACTIVE');
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = fn();
      db.exec('COMMIT');
      return result;
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  };
  // Reject wrong keys instead of silently losing sight of existing revocations.
  const config = { version: 1, key_id: keyId, key_check: digest('key-check', 'relay-link-storage-v1'), max_rows: maxRows, max_ttl_seconds: maxTtlSeconds, max_payload_bytes: maxPayloadBytes };
  transaction(() => {
    const previous = db.prepare('SELECT * FROM relay_link_config WHERE singleton = 1').get();
    if (!previous) {
      const existing = db.prepare('SELECT (SELECT count(*) FROM relay_link_records) + (SELECT count(*) FROM relay_link_revoked_grants) AS n').get().n;
      if (existing !== 0) throw new StorageError('CONFIG_MISSING');
      db.prepare('INSERT INTO relay_link_config VALUES (1, ?, ?, ?, ?, ?, ?)').run(...Object.values(config));
    } else {
      const matchingKey = typeof previous.key_check === 'string' && previous.key_check.length === config.key_check.length
        && timingSafeEqual(Buffer.from(previous.key_check), Buffer.from(config.key_check));
      if (!matchingKey || Object.keys(config).some((name) => name !== 'key_check' && config[name] !== previous[name])) {
        throw new StorageError('CONFIG_MISMATCH', 'Storage key, key ID, version, or bounds do not match');
      }
    }
  });
  const q = {
    find: db.prepare('SELECT * FROM relay_link_records WHERE namespace = ? AND id_hash = ?'),
    uid: db.prepare("SELECT * FROM relay_link_records WHERE namespace = 'oidc:Session' AND uid_hash = ?"),
    revoked: db.prepare('SELECT 1 FROM relay_link_revoked_grants WHERE grant_hash = ?'),
    grantHashes: db.prepare('SELECT DISTINCT grant_hash FROM relay_link_records WHERE grant_hash IS NOT NULL'),
    count: db.prepare('SELECT (SELECT count(*) FROM relay_link_records) + (SELECT count(*) FROM relay_link_revoked_grants) AS n'),
    expire: db.prepare('DELETE FROM relay_link_records WHERE expires_at <= ?'),
    expiredGrants: db.prepare("SELECT DISTINCT grant_hash FROM relay_link_records WHERE expires_at <= ? AND namespace IN ('oidc:Grant', 'delegation') AND grant_hash IS NOT NULL"),
    delete: db.prepare('DELETE FROM relay_link_records WHERE namespace = ? AND id_hash = ?'),
    deleteGrant: db.prepare('DELETE FROM relay_link_records WHERE grant_hash = ?'),
    revoke: db.prepare('INSERT INTO relay_link_revoked_grants (grant_hash, revoked_at) VALUES (?, ?) ON CONFLICT DO NOTHING'),
    write: db.prepare(`INSERT INTO relay_link_records
      (namespace, id_hash, grant_hash, uid_hash, expires_at, consumed_at, key_id, nonce, ciphertext, tag)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(namespace, id_hash) DO UPDATE SET
      grant_hash=excluded.grant_hash, uid_hash=excluded.uid_hash, expires_at=excluded.expires_at,
      consumed_at=excluded.consumed_at, key_id=excluded.key_id, nonce=excluded.nonce,
      ciphertext=excluded.ciphertext, tag=excluded.tag`),
    consume: db.prepare(`UPDATE relay_link_records SET consumed_at=?, nonce=?, ciphertext=?, tag=?
      WHERE namespace=? AND id_hash=? AND consumed_at IS NULL AND expires_at > ?`),
  };
  const revoked = (hash) => hash !== null && Boolean(q.revoked.get(hash));
  const prune = (at) => {
    let removed = 0;
    // Each expired grant/delegation frees at least one row before adding one
    // tombstone, so this cannot exceed the existing bounded row count. Never
    // permit a pruned delegation/expired grant ID to remap to a fresh worker.
    for (const { grant_hash: hash } of q.expiredGrants.all(at)) {
      removed += q.deleteGrant.run(hash).changes;
      q.revoke.run(hash, at);
    }
    return removed + q.expire.run(at).changes;
  };
  const capacity = (at) => {
    prune(at);
    if (q.count.get().n >= maxRows) throw new StorageError('CAPACITY', 'Encrypted storage capacity reached; fail closed');
  };
  const aad = (row) => Buffer.from(JSON.stringify([
    'relay-link-storage-v1', row.namespace, row.id_hash, row.key_id,
    row.expires_at, row.grant_hash, row.uid_hash, row.consumed_at,
  ]));
  const serialize = (payload) => {
    object(payload);
    let json;
    try { json = JSON.stringify(payload); } catch { throw new TypeError('Payload must be serializable JSON'); }
    if (!json || Buffer.byteLength(json) > maxPayloadBytes) throw new StorageError('PAYLOAD_SIZE');
    return json;
  };
  const seal = (row, payload) => {
    const json = serialize(payload);
    const nonce = randomBytes(12); // A per-write nonce, never an encryption/signing key.
    const cipher = createCipheriv('aes-256-gcm', encryptionKey, nonce, { authTagLength: 16 });
    cipher.setAAD(aad(row));
    return { nonce, ciphertext: Buffer.concat([cipher.update(json, 'utf8'), cipher.final()]), tag: cipher.getAuthTag() };
  };
  const open = (row) => {
    try {
      if (row.key_id !== keyId || row.ciphertext.length > maxPayloadBytes || row.nonce.length !== 12 || row.tag.length !== 16) throw new Error();
      const decipher = createDecipheriv('aes-256-gcm', encryptionKey, row.nonce, { authTagLength: 16 });
      decipher.setAAD(aad(row));
      decipher.setAuthTag(row.tag);
      return object(JSON.parse(Buffer.concat([decipher.update(row.ciphertext), decipher.final()]).toString('utf8')));
    } catch {
      // Never include ciphertext, payload, token, identifier or underlying cause.
      throw new StorageError('INTEGRITY', 'Encrypted storage integrity check failed');
    }
  };
  const usable = (row, at) => row && row.expires_at > at && !revoked(row.grant_hash);
  const read = (namespace, id, at = clock()) => {
    const row = q.find.get(namespace, idHash(namespace, id));
    return usable(row, at) ? { row, payload: open(row) } : undefined;
  };
  const expiry = (ttl, at) => at + integer(ttl, 1, maxTtlSeconds, 'TTL in seconds') * 1000;
  const write = (row, payload) => {
    const encrypted = seal(row, payload);
    q.write.run(row.namespace, row.id_hash, row.grant_hash, row.uid_hash, row.expires_at, row.consumed_at, keyId, encrypted.nonce, encrypted.ciphertext, encrypted.tag);
  };
  const makeRow = (namespace, id, expiresAt, grant = null, uid = null) => ({
    namespace, id_hash: idHash(namespace, id), grant_hash: grant, uid_hash: uid,
    expires_at: expiresAt, consumed_at: null, key_id: keyId,
  });
  const revokeHash = (hash, at) => {
    // First free records, then reserve the permanent revocation marker. A failure
    // rolls back both steps. Tombstones are NEVER evicted to admit fresh grants.
    q.deleteGrant.run(hash);
    if (!revoked(hash)) {
      capacity(at);
      q.revoke.run(hash, at);
    }
  };
  const revokeGrant = (id) => transaction(() => revokeHash(grantHash(id), clock()));
  /**
   * Explicit provider lifecycle fence for every grant ID known to this database.
   * Includes never-presented tokens and orphaned grant-linked records. The write
   * transaction admits no concurrent insertion between discovery and revocation.
   * Each new tombstone replaces at least one record, so even a full store remains
   * within its row bound. Existing tombstones are retained unchanged.
   * Returns only the count of newly tombstoned distinct grant IDs.
   *
   * This cannot anticipate never-stored IDs. The caller MUST close/abort the old
   * provider and check its lifecycle after awaits before creating fresh IDs.
   * Explicit invocation is required on startup/shutdown; no import-time action.
   */
  const revokeAllGrants = () => transaction(() => {
    const at = clock();
    const hashes = q.grantHashes.all();
    let count = 0;
    for (const { grant_hash: hash } of hashes) {
      q.deleteGrant.run(hash);
      count += q.revoke.run(hash, at).changes;
    }
    return count;
  });
  const checkBinding = (payload, delegation) => {
    if (delegation && (payload.accountId !== delegation.subject || payload.clientId !== delegation.clientId)) failGrant();
  };

  class Adapter {
    constructor(model) {
      if (!MODELS.has(model)) throw new StorageError('UNSUPPORTED_MODEL', 'OIDC model is not enabled');
      Object.defineProperty(this, 'model', { value: model, enumerable: true });
    }
    async upsert(id, payload, expiresIn) {
      object(payload);
      const namespace = `oidc:${this.model}`;
      const at = clock();
      let expiresAt = expiry(expiresIn, at);
      if (payload.exp !== undefined) {
        integer(payload.exp, 1, Math.floor(Number.MAX_SAFE_INTEGER / 1000), 'payload expiration');
        expiresAt = Math.min(expiresAt, payload.exp * 1000);
        if (expiresAt <= at) failGrant();
      }
      if (payload.kind !== undefined && payload.kind !== this.model) throw new StorageError('MODEL_MISMATCH');
      if (payload.jti !== undefined && payload.jti !== id) throw new StorageError('ID_MISMATCH');
      let grant = null;
      if (this.model === 'Grant') grant = grantHash(id);
      // v9.12.2 indexes only grantable token artifacts. Interaction.grantId
      // is a resume annotation: account-switch logout revokes the old grant
      // before resuming/updating that Interaction. It confers no authority.
      else if (['AccessToken', 'AuthorizationCode'].includes(this.model) && payload.grantId !== undefined) {
        grant = grantHash(payload.grantId);
      }
      if (['AccessToken', 'AuthorizationCode'].includes(this.model) && grant === null) failGrant();
      const uid = this.model === 'Session' ? digest('session-uid', payload.uid) : null;
      const row = makeRow(namespace, id, expiresAt, grant, uid);
      transaction(() => {
        prune(at);
        if (revoked(grant)) failGrant();
        const previous = q.find.get(namespace, row.id_hash);
        if (previous) {
          const previousPayload = open(previous);
          if (['Grant', 'AccessToken', 'AuthorizationCode'].includes(this.model)
            && (previousPayload.accountId !== payload.accountId || previousPayload.clientId !== payload.clientId)) failGrant();
          if (previous.consumed_at !== null || this.model === 'ReplayDetection') failGrant();
          if (previous.grant_hash !== row.grant_hash) failGrant();
        } else capacity(at);
        if (grant !== null && ['Grant', 'AccessToken', 'AuthorizationCode'].includes(this.model)) {
          const delegationId = this.model === 'Grant' ? id : payload.grantId;
          checkBinding(payload, read('delegation', delegationId, at)?.payload);
        }
        const value = { ...payload };
        if (Object.hasOwn(value, 'consumed') && value.consumed !== undefined) {
          // Only consume() can set the authoritative one-use marker.
          if (value.consumed) failGrant();
          delete value.consumed;
        }
        write(row, value);
      });
    }
    async find(id) {
      return read(`oidc:${this.model}`, id)?.payload;
    }
    async findByUid(uid) {
      if (this.model !== 'Session') throw new StorageError('UNSUPPORTED_INDEX');
      const row = q.uid.get(digest('session-uid', uid));
      return usable(row, clock()) ? open(row) : undefined;
    }
    async findByUserCode() {
      // DeviceCode is deliberately excluded from the enabled model set.
      throw new StorageError('UNSUPPORTED_INDEX');
    }
    async consume(id) {
      if (this.model !== 'AuthorizationCode') throw new StorageError('NOT_CONSUMABLE');
      const namespace = `oidc:${this.model}`;
      const at = clock();
      const success = transaction(() => {
        const found = read(namespace, id, at);
        if (!found) return false;
        const { row, payload } = found;
        if (row.consumed_at !== null) {
          if (row.grant_hash) revokeHash(row.grant_hash, at);
          return false; // Commit replay revocation before throwing outside.
        }
        const consumedAt = Math.max(1, Math.floor(at / 1000));
        const encrypted = seal({ ...row, consumed_at: consumedAt }, { ...payload, consumed: consumedAt });
        const result = q.consume.run(consumedAt, encrypted.nonce, encrypted.ciphertext, encrypted.tag, namespace, row.id_hash, at);
        return result.changes === 1;
      });
      if (!success) failGrant();
    }
    async destroy(id) {
      if (this.model === 'Grant') return revokeGrant(id);
      transaction(() => { q.delete.run(`oidc:${this.model}`, idHash(`oidc:${this.model}`, id)); });
    }
    async revokeByGrantId(id) { revokeGrant(id); }
  }

  const stateNamespace = (name) => {
    if (!STATES.has(name)) throw new StorageError('UNSUPPORTED_NAMESPACE');
    return `state:${name}`;
  };
  const state = Object.freeze({
    put(name, id, payload, ttlSeconds) {
      const namespace = stateNamespace(name);
      const at = clock();
      integer(ttlSeconds, 1, name === 'account' ? maxTtlSeconds : Math.min(600, maxTtlSeconds), 'state TTL in seconds');
      const row = makeRow(namespace, id, expiry(ttlSeconds, at));
      transaction(() => {
        const previous = q.find.get(namespace, row.id_hash);
        if (previous) {
          open(previous);
          // Existing state is immutable; use get() to reuse the displayed form.
          throw new StorageError('STATE_EXISTS');
        }
        capacity(at);
        write(row, payload);
      });
    },
    get(name, id) {
      const found = read(stateNamespace(name), id);
      return found && found.row.consumed_at === null ? found.payload : undefined;
    },
    consume(name, id) {
      const namespace = stateNamespace(name);
      const at = clock();
      return transaction(() => {
        const found = read(namespace, id, at);
        if (!found || found.row.consumed_at !== null) return undefined;
        const consumedAt = Math.max(1, Math.floor(at / 1000));
        const encrypted = seal({ ...found.row, consumed_at: consumedAt }, found.payload);
        const result = q.consume.run(consumedAt, encrypted.nonce, encrypted.ciphertext, encrypted.tag, namespace, found.row.id_hash, at);
        return result.changes === 1 ? found.payload : undefined;
      });
    },
    destroy(name, id) {
      const namespace = stateNamespace(name);
      transaction(() => { q.delete.run(namespace, idHash(namespace, id)); });
    },
  });
  const delegationValue = (input, at) => {
    object(input);
    const allowed = new Set(['workspaceId', 'accountId', 'agentId', 'runId', 'token', 'expiresAt', 'subject', 'clientId', 'consentedAt']);
    if (Object.keys(input).some((name) => !allowed.has(name))) throw new TypeError('Unsupported delegation property');
    for (const name of ['accountId', 'agentId']) {
      if (!UUID.test(input[name])) throw new TypeError(`Invalid ${name} UUID`);
    }
    for (const name of ['workspaceId', 'runId']) {
      if (typeof input[name] !== 'string' || !OPAQUE_ID.test(input[name])) throw new TypeError(`Invalid ${name}`);
    }
    if (typeof input.token !== 'string' || !RELAY_TOKEN.test(input.token)) throw new TypeError('Invalid Relay worker token');
    const value = {
      workspaceId: input.workspaceId,
      accountId: input.accountId.toLowerCase(), agentId: input.agentId.toLowerCase(), runId: input.runId,
      token: input.token,
      expiresAt: integer(input.expiresAt, at + 1, at + maxTtlSeconds * 1000, 'delegation expiry'),
      subject: textId(input.subject, 'subject', 256), clientId: textId(input.clientId, 'clientId', 256),
      consentedAt: integer(input.consentedAt, Math.max(1, at - 900000), at, 'consent timestamp'),
      scope: 'browser:control', scopes: ['browser:control'],
    };
    return value;
  };
  const delegations = Object.freeze({
    /** Input MUST originate from a validated Relay login/context, never request IDs. */
    put(id, input) {
      const at = clock();
      const value = delegationValue(input, at);
      const hash = grantHash(id);
      const row = makeRow('delegation', id, value.expiresAt, hash);
      transaction(() => {
        prune(at);
        if (revoked(hash)) failGrant();
        const previous = read('delegation', id, at);
        if (previous) {
          if (serialize(previous.payload) !== serialize(value)) throw new StorageError('IMMUTABLE_DELEGATION');
          return;
        }
        const grant = read('oidc:Grant', id, at);
        if (grant) checkBinding(grant.payload, value);
        capacity(at);
        write(row, value);
      });
    },
    get(id) { return read('delegation', id)?.payload; },
    destroy(id) { revokeGrant(id); },
  });
  return Object.freeze({ Adapter, state, delegations, revokeAllGrants, pruneExpired: () => transaction(() => prune(clock())) });
}

import {createRelayAccountLinking} from './provider.mjs';
import {createLoopbackTLSEntry} from './tls-entry.mjs';
import {createRelayProductionHost} from '../production/host.mjs';

/** Complete source composition, deliberately without a CLI, environment-secret
 * loader, DB creation/migration, key generation, browser login, or public bind.
 * All values must come from one reviewed administrator-owned runtime module.
 * Importing/constructing cannot expose a socket; listen() is separate.
 */
export async function createLinkedRelayService(options = {}) {
  const names = ['origin', 'selected', 'client', 'store', 'jwks', 'cookieKeys', 'tls', 'profileRoot', 'port'];
  if (!options || Object.getPrototypeOf(options) !== Object.prototype || Object.keys(options).some(key => !names.includes(key))) {
    throw new TypeError('Explicit linked-service configuration is required.');
  }
  const accountLinking = createRelayAccountLinking({origin: options.origin, selected: options.selected, client: options.client,
    store: options.store, jwks: options.jwks, cookieKeys: options.cookieKeys});
  let application;
  try {
    application = await createRelayProductionHost({origin: options.origin, issuers: [options.origin],
      profileRoot: options.profileRoot, hooks: accountLinking.hooks});
    return createLoopbackTLSEntry({origin: options.origin, accountLinking, application,
      tls: options.tls, ...(options.port === undefined ? {} : {port: options.port})});
  } catch (error) {
    await Promise.allSettled([accountLinking.close(), application?.close()]);
    throw error;
  }
}

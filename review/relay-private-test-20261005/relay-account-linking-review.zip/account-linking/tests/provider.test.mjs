import test from 'node:test';
import assert from 'node:assert/strict';
import {request as httpsRequest} from 'node:https';
import {generateKeyPairSync, randomBytes, createHash} from 'node:crypto';
import {mkdtemp, readFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {DatabaseSync} from 'node:sqlite';
import {errors} from 'oidc-provider';
import {createEncryptedStore, initializeStorage} from '../storage.mjs';
import {createRelayAccountLinking} from '../provider.mjs';
import {createLoopbackTLSEntry} from '../tls-entry.mjs';
import {createRelayProductionHost} from '../../production/host.mjs';

const selected = {workspaceId: 'test-studio', accountId: '11111111-1111-4111-8111-111111111111', agentId: '22222222-2222-4222-8222-222222222222'};
const token = 'a'.repeat(64), runId = 'test-run';
const client = {id: 'test-client', name: 'Fixture ChatGPT client', redirectUri: 'https://client.example.invalid/callback'};
// Test-only TLS certificate and encryption/signing keys. Never copied to a
// deployable configuration/artifact; all fixtures are deleted after the suite.
let tlsDir, tls;
test.before(async () => {
  tlsDir = await mkdtemp(join(tmpdir(), 'relay-link-tls-test-'));
  execFileSync('openssl', ['req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:P-256', '-nodes',
    '-keyout', join(tlsDir, 'key.pem'), '-out', join(tlsDir, 'cert.pem'), '-days', '1', '-subj', '/CN=localhost',
    '-addext', 'subjectAltName=DNS:localhost'], {stdio: 'ignore'});
  tls = {key: await readFile(join(tlsDir, 'key.pem')), cert: await readFile(join(tlsDir, 'cert.pem'))};
});
test.after(async () => {await rm(tlsDir, {recursive: true, force: true});});

async function fixture(t, {fullHost = false} = {}) {
  const db = new DatabaseSync(':memory:'); initializeStorage(db);
  const store = createEncryptedStore({db, key: randomBytes(32), keyId: 'test-only', invalidGrant: () => new errors.InvalidGrant()});
  let service;
  const origin = 'https://localhost';
  const {privateKey} = generateKeyPairSync('ec', {namedCurve: 'P-256'});
  const jwk = {...privateKey.export({format: 'jwk'}), kid: 'test-only', alg: 'ES256'};
  const backend = {valid: true, checks: 0, logins: 0, pause: null};
  const relayClient = {selected,
    login: async ({username, password}) => {
      backend.logins++; assert.equal(username, 'dot-fixture'); assert.equal(password, 'test-only-password');
      if (!backend.valid) throw new Error('fixture-denied');
      return {...selected, runId, token, expiresAt: Date.now() + 24 * 3600_000};
    },
    check: async value => {backend.checks++; if (backend.pause) await backend.pause(); if (!backend.valid || value.token !== token || value.accountId !== selected.accountId || value.runId !== runId) throw new Error('fixture-denied'); return value;}
  };
  service = createRelayAccountLinking({origin, selected, client, store, jwks: {keys: [jwk]}, cookieKeys: ['t'.repeat(64)], relayClient, pollIntervalMs: 1000});
  const revoked = [], unavailable = [];
  let stop, application, profile;
  if (fullHost) {
    profile = await mkdtemp(join(tmpdir(), 'relay-linked-host-test-'));
    application = await createRelayProductionHost({origin, issuers: [origin], profileRoot: profile, hooks: service.hooks});
    stop = () => application.close();
  } else {
    stop = await service.hooks.subscribeRevocations(async ctx => {revoked.push(ctx); return {closed: true};}, {onUnavailable: () => unavailable.push(true)});
    application = {fetch: async () => new Response('Unavailable', {status: 404}), close: async () => {}};
  }
  const entry = createLoopbackTLSEntry({origin, accountLinking: service, application, tls, port: 0});
  const {port} = await entry.listen();
  t.after(async () => {await entry.close(); await stop(); db.close(); if (profile) await rm(profile, {recursive: true, force: true});});
  const jar = new Map();
  async function request(path, {method = 'GET', data, json, headers = {}, cookies = true} = {}) {
    if (path.startsWith(origin)) path = path.slice(origin.length);
    const body = json ? JSON.stringify(json) : data ? new URLSearchParams(data).toString() : undefined;
    return new Promise((resolve, reject) => {
      const req = httpsRequest({host: '127.0.0.1', port, servername: 'localhost', ca: tls.cert, method, path,
        headers: {host: 'localhost', ...(cookies && jar.size ? {cookie: [...jar].map(([k, v]) => `${k}=${v}`).join('; ')} : {}),
          ...(body ? {'content-type': json ? 'application/json' : 'application/x-www-form-urlencoded', 'content-length': Buffer.byteLength(body)} : {}), ...headers}}, res => {
        for (const cookie of res.headers['set-cookie'] || []) {const entry = cookie.split(';')[0], at = entry.indexOf('='); jar.set(entry.slice(0, at), entry.slice(at + 1));}
        const parts = []; res.on('data', x => parts.push(x)); res.on('end', () => resolve({status: res.statusCode, headers: res.headers, body: Buffer.concat(parts).toString('utf8')}));
      }); req.on('error', reject); req.end(body);
    });
  }
  const verifier = 'v'.repeat(43), challenge = createHash('sha256').update(verifier).digest('base64url');
  function authPath(overrides = {}) {return '/auth?' + new URLSearchParams({client_id: client.id, redirect_uri: client.redirectUri,
    response_type: 'code', scope: 'browser:control', resource: `${origin}/mcp`, code_challenge: challenge, code_challenge_method: 'S256', state: 'test-state', ...overrides});}
  function csrf(result) {const match = /name="csrf" value="([^"]+)"/.exec(result.body); assert.ok(match, result.body); return match[1];}
  async function start(overrides) {
    const auth = await request(authPath(overrides)); assert.equal(auth.status, 303, auth.body);
    const path = auth.headers.location, login = await request(path); assert.equal(login.status, 200, login.body);
    return {path, login};
  }
  async function authorize(overrides) {
    const {path, login} = await start(overrides);
    const signed = await request(path, {method: 'POST', headers: {origin}, data: {action: 'login', csrf: csrf(login), username: 'dot-fixture', password: 'test-only-password'}});
    assert.equal(signed.status, 303, signed.body);
    let resumed = await request(signed.headers.location);
    if (resumed.status === 200 && resumed.body.includes('/session/end/confirm')) {
      assert.match(resumed.headers['content-security-policy'], /script-src[^;]*'sha256-/);
      const xsrf = /name="xsrf" value="([^"]+)"/.exec(resumed.body)?.[1]; assert.ok(xsrf);
      const switched = await request('/session/end/confirm', {method: 'POST', headers: {origin}, data: {xsrf, logout: 'yes'}});
      assert.equal(switched.status, 303, switched.body); resumed = await request(switched.headers.location);
    }
    assert.equal(resumed.status, 303, resumed.body);
    const consentPath = resumed.headers.location, consent = await request(consentPath); assert.equal(consent.status, 200, consent.body);
    assert.match(consent.body, /Permission: browser:control/); assert.doesNotMatch(consent.body, new RegExp(token));
    const accepted = await request(consentPath, {method: 'POST', headers: {origin}, data: {action: 'consent', csrf: csrf(consent), approve: 'browser:control'}});
    assert.equal(accepted.status, 303, accepted.body);
    const finished = await request(accepted.headers.location); assert.equal(finished.status, 303, finished.body);
    const callback = new URL(finished.headers.location); assert.equal(callback.origin + callback.pathname, client.redirectUri);
    assert.equal(callback.searchParams.get('iss'), origin);
    assert.equal(callback.searchParams.get('state'), 'test-state'); assert.ok(callback.searchParams.get('code'), finished.headers.location);
    return callback.searchParams.get('code');
  }
  async function exchange(code, overrides = {}) {
    return request('/token', {method: 'POST', cookies: false, data: {grant_type: 'authorization_code', client_id: client.id,
      code, redirect_uri: client.redirectUri, code_verifier: verifier, resource: `${origin}/mcp`, ...overrides}});
  }
  return {service, request, start, csrf, authorize, exchange, authPath, origin, backend, revoked, unavailable, store, stop, db, entry};
}

test('real oidc-provider discovery and complete TLS login/consent/PKCE exchange', async t => {
  const f = await fixture(t);
  const discovery = JSON.parse((await f.request('/.well-known/oauth-authorization-server')).body);
  assert.equal(discovery.issuer, f.origin); assert.deepEqual(discovery.code_challenge_methods_supported, ['S256']);
  assert.deepEqual(discovery.scopes_supported, ['browser:control', 'openid']);
  assert.deepEqual(discovery.token_endpoint_auth_methods_supported, ['none']);
  assert.equal(discovery.authorization_response_iss_parameter_supported, true);
  assert.deepEqual(discovery.grant_types_supported, ['authorization_code']); assert.equal(discovery.registration_endpoint, undefined);
  const code = await f.authorize(), result = await f.exchange(code); assert.equal(result.status, 200, result.body);
  const access = JSON.parse(result.body); assert.equal(access.scope, 'browser:control'); assert.equal(access.refresh_token, undefined);
  assert.ok(access.expires_in > 0 && access.expires_in <= 900);
  const identity = await f.service.hooks.verifyAccessToken(access.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]});
  assert.equal(identity.claims.scope, 'browser:control'); assert.ok(Object.isFrozen(identity.requestContext));
  assert.equal((await f.service.hooks.verifyAccessToken(access.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]})).requestContext, identity.requestContext);
  const reference = await f.service.hooks.resolveHostReference({requestContext: identity.requestContext, scopes: ['browser:control']});
  const binding = await f.service.hooks.resolveBinding(reference);
  assert.deepEqual(binding, {...selected, runId});
  const session = await f.service.hooks.resolveWorkerSession(binding); assert.equal(session.token, token); assert.equal(session.role, 'worker');
  assert.equal(await f.service.hooks.authorizeAction({name: 'browser_open', arguments: {}, binding}, reference), true);
  assert.equal(await f.service.hooks.authorizeAction({name: 'browser_fill', arguments: {}, binding}, reference), false);
  assert.equal(await f.service.hooks.authorizeAction({name: 'relay_fast_send', arguments: {}, binding}, reference), false);
  assert.ok(f.backend.checks > 8);
});
test('wrong PKCE verifier cannot exchange the authorization code', async t => {
  const f = await fixture(t), code = await f.authorize();
  const result = await f.exchange(code, {code_verifier: 'x'.repeat(43)}); assert.equal(result.status, 400); assert.equal(JSON.parse(result.body).error, 'invalid_grant');
});
test('advertised optional openid produces only a pseudonymous sign-in and browser-only resource token', async t => {
  const f = await fixture(t), code = await f.authorize({scope: 'openid browser:control'});
  const result = await f.exchange(code); assert.equal(result.status, 200, result.body);
  const tokens = JSON.parse(result.body); assert.equal(tokens.scope, 'browser:control'); assert.ok(tokens.id_token);
  const id = JSON.parse(Buffer.from(tokens.id_token.split('.')[1], 'base64url').toString());
  assert.equal(id.iss, f.origin); assert.equal(id.aud, client.id);
  assert.notEqual(id.sub, selected.accountId); assert.equal(id.email, undefined); assert.equal(id.name, undefined);
  await assert.rejects(f.service.hooks.verifyAccessToken(tokens.id_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]}));
});
test('unregistered redirects and resource, extra scopes and missing PKCE do not issue a code', async t => {
  const f = await fixture(t);
  for (const changes of [{redirect_uri: 'https://evil.example.invalid/callback'}, {resource: 'https://evil.example.invalid/mcp'},
    {scope: 'browser:control relay:write'}, {code_challenge: '', code_challenge_method: ''}, {response_mode: 'form_post'}, {response_mode: 'fragment'}]) {
    const result = await f.request(f.authPath(changes));
    assert.ok(result.status >= 400 || !result.headers.location?.includes('/interaction/'), JSON.stringify(result));
  }
});
test('login CSRF, replay, cross-origin and unknown role fields deny before backend login', async t => {
  const f = await fixture(t), {path, login} = await f.start();
  const valid = {action: 'login', csrf: f.csrf(login), username: 'dot-fixture', password: 'test-only-password'};
  for (const [headers, data] of [[{origin: 'https://evil.example.invalid'}, valid], [{origin: f.origin}, {...valid, csrf: 'x'.repeat(43)}],
    [{origin: f.origin}, {...valid, role: 'manager'}], [{origin: f.origin}, valid]]) {
    const result = await f.request(path, {method: 'POST', headers, data}); assert.ok([400, 403].includes(result.status), result.body);
  }
  assert.equal(f.backend.logins, 0);
});
test('revocation immediately rejects requests and polling closes an idle context', async t => {
  const f = await fixture(t), code = await f.authorize(), access = JSON.parse((await f.exchange(code)).body);
  const identity = await f.service.hooks.verifyAccessToken(access.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]});
  f.backend.valid = false;
  await new Promise(resolve => setTimeout(resolve, 1200));
  assert.ok(f.revoked.includes(identity.requestContext));
  await assert.rejects(f.service.hooks.verifyAccessToken(access.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]}));
});
test('provider revocation endpoint retires a token grant', async t => {
  const f = await fixture(t), code = await f.authorize(), access = JSON.parse((await f.exchange(code)).body);
  await f.service.hooks.verifyAccessToken(access.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]});
  const result = await f.request('/token/revocation', {method: 'POST', cookies: false, data: {client_id: client.id, token: access.access_token}});
  assert.equal(result.status, 200, result.body);
  await assert.rejects(f.service.hooks.verifyAccessToken(access.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]}));
});
test('explicit reconnect in the same browser uses provider confirmation and retires old authority', async t => {
  const f = await fixture(t), firstCode = await f.authorize(), first = JSON.parse((await f.exchange(firstCode)).body);
  const oldIdentity = await f.service.hooks.verifyAccessToken(first.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]});
  const secondCode = await f.authorize(), second = JSON.parse((await f.exchange(secondCode)).body);
  assert.ok(second.access_token); assert.notEqual(first.access_token, second.access_token);
  await assert.rejects(f.service.hooks.verifyAccessToken(first.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]}));
  const current = await f.service.hooks.verifyAccessToken(second.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]});
  const reference = await f.service.hooks.resolveHostReference({requestContext: current.requestContext, scopes: ['browser:control']});
  assert.equal((await f.service.hooks.resolveWorkerSession(await f.service.hooks.resolveBinding(reference))).token, token);
  assert.ok(f.revoked.includes(oldIdentity.requestContext));
});
test('introspection checks live Relay status even without a prior MCP request', async t => {
  const f = await fixture(t), code = await f.authorize(), access = JSON.parse((await f.exchange(code)).body);
  f.backend.valid = false;
  const result = await f.request('/token/introspection', {method: 'POST', cookies: false, data: {client_id: client.id, token: access.access_token}});
  assert.equal(result.status, 200); assert.equal(JSON.parse(result.body).active, false);
});
test('unsubscribe followed by close destroys durable grants and is idempotent', async t => {
  const f = await fixture(t), code = await f.authorize(), access = JSON.parse((await f.exchange(code)).body);
  const payload = await new f.store.Adapter('AccessToken').find(access.access_token);
  await f.stop(); await f.service.close();
  assert.equal(await new f.store.Adapter('AccessToken').find(access.access_token), undefined);
  assert.equal(f.store.delegations.get(payload.grantId), undefined);
  assert.ok(f.db.prepare('SELECT COUNT(*) AS n FROM relay_link_revoked_grants').get().n > 0);
});
test('closing during token exchange denies late issuance and drains the request', async t => {
  const f = await fixture(t), code = await f.authorize();
  let release, started; const waiting = new Promise(resolve => {started = resolve;});
  f.backend.pause = () => new Promise(resolve => {release = resolve; started();});
  const response = f.exchange(code); await waiting;
  f.backend.pause = null; const close = f.service.close(); release(); await close;
  const result = await response; assert.notEqual(result.status, 200); assert.equal(JSON.parse(result.body).access_token, undefined);
  assert.equal(f.db.prepare("SELECT COUNT(*) AS n FROM relay_link_records WHERE namespace='oidc:AccessToken'").get().n, 0);
});
test('concurrent exchange never succeeds twice and replay retires the grant', async t => {
  const f = await fixture(t), code = await f.authorize();
  const results = await Promise.all([f.exchange(code), f.exchange(code)]);
  assert.ok(results.filter(result => result.status === 200).length <= 1);
  const success = results.find(result => result.status === 200);
  if (success) await assert.rejects(f.service.hooks.verifyAccessToken(JSON.parse(success.body).access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]}));
});
test('durable delegation revoked during a Relay check cannot return a stale authorization', async t => {
  const f = await fixture(t), code = await f.authorize(), access = JSON.parse((await f.exchange(code)).body);
  const payload = await new f.store.Adapter('AccessToken').find(access.access_token);
  let release, started; const waiting = new Promise(resolve => {started = resolve;});
  f.backend.pause = () => new Promise(resolve => {release = resolve; started();});
  const checking = f.service.hooks.verifyAccessToken(access.access_token, {resource: `${f.origin}/mcp`, issuers: [f.origin]});
  await waiting; f.store.delegations.destroy(payload.grantId); f.backend.pause = null; release();
  await assert.rejects(checking);
});
test('separately rendered forms cannot submit one login interaction twice', async t => {
  const f = await fixture(t), {path, login} = await f.start(), other = await f.request(path);
  const bodies = [login, other].map(result => ({action: 'login', csrf: f.csrf(result), username: 'dot-fixture', password: 'test-only-password'}));
  const results = await Promise.all(bodies.map(data => f.request(path, {method: 'POST', headers: {origin: f.origin}, data})));
  assert.equal(results.filter(result => result.status === 303).length, 1); assert.equal(f.backend.logins, 1);
});
test('TLS entry rejects untrusted authority, forwarding, oversized forms and MCP cookies/query', async t => {
  const f = await fixture(t);
  assert.equal((await f.request('/auth', {headers: {host: 'evil.example.invalid'}})).status, 403);
  assert.equal((await f.request('/auth', {headers: {'x-forwarded-host': 'localhost'}})).status, 400);
  assert.equal((await f.request('/auth', {method: 'POST', data: {padding: 'x'.repeat(17000)}})).status, 413);
  assert.equal((await f.request('/mcp?token=bad', {cookies: false})).status, 400);
  assert.equal((await f.request('/mcp', {headers: {cookie: 'untrusted=x'}})).status, 400);
  assert.equal((await f.request('/session/end/confirm', {method: 'POST', data: {xsrf: 'bad', logout: 'yes'}})).status, 400);
});
test('real provider TLS dispatcher to production OAuth host exposes only five browser tools', async t => {
  const f = await fixture(t, {fullHost: true});
  const metadata = await f.request('/.well-known/oauth-protected-resource/mcp', {cookies: false});
  assert.equal(metadata.status, 200); assert.deepEqual(JSON.parse(metadata.body).scopes_supported, ['browser:control']);
  const code = await f.authorize(), access = JSON.parse((await f.exchange(code)).body);
  const response = await f.request('/mcp', {method: 'POST', cookies: false,
    headers: {authorization: `Bearer ${access.access_token}`, accept: 'application/json, text/event-stream'},
    json: {jsonrpc: '2.0', id: 1, method: 'tools/list', params: {}}});
  assert.equal(response.status, 200, response.body);
  const result = JSON.parse(response.body.startsWith('event:') ? response.body.split('\n').find(line => line.startsWith('data:')).slice(5).trim() : response.body);
  assert.deepEqual(result.result.tools.map(tool => tool.name).sort(), ['browser_click', 'browser_close', 'browser_observe', 'browser_open', 'browser_screenshot']);
  f.backend.valid = false;
  const denied = await f.request('/mcp', {method: 'POST', cookies: false,
    headers: {authorization: `Bearer ${access.access_token}`, accept: 'application/json, text/event-stream'},
    json: {jsonrpc: '2.0', id: 2, method: 'tools/list', params: {}}});
  assert.equal(denied.status, 401);
});

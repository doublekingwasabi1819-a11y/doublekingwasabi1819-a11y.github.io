# Relay account-linking validation — 2026-10-05 UTC

Status: source prepared and functionally tested locally. No live configuration,
worker login, key/client creation, database migration, server install, push,
deployment, DNS/firewall change or public access was performed.

- Node 24.19.0. Locked `npm ci --ignore-scripts --no-audit --no-fund` succeeded.
- Account-linking: 57 tests, 57 passed, zero skipped/failed.
- Existing production foundation: 28 tests, 28 passed.
- Pinned controller baseline: 244 tests, 242 passed, 2 Chromium tests skipped
  because the pinned browser is absent. This is NOT a full browser pass.
- All 34 entries in the original controller SHA256 manifest pass unchanged.
- Syntax checks passed for provider, Relay session, encrypted storage, TLS
  dispatcher and composition modules.
- Official npm audit reported zero known vulnerabilities for the locked tree.

Functional tests include actual TLS, actual oidc-provider discovery and protocol,
worker login/consent with a synthetic Relay backend, S256, strict callback/resource,
optional advertised openid with only a pseudonymous ID token, browser-only access
tokens, CSRF/replay, concurrent code exchange, same-browser reconnect, live
revocation/expiry checks, shutdown races and actual production-host tool discovery.
SQLite tests include file-backed persistence and independent-connection races.
No real worker browser was launched; no real ChatGPT account-link was tested.

Independent final review is incomplete following an automated security review
block. Earlier reported lifecycle/authorization issues were corrected and covered
by regression tests. The final TLS dispatcher/composition and later fixes still
require an approved final review. This package is not cleared for public deployment.

## Applying the source

Apply the prior production-host foundation first, beside the repository's pinned
controller directory. This package's patch adds only account-linking/. It does not
change production/, controller/, the root web app, or existing checksum manifests.
The original production HTTP CLI/proxy cannot serve OAuth cookies and callbacks;
use the new TLS composition after the runtime/bootstrap/proxy have been reviewed.

Read account-linking/README.md for runtime contracts, single-process storage
limits, 15-minute re-consent limitation, poll revocation latency, exact remaining
approvals and live validation gates. No filled-in credential configuration or
activation command is included.

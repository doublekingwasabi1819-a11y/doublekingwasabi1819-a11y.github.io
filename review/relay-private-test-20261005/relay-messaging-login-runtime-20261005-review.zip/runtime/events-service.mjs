import {AsyncLocalStorage} from 'node:async_hooks';
import {RelayEvents, RelayError} from '../relay-events/core.mjs';
import {createDispatcher, tools as workTools} from '../relay-events/mcp.mjs';
import {createWebhookTransport} from '../relay-events/transport.mjs';
import {createAuthenticatedRelaySource} from '../relay-events/authenticated-source-adapter.mjs';
import {createMessageAccess, messageTools} from '../relay-events/message-access.mjs';
import {createRelayMessageCapability, relayMessageToolDescriptors} from '../relay-events/send-capability.mjs';
import {messageSourceId} from '../relay-events/message-shapes.mjs';
import {createManagerReceiptReader, createManagerReceiptRoute} from '../receipt-ui/event-host/manager-receipts.mjs';
import {createLoopbackEntry} from '../production/http-entry.mjs';
import {canonicalOrigin} from '../production/host.mjs';

const plain = value => value && Object.getPrototypeOf(value) === Object.prototype;
const consentId = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const same = (a, b) => ['workspaceId', 'accountId', 'agentId', 'runId'].every(k => a?.[k] === b?.[k]);
const denied = () => {throw new RelayError(-32001, 'A separately authorized messaging connection is required.');};
const requiredHooks = ['authenticate', 'authorizeContinuing', 'withAuthorizedRelay', 'authorizeRead', 'authorizeRelay', 'resolveIngestionContext'];
const scopesFor = action => ['relay:work', ...(['pause', 'execute'].includes(action) ? [] : action === 'send' ? ['relay:write'] : action === 'reply' || action === 'ingest' ? ['relay:read', 'relay:write'] : ['relay:read'])];
const response = (status, body, extra = {}) => new Response(JSON.stringify(body), {status, headers: {'content-type':'application/json', 'cache-control':'no-store', ...extra}});
const metadata = tool => {const action = tool.name === 'relay_message_send' ? 'send' : tool.name === 'relay_message_reply' ? 'reply' : tool.name === 'relay_work_pause' ? 'pause' : tool.name === 'relay_work_transition' ? 'execute' : 'read'; const schemes = [{type:'oauth2', scopes:scopesFor(action)}]; return {...structuredClone(tool), securitySchemes:schemes, _meta:{securitySchemes:schemes}};};

/** Separate modern-events resource. Does not reuse provider browser credentials,
 * modify the five-tool browser registry or install the old ten-tool patch.
 * Runtime composition supplies the concrete same-issuer provider hooks.
 * Only direct low-level use permits an independently supplied implementation.
 * Stores are caller-owned and are never created/migrated by this factory.
 */
export function validateEventsConfiguration(options = {}, {requireHooks = true} = {}) {
  const names = ['enabled','origin','issuers','port','binding','store','allowedCallbackHosts','transport','hooks','messageRead','messageSend','ingestion','receipts','intervalMs'];
  if (!plain(options) || options.enabled !== true || Object.keys(options).some(k => !names.includes(k)) ||
      ![options.messageRead, options.messageSend, options.ingestion].every(v => typeof v === 'boolean') ||
      options.ingestion && !options.messageRead || options.messageSend && !options.messageRead) throw new TypeError('Explicit event/message opt-ins are required.');
  const origin = canonicalOrigin(options.origin), resource = `${origin}/mcp`, binding = Object.freeze({...options.binding});
  if ((requireHooks ? !plain(options.hooks) || requiredHooks.some(k => typeof options.hooks[k] !== 'function') || Object.keys(options.hooks).some(k => !requiredHooks.includes(k)) : Object.hasOwn(options, 'hooks')) ||
      !options.store || !['read','write','close'].every(k => typeof options.store[k] === 'function')) throw new TypeError('Existing store and verified message authority hooks are required.');
  if (!Array.isArray(options.allowedCallbackHosts) || !options.allowedCallbackHosts.length) throw new TypeError('An explicit callback host allowlist is required.');
  if (!plain(options.binding) || Object.keys(options.binding).sort().join(',') !== 'accountId,agentId,runId,workspaceId' ||
      !['workspaceId','runId'].every(k => typeof binding[k] === 'string' && /^[A-Za-z0-9._:-]{1,128}$/.test(binding[k])) ||
      !['accountId','agentId'].every(k => typeof binding[k] === 'string' && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(binding[k]))) throw new TypeError('An exact selected worker/run binding is required.');
  if (options.port !== undefined && (!Number.isSafeInteger(options.port) || options.port < 0 || options.port > 65535)) throw new TypeError('A loopback events port is required.');
  const intervalMs = options.intervalMs ?? 15000;
  if (!Number.isSafeInteger(intervalMs) || intervalMs < 1000 || intervalMs > 60000) throw new TypeError('A bounded polling interval is required.');
  if (!Array.isArray(options.issuers) || !options.issuers.length || options.issuers.some(v => typeof v !== 'string')) throw new TypeError('Explicit messaging authorization issuers are required.');
  const issuers = Object.freeze(options.issuers.map(canonicalOrigin));
  const receipts = options.receipts;
  if (receipts !== undefined && (!plain(receipts) || receipts.enabled !== true || !options.messageRead ||
      ['authenticateManager','authorizeManager','readMetadata','authorizeAudit','sourcePolicy'].some(k => typeof receipts[k] !== 'function') ||
      Object.keys(receipts).some(k => !['enabled','authenticateManager','authorizeManager','readMetadata','authorizeAudit','sourcePolicy'].includes(k)))) throw new TypeError('Separate manager receipt authority is required.');
  if (options.transport !== undefined && typeof options.transport !== 'function') throw new TypeError('An explicit approved callback transport is required.');
  // Validate callback policy before runtime constructs an authority that owns grants.
  createWebhookTransport({allowedHosts: [...options.allowedCallbackHosts]});
  return {origin, resource, binding, intervalMs, issuers, receipts};
}
export function createEventsService(options = {}) {
  const {origin, resource, binding, intervalMs, issuers, receipts} = validateEventsConfiguration(options);
  const hooks = Object.freeze(Object.fromEntries(requiredHooks.map(k => [k, options.hooks[k].bind(options.hooks)])));
  const challenge = (scopes, error) => `Bearer resource_metadata="${origin}/.well-known/oauth-protected-resource/mcp", scope="${scopes.join(' ')}"${error ? `, error="${error}"` : ''}`;
  const manager = receipts && Object.freeze(Object.fromEntries(Object.entries(receipts).map(([k,v]) => [k, typeof v === 'function' ? v.bind(receipts) : v])));
  let closed = false, failed = false, timer, cycle, closing, finish;
  const completion = new Promise(resolve => {finish = resolve;});
  const shutdown = new AbortController();
  const authorization = new AsyncLocalStorage();
  const pending = new Set();
  const track = operation => {const p = Promise.resolve().then(operation); pending.add(p); p.finally(() => pending.delete(p)).catch(() => {}); return p;};
  const active = signal => {if (closed || signal?.aborted) denied();};
  const transport = options.transport ?? createWebhookTransport({allowedHosts:[...options.allowedCallbackHosts]});
  if (typeof transport !== 'function') throw new TypeError('An explicit approved callback transport is required.');
  const engine = new RelayEvents({store:options.store, transport: request => {active(); return transport(request);}, authorize: async query => {
    active();
    if (query.principal !== binding.accountId || query.agent_id !== binding.agentId) return false;
    if (!['read','subscribe','enqueue','pause','execute','discover'].includes(query.action)) return false;
    const context = authorization.getStore();
    // Request and ingestion operations retain their original grant across all
    // asynchronous queue locks. A newer grant for this worker is not a fallback.
    if (!context && ['enqueue','pause','execute'].includes(query.action)) return false;
    if (context && query.consentId !== undefined && query.consentId !== context.consentId) return false;
    const scopes = scopesFor(query.action === 'enqueue' ? 'ingest' : query.action);
    const checkContext = async () => {
      active(context?.signal);
      const verified = await hooks.authorizeRelay(context,{scopes,binding,action:query.action});
      if (!same(verified?.binding,binding) || !scopes.every(scope => verified?.scopes?.includes(scope))) denied();
      active(context.signal);
    };
    if (context) await checkContext();
    const allowed = await hooks.authorizeContinuing({...query, ...(context ? {consentId:context.consentId} : {}), binding, signal:context?.signal ?? shutdown.signal});
    active(context?.signal);
    if (context && allowed === true) await checkContext();
    return allowed === true;
  }});
  const source = createAuthenticatedRelaySource({binding, withAuthorizedRelay: async (...args) => {active(args[0]?.signal); const r = await hooks.withAuthorizedRelay(...args); active(args[0]?.signal); return r;}});
  const access = createMessageAccess({enabled:options.messageRead, engine, sourcePolicy: q => manager && q.principal !== binding.accountId ? manager.sourcePolicy(q) : source.sourcePolicy(q.context), readMessage:source.readMessage,
    authorizeRead:hooks.authorizeRead, ...(manager ? {authorizeAudit:manager.authorizeAudit} : {})});
  const sender = createRelayMessageCapability({enabled:options.messageSend, binding, authorizeRelay:hooks.authorizeRelay, sourcePolicy:source.sourcePolicy, callSource:source.callSource});
  const reader = manager && createManagerReceiptReader({enabled:true, engine, messageAccess:access, workspaceId:binding.workspaceId, authorizeManager:manager.authorizeManager, readMetadata:manager.readMetadata});
  const receiptRoute = manager && createManagerReceiptRoute({enabled:true, path:'/manager-receipts', allowedOrigins:[origin], authenticateManager:manager.authenticateManager, readReceipt:reader});
  const descriptors = [...workTools, ...(access ? messageTools : []), ...sender.tools].map(metadata);
  const dispatch = createDispatcher(engine);
  async function authenticate(request, signal) {
    active(signal);
    const identity = await hooks.authenticate(request, {resource, issuers, signal}); active(signal);
    if (!plain(identity) || identity.principalId !== binding.accountId || !same(identity.binding, binding) ||
        !identity.reference || !consentId(identity.consentId) || !Array.isArray(identity.scopes) || identity.scopes.some(s => typeof s !== 'string') ||
        !Number.isSafeInteger(identity.expiresAt) || identity.expiresAt <= Date.now()) denied();
    return Object.freeze({principalId:identity.principalId, binding, reference:identity.reference, consentId:identity.consentId, scopes:Object.freeze([...identity.scopes]), expiresAt:identity.expiresAt, signal});
  }
  async function fetch(request) {
    if (closed) return response(503,{error:'Unavailable'});
    const url = new URL(request.url);
    if (url.origin !== origin || url.search || url.hash || request.headers.has('cookie')) return response(400,{error:'Invalid request'});
    if (url.pathname === '/.well-known/oauth-protected-resource/mcp' && request.method === 'GET') return response(200,{resource,authorization_servers:[...issuers],scopes_supported:['relay:work','relay:read','relay:write'],bearer_methods_supported:['header']});
    if (url.pathname === '/manager-receipts') return receiptRoute ? track(() => receiptRoute(request)) : response(404,{error:'Unavailable'});
    if (url.pathname !== '/mcp' || request.method !== 'POST') return response(404,{error:'Unavailable'});
    if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get('content-type') ?? '')) return response(415,{error:'JSON required'});
    return track(async () => {
      const signal = AbortSignal.any([shutdown.signal, request.signal, AbortSignal.timeout(30000)]);
      let context;
      try {context = await authenticate(request, signal);} catch {return response(401,{error:'Unauthorized'},{'www-authenticate':challenge(['relay:work','relay:read','relay:write'],request.headers.has('authorization') ? 'invalid_token' : undefined)});}
      let rpc;
      try {const body = await request.text(); if (Buffer.byteLength(body) > 65536) return response(413,{error:'Too large'}); rpc = JSON.parse(body);} catch {return response(400,{error:'Invalid JSON'});}
      const id = rpc?.id ?? null;
      const failure = (code, message) => response(200,{jsonrpc:'2.0', id, error:{code, message}});
      if (!plain(rpc) || rpc.jsonrpc !== '2.0' || !['string','number'].includes(typeof rpc.id) || typeof rpc.method !== 'string') return failure(-32600,'Invalid request');
      return authorization.run(context, async () => {try {
        if (rpc.method !== 'server/discover' && request.headers.get('mcp-protocol-version') !== '2026-07-28') return failure(-32601,'MCP Events requires protocol 2026-07-28');
        let action = 'read', descriptor;
        if (rpc.method === 'tools/call') {
          descriptor = descriptors.find(t => t.name === rpc.params?.name);
          if (!descriptor) return failure(-32601,'Tool unavailable');
          action = descriptor.name === 'relay_message_send' ? 'send' : descriptor.name === 'relay_message_reply' ? 'reply' : descriptor.name === 'relay_work_pause' ? 'pause' : descriptor.name === 'relay_work_transition' ? 'execute' : 'read';
          const args = rpc.params.arguments;
          if (!plain(args) || Object.keys(args).some(k => !Object.hasOwn(descriptor.inputSchema.properties,k)) || descriptor.inputSchema.required.some(k => !Object.hasOwn(args,k))) return failure(-32602,'Invalid tool arguments');
        } else if (['events/subscribe','events/unsubscribe'].includes(rpc.method)) action = 'subscribe';
        if (!scopesFor(action).every(scope => context.scopes.includes(scope))) return response(403,
          {jsonrpc:'2.0',id,error:{code:-32001,message:'Additional messaging permission is required.'}},
          {'www-authenticate':challenge(scopesFor(action),'insufficient_scope')});
        const args = rpc.params?.arguments;
        if (args?.agent_id !== undefined && args.agent_id !== binding.agentId) denied();
        await engine.access(binding.accountId,binding.agentId, action === 'send' || action === 'reply' ? 'execute' : action);
        let result;
        if (rpc.method === 'tools/list') result = {tools:structuredClone(descriptors)};
        // The deadline is trusted authentication output, never a caller field.
        // A fresh consent cannot revive a subscription created by an old lease.
        else if (rpc.method === 'events/subscribe') result = await engine.subscribe(binding.accountId,rpc.params,{expiresAt:context.expiresAt,consentId:context.consentId});
        else if (descriptor?.name.startsWith('relay_message_')) {
          const name = descriptor.name;
          const value = name === 'relay_message_fetch' ? await access.fetch(binding.accountId,args,context) : name === 'relay_message_acknowledge' ? await access.acknowledge(binding.accountId,args,context) : await sender.callTool({name,arguments:args},context);
          result = {...(value.status === 'uncertain' ? {isError:true} : {}), content:[{type:'text',text:JSON.stringify(value)}], structuredContent:value};
        } else {
          // Existing dispatcher owns work/events validation and durable semantics.
          // Its discovery check lacks an agent; use the already authorized binding.
          if (rpc.method === 'events/list') {const {eventDefinition} = await import('../relay-events/core.mjs'); result = {events:[structuredClone(eventDefinition)]};}
          else {const dispatched = await dispatch(binding.accountId,rpc); if (dispatched.error) return response(200,dispatched); result = dispatched.result;}
        }
        const fresh = await authenticate(request,signal);
        if (fresh.reference !== context.reference || fresh.consentId !== context.consentId || !same(fresh.binding,context.binding) || !scopesFor(action).every(scope => fresh.scopes.includes(scope))) denied();
        return response(200,{jsonrpc:'2.0',id,result});
      } catch (error) {return failure(error instanceof RelayError ? error.code : -32001, 'The authorized event operation could not be completed.');}});
    });
  }
  async function pump() {
    active(); if (!options.ingestion) return {handedOff:0};
    const resolved = await hooks.resolveIngestionContext({binding, signal:shutdown.signal}); active();
    // Missing/expired/revoked consent is idle, not an authority outage. Leave
    // source notifications untouched and keep OAuth and the listener available.
    if (resolved === null) return {handedOff:0,paused:true,reason:'consent-required'};
    if (!plain(resolved) || !resolved.reference || !consentId(resolved.consentId) || !same(resolved.binding,binding)) denied();
    const context = Object.freeze({...resolved,signal:shutdown.signal});
    return authorization.run(context, async () => {
    // Ingestion requires independent continuing read+write consent. This context
    // is server-owned; it cannot originate in a request body or browser token.
    let authorized = await hooks.authorizeRelay(context,{scopes:scopesFor('ingest'),binding,action:'ingest'});
    if (!same(authorized?.binding,binding) || !scopesFor('ingest').every(s => authorized?.scopes?.includes(s))) denied();
    const page = await source.listNotifications(context,{limit:100}); let handedOff = 0;
    for (const notification of page.notifications) {
      active();
      const message = await source.readMessage({principal:binding.accountId,agent_id:binding.agentId,message:{id:notification.messageId},context});
      if (message.workspaceId !== binding.workspaceId || message.senderId === binding.accountId || !message.notificationRecipientIds.includes(binding.accountId)) denied();
      const link = {id:message.id,senderId:message.senderId,visibility:message.visibility,createdAt:message.createdAt,roomId:message.roomId,
        ...(message.visibility === 'private' ? {recipientId:binding.accountId} : {workspaceId:binding.workspaceId})};
      await engine.enqueue(binding.accountId,{agent_id:binding.agentId,source_id:messageSourceId(link),message:link});
      // ACK occurs only after the SQLite work commit. Crashes/retries coalesce by
      // stable source ID; this source ACK never means message read or agent ACK.
      active(); await source.acknowledgeNotificationHandoff(context,{notificationId:notification.id}); handedOff++;
    }
    return {handedOff,hasMore:page.hasMore};
    });
  }
  function runCycle() {
    if (cycle) return cycle;
    cycle = track(async () => {const handoff = await pump(); active();
      if (handoff.paused) return {handoff,tick:{sent:0,paused:true,reason:'consent-required'}};
      const tick = await engine.tick(); return {handoff,tick};}).finally(() => {cycle = undefined;});
    return cycle;
  }
  function close() {
    if (closing) return closing;
    closed = true; clearInterval(timer); shutdown.abort();
    closing = Promise.resolve().then(async () => {let deadline; try {await Promise.race([Promise.allSettled([...pending]).then(() => engine.exclusive(async()=>{})),new Promise((_,reject)=>{deadline=setTimeout(()=>reject(new Error('Event cleanup timed out.')),12000);})]);} finally {clearTimeout(deadline);}});
    closing.then(() => finish({ok:!failed}), () => finish({ok:false})); return closing;
  }
  const entry = createLoopbackEntry({origin, application:{fetch,close,completion}, ...(options.port === undefined ? {} : {port:options.port})});
  return Object.freeze({async listen() {const address = await entry.listen(); timer = setInterval(() => {runCycle().catch(() => {failed=true; void entry.close().catch(()=>{});});},intervalMs); timer.unref(); return address;}, close:()=>entry.close(), completion:entry.completion, runCycle, fetch});
}

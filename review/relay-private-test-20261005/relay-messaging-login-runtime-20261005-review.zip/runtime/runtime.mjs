import {createLinkedRelayService} from '../account-linking/compose.mjs';
import {createEventsService, validateEventsConfiguration} from './events-service.mjs';

const plain = value => value && Object.getPrototypeOf(value) === Object.prototype;
/** One process, two explicit loopback resources. Browser-only is the default.
 * Explicit messaging config enables a second audience at the same issuer.
 * The browser audience never conveys messaging permission. This composition
 * uses only the provider's concrete hooks, never caller-supplied authority.
 * Existing stores belong to the caller. Construction neither listens nor runs
 * the outbox/tick loop. Schema installation and credential provisioning are out
 * of scope. Start exactly one process for these private stores.
 */
export async function createRuntime(options = {}) {
  if (!plain(options) || !plain(options.browser) || Object.keys(options).some(k => !['browser','events'].includes(k))) throw new TypeError('Explicit runtime configuration is required.');
  const events = options.events;
  if (Object.hasOwn(options.browser, 'messaging')) throw new TypeError('Configure messaging only through the runtime events resource.');
  if (events !== undefined && (!plain(events) || events.enabled !== true ||
      events.origin === options.browser.origin || Object.hasOwn(events, 'hooks') || Object.hasOwn(events, 'issuers') ||
      !['workspaceId','accountId','agentId'].every(k => events.binding?.[k] === options.browser.selected?.[k]))) throw new TypeError('Events require a distinct resource, the exact selected worker, and the concrete provider authority.');
  const {client:messageClient, ...eventServiceOptions} = events ?? {};
  if (events) {
    if (!plain(messageClient) || Object.keys(messageClient).sort().join(',') !== 'id,name,redirectUri' ||
        !/^[A-Za-z0-9_-]{1,128}$/.test(messageClient.id) || messageClient.id === options.browser.client?.id ||
        typeof messageClient.name !== 'string' || messageClient.name.length < 1 || messageClient.name.length > 100 ||
        typeof messageClient.redirectUri !== 'string') throw new TypeError('A distinct explicitly registered messaging client is required.');
    const redirect = new URL(messageClient.redirectUri);
    if (redirect.protocol !== 'https:' || redirect.username || redirect.password || redirect.search || redirect.hash || redirect.href !== messageClient.redirectUri) throw new TypeError('An exact messaging callback is required.');
    validateEventsConfiguration({...eventServiceOptions, issuers:[options.browser.origin]}, {requireHooks:false});
  }
  let browser, messages, closing, closed = false, started = false, failed = false, finish;
  const completion = new Promise(resolve => {finish = resolve;});
  try {
    browser = await createLinkedRelayService({...options.browser, ...(events ? {messaging:{
      resource: `${events.origin}/mcp`, binding: events.binding, client:messageClient}} : {})});
    if (events) {
      if (browser.messageResource?.resource !== `${events.origin}/mcp` || browser.messageResource?.issuer !== options.browser.origin ||
          !['workspaceId','accountId','agentId','runId'].every(k => browser.messageResource?.binding?.[k] === events.binding[k])) throw new TypeError('The concrete messaging resource is unavailable.');
      messages = createEventsService({...eventServiceOptions, issuers:[browser.messageResource.issuer], hooks:browser.messageHooks});
    }
  } catch (error) {await Promise.allSettled([browser?.close(),messages?.close()]); throw error;}
  function close() {
    if (closing) return closing; closed = true;
    closing = Promise.allSettled([browser.close(),messages?.close()]).then(results => {
      if (results.some(r => r.status === 'rejected')) {failed = true; throw new Error('Runtime cleanup failed.');}
    });
    closing.then(() => finish({ok:!failed}), () => finish({ok:false})); return closing;
  }
  for (const service of [browser,messages].filter(Boolean)) service.completion.then(result => {
    if (closed) return; failed = result?.ok !== true; void close().catch(()=>{});
  }, () => {failed = true; void close().catch(()=>{});});
  return Object.freeze({async listen() {
    if (started || closed) throw new Error('Runtime is unavailable.'); started = true;
    try {const b = await browser.listen(); const e = messages ? await messages.listen() : undefined;
      return Object.freeze({browser:b,...(e?{events:e}:{})});
    } catch {failed = true; await close().catch(()=>{}); throw new Error('Runtime startup failed.');}
  }, close, completion,
  // Trusted operator/test diagnostic only, not an HTTP or MCP method. A running
  // loop uses the same serialized operation; it cannot create parallel pumps.
  ...(messages ? {runCycle:messages.runCycle} : {})});
}

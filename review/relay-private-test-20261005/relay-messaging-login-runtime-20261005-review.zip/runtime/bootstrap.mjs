import {constants, closeSync, fstatSync, lstatSync, openSync, readSync, realpathSync} from 'node:fs';
import {dirname, isAbsolute, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createPrivateKey, createPublicKey, X509Certificate} from 'node:crypto';
import {createSecureContext} from 'node:tls';
import {DatabaseSync} from 'node:sqlite';
import {createEncryptedStore} from '../account-linking/storage.mjs';

/** Private, existing-resource bootstrap. This module does not initialize schema,
 * mint keys, create identities, import operator code, listen, or read environment
 * variables on import. Version 1 is browser-only; version 2 explicitly enables
 * the concrete same-provider messaging resource without configurable hook code.
 * A dedicated non-root service user must own all configured files/directories.
 */
export class BootstrapError extends Error {
  constructor(code = 'CONFIGURATION_UNAVAILABLE') {
    super('Relay runtime configuration or private storage is unavailable.');
    this.name = 'BootstrapError'; this.code = code;
  }
}
const fail = code => {throw new BootstrapError(code);};
const requireValue = (condition, code) => {if (!condition) fail(code);};
const plain = value => value !== null && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype;
const exact = (value, names) => requireValue(plain(value) && Object.keys(value).length === names.length && names.every(name => Object.hasOwn(value, name)), 'INVALID_CONFIGURATION');
const integer = (value, min, max) => Number.isSafeInteger(value) && value >= min && value <= max;
const text = (value, max) => typeof value === 'string' && value.length > 0 && Buffer.byteLength(value) <= max && !/[\x00-\x1f\x7f]/.test(value);
const opaque = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(value);
const sameFile = (a, b) => a.dev === b.dev && a.ino === b.ino && a.mode === b.mode && a.uid === b.uid && a.nlink === b.nlink;

function serviceUid() {
  requireValue(typeof process.getuid === 'function' && process.getuid() !== 0, 'SERVICE_USER_REQUIRED');
  return process.getuid();
}

/** Reject symlinks, aliases, permissive parents, hard-linked secret files, and
 * ancestors that another user can replace. No chmod/chown or directory creation.
 */
function checkedPath(path, {directory = false, database = false} = {}) {
  const uid = serviceUid();
  requireValue(text(path, 4096) && isAbsolute(path) && resolve(path) === path && path !== '/', 'PRIVATE_PATH_REQUIRED');
  requireValue(realpathSync(path) === path, 'PRIVATE_PATH_REQUIRED');
  const stat = lstatSync(path), mode = stat.mode & 0o7777;
  requireValue(!stat.isSymbolicLink() && stat.uid === uid && (directory ? stat.isDirectory() && mode === 0o700 :
    stat.isFile() && stat.nlink === 1 && (database ? mode === 0o600 : [0o400, 0o600].includes(mode))), 'PRIVATE_PATH_REQUIRED');
  let ancestor = dirname(path), first = true;
  while (true) {
    const parent = lstatSync(ancestor);
    requireValue(parent.isDirectory() && !parent.isSymbolicLink() && [0, uid].includes(parent.uid) && !(parent.mode & 0o022), 'PRIVATE_PARENT_REQUIRED');
    if (first) requireValue(parent.uid === uid && (parent.mode & 0o7777) === 0o700, 'PRIVATE_PARENT_REQUIRED');
    if (ancestor === '/') break;
    ancestor = dirname(ancestor); first = false;
  }
  return stat;
}

function readPrivate(path, maximum) {
  const expected = checkedPath(path);
  requireValue(expected.size > 0 && expected.size <= maximum, 'PRIVATE_FILE_SIZE');
  const fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = fstatSync(fd);
    requireValue(sameFile(expected, opened) && opened.size === expected.size, 'PRIVATE_FILE_CHANGED');
    const bytes = Buffer.alloc(maximum + 1);
    let total = 0, count;
    while (total < bytes.length && (count = readSync(fd, bytes, total, bytes.length - total, null)) !== 0) total += count;
    requireValue(total === expected.size && total <= maximum && sameFile(opened, lstatSync(path)), 'PRIVATE_FILE_CHANGED');
    return bytes.subarray(0, total);
  } finally {closeSync(fd);}
}
function readJSON(path, maximum = 65536) {
  const bytes = readPrivate(path, maximum);
  try {return JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(bytes));}
  finally {bytes.fill(0);}
}
function https(value, originOnly = false) {
  requireValue(text(value, 2048), 'INVALID_CONFIGURATION');
  const url = new URL(value);
  requireValue(url.protocol === 'https:' && !url.username && !url.password && !url.hash && !url.search &&
    (originOnly ? url.origin === value : url.href === value), 'INVALID_CONFIGURATION');
}
function checkedConfiguration(value) {
  requireValue(plain(value) && [1, 2].includes(value.version), 'INVALID_CONFIGURATION');
  exact(value, ['version', 'origin', 'selected', 'client', 'profileRoot', 'port', 'storage', 'secrets', ...(value.version === 2 ? ['messaging'] : [])]);
  requireValue(integer(value.port, 1, 65535), 'INVALID_CONFIGURATION');
  https(value.origin, true);
  exact(value.selected, ['workspaceId', 'accountId', 'agentId']);
  requireValue(opaque(value.selected.workspaceId) && uuid(value.selected.accountId) && uuid(value.selected.agentId), 'EXACT_WORKER_REQUIRED');
  exact(value.client, ['id', 'name', 'redirectUri']);
  requireValue(opaque(value.client.id) && text(value.client.name, 100), 'EXACT_CLIENT_REQUIRED');
  https(value.client.redirectUri);
  exact(value.storage, ['databasePath', 'encryptionKeyPath', 'keyId', 'maxRows', 'maxTtlSeconds', 'maxPayloadBytes']);
  requireValue(text(value.storage.keyId, 128) && integer(value.storage.maxRows, 1, 1000000) &&
    integer(value.storage.maxTtlSeconds, 900, 900) && integer(value.storage.maxPayloadBytes, 256, 262144), 'INVALID_STORAGE_CONFIGURATION');
  exact(value.secrets, ['jwksPath', 'cookieKeysPath', 'tlsKeyPath', 'tlsCertPath']);
  checkedPath(value.profileRoot, {directory: true});
  if (value.version === 2) {
    const messaging = value.messaging;
    exact(messaging, ['enabled', 'origin', 'port', 'runId', 'client', 'databasePath', 'allowedCallbackHosts', 'intervalMs', 'messageRead', 'messageSend', 'ingestion']);
    https(messaging.origin, true);
    exact(messaging.client, ['id', 'name', 'redirectUri']);
    requireValue(opaque(messaging.client.id) && messaging.client.id !== value.client.id && text(messaging.client.name, 100), 'EXACT_MESSAGING_CLIENT_REQUIRED');
    https(messaging.client.redirectUri);
    requireValue(messaging.enabled === true && messaging.messageRead === true && messaging.messageSend === true && messaging.ingestion === true &&
      messaging.origin !== value.origin && integer(messaging.port, 1, 65535) && messaging.port !== value.port && opaque(messaging.runId) &&
      integer(messaging.intervalMs, 1000, 60000) && Array.isArray(messaging.allowedCallbackHosts) && messaging.allowedCallbackHosts.length >= 1 && messaging.allowedCallbackHosts.length <= 32 &&
      new Set(messaging.allowedCallbackHosts).size === messaging.allowedCallbackHosts.length && messaging.allowedCallbackHosts.every(host =>
        typeof host === 'string' && host.length <= 253 && /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(host)), 'INVALID_MESSAGING_CONFIGURATION');
  }
  const paths = [value.storage.databasePath, value.storage.encryptionKeyPath, ...Object.values(value.secrets), ...(value.version === 2 ? [value.messaging.databasePath] : [])];
  requireValue(new Set(paths).size === paths.length && !paths.includes(value.profileRoot), 'DISTINCT_PATHS_REQUIRED');
  return value;
}
function checkedJwks(value) {
  exact(value, ['keys']);
  requireValue(Array.isArray(value.keys) && value.keys.length >= 1 && value.keys.length <= 4, 'INVALID_SIGNING_KEYS');
  const ids = new Set();
  for (const key of value.keys) {
    requireValue(plain(key) && Object.keys(key).every(name => ['kty', 'crv', 'x', 'y', 'd', 'kid', 'alg', 'use'].includes(name)) &&
      key.kty === 'EC' && key.crv === 'P-256' && key.alg === 'ES256' && text(key.kid, 128) && !ids.has(key.kid) &&
      (key.use === undefined || key.use === 'sig') && ['x', 'y', 'd'].every(name => typeof key[name] === 'string' && /^[A-Za-z0-9_-]{43}$/.test(key[name])), 'INVALID_SIGNING_KEYS');
    const privateKey = createPrivateKey({key, format: 'jwk'}), publicKey = createPublicKey(privateKey).export({format: 'jwk'});
    requireValue(privateKey.asymmetricKeyType === 'ec' && publicKey.x === key.x && publicKey.y === key.y, 'INVALID_SIGNING_KEYS');
    ids.add(key.kid);
  }
  return value;
}

// Exact current account-linking schema. Comparison removes insignificant SQL
// whitespace/case and IF NOT EXISTS; it never executes these declarations.
const normalizeSQL = sql => sql.replace(/\bIF\s+NOT\s+EXISTS\s+/gi, '').replace(/\s+/g, '').replace(/;$/, '').toLowerCase();
const SCHEMA = Object.freeze({
  relay_link_config: ['table', `CREATE TABLE relay_link_config (
    singleton INTEGER PRIMARY KEY CHECK(singleton = 1), version INTEGER NOT NULL CHECK(version = 1),
    key_id TEXT NOT NULL, key_check TEXT NOT NULL, max_rows INTEGER NOT NULL,
    max_ttl_seconds INTEGER NOT NULL, max_payload_bytes INTEGER NOT NULL) STRICT`],
  relay_link_records: ['table', `CREATE TABLE relay_link_records (
    namespace TEXT NOT NULL, id_hash TEXT NOT NULL, grant_hash TEXT, uid_hash TEXT,
    expires_at INTEGER NOT NULL, consumed_at INTEGER, key_id TEXT NOT NULL,
    nonce BLOB NOT NULL CHECK(length(nonce) = 12), ciphertext BLOB NOT NULL,
    tag BLOB NOT NULL CHECK(length(tag) = 16), PRIMARY KEY(namespace, id_hash)) STRICT`],
  relay_link_expiry: ['index', 'CREATE INDEX relay_link_expiry ON relay_link_records(expires_at)'],
  relay_link_grant: ['index', 'CREATE INDEX relay_link_grant ON relay_link_records(grant_hash) WHERE grant_hash IS NOT NULL'],
  relay_link_session_uid: ['index', 'CREATE UNIQUE INDEX relay_link_session_uid ON relay_link_records(namespace, uid_hash) WHERE uid_hash IS NOT NULL'],
  relay_link_revoked_grants: ['table', 'CREATE TABLE relay_link_revoked_grants (grant_hash TEXT PRIMARY KEY, revoked_at INTEGER NOT NULL) STRICT'],
});
function verifyExistingSchema(db) {
  const rows = db.prepare("SELECT name, type, sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%'").all();
  requireValue(rows.length === Object.keys(SCHEMA).length && rows.every(row => Object.hasOwn(SCHEMA, row.name) &&
    row.type === SCHEMA[row.name][0] && typeof row.sql === 'string' && normalizeSQL(row.sql) === normalizeSQL(SCHEMA[row.name][1])), 'EXISTING_SCHEMA_REQUIRED');
  const config = db.prepare('SELECT singleton, version FROM relay_link_config').all();
  requireValue(config.length <= 1 && (config.length === 0 || config[0].singleton === 1 && config[0].version === 1), 'INVALID_STORE_CONFIGURATION');
  // An explicitly provisioned empty schema may bind the already-approved key
  // and bounds on first start. createEncryptedStore refuses missing bindings if
  // records/tombstones exist, and verifies every existing binding unchanged.
  const integrity = db.prepare('PRAGMA quick_check').all();
  requireValue(integrity.length === 1 && integrity[0].quick_check === 'ok', 'DATABASE_INTEGRITY');
}
const EVENT_SCHEMA = 'CREATE TABLE relay_state (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL)';
function verifyExistingEventSchema(db) {
  const rows = db.prepare("SELECT name, type, sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%'").all();
  requireValue(rows.length === 1 && rows[0].name === 'relay_state' && rows[0].type === 'table' &&
    typeof rows[0].sql === 'string' && normalizeSQL(rows[0].sql) === normalizeSQL(EVENT_SCHEMA), 'EXISTING_EVENT_SCHEMA_REQUIRED');
  const values = db.prepare('SELECT id, body FROM relay_state').all();
  requireValue(values.length <= 1 && values.every(row => row.id === 1 && typeof row.body === 'string'), 'INVALID_EVENT_STATE');
  if (values.length) {
    let state; try {state = JSON.parse(values[0].body);} catch {fail('INVALID_EVENT_STATE');}
    requireValue(plain(state) && ['subscriptions', 'work', 'deliveries', 'paused'].every(key => plain(state[key])), 'INVALID_EVENT_STATE');
  }
  const integrity = db.prepare('PRAGMA quick_check').all();
  requireValue(integrity.length === 1 && integrity[0].quick_check === 'ok', 'DATABASE_INTEGRITY');
}
function existingEventStore(db) {
  // This adapter deliberately does not use SqliteStore's provisioning constructor.
  // The DB has already been opened mode=rw, exclusively locked and validated.
  return Object.freeze({
    read() {const row = db.prepare('SELECT body FROM relay_state WHERE id=1').get();
      return row ? JSON.parse(row.body) : {subscriptions:{}, work:{}, deliveries:{}, paused:{}};},
    write(state) {db.prepare('INSERT INTO relay_state(id,body) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body').run(JSON.stringify(state));},
    close() {db.close();},
  });
}
function checkSidecars(path) {
  for (const suffix of ['-wal', '-shm', '-journal']) {
    try {lstatSync(path + suffix);} catch (error) {if (error.code === 'ENOENT') continue; throw error;}
    checkedPath(path + suffix, {database: true});
  }
}

function openExistingDatabase(path, verify) {
  const before = checkedPath(path, {database:true});
  checkSidecars(path);
  const url = pathToFileURL(path); url.searchParams.set('mode', 'rw');
  const db = new DatabaseSync(url.href, {allowExtension:false});
  try {
    requireValue(sameFile(before, checkedPath(path, {database:true})), 'PRIVATE_FILE_CHANGED');
    checkSidecars(path);
    db.exec('PRAGMA trusted_schema=OFF; PRAGMA busy_timeout=1000; PRAGMA synchronous=FULL;');
    // Refuse an empty/incorrect file before a write transaction can initialize
    // even its SQLite header. Recheck after taking the retained exclusive lock.
    verify(db);
    db.exec('PRAGMA locking_mode=EXCLUSIVE; BEGIN EXCLUSIVE; COMMIT;');
    verify(db);
    checkSidecars(path);
    return db;
  } catch (error) {try {db.close();} catch {} throw error;}
}

/** Creates but does not listen. runtimeFactory is a trusted in-process test seam,
 * never configurable from JSON, environment, CLI, network, or a hook module.
 * close() and completion always close the runtime before closing both databases.
 */
export async function bootstrapRuntime(configPath, {runtimeFactory} = {}) {
  let db, eventDb, runtime, encryptionKey, tlsKey;
  try {
    serviceUid();
    const configuration = checkedConfiguration(readJSON(configPath));
    const {storage, secrets} = configuration;
    requireValue(![storage.databasePath, storage.encryptionKeyPath, ...Object.values(secrets), ...(configuration.version === 2 ? [configuration.messaging.databasePath] : [])].includes(configPath), 'DISTINCT_PATHS_REQUIRED');
    encryptionKey = readPrivate(storage.encryptionKeyPath, 32);
    requireValue(encryptionKey.byteLength === 32, 'INVALID_ENCRYPTION_KEY');
    const jwks = checkedJwks(readJSON(secrets.jwksPath));
    const cookieKeys = readJSON(secrets.cookieKeysPath, 32768);
    requireValue(Array.isArray(cookieKeys) && cookieKeys.length >= 1 && cookieKeys.length <= 4 &&
      cookieKeys.every(key => text(key, 4096) && key.length >= 64) && new Set(cookieKeys).size === cookieKeys.length, 'INVALID_COOKIE_KEYS');
    tlsKey = readPrivate(secrets.tlsKeyPath, 65536);
    const cert = readPrivate(secrets.tlsCertPath, 262144);
    requireValue(new X509Certificate(cert).checkPrivateKey(createPrivateKey(tlsKey)), 'INVALID_TLS_KEYS');
    createSecureContext({key: tlsKey, cert, minVersion: 'TLSv1.2'});
    // Restrict future SQLite sidecars and isolated worker-profile creation. This
    // deliberate process-wide change is only performed by explicit bootstrap.
    process.umask(0o077);
    // Validate/open both existing stores before binding the approved encryption
    // key to an empty provider schema. No event schema is created or migrated.
    db = openExistingDatabase(storage.databasePath, verifyExistingSchema);
    if (configuration.version === 2) eventDb = openExistingDatabase(configuration.messaging.databasePath, verifyExistingEventSchema);
    const store = createEncryptedStore({db, key: encryptionKey, keyId: storage.keyId,
      maxRows: storage.maxRows, maxTtlSeconds: storage.maxTtlSeconds, maxPayloadBytes: storage.maxPayloadBytes});
    encryptionKey.fill(0); encryptionKey = undefined;
    if (runtimeFactory === undefined) ({createRuntime: runtimeFactory} = await import('./runtime.mjs'));
    requireValue(typeof runtimeFactory === 'function', 'INVALID_RUNTIME_FACTORY');
    runtime = await runtimeFactory({browser: {origin: configuration.origin, selected: configuration.selected,
      client: configuration.client, store, jwks, cookieKeys, tls: {key: tlsKey, cert},
      profileRoot: configuration.profileRoot, port: configuration.port},
      ...(configuration.version === 2 ? {events:{enabled:true, origin:configuration.messaging.origin,
        port:configuration.messaging.port, client:configuration.messaging.client, binding:{...configuration.selected, runId:configuration.messaging.runId},
        store:existingEventStore(eventDb), allowedCallbackHosts:configuration.messaging.allowedCallbackHosts,
        intervalMs:configuration.messaging.intervalMs, messageRead:true, messageSend:true, ingestion:true}} : {})});
    requireValue(runtime && typeof runtime.listen === 'function' && typeof runtime.close === 'function' &&
      runtime.completion instanceof Promise, 'INVALID_RUNTIME');
    // The runtime's TLS context now owns its key; do not expose raw secrets in the
    // returned bootstrap handle or errors.
    let closing, finished, healthy = true;
    const completion = new Promise(resolve => {finished = resolve;});
    function close() {
      if (closing) return closing;
      closing = Promise.resolve().then(async () => {
        let failed = false;
        try {await runtime.close();} catch {failed = true;}
        try {eventDb?.close();} catch {failed = true;}
        try {db.close();} catch {failed = true;}
        tlsKey.fill(0);
        if (failed) fail('RUNTIME_CLEANUP_FAILED');
      });
      closing.then(() => finished(Object.freeze({ok: healthy})), () => finished(Object.freeze({ok: false})));
      return closing;
    }
    runtime.completion.then(outcome => {healthy = healthy && outcome?.ok === true; void close().catch(() => {});},
      () => {healthy = false; void close().catch(() => {});});
    return Object.freeze({
      async listen() {
        try {return await runtime.listen();}
        catch {healthy = false; await close().catch(() => {}); fail('RUNTIME_LISTEN_FAILED');}
      }, close, completion,
    });
  } catch (error) {
    if (runtime && typeof runtime.close === 'function') await Promise.resolve().then(() => runtime.close()).catch(() => {});
    try {eventDb?.close();} catch {}
    try {db?.close();} catch {}
    encryptionKey?.fill(0); tlsKey?.fill(0);
    // No paths, PEM/JWK fields, SQL text, identifiers, or underlying causes escape.
    throw error instanceof BootstrapError ? error : new BootstrapError();
  }
}

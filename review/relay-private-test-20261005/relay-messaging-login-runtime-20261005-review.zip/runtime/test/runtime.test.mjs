import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {request as httpsRequest} from 'node:https';
import {request as httpRequest} from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {randomBytes,generateKeyPairSync,createHash,randomUUID} from 'node:crypto';
import {createEncryptedStore,initializeStorage} from '../../account-linking/storage.mjs';
import {SqliteStore} from '../../relay-events/store.mjs';
import {createRuntime} from '../runtime.mjs';
import {createEventsService} from '../events-service.mjs';
import {createMessageFixture} from './sql-fixture.mjs';

const parseWire = text => JSON.parse(text.startsWith('event:') ? text.split('\n').find(x=>x.startsWith('data:')).slice(5).trim() : text);
const fixtureRoot = process.env.RELAY_PGLITE_ROOT;
const insecureConfig = {enabled:true,origin:'https://events.localhost',binding:{},messageRead:true,messageSend:true,ingestion:true};
test('incomplete or caller-authorized configs cannot construct the runtime', async()=>{
  await assert.rejects(createRuntime(),/Explicit runtime/);
  assert.throws(()=>createEventsService(insecureConfig),/verified message authority/);
  await assert.rejects(createRuntime({browser:{selected:{},origin:'https://localhost'},events:{...insecureConfig,origin:'https://localhost'}}),/distinct resource/);
  for(const injected of [{hooks:{}},{issuers:['https://localhost']}]) await assert.rejects(createRuntime({browser:{selected:{},origin:'https://localhost'},events:{...insecureConfig,...injected}}),/concrete provider/);
  await assert.rejects(createRuntime({browser:{messaging:{}}}),/only through/);
  assert.throws(()=>createEventsService({...insecureConfig,messageRead:false}),/opt-ins/);
});

test('same real provider links separate browser and messaging clients to real local Edge/SQL events, send, reply and ACK', {timeout:120000}, async t=>{
  assert.ok(fixtureRoot,'Set RELAY_PGLITE_ROOT to the pinned local PGlite fixture installation.');
  const f = await createMessageFixture(), dir = await mkdtemp(join(tmpdir(),'relay-runtime-fixture-'));
  let runtime; const db = new DatabaseSync(':memory:'); initializeStorage(db);
  const eventStore = new SqliteStore(join(dir,'events.db'));
  const originalFetch = globalThis.fetch;
  t.after(async()=>{globalThis.fetch=originalFetch;await runtime?.close();eventStore.close();db.close();await f.close();await rm(dir,{recursive:true,force:true});});
  const selected = {workspaceId:f.capabilities.workspaceId,accountId:f.b.id,agentId:f.b.agentId};
  const binding = {...selected,runId:f.b.runId};
  const origin = 'https://localhost', eventsOrigin = 'https://events.localhost';
  let failAckOnce=false; const callbackBodies=[], relayCalls=[];
  execFileSync('openssl',['req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:P-256','-nodes','-keyout',join(dir,'key.pem'),'-out',join(dir,'cert.pem'),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost'],{stdio:'ignore'});
  const tls={key:await readFile(join(dir,'key.pem')),cert:await readFile(join(dir,'cert.pem'))};
  const {privateKey}=generateKeyPairSync('ec',{namedCurve:'P-256'});
  const client={id:'local-fixture-client',name:'Browser fixture',redirectUri:'https://client.example.invalid/callback'};
  const messageClient={id:'local-fixture-messages',name:'Message fixture',redirectUri:'https://messages.example.invalid/callback'};
  // Both provider audiences use the real Relay session client and exact local
  // Edge handler + PostgreSQL. This fixture cannot make an external fetch.
  globalThis.fetch=async(url,init)=>{
    assert.equal(url,'https://mukbnmewwoeweogmcuno.supabase.co/functions/v1/relay');
    const action=JSON.parse(init.body).action;relayCalls.push(action);
    if(failAckOnce&&action==='messages.notifications.ack'){failAckOnce=false;return new Response('{"error":"Fixture interrupted handoff"}',{status:503,headers:{'content-type':'application/json'}});}
    return f.handler(new Request(url,init));
  };
  const providerStore=createEncryptedStore({db,key:randomBytes(32),keyId:'fixture-only'});
  runtime=await createRuntime({browser:{origin,selected,client,store:providerStore,jwks:{keys:[{...privateKey.export({format:'jwk'}),kid:'fixture-only',alg:'ES256'}]},cookieKeys:['t'.repeat(64)],tls,profileRoot:dir,port:0},events:{enabled:true,origin:eventsOrigin,client:messageClient,port:0,binding,store:eventStore,allowedCallbackHosts:['callback.example.invalid'],messageRead:true,messageSend:true,ingestion:true,intervalMs:60000,transport:async req=>{const body=JSON.parse(req.body);assert.match(req.headers['webhook-signature'],/^v1,/);if(body.type==='verification')return {status:200,body:{challenge:body.challenge}};req.onSent?.();callbackBodies.push(body);return {status:200,body:{}};}}});
  const addresses=await runtime.listen();assert.equal(addresses.browser.address,'127.0.0.1');assert.equal(addresses.events.address,'127.0.0.1');
  const beforeConsent=relayCalls.length;
  assert.equal((await runtime.runCycle()).handoff.reason,'consent-required');
  assert.equal(relayCalls.length,beforeConsent,'No Relay request before explicit messaging consent');
  const jar=new Map();
  async function browser(path,{method='GET',data,json,headers={},cookies=true}={}){
    if(path.startsWith(origin))path=path.slice(origin.length);
    const body=json?JSON.stringify(json):data?new URLSearchParams(data).toString():undefined;
    return new Promise((resolve,reject)=>{const req=httpsRequest({host:'127.0.0.1',port:addresses.browser.port,servername:'localhost',ca:tls.cert,method,path,headers:{host:'localhost',...(cookies&&jar.size?{cookie:[...jar].map(([k,v])=>`${k}=${v}`).join('; ')}:{}),...(body?{'content-type':json?'application/json':'application/x-www-form-urlencoded','content-length':Buffer.byteLength(body)}:{}),...headers}},res=>{for(const item of res.headers['set-cookie']||[]){const s=item.split(';')[0],i=s.indexOf('=');jar.set(s.slice(0,i),s.slice(i+1));}const chunks=[];res.on('data',p=>chunks.push(p));res.on('error',reject);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,body:Buffer.concat(chunks).toString()}));});req.on('error',reject);req.end(body);});
  }
  const field=(html,name)=>new RegExp(`name="${name}" value="([^"]+)"`).exec(html)?.[1];
  async function link(selectedClient,resource,scope){
    const verifier=randomBytes(32).toString('base64url'),challenge=createHash('sha256').update(verifier).digest('base64url');
    const start=await browser('/auth?'+new URLSearchParams({client_id:selectedClient.id,redirect_uri:selectedClient.redirectUri,response_type:'code',scope,resource,code_challenge:challenge,code_challenge_method:'S256',state:'fixture'}));assert.equal(start.status,303,start.body);
    const login=await browser(start.headers.location);assert.ok(field(login.body,'csrf'),login.body);
    const signed=await browser(start.headers.location,{method:'POST',headers:{origin},data:{action:'login',csrf:field(login.body,'csrf'),username:f.b.username,password:f.password}});assert.equal(signed.status,303,signed.body);
    const resumed=await browser(signed.headers.location);assert.equal(resumed.status,303,resumed.body);
    const consent=await browser(resumed.headers.location);assert.ok(field(consent.body,'approve'),consent.body);
    assert.equal(field(consent.body,'approve'),scope.split(' ').filter(s=>s!=='openid').sort().join(' '));
    assert.ok(consent.body.includes(binding.runId));
    const allowed=await browser(resumed.headers.location,{method:'POST',headers:{origin},data:{action:'consent',csrf:field(consent.body,'csrf'),approve:field(consent.body,'approve')}});assert.equal(allowed.status,303,allowed.body);
    const finished=await browser(allowed.headers.location);assert.equal(finished.status,303,finished.body);
    const location=new URL(finished.headers.location);assert.ok(location.href.startsWith(selectedClient.redirectUri),finished.headers.location);assert.equal(location.searchParams.has('error'),false,location.href);
    const code=location.searchParams.get('code');assert.ok(code);
    const exchange=await browser('/token',{method:'POST',cookies:false,data:{grant_type:'authorization_code',client_id:selectedClient.id,code,redirect_uri:selectedClient.redirectUri,code_verifier:verifier,resource}});assert.equal(exchange.status,200,exchange.body);
    const token=JSON.parse(exchange.body);assert.ok(token.access_token);assert.equal(token.refresh_token,undefined);assert.ok(token.expires_in>0&&token.expires_in<=900);return token.access_token;
  }
  const browserToken=await link(client,origin+'/mcp','browser:control');
  async function browserTools(token=browserToken){return browser('/mcp',{method:'POST',cookies:false,headers:{authorization:`Bearer ${token}`,accept:'application/json, text/event-stream'},json:{jsonrpc:'2.0',id:1,method:'tools/list',params:{}}});}
  let listed=await browserTools();assert.equal(listed.status,200,listed.body);assert.equal(parseWire(listed.body).result.tools.length,5);assert.ok(parseWire(listed.body).result.tools.every(x=>x.name.startsWith('browser_')));
  let nextId=0,messageToken;
  async function event(method,params={},extra={}){
    const path=extra.path??'/mcp',body=JSON.stringify(extra.body??{jsonrpc:'2.0',id:++nextId,method,params});
    return new Promise((resolve,reject)=>{const req=httpRequest({host:'127.0.0.1',port:addresses.events.port,path,method:'POST',headers:{host:'events.localhost','content-type':'application/json','content-length':Buffer.byteLength(body),'mcp-protocol-version':'2026-07-28',authorization:`Bearer ${messageToken}`,...extra.headers}},res=>{const chunks=[];res.on('data',p=>chunks.push(p));res.on('error',reject);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,data:JSON.parse(Buffer.concat(chunks).toString())}));});req.on('error',reject);req.end(body);});
  }
  const wrongAudience=await event('tools/list',{}, {headers:{authorization:`Bearer ${browserToken}`}});
  assert.equal(wrongAudience.status,401);
  assert.equal(wrongAudience.headers['www-authenticate'],`Bearer resource_metadata="${eventsOrigin}/.well-known/oauth-protected-resource/mcp", scope="relay:work relay:read relay:write", error="invalid_token"`);
  assert.equal((await event('tools/list',{}, {headers:{authorization:`Bearer ${f.b.token}`}})).status,401);
  assert.equal((await runtime.runCycle()).handoff.reason,'consent-required','Browser consent never starts messaging ingestion');
  messageToken=await link(messageClient,eventsOrigin+'/mcp','relay:work relay:read relay:write');
  listed=await browserTools();assert.equal(listed.status,200,listed.body);assert.equal(parseWire(listed.body).result.tools.length,5,'Messaging login preserves separate browser grant');
  assert.equal((await browserTools(messageToken)).status,401);
  assert.equal((await event('tools/list',{}, {headers:{cookie:'session=fixture'}})).status,400);
  assert.equal((await event('tools/list',{}, {headers:{'x-forwarded-host':'other.invalid'}})).status,400);
  const tools=await event('tools/list');assert.equal(tools.data.result.tools.length,7,JSON.stringify(tools));assert.ok(tools.data.result.tools.every(x=>!x.name.startsWith('browser_')));
  assert.ok(!JSON.stringify(tools).includes('browser:control'));
  assert.equal((await event('events/list',{}, {headers:{'mcp-protocol-version':'2025-11-25'}})).data.error.code,-32601);
  const subscribeParams={name:'relay.work.available',arguments:{agent_id:f.b.agentId},delivery:{mode:'webhook',url:'https://callback.example.invalid/wake',secret:'whsec_'+Buffer.alloc(32,5).toString('base64')}};
  const subscribed=await event('events/subscribe',subscribeParams);assert.ok(subscribed.data.result.id,JSON.stringify(subscribed));
  const actualAccessToken=await new providerStore.Adapter('AccessToken').find(messageToken);
  assert.ok(actualAccessToken?.exp);
  assert.equal(Date.parse(subscribed.data.result.refreshBefore),actualAccessToken.exp*1000,'Subscription deadline is exactly bounded by the authenticated token, not the default 24-hour subscription TTL');
  assert.equal(eventStore.read().subscriptions[subscribed.data.result.id].expires,actualAccessToken.exp*1000);
  const originalConsentId=createHash('sha256').update(actualAccessToken.grantId).digest('hex');
  assert.equal(eventStore.read().subscriptions[subscribed.data.result.id].consentId,originalConsentId);
  const command={clientId:randomUUID(),workspaceId:selected.workspaceId,roomId:f.capabilities.roomId,visibility:'private',senderId:f.a.id,recipientIds:[f.b.id],notificationRecipientIds:[f.b.id],participantIds:[f.a.id,f.b.id].sort(),body:'Local SQL fixture private message',replyToMessageId:null};
  const message=(await f.rpc('messages.send',f.a.token,{command})).message;assert.ok(message.id);
  failAckOnce=true;await assert.rejects(runtime.runCycle());assert.equal(Object.keys(eventStore.read().work).length,1);assert.equal((await f.rpc('messages.notifications',f.b.token,{limit:100})).notifications.length,1);
  const cycle=await runtime.runCycle();assert.equal(cycle.handoff.handedOff,1);assert.equal(cycle.tick.sent,1);assert.equal(Object.keys(eventStore.read().work).length,1);assert.equal((await f.rpc('messages.notifications',f.b.token,{limit:100})).notifications.length,0);assert.equal(callbackBodies.length,1);assert.ok(!JSON.stringify(callbackBodies).includes(command.body));
  const work=Object.values(eventStore.read().work)[0],args={agent_id:f.b.agentId,work_id:work.id,message_id:message.id};
  assert.equal((await event('tools/call',{name:'relay_message_acknowledge',arguments:{...args,fetch_receipt:'0'.repeat(64)}})).data.error.code,-32001);
  const fetched=await event('tools/call',{name:'relay_message_fetch',arguments:args});assert.equal(fetched.data.result.structuredContent.message.body,command.body,JSON.stringify(fetched));assert.equal(eventStore.read().work[work.id].agentAcknowledgedAt,undefined);
  const acknowledged=await event('tools/call',{name:'relay_message_acknowledge',arguments:{...args,fetch_receipt:fetched.data.result.structuredContent.fetch_receipt}});assert.equal(typeof acknowledged.data.result.structuredContent.agentAcknowledgedAt,'number');
  assert.equal((await f.sql('SELECT read_at FROM relay_private.direct_messages WHERE id=$1',[message.id])).rows[0].read_at,null,'Agent ACK does not mark source DM read');
  assert.equal((await event(null,{}, {path:'/manager-receipts',body:{messageId:message.id}})).status,404,'No manager credential or proxy is fabricated');
  const sendArgs={visibility:'private',room_id:f.capabilities.roomId,recipient_ids:[f.a.id],body:'Local fixture reply',client_id:randomUUID(),reply_to_message_id:message.id};
  const reply=await event('tools/call',{name:'relay_message_reply',arguments:sendArgs});assert.equal(reply.data.result.structuredContent.status,'persisted',JSON.stringify(reply));
  assert.equal(reply.data.result.structuredContent.message.replyToMessageId,message.id);
  const mismatched=await event('tools/call',{name:'relay_message_reply',arguments:{...sendArgs,recipient_ids:[f.c.id],client_id:randomUUID()}});assert.notEqual(mismatched.data.result?.structuredContent?.status,'persisted');
  const previousToken=messageToken;
  messageToken=await link(messageClient,eventsOrigin+'/mcp','relay:work');
  assert.equal((await event('tools/list',{}, {headers:{authorization:`Bearer ${previousToken}`}})).status,401);
  assert.equal((await event('tools/call',{name:'relay_work_pause',arguments:{agent_id:f.b.agentId,paused:true}})).data.result.structuredContent.paused,true);
  const missingRead=await event('tools/list');assert.equal(missingRead.data.error.code,-32001);assert.equal(missingRead.status,403);
  assert.equal(missingRead.headers['www-authenticate'],`Bearer resource_metadata="${eventsOrigin}/.well-known/oauth-protected-resource/mcp", scope="relay:work relay:read", error="insufficient_scope"`);
  assert.equal((await runtime.runCycle()).handoff.reason,'consent-required');
  assert.equal((await browserTools()).status,200);
  messageToken=await link(messageClient,eventsOrigin+'/mcp','relay:work relay:read');
  const readOnlyFetch=await event('tools/call',{name:'relay_message_fetch',arguments:args});assert.equal(readOnlyFetch.data.result.structuredContent.message.id,message.id);
  const readOnlyAck=await event('tools/call',{name:'relay_message_acknowledge',arguments:{...args,fetch_receipt:readOnlyFetch.data.result.structuredContent.fetch_receipt}});assert.equal(typeof readOnlyAck.data.result.structuredContent.agentAcknowledgedAt,'number');
  assert.equal((await event('tools/call',{name:'relay_message_reply',arguments:{...sendArgs,client_id:randomUUID()}})).data.error.code,-32001);
  messageToken=await link(messageClient,eventsOrigin+'/mcp','relay:work relay:write');
  const send=await event('tools/call',{name:'relay_message_send',arguments:{visibility:'private',room_id:f.capabilities.roomId,recipient_ids:[f.a.id],body:'Write-only consent message',client_id:randomUUID()}});assert.equal(send.data.result.structuredContent.status,'persisted',JSON.stringify(send));
  assert.equal((await event('tools/call',{name:'relay_message_fetch',arguments:args})).data.error.code,-32001);
  assert.equal((await event('tools/call',{name:'relay_message_reply',arguments:{...sendArgs,client_id:randomUUID()}})).data.error.code,-32001);
  messageToken=await link(messageClient,eventsOrigin+'/mcp','relay:work relay:read relay:write');
  await event('tools/call',{name:'relay_work_pause',arguments:{agent_id:f.b.agentId,paused:false}});
  const publicCommand={...command,clientId:randomUUID(),visibility:'public',recipientIds:[],participantIds:[],body:'Local SQL fixture public message'};
  const publicMessage=(await f.rpc('messages.send',f.a.token,{command:publicCommand})).message;
  assert.ok(publicMessage.id);
  // Clear only the test queue's per-agent delivery cooldown. Otherwise its
  // two-minute throttle could mask an incorrect old-consent callback delivery.
  const beforeReconnectTick=eventStore.read();beforeReconnectTick.lastSent={};eventStore.write(beforeReconnectTick);
  const publicCycle=await runtime.runCycle();assert.equal(publicCycle.handoff.handedOff,1);assert.equal(publicCycle.tick.sent,0);
  assert.equal(callbackBodies.length,1,'Fresh messaging consent must not revive the previous grant’s callback');
  assert.equal(eventStore.read().subscriptions[subscribed.data.result.id],undefined,'Tick retires the old grant-bound callback');
  const resubscribed=await event('events/subscribe',subscribeParams);assert.ok(resubscribed.data.result.id,JSON.stringify(resubscribed));
  const renewedToken=await new providerStore.Adapter('AccessToken').find(messageToken);
  const renewedConsentId=createHash('sha256').update(renewedToken.grantId).digest('hex');
  assert.notEqual(renewedConsentId,originalConsentId);
  assert.equal(eventStore.read().subscriptions[resubscribed.data.result.id].consentId,renewedConsentId);
  assert.equal((await runtime.runCycle()).tick.sent,1);assert.equal(callbackBodies.length,2);
  const publicWork=Object.values(eventStore.read().work).find(w=>w.message.id===publicMessage.id);
  const publicFetch=await event('tools/call',{name:'relay_message_fetch',arguments:{...args,work_id:publicWork.id,message_id:publicMessage.id}});assert.equal(publicFetch.data.result.structuredContent.message.visibility,'public');
  const publicReply=await event('tools/call',{name:'relay_message_reply',arguments:{visibility:'public',room_id:f.capabilities.roomId,recipient_ids:[],notify_recipient_ids:[f.a.id],body:'Public reply fixture',client_id:randomUUID(),reply_to_message_id:publicMessage.id}});
  assert.equal(publicReply.data.result?.structuredContent?.status,'persisted',JSON.stringify(publicReply));
  const revoked=await browser('/token/revocation',{method:'POST',cookies:false,data:{token:messageToken,token_type_hint:'access_token',client_id:messageClient.id}});assert.equal(revoked.status,200,revoked.body);
  assert.equal((await event('tools/list')).status,401);
  const afterRevocation=relayCalls.length;assert.equal((await runtime.runCycle()).handoff.reason,'consent-required');assert.equal(relayCalls.length,afterRevocation);
  assert.equal((await browserTools()).status,200);
  await runtime.close();assert.deepEqual(await runtime.completion,{ok:true});
  assert.ok(!JSON.stringify(eventStore.read()).includes(command.body));assert.ok(!JSON.stringify(eventStore.read()).includes(publicCommand.body));
});

// Low-level service contract tests deliberately inject authority hooks. The
// public runtime integration tests use only the real account-linking provider.
import test from 'node:test';
import assert from 'node:assert/strict';
import {createEventsService} from '../events-service.mjs';
const binding = {workspaceId:'fixture-workspace', accountId:'11111111-1111-4111-8111-111111111111', agentId:'22222222-2222-4222-8222-222222222222', runId:'fixture-run'};
const origin = 'https://events.localhost';
const consentId = 'a'.repeat(64);
function fixture(t) {
  let state = {subscriptions:{}, work:{}, deliveries:{}, paused:{}};
  const reference = Object.freeze({}), scopes = new Set(['relay:work','relay:read','relay:write']), calls = [];
  const hooks = {
    async authenticate() {return {reference,consentId,binding,principalId:binding.accountId,scopes:[...scopes],expiresAt:Date.now()+60000};},
    async authorizeContinuing(query) {calls.push(['continuing',query.action]);return true;},
    async withAuthorizedRelay() {calls.push(['relay']);throw new Error('Unexpected source call');},
    async authorizeRead() {return true;},
    async authorizeRelay(_context, policy) {calls.push(['authorize',policy]);return {binding,scopes:[...scopes]};},
    async resolveIngestionContext() {calls.push(['resolve']);return null;},
  };
  const options = {enabled:true,origin,issuers:['https://localhost'],binding,port:0,
    store:{read:()=>structuredClone(state),write:value=>{state=structuredClone(value);},close(){}},
    hooks,allowedCallbackHosts:['callback.example.invalid'],intervalMs:1000,messageRead:true,messageSend:true,ingestion:true,
    transport:async()=>{calls.push(['transport']);throw new Error('Unexpected callback');}};
  const create = overrides => {const service = createEventsService({...options,...overrides});t.after(()=>service.close());return service;};
  const rpc = async(service, method, params={}, token='fixture') => {
    const response = await service.fetch(new Request(origin+'/mcp', {method:'POST',headers:{authorization:`Bearer ${token}`, 'content-type':'application/json','mcp-protocol-version':'2026-07-28'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})}));
    return {status:response.status,headers:Object.fromEntries(response.headers),body:await response.json()};
  };
  return {hooks,scopes,calls,options,create,rpc};
}

test('missing ingestion consent pauses without Relay calls, source ACK, callbacks or event tick', async t=>{
  const f=fixture(t),service=f.create();
  const result=await service.runCycle();
  assert.deepEqual(result,{handoff:{handedOff:0,paused:true,reason:'consent-required'},tick:{sent:0,paused:true,reason:'consent-required'}});
  assert.deepEqual(f.calls,[['resolve']]);
  assert.equal((await f.rpc(service,'tools/list')).status,200);
});

test('scheduled no-consent cycles preserve a live listener; genuine authority outage terminates it', {timeout:5000}, async t=>{
  const f=fixture(t),service=f.create();let outage=false;
  f.hooks.resolveIngestionContext=async()=>{if(outage)throw new Error('Authority outage');return null;};
  // Hooks are captured at construction. Create with the changed resolver.
  await service.close(); const running=f.create();await running.listen();
  await new Promise(resolve=>setTimeout(resolve,1100));
  assert.equal((await f.rpc(running,'tools/list')).status,200);
  outage=true;
  assert.deepEqual(await running.completion,{ok:false});
  assert.equal((await f.rpc(running,'tools/list')).status,503);
});

test('advertised messaging scopes contain relay:work and never browser:control', async t=>{
  const f=fixture(t),service=f.create({ingestion:false});
  const response=await service.fetch(new Request(origin+'/.well-known/oauth-protected-resource/mcp'));
  assert.deepEqual((await response.json()).scopes_supported,['relay:work','relay:read','relay:write']);
  const tools=(await f.rpc(service,'tools/list')).body.result.tools;
  const scopes=name=>tools.find(tool=>tool.name===name).securitySchemes[0].scopes;
  assert.deepEqual(scopes('relay_work_pause'),['relay:work']);
  assert.deepEqual(scopes('relay_work_transition'),['relay:work']);
  assert.deepEqual(scopes('relay_work_status'),['relay:work','relay:read']);
  assert.deepEqual(scopes('relay_message_fetch'),['relay:work','relay:read']);
  assert.deepEqual(scopes('relay_message_acknowledge'),['relay:work','relay:read']);
  assert.deepEqual(scopes('relay_message_send'),['relay:work','relay:write']);
  assert.deepEqual(scopes('relay_message_reply'),['relay:work','relay:read','relay:write']);
});

test('work-only token can pause but cannot discover, subscribe, read or send', async t=>{
  const f=fixture(t);f.scopes.delete('relay:read');f.scopes.delete('relay:write');const service=f.create({ingestion:false});
  assert.equal((await f.rpc(service,'tools/call',{name:'relay_work_pause',arguments:{agent_id:binding.agentId,paused:true}})).body.result.structuredContent.paused,true);
  for(const [method,params] of [['tools/list',{}],['server/discover',{}],['events/list',{}],['events/subscribe',{}],['tools/call',{name:'relay_message_send',arguments:{visibility:'private',room_id:'fixture-room',recipient_ids:[binding.accountId],body:'test',client_id:'33333333-3333-4333-8333-333333333333'}}]]){
    assert.equal((await f.rpc(service,method,params)).body.error.code,-32001,method);
  }
  assert.ok(!f.calls.some(([call])=>call==='relay'));
});

test('ingestion policy requires all three messaging scopes, never browser authority', async t=>{
  const f=fixture(t);f.hooks.resolveIngestionContext=async()=>({binding,reference:{},consentId});f.scopes.delete('relay:write');const service=f.create();
  await assert.rejects(service.runCycle());
  assert.deepEqual(f.calls.find(([call])=>call==='authorize')[1].scopes,['relay:work','relay:read','relay:write']);
  assert.ok(!f.calls.some(([call])=>call==='relay'));
});

test('subscription uses the trusted access-token deadline and cannot deliver after expiry under later consent', async t=>{
  let now=Date.now();const expiresAt=now+5000;
  t.mock.method(Date,'now',()=>now);
  const f=fixture(t),reference=Object.freeze({});
  f.hooks.authenticate=async()=>({reference,consentId,binding,principalId:binding.accountId,scopes:[...f.scopes],expiresAt});
  f.options.store.write({subscriptions:{},deliveries:{},paused:{},work:{fixture:{id:'fixture',owner:binding.accountId,agent:binding.agentId,status:'queued',createdAt:now,updatedAt:now,generation:0,recoveries:0,lastWake:now,priority:'normal',notBefore:0}}});
  const bodies=[];
  const service=f.create({ingestion:false,transport:async request=>{
    const body=JSON.parse(request.body);bodies.push(body);
    return {status:200,body:body.type==='verification'?{challenge:body.challenge}:{}};
  }});
  const subscribed=await f.rpc(service,'events/subscribe',{name:'relay.work.available',arguments:{agent_id:binding.agentId},ttlMs:86400000,
    delivery:{mode:'webhook',url:'https://callback.example.invalid/wake',secret:'whsec_'+Buffer.alloc(32,8).toString('base64')}});
  assert.equal(Date.parse(subscribed.body.result.refreshBefore),expiresAt);
  assert.equal(Object.values(f.options.store.read().deliveries)[0].status,'queued');
  assert.equal(bodies.length,1);assert.equal(bodies[0].type,'verification');
  // Continuing authority deliberately stays true, as if new consent has been
  // granted. The old subscription must nevertheless remain absolutely expired.
  now=expiresAt+1;
  assert.equal((await service.runCycle()).tick.sent,0);
  assert.equal(bodies.length,1);assert.equal(Object.values(f.options.store.read().deliveries)[0].status,'cancelled');
});


test('concurrent fresh consent cannot lend authority to an older in-flight work mutation', async t=>{
  const f=fixture(t),oldRef=Object.freeze({old:true}),newRef=Object.freeze({new:true});
  const newConsentId='b'.repeat(64);let current=consentId,release,entered;
  const waiting=new Promise(resolve=>{entered=resolve;}),gate=new Promise(resolve=>{release=resolve;});
  f.hooks.authenticate=async request=>{
    const newer=request.headers.get('authorization')==='Bearer new';
    return {reference:newer?newRef:oldRef,consentId:newer?newConsentId:consentId,binding,principalId:binding.accountId,scopes:[...f.scopes],expiresAt:Date.now()+60000};
  };
  const checked=[];
  f.hooks.authorizeRelay=async context=>{checked.push(context.consentId);if(context.consentId!==current)throw new Error('Original consent revoked');return {binding,scopes:[...f.scopes]};};
  let held=false;
  f.hooks.authorizeContinuing=async query=>{
    if(!held&&query.action==='pause'&&query.consentId===consentId){held=true;entered();await gate;}
    return true;
  };
  const service=f.create({ingestion:false});
  const old=f.rpc(service,'tools/call',{name:'relay_work_pause',arguments:{agent_id:binding.agentId,paused:true}},'old');
  await waiting;current=newConsentId;
  const fresh=await f.rpc(service,'tools/call',{name:'relay_work_pause',arguments:{agent_id:binding.agentId,paused:false}},'new');
  assert.equal(fresh.body.result.structuredContent.paused,false);
  release();assert.equal((await old).body.error.code,-32001);
  assert.deepEqual(Object.values(f.options.store.read().paused),[false]);
  assert.ok(checked.includes(newConsentId));assert.equal(checked.at(-1),consentId,'Old asynchronous request retains its own consent after a newer request finishes');
});

test('ingestion keeps its original consent through source reads and refuses enqueue or ACK after replacement', async t=>{
  const f=fixture(t),reference=Object.freeze({ingestion:true}),context={reference,consentId,binding};
  let current=consentId;const sourceCalls=[];
  const id='33333333-3333-4333-8333-333333333333',senderId='55555555-5555-4555-8555-555555555555';
  f.hooks.resolveIngestionContext=async()=>context;
  f.hooks.authorizeRelay=async received=>{
    assert.equal(received.reference,reference);assert.equal(received.consentId,consentId);
    if(current!==received.consentId)throw new Error('Ingestion consent was replaced');
    return {binding,scopes:[...f.scopes]};
  };
  f.hooks.withAuthorizedRelay=async(received,_policy,callback)=>{
    assert.equal(received.reference,reference);
    return callback({binding,scopes:[...f.scopes],call:async action=>{
      sourceCalls.push(action);
      if(action==='messages.notifications')return {notifications:[{id:'66666666-6666-4666-8666-666666666666',messageId:id,recipientId:binding.accountId,createdAt:new Date().toISOString()}],hasMore:false};
      if(action==='messages.get'){
        current='b'.repeat(64);
        return {message:{id,clientId:'44444444-4444-4444-8444-444444444444',senderId,workspaceId:binding.workspaceId,roomId:'fixture-room',visibility:'private',recipientIds:[binding.accountId],notificationRecipientIds:[binding.accountId],participantIds:[senderId,binding.accountId].sort(),body:'Local unit fixture',replyToMessageId:null,createdAt:new Date().toISOString()}};
      }
      throw new Error('Source ACK must not occur after consent replacement');
    }});
  };
  const service=f.create();await assert.rejects(service.runCycle());
  assert.deepEqual(sourceCalls,['messages.notifications','messages.get']);
  assert.deepEqual(f.options.store.read().work,{});
});


test('OAuth challenges advertise messaging resource metadata and exact operation scopes', async t=>{
  const denied=fixture(t);denied.hooks.authenticate=async()=>{throw new Error('Invalid bearer');};
  const deniedService=denied.create();
  const unauthorized=await denied.rpc(deniedService,'tools/list');
  assert.equal(unauthorized.status,401);
  assert.equal(unauthorized.headers['www-authenticate'],`Bearer resource_metadata="${origin}/.well-known/oauth-protected-resource/mcp", scope="relay:work relay:read relay:write", error="invalid_token"`);
  const noBearer=await deniedService.fetch(new Request(origin+'/mcp',{method:'POST',headers:{'content-type':'application/json'},body:'{}'}));
  assert.equal(noBearer.status,401);
  assert.equal(noBearer.headers.get('www-authenticate'),`Bearer resource_metadata="${origin}/.well-known/oauth-protected-resource/mcp", scope="relay:work relay:read relay:write"`);
  const f=fixture(t);f.scopes.delete('relay:read');f.scopes.delete('relay:write');const service=f.create({ingestion:false});
  const send={visibility:'private',room_id:'fixture-room',recipient_ids:[binding.accountId],body:'test',client_id:'33333333-3333-4333-8333-333333333333'};
  for(const [method,params,scopes] of [
    ['tools/list',{},'relay:work relay:read'],
    ['events/subscribe',{},'relay:work relay:read'],
    ['tools/call',{name:'relay_message_send',arguments:send},'relay:work relay:write'],
    ['tools/call',{name:'relay_message_reply',arguments:{...send,reply_to_message_id:'44444444-4444-4444-8444-444444444444'}},'relay:work relay:read relay:write'],
  ]){
    const result=await f.rpc(service,method,params);
    assert.equal(result.status,403);assert.equal(result.body.error.code,-32001);assert.equal(result.body.id,1);
    assert.equal(result.headers['www-authenticate'],`Bearer resource_metadata="${origin}/.well-known/oauth-protected-resource/mcp", scope="${scopes}", error="insufficient_scope"`);
  }
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, mkdirSync, writeFileSync, readFileSync, chmodSync, renameSync, symlinkSync, linkSync, existsSync, readdirSync, rmSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, join} from 'node:path';
import {execFileSync, spawnSync} from 'node:child_process';
import {generateKeyPairSync, randomBytes} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {EventEmitter} from 'node:events';
import {createServer} from 'node:net';
import {request} from 'node:https';
import {request as httpRequest} from 'node:http';
import {initializeStorage, createEncryptedStore} from '../../account-linking/storage.mjs';
import {bootstrapRuntime, BootstrapError} from '../bootstrap.mjs';
import {startRuntimeCli} from '../serve.mjs';

const here = dirname(fileURLToPath(import.meta.url));
let materials, tls, jwks, previousUmask;
test.before(() => {
  previousUmask = process.umask(0o077);
  // Temporary test-only material is generated and removed inside this checkout.
  // This does not initialize any operator database or provision live credentials.
  materials = mkdtempSync(join(here, '.bootstrap-tls-'));
  execFileSync('openssl', ['req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:P-256', '-nodes',
    '-keyout', join(materials, 'key.pem'), '-out', join(materials, 'cert.pem'), '-days', '1', '-subj', '/CN=localhost'], {stdio: 'ignore'});
  tls = {key: readFileSync(join(materials, 'key.pem')), cert: readFileSync(join(materials, 'cert.pem'))};
  const {privateKey} = generateKeyPairSync('ec', {namedCurve: 'P-256'});
  jwks = {keys: [{...privateKey.export({format: 'jwk'}), kid: 'fixture-signing', alg: 'ES256'}]};
});
test.after(() => {rmSync(materials, {recursive: true, force: true}); process.umask(previousUmask);});
function fixture(t, {schema = true, bind = true} = {}) {
  const root = mkdtempSync(join(here, '.bootstrap-test-'));
  t.after(() => rmSync(root, {recursive: true, force: true}));
  mkdirSync(join(root, 'profiles'), {mode: 0o700});
  const config = {version: 1, origin: 'https://localhost', selected: {workspaceId: 'fixture-workspace',
    accountId: '11111111-1111-4111-8111-111111111111', agentId: '22222222-2222-4222-8222-222222222222'},
    client: {id: 'fixture-client', name: 'Local fixture', redirectUri: 'https://client.example.invalid/callback'},
    profileRoot: join(root, 'profiles'), port: 18789,
    storage: {databasePath: join(root, 'account.sqlite'), encryptionKeyPath: join(root, 'storage.key'),
      keyId: 'fixture-key', maxRows: 10000, maxTtlSeconds: 900, maxPayloadBytes: 65536},
    secrets: {jwksPath: join(root, 'jwks.json'), cookieKeysPath: join(root, 'cookies.json'),
      tlsKeyPath: join(root, 'key.pem'), tlsCertPath: join(root, 'cert.pem')}};
  const key = randomBytes(32);
  const put = (path, value) => {writeFileSync(path, value, {mode: 0o600}); chmodSync(path, 0o600);};
  put(config.storage.encryptionKeyPath, key); put(config.secrets.jwksPath, JSON.stringify(jwks));
  put(config.secrets.cookieKeysPath, JSON.stringify(['fixture-cookie-'.repeat(6)]));
  put(config.secrets.tlsKeyPath, tls.key); put(config.secrets.tlsCertPath, tls.cert);
  const db = new DatabaseSync(config.storage.databasePath);
  if (schema) initializeStorage(db);
  if (schema && bind) createEncryptedStore({db, key, keyId: config.storage.keyId});
  db.close(); chmodSync(config.storage.databasePath, 0o600);
  const path = join(root, 'config.json'), save = () => put(path, JSON.stringify(config)); save();
  const state = {calls: [], options: undefined}; let finish;
  const completion = new Promise(resolve => {finish = resolve;});
  const fake = {async listen() {state.calls.push('listen'); return {browser: {address: '127.0.0.1', port: config.port}};},
    async close() {state.calls.push('close'); state.options.browser.store.state.get('login', 'fixture-check'); finish({ok: true});}, completion};
  const runtimeFactory = async options => {state.calls.push('construct'); state.options = options; return fake;};
  const start = async () => {const runtime = await bootstrapRuntime(path, {runtimeFactory}); t.after(() => runtime.close().catch(() => {})); return runtime;};
  return {root, path, config, key, put, save, state, fake, runtimeFactory, start, finish};
}
async function denied(f, code) {
  await assert.rejects(f.start(), error => error instanceof BootstrapError && (!code || error.code === code) &&
    !error.message.includes(f.root) && !error.message.includes(f.config.selected.accountId));
  assert.deepEqual(f.state.calls, []);
}
function editDatabase(f, fn) {const db = new DatabaseSync(f.config.storage.databasePath); try {fn(db);} finally {db.close();}}

test('private bootstrap assembles browser-only options without listening and closes the DB after runtime', async t => {
  const f = fixture(t), before = readFileSync(f.config.storage.databasePath);
  const runtime = await f.start();
  assert.deepEqual(f.state.calls, ['construct']);
  assert.deepEqual(Object.keys(f.state.options), ['browser']);
  assert.deepEqual(f.state.options.browser.selected, f.config.selected);
  assert.equal(f.state.options.browser.cookieKeys[0], 'fixture-cookie-'.repeat(6));
  assert.equal(f.state.options.browser.tls.key.toString(), tls.key.toString());
  assert.equal((await runtime.listen()).browser.port, f.config.port);
  await runtime.close(); await runtime.close();
  assert.deepEqual(f.state.calls, ['construct', 'listen', 'close']);
  assert.deepEqual(await runtime.completion, {ok: true});
  assert.throws(() => f.state.options.browser.store.state.get('login', 'fixture-check'));
  assert.ok(f.state.options.browser.tls.key.every(byte => byte === 0));
  assert.deepEqual(readFileSync(f.config.storage.databasePath), before);
});

test('an explicitly existing empty schema binds approved key/bounds without applying schema', async t => {
  const f = fixture(t, {bind: false}), runtime = await f.start(); await runtime.close();
  editDatabase(f, db => {assert.equal(db.prepare('SELECT count(*) AS n FROM relay_link_config').get().n, 1);
    assert.equal(db.prepare('SELECT key_id FROM relay_link_config').get().key_id, 'fixture-key');});
});

test('missing schema fails without initialization', async t => {
  const f = fixture(t, {schema: false}); await denied(f, 'EXISTING_SCHEMA_REQUIRED');
  editDatabase(f, db => assert.equal(db.prepare('SELECT count(*) AS n FROM sqlite_schema').get().n, 0));
});

test('a missing database is never created', async t => {
  const f = fixture(t); rmSync(f.config.storage.databasePath); await denied(f);
  assert.equal(existsSync(f.config.storage.databasePath), false);
  assert.equal(readdirSync(f.root).some(name => name.startsWith('account.sqlite')), false);
});

test('empty config binding cannot erase preexisting revocation tombstones', async t => {
  const f = fixture(t, {bind: false});
  editDatabase(f, db => db.prepare('INSERT INTO relay_link_revoked_grants VALUES (?, ?)').run('fixture-hash', 1));
  await denied(f); editDatabase(f, db => assert.equal(db.prepare('SELECT count(*) AS n FROM relay_link_config').get().n, 0));
});

test('wrong encryption key and changed bound limits do not rewrite storage binding', async t => {
  for (const change of ['key', 'bounds']) await t.test(change, async child => {
    const f = fixture(child), before = readFileSync(f.config.storage.databasePath);
    if (change === 'key') f.put(f.config.storage.encryptionKeyPath, randomBytes(32)); else {f.config.storage.maxRows = 9999; f.save();}
    await denied(f); assert.deepEqual(readFileSync(f.config.storage.databasePath), before);
  });
});

test('altered schema, unexpected triggers and extra application tables fail closed', async t => {
  for (const sql of ['DROP INDEX relay_link_session_uid', 'CREATE TRIGGER unexpected AFTER INSERT ON relay_link_config BEGIN SELECT 1; END',
    'CREATE TABLE unexpected(x)']) await t.test(sql.split(' ').slice(0, 3).join(' '), async child => {
    const f = fixture(child); editDatabase(f, db => db.exec(sql)); await denied(f, 'EXISTING_SCHEMA_REQUIRED');
  });
});

test('unrecognized configuration, hooks and missing exact worker identities are rejected', async t => {
  for (const change of ['events', 'hookModule', 'storage-extra', 'worker-missing', 'worker-name', 'port-zero', 'port-default', 'ttl-extension', 'origin-http']) {
    await t.test(change, async child => {
      const f = fixture(child);
      if (change === 'events') f.config.events = {enabled: true};
      if (change === 'hookModule') f.config.hookModule = '/fixture/hooks.mjs';
      if (change === 'storage-extra') f.config.storage.initialize = true;
      if (change === 'worker-missing') delete f.config.selected.accountId;
      if (change === 'worker-name') f.config.selected.agentId = 'dot';
      if (change === 'port-zero') f.config.port = 0;
      if (change === 'port-default') delete f.config.port;
      if (change === 'ttl-extension') f.config.storage.maxTtlSeconds = 901;
      if (change === 'origin-http') f.config.origin = 'http://localhost';
      f.save(); await denied(f);
    });
  }
});

test('canonical absolute paths and private parent ownership/modes are required', async t => {
  for (const change of ['relative', 'alias', 'parent-public', 'ancestor-write', 'profile-public', 'config-public', 'key-public', 'database-public']) {
    await t.test(change, async child => {
      const f = fixture(child);
      if (change === 'relative') f.config.storage.encryptionKeyPath = 'storage.key';
      if (change === 'alias') f.config.storage.encryptionKeyPath = `${f.root}/./storage.key`;
      if (change === 'parent-public') chmodSync(f.root, 0o755);
      if (change === 'ancestor-write') {
        const nested = join(f.root, 'nested'); mkdirSync(nested, {mode: 0o700});
        const dest = join(nested, 'storage.key'); renameSync(f.config.storage.encryptionKeyPath, dest); f.config.storage.encryptionKeyPath = dest;
        chmodSync(f.root, 0o720);
      }
      if (change === 'profile-public') chmodSync(f.config.profileRoot, 0o755);
      if (change === 'config-public') chmodSync(f.path, 0o644);
      if (change === 'key-public') chmodSync(f.config.storage.encryptionKeyPath, 0o644);
      if (change === 'database-public') chmodSync(f.config.storage.databasePath, 0o644);
      if (!['config-public', 'parent-public', 'ancestor-write'].includes(change)) f.save();
      else if (change === 'ancestor-write') writeFileSync(f.path, JSON.stringify(f.config));
      await denied(f);
    });
  }
});

test('symlinked or hard-linked secrets and unsafe existing SQLite sidecars are rejected', async t => {
  for (const change of ['symlink', 'hardlink', 'journal-link', 'wal-public']) await t.test(change, async child => {
    const f = fixture(child), path = f.config.storage.encryptionKeyPath;
    if (change === 'symlink') {renameSync(path, `${path}.actual`); symlinkSync(`${path}.actual`, path);}
    if (change === 'hardlink') linkSync(path, `${path}.copy`);
    if (change === 'journal-link') symlinkSync(path, `${f.config.storage.databasePath}-journal`);
    if (change === 'wal-public') {f.put(`${f.config.storage.databasePath}-wal`, 'fixture'); chmodSync(`${f.config.storage.databasePath}-wal`, 0o644);}
    await denied(f);
  });
});

test('missing, oversized and malformed secret material does not reach the runtime', async t => {
  for (const change of ['missing-key', 'short-key', 'oversized-config', 'bad-jwks', 'public-jwk', 'bad-cookie', 'bad-tls', 'different-tls-key']) {
    await t.test(change, async child => {
      const f = fixture(child);
      if (change === 'missing-key') rmSync(f.config.storage.encryptionKeyPath);
      if (change === 'short-key') f.put(f.config.storage.encryptionKeyPath, randomBytes(31));
      if (change === 'oversized-config') f.put(f.path, ' '.repeat(65537));
      if (change === 'bad-jwks') f.put(f.config.secrets.jwksPath, '{');
      if (change === 'public-jwk') {const value = structuredClone(jwks); delete value.keys[0].d; f.put(f.config.secrets.jwksPath, JSON.stringify(value));}
      if (change === 'bad-cookie') f.put(f.config.secrets.cookieKeysPath, '["short"]');
      if (change === 'bad-tls') f.put(f.config.secrets.tlsKeyPath, 'private-do-not-log');
      if (change === 'different-tls-key') {
        const {privateKey} = generateKeyPairSync('ec', {namedCurve: 'P-256'});
        f.put(f.config.secrets.tlsKeyPath, privateKey.export({format: 'pem', type: 'pkcs8'}));
      }
      await denied(f);
    });
  }
});

test('one private database cannot back overlapping runtime instances', async t => {
  const f = fixture(t), first = await f.start();
  await assert.rejects(bootstrapRuntime(f.path, {runtimeFactory: f.runtimeFactory}), BootstrapError);
  assert.deepEqual(f.state.calls, ['construct']); await first.close();
});

test('runtime construction failure sanitizes error and releases database', async t => {
  const f = fixture(t);
  await assert.rejects(bootstrapRuntime(f.path, {runtimeFactory: async () => {throw new Error(`secret ${f.root}`);}}),
    error => error instanceof BootstrapError && !error.message.includes(f.root));
  const runtime = await f.start(); await runtime.close();
});

test('listen failure closes runtime and database with unhealthy completion', async t => {
  const f = fixture(t); f.fake.listen = async () => {throw new Error('secret-listen-detail');};
  const runtime = await f.start(); await assert.rejects(runtime.listen(), error => error.code === 'RUNTIME_LISTEN_FAILED');
  assert.deepEqual(await runtime.completion, {ok: false});
  assert.throws(() => f.state.options.browser.store.state.get('login', 'fixture-check'));
});

test('spontaneous unhealthy completion closes runtime and database', async t => {
  const f = fixture(t), runtime = await f.start(); f.finish({ok: false});
  assert.deepEqual(await runtime.completion, {ok: false}); assert.deepEqual(f.state.calls, ['construct', 'close']);
  assert.throws(() => f.state.options.browser.store.state.get('login', 'fixture-check'));
});

test('cleanup rejection still closes database and reports unhealthy completion', async t => {
  const f = fixture(t); f.fake.close = async () => {throw new Error('private-cleanup-detail');};
  const runtime = await f.start(); await assert.rejects(runtime.close(), error => error.code === 'RUNTIME_CLEANUP_FAILED');
  assert.deepEqual(await runtime.completion, {ok: false});
  assert.throws(() => f.state.options.browser.store.state.get('login', 'fixture-check'));
});

function cliFixture() {
  const lifecycle = new EventEmitter(), events = [], output = [], errors = []; let finish;
  const completion = new Promise(resolve => {finish = resolve;});
  const runtime = {async listen() {events.push('listen'); return {browser: {port: 18789}};}, async close() {events.push('close'); finish({ok: true});}, completion};
  return {lifecycle, events, output, errors, finish, runtime,
    options: {env: {RELAY_RUNTIME_CONFIG: '/private/config.json'}, args: [], lifecycle,
      output: {write: value => output.push(value)}, errorOutput: {write: value => errors.push(value)},
      bootstrap: async path => {assert.equal(path, '/private/config.json'); events.push('bootstrap'); return runtime;}}};
}
const settle = () => new Promise(resolve => setImmediate(resolve));

test('CLI listens explicitly, handles both shutdown signals once, and removes handlers', async () => {
  const f = cliFixture(); await startRuntimeCli(f.options); f.lifecycle.emit('SIGTERM'); f.lifecycle.emit('SIGINT'); await settle();
  assert.deepEqual(f.events, ['bootstrap', 'listen', 'close']);
  assert.deepEqual(f.output, ['Relay runtime listening on loopback TLS port 18789.\n']);
  assert.equal(f.lifecycle.listenerCount('SIGTERM'), 0); assert.equal(f.lifecycle.listenerCount('SIGINT'), 0);
});

test('CLI suppresses startup listening after signal received during bootstrap', async () => {
  const f = cliFixture(); f.options.bootstrap = async () => {f.lifecycle.emit('SIGTERM'); return f.runtime;};
  await startRuntimeCli(f.options); assert.deepEqual(f.events, ['close']); assert.deepEqual(f.output, []);
});

test('CLI fails with sanitized startup error and removes signal handlers', async () => {
  const f = cliFixture(); f.runtime.listen = async () => {throw new Error('secret-details');};
  await assert.rejects(startRuntimeCli(f.options), error => error.code === 'RUNTIME_START_FAILED' && !error.message.includes('secret'));
  assert.deepEqual(f.events, ['bootstrap', 'close']); assert.equal(f.lifecycle.listenerCount('SIGTERM'), 0);
});

test('CLI reports unhealthy lifecycle without leaking runtime details', async () => {
  const f = cliFixture(); await startRuntimeCli(f.options); f.finish({ok: false, detail: 'secret-details'}); await settle();
  assert.equal(f.lifecycle.exitCode, 1); assert.equal(f.errors.length, 1); assert.ok(!f.errors[0].includes('secret'));
});

test('CLI rejects unexpected arguments, missing config, and ambient module/fixture injection', async () => {
  for (const value of [{args: ['--fixture']}, {env: {}}, {env: {RELAY_RUNTIME_CONFIG: '/private/config.json', NODE_OPTIONS: '--inspect'}},
    {env: {RELAY_RUNTIME_CONFIG: '/private/config.json', NODE_PATH: '/modules'}},
    {env: {RELAY_RUNTIME_CONFIG: '/private/config.json', RELAY_FIXTURE_MCP_TOKEN: 'fixture'}}]) {
    const f = cliFixture(); await assert.rejects(startRuntimeCli({...f.options, ...value}), BootstrapError); assert.deepEqual(f.events, []);
  }
});

test('importing bootstrap and serve has no configuration, key generation, database or listen side effect', () => {
  const result = spawnSync(process.execPath, ['--input-type=module', '-e',
    `await import(${JSON.stringify(new URL('../bootstrap.mjs', import.meta.url).href)}); await import(${JSON.stringify(new URL('../serve.mjs', import.meta.url).href)});`],
    {env: {...process.env, RELAY_RUNTIME_CONFIG: '/missing/private/config.json'}, encoding: 'utf8', timeout: 5000});
  assert.equal(result.status, 0); assert.equal(result.stdout, '');
  assert.ok(!result.stderr.includes('startup failed'));
});


test('real private bootstrap and CLI serve local TLS discovery with no worker login or Chromium', async t => {
  const f = fixture(t), probe = createServer();
  await new Promise((resolve, reject) => {probe.once('error', reject); probe.listen(0, '127.0.0.1', resolve);});
  const port = probe.address().port;
  await new Promise((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  f.config.port = port; f.save();
  const lifecycle = new EventEmitter(), messages = [];
  const runtime = await startRuntimeCli({env: {RELAY_RUNTIME_CONFIG: f.path}, args: [], lifecycle,
    output: {write: message => messages.push(message)}, errorOutput: {write: message => messages.push(message)}});
  t.after(() => runtime.close().catch(() => {}));
  const result = await new Promise((resolve, reject) => {
    const req = request({hostname: '127.0.0.1', port, servername: 'localhost', ca: tls.cert,
      path: '/.well-known/openid-configuration', headers: {host: 'localhost'}}, res => {
      const parts = []; res.on('data', chunk => parts.push(chunk)); res.on('error', reject);
      res.on('end', () => resolve({status: res.statusCode, body: JSON.parse(Buffer.concat(parts).toString('utf8'))}));
    }); req.on('error', reject); req.end();
  });
  assert.equal(result.status, 200); assert.equal(result.body.issuer, 'https://localhost');
  assert.deepEqual(messages, [`Relay runtime listening on loopback TLS port ${port}.\n`]);
  lifecycle.emit('SIGTERM'); assert.deepEqual(await runtime.completion, {ok: true});
  assert.deepEqual(readdirSync(f.config.profileRoot), []);
});

function messagingFixture(t, {schema = true, state} = {}) {
  const f = fixture(t);
  f.config.version = 2;
  f.config.messaging = {enabled:true, origin:'https://events.localhost', port:18790, runId:'fixture-run',
    client:{id:'fixture-messaging-client', name:'Message fixture', redirectUri:'https://messages.example.invalid/callback'},
    databasePath:join(f.root, 'events.sqlite'), allowedCallbackHosts:['callback.example.invalid'], intervalMs:15000,
    messageRead:true, messageSend:true, ingestion:true};
  const db = new DatabaseSync(f.config.messaging.databasePath);
  if (schema) db.exec('CREATE TABLE relay_state (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL)');
  if (state) db.prepare('INSERT INTO relay_state VALUES (1, ?)').run(JSON.stringify(state));
  db.close(); chmodSync(f.config.messaging.databasePath, 0o600); f.save();
  const close = f.fake.close;
  f.fake.close = async () => {f.state.options.events.store.read(); await close();};
  return f;
}
function editEvents(f, fn) {const db = new DatabaseSync(f.config.messaging.databasePath); try {fn(db);} finally {db.close();}}

test('v2 maps explicit messaging JSON to concrete runtime options and closes both databases after runtime', async t => {
  const state = {subscriptions:{}, work:{}, deliveries:{}, paused:{}}, f = messagingFixture(t, {state});
  const before = readFileSync(f.config.messaging.databasePath), runtime = await f.start();
  const events = f.state.options.events;
  assert.deepEqual(Object.keys(f.state.options).sort(), ['browser', 'events']);
  assert.deepEqual(events.binding, {...f.config.selected, runId:f.config.messaging.runId});
  assert.deepEqual(events.client, f.config.messaging.client);
  assert.equal(events.origin, f.config.messaging.origin); assert.equal(events.port, f.config.messaging.port);
  assert.equal(events.ingestion, true); assert.equal(events.messageRead, true); assert.equal(events.messageSend, true);
  assert.deepEqual(events.allowedCallbackHosts, ['callback.example.invalid']); assert.equal(events.intervalMs, 15000);
  assert.equal(Object.hasOwn(events, 'hooks'), false); assert.equal(Object.hasOwn(events, 'issuers'), false);
  assert.deepEqual(events.store.read(), state);
  await runtime.close(); assert.deepEqual(await runtime.completion, {ok:true});
  assert.throws(() => events.store.read()); assert.throws(() => f.state.options.browser.store.state.get('login', 'fixture-check'));
  assert.deepEqual(readFileSync(f.config.messaging.databasePath), before);
});

test('v2 rejects incomplete, cross-bound, injected and nonexplicit messaging settings', async t => {
  const changes = {
    'missing-config': f => delete f.config.messaging,
    'unsupported-version': f => f.config.version = 3,
    'legacy-version-with-messaging': f => f.config.version = 1,
    'same-origin': f => f.config.messaging.origin = f.config.origin,
    'http-origin': f => f.config.messaging.origin = 'http://events.localhost',
    'same-port': f => f.config.messaging.port = f.config.port,
    'ephemeral-port': f => f.config.messaging.port = 0,
    'missing-run': f => delete f.config.messaging.runId,
    'empty-run': f => f.config.messaging.runId = '',
    'extra-account': f => f.config.messaging.accountId = f.config.selected.accountId,
    'injected-hooks': f => f.config.messaging.hooks = {},
    'injected-issuer': f => f.config.messaging.issuers = ['https://other.invalid'],
    'injected-manager': f => f.config.messaging.receipts = {enabled:true},
    'missing-client': f => delete f.config.messaging.client,
    'same-client-id': f => f.config.messaging.client.id = f.config.client.id,
    'http-callback': f => f.config.messaging.client.redirectUri = 'http://client.invalid/callback',
    'missing-enabled': f => delete f.config.messaging.enabled,
    'disabled-read': f => f.config.messaging.messageRead = false,
    'disabled-send': f => f.config.messaging.messageSend = false,
    'disabled-ingestion': f => f.config.messaging.ingestion = false,
    'empty-allowlist': f => f.config.messaging.allowedCallbackHosts = [],
    'wildcard-allowlist': f => f.config.messaging.allowedCallbackHosts = ['*.invalid'],
    'URL-allowlist': f => f.config.messaging.allowedCallbackHosts = ['https://callback.invalid'],
    'duplicate-allowlist': f => f.config.messaging.allowedCallbackHosts.push('callback.example.invalid'),
    'unbounded-interval': f => f.config.messaging.intervalMs = 60001,
    'same-provider-db': f => f.config.messaging.databasePath = f.config.storage.databasePath,
    'same-secret-path': f => f.config.messaging.databasePath = f.config.storage.encryptionKeyPath,
    'same-config-path': f => f.config.messaging.databasePath = f.path,
  };
  for (const [name, change] of Object.entries(changes)) await t.test(name, async child => {
    const f = messagingFixture(child); change(f); f.save(); await denied(f);
  });
});

test('v2 requires the exact preexisting event schema without creating or repairing storage', async t => {
  for (const kind of ['missing-file', 'no-schema', 'missing-table', 'extra-table', 'extra-trigger', 'altered-table', 'invalid-state']) await t.test(kind, async child => {
    const f = messagingFixture(child, {schema:kind !== 'no-schema'}), path = f.config.messaging.databasePath;
    if (kind === 'missing-file') rmSync(path);
    if (kind === 'missing-table') editEvents(f, db => db.exec('DROP TABLE relay_state'));
    if (kind === 'extra-table') editEvents(f, db => db.exec('CREATE TABLE unexpected(x)'));
    if (kind === 'extra-trigger') editEvents(f, db => db.exec('CREATE TRIGGER unexpected AFTER INSERT ON relay_state BEGIN SELECT 1; END'));
    if (kind === 'altered-table') editEvents(f, db => db.exec('DROP TABLE relay_state; CREATE TABLE relay_state(id INTEGER PRIMARY KEY, body TEXT NOT NULL)'));
    if (kind === 'invalid-state') editEvents(f, db => db.prepare('INSERT INTO relay_state VALUES (1, ?)').run('{'));
    const before = existsSync(path) ? readFileSync(path) : undefined;
    await denied(f);
    if (before) assert.deepEqual(readFileSync(path), before); else assert.equal(existsSync(path), false);
  });
});

test('v2 refuses unsafe event files and sidecars without chmod or replacement', async t => {
  for (const kind of ['public-file', 'symlink', 'hardlink', 'public-wal', 'journal-symlink']) await t.test(kind, async child => {
    const f = messagingFixture(child), path = f.config.messaging.databasePath;
    if (kind === 'public-file') chmodSync(path, 0o644);
    if (kind === 'symlink') {renameSync(path, path + '.actual'); symlinkSync(path + '.actual', path);}
    if (kind === 'hardlink') linkSync(path, path + '.other');
    if (kind === 'public-wal') {f.put(path + '-wal', 'fixture'); chmodSync(path + '-wal', 0o644);}
    if (kind === 'journal-symlink') symlinkSync(f.config.storage.encryptionKeyPath, path + '-journal');
    await denied(f);
  });
});

test('v2 event DB independently prevents overlap even with separate provider databases', async t => {
  const first = messagingFixture(t), second = messagingFixture(t), runtime = await first.start();
  second.config.messaging.databasePath = first.config.messaging.databasePath; second.save();
  await denied(second); await runtime.close();
  const next = await second.start(); await next.close();
});

test('v2 constructor and cleanup failures release both exclusive database handles', async t => {
  const f = messagingFixture(t);
  await assert.rejects(bootstrapRuntime(f.path, {runtimeFactory:async () => {throw new Error('private detail');}}), BootstrapError);
  const runtime = await f.start();
  f.fake.close = async () => {throw new Error('private cleanup detail');};
  await assert.rejects(runtime.close(), error => error.code === 'RUNTIME_CLEANUP_FAILED');
  assert.deepEqual(await runtime.completion, {ok:false});
  assert.throws(() => f.state.options.events.store.read());
  editEvents(f, db => assert.equal(db.prepare('SELECT count(*) AS n FROM relay_state').get().n, 0));
  editDatabase(f, db => assert.equal(db.prepare('SELECT count(*) AS n FROM relay_link_config').get().n, 1));
});


test('real v2 JSON bootstrap and CLI keep both resources available before consent with no Relay request', {timeout:10000}, async t => {
  const f = messagingFixture(t), probes = [createServer(), createServer()];
  const ports = [];
  for (const server of probes) {
    await new Promise((resolve, reject) => {server.once('error', reject); server.listen(0, '127.0.0.1', resolve);});
    ports.push(server.address().port);
  }
  for (const server of probes) await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  f.config.port = ports[0]; f.config.messaging.port = ports[1]; f.config.messaging.intervalMs = 1000; f.save();
  const originalFetch = globalThis.fetch, calls = [], lifecycle = new EventEmitter(), messages = [];
  globalThis.fetch = async (...args) => {calls.push(args);throw new Error('No Relay request is authorized before consent');};
  let runtime;
  t.after(async () => {globalThis.fetch=originalFetch;await runtime?.close();});
  runtime = await startRuntimeCli({env:{RELAY_RUNTIME_CONFIG:f.path}, args:[], lifecycle,
    output:{write:message=>messages.push(message)}, errorOutput:{write:message=>messages.push(message)}});
  const get = async (port, path, secure) => new Promise((resolve, reject) => {
    const transport = secure ? request : httpRequest;
    const req = transport({hostname:'127.0.0.1', port, path, ...(secure ? {servername:'localhost',ca:tls.cert} : {}),
      headers:{host:secure ? 'localhost' : 'events.localhost'}}, res => {
      const chunks=[];res.on('data',chunk=>chunks.push(chunk));res.on('error',reject);
      res.on('end',()=>resolve({status:res.statusCode,body:JSON.parse(Buffer.concat(chunks).toString())}));
    });req.on('error',reject);req.end();
  });
  const discovery = await get(ports[1], '/.well-known/oauth-protected-resource/mcp', false);
  assert.equal(discovery.status,200);assert.equal(discovery.body.resource,'https://events.localhost/mcp');
  assert.deepEqual(discovery.body.authorization_servers,['https://localhost']);
  assert.deepEqual(discovery.body.scopes_supported,['relay:work','relay:read','relay:write']);
  await new Promise(resolve=>setTimeout(resolve,1150));
  assert.equal((await get(ports[1], '/.well-known/oauth-protected-resource/mcp', false)).status,200);
  assert.equal((await get(ports[0], '/.well-known/openid-configuration', true)).status,200);
  assert.deepEqual(calls,[]);
  assert.deepEqual(messages,[`Relay runtime listening on loopback TLS port ${ports[0]} and messaging loopback port ${ports[1]}.\n`]);
  lifecycle.emit('SIGTERM');assert.deepEqual(await runtime.completion,{ok:true});
  editEvents(f, db=>assert.equal(db.prepare('SELECT count(*) AS n FROM relay_state').get().n,0));
  assert.deepEqual(readdirSync(f.config.profileRoot),[]);
});

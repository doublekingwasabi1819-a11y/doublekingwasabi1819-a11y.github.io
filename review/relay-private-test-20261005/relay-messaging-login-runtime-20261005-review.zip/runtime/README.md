# Runtime interfaces

The production entrypoint is `serve.mjs`. Set `RELAY_RUNTIME_CONFIG` to an
administrator-controlled private JSON file and run it only after the exact
installation, credentials, callback policy and exposure have been approved.
No filled-in real configuration is included. Both example JSON files are
intentionally unusable. The existing independent review gate remains unresolved.

## Browser-only and explicit messaging

Version 1 (`config.example.json`) remains browser-only. Version 2
(`config.messaging.example.json`) adds one explicit `messaging` object:

- `enabled`, `messageRead`, `messageSend` and `ingestion` must all be `true`.
- `origin` is a distinct canonical HTTPS origin; `port` is a distinct loopback
  port. The messaging audience is exactly `origin + '/mcp'`.
- `client` is a separately registered OAuth client with its own exact ID, name
  and HTTPS callback. Its ID must differ from the browser client's ID.
- `runId` is the operator-selected current worker run. Workspace, account and
  agent IDs are inherited unchanged from `selected`; there is no second account
  selection, username fallback or inferred identity.
- `databasePath` points to an already-provisioned private event SQLite file.
- `allowedCallbackHosts` is a nonempty exact DNS hostname allowlist, with no
  wildcards, URLs or duplicate entries.
- `intervalMs` is between 1,000 and 60,000; the ordinary setting is 15,000.

Both resources use the original provider issuer (`origin` at the top level).
They have distinct clients, audiences, scopes and explicitly consented grants.
Browser consent grants only `browser:control`; it cannot read or send messages.
A messaging bearer cannot control the browser, and a raw Relay session is not an
MCP bearer. Each audience still requires fresh worker login and explicit consent.
Delegations last at most 15 minutes. There are no refresh tokens, background
login, lifetime extension or automatic consent renewal.

The programmatic entrypoint is `createRuntime({browser, events})`. `browser` uses
the existing linked-service options. `events` follows `EventsConfig` in
`contracts.d.ts`, including its own `client` and exact full worker/run binding.
Runtime rejects caller-supplied messaging `hooks` and `issuers`. It obtains the
six concrete hooks privately from the account-linking provider through compose,
and derives the sole issuer from the browser origin. Only the low-level
`createEventsService` interface accepts injected authority for isolated tests or
separately approved integrations.

## Message and work permissions

Unauthorized requests receive a `WWW-Authenticate` Bearer challenge containing
the exact protected-resource metadata URL and messaging scopes. A valid narrow
token receives HTTP 403 with `error="insufficient_scope"`, the required scopes
for that operation, and its original JSON-RPC error ID. This enables explicit
client reauthorization using the same issuer, following the
[MCP authorization challenge format](https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization).

Every request verifies the actual provider access-token and grant records, exact
resource, scopes, expiry, revocation, pinned worker/run and live Relay session.
The provider rechecks relevant authorization around source calls; the runtime
rechecks request credentials after the operation. No request field or display
name supplies identity or authority.

- Discovery, subscription, work status and message fetch: `relay:work relay:read`
- Message send: `relay:work relay:write`
- Same-audience reply: `relay:work relay:read relay:write`
- Work pause and transition: `relay:work`
- Explicit message ACK: `relay:work relay:read`, plus the existing fetched receipt
- Notification ingestion: all three messaging scopes

Event subscriptions are capped at the authenticated access token’s absolute
expiry. Caller-supplied TTLs cannot extend that bound, and a later fresh consent
cannot revive an expired subscription. Each subscription is also bound to its
specific consent-grant fingerprint. Replacing or revoking that grant retires the
old callback even if its deadline has not elapsed; new consent requires a new
explicit subscription. Legacy subscriptions without that binding are denied.
Callback verification and continuing authority are rechecked before commit.
Request and ingestion operations retain their exact original consent across
asynchronous work-queue locks, so a newer grant cannot authorize an older
in-flight request or notification handoff.

The five browser tools are unchanged. The modern event resource exposes three
work tools and the four explicitly enabled message tools, using MCP Events
protocol `2026-07-28`. It does not install the old ten-tool controller patch.

## Consent-aware ingestion

Each serialized cycle fetches at most 100 explicit source notifications. It
commits a stable-ID work item before acknowledging durable source handoff. A
crash between those steps safely coalesces on retry. This source ACK does not
mean message read, agent ACK or completed work. Message fetch and explicit agent
ACK remain distinct, and agent ACK does not mark the source DM read.

When no active full-scope consent exists, the concrete resolver returns `null`.
The cycle reports `paused: true, reason: 'consent-required'`, without a Relay call,
source ACK, delivery tick or callback. Both listeners stay available for a new
explicit login and consent. A real authority outage throws and the scheduled
loop fails closed, retaining source notifications and queued work. The normal
15-second idle cycle costs no model invocation.

## Existing stores and lifecycle

Bootstrap validates canonical private file/directory ownership, permissions,
symlinks, hard links and SQLite sidecars. A dedicated non-root service user must
own the configured private files and their immediate directories. It opens only
existing files in SQLite `mode=rw`, validates each exact schema and integrity,
and takes a retained exclusive lock on both databases. It never creates a DB,
applies schema, changes file modes, migrates data or generates credentials.
An already-approved empty provider schema may bind its approved encryption key
and storage bounds through the existing encrypted-store factory. Event storage
uses the existing `relay_state` schema without calling its provisioning
constructor. It contains queue and receipt metadata plus callback secrets, so
its file remains private even though message bodies are excluded.

Construction does not listen or poll. Explicit `listen()` opens the browser's
loopback TLS socket and the messaging resource's loopback HTTP socket. The latter
still needs an independently configured HTTPS front end with exact Host/header
policy; this change does not create a proxy or public exposure. SIGINT/SIGTERM,
startup failure or terminal component failure closes both components before
bootstrap closes either database. Programmatic callers retain store ownership
and close them after runtime shutdown. Use one process, with no overlapping
replicas. A cleanup timeout is not proof that an uncooperative process has ended;
the existing supervisor process-group teardown requirement still applies.

## Manager receipts

The worker's queue records fetch and agent-ACK metadata, but JSON bootstrap does
not enable a manager endpoint or invent manager credentials. Programmatic
`receipts` remains a separate opt-in requiring verified manager/source-policy
hooks. The existing same-origin proxy factory and receipt UI remain included and
locally tested in receipt-ui/. Production binding of authenticateRelayManager
and readThroughAuthorizedService to an approved trust channel is still
unconfigured, as is its live same-origin endpoint. Do not forward browser credentials to a
second origin. No real ChatGPT callback, live deployment or production worker
has been exercised by the local fixtures.

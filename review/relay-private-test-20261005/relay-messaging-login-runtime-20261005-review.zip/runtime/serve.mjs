import {pathToFileURL} from 'node:url';
import {bootstrapRuntime, BootstrapError} from './bootstrap.mjs';

/** Explicit CLI only. Configuration and secrets never travel as command-line
 * values; RELAY_RUNTIME_CONFIG is only the absolute private JSON pathname.
 * The supervisor must still bound shutdown and kill its entire process group.
 */
export async function startRuntimeCli({args = process.argv.slice(2), env = process.env,
  output = process.stdout, errorOutput = process.stderr, lifecycle = process,
  bootstrap = bootstrapRuntime} = {}) {
  if (!Array.isArray(args) || args.length !== 0 || !env || typeof env.RELAY_RUNTIME_CONFIG !== 'string' ||
    ['NODE_OPTIONS', 'NODE_PATH', 'RELAY_FIXTURE_MCP_TOKEN'].some(name => env[name])) throw new BootstrapError('EXPLICIT_CONFIGURATION_REQUIRED');
  let runtime, stopRequested = false, cleanup;
  const shutdown = () => {
    stopRequested = true;
    if (!runtime) return Promise.resolve();
    if (!cleanup) cleanup = runtime.close();
    return cleanup;
  };
  const onSignal = () => {void shutdown().catch(() => {});};
  lifecycle.on('SIGTERM', onSignal); lifecycle.on('SIGINT', onSignal);
  const detach = () => {lifecycle.off('SIGTERM', onSignal); lifecycle.off('SIGINT', onSignal);};
  try {
    runtime = await bootstrap(env.RELAY_RUNTIME_CONFIG);
    if (stopRequested) {await shutdown(); detach(); return runtime;}
    void runtime.completion.then(outcome => {
      detach();
      if (outcome?.ok !== true) {
        lifecycle.exitCode = 1;
        errorOutput.write('Relay runtime stopped after lifecycle or cleanup failure.\n');
      }
    }, () => {
      detach(); lifecycle.exitCode = 1;
      errorOutput.write('Relay runtime stopped after lifecycle or cleanup failure.\n');
    });
    const {browser: address, events} = await runtime.listen();
    if (!stopRequested) {
      // Only an already-validated numeric loopback port is emitted, never origin,
      // selected account/client IDs, paths, credentials, or underlying errors.
      if (!Number.isInteger(address?.port) || address.port < 1 || address.port > 65535) throw new BootstrapError('INVALID_LISTEN_RESULT');
      if (events !== undefined && (!Number.isInteger(events?.port) || events.port < 1 || events.port > 65535 || events.port === address.port)) throw new BootstrapError('INVALID_LISTEN_RESULT');
      output.write(`Relay runtime listening on loopback TLS port ${address.port}${events ? ` and messaging loopback port ${events.port}` : ''}.\n`);
    }
    return runtime;
  } catch {
    await shutdown().catch(() => {}); detach();
    throw new BootstrapError('RUNTIME_START_FAILED');
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const runtime = await startRuntimeCli();
    void runtime.completion.then(outcome => {
      if (outcome?.ok !== true) process.stderr.write('Relay runtime requires supervisor cleanup.\n', () => process.exit(1));
    }, () => process.exit(1));
  }
  catch {process.stderr.write('Relay runtime startup failed. Review private configuration and service prerequisites.\n'); process.exitCode = 1;}
}

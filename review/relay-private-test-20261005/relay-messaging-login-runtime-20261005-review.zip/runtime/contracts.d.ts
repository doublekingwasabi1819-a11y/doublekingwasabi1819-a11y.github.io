/** Documentation-only TypeScript contracts. Runtime obtains concrete authority
 * from its actual account-linking provider. Browser consent cannot satisfy it.
 */
export type Scope = 'relay:work' | 'relay:read' | 'relay:write';
export type OAuthClient = Readonly<{id:string; name:string; redirectUri:string}>;
export type Binding = Readonly<{workspaceId:string; accountId:string; agentId:string; runId:string}>;
/** consentId is the provider-generated grant fingerprint, never client input. */
export type Context = Readonly<{reference:object; consentId:string; binding:Binding; signal?:AbortSignal}>;
export type Identity = Context & Readonly<{principalId:string; scopes:readonly Scope[]; expiresAt:number}>;
export type VerifiedRelay = Readonly<{binding:Binding; scopes:readonly Scope[]; call(action:string,data:unknown):Promise<unknown>}>;
export interface EventAuthorityHooks {
  /** Verify signature/introspection, explicit issuer+resource audience, expiry,
   * live revocation, consent and pinned worker/run. Return a stable reference
   * for the same credential. Never treat a raw Relay session, unverified JWT,
   * browser-only provider token, request field or display name as event consent.
   */
  authenticate(request:Request, policy:{resource:string; issuers:readonly string[]; signal:AbortSignal}):Promise<Identity>;
  /** Check the current explicit 15-minute messaging grant and live Relay run.
   * Work pause/transition require relay:work; read/subscription/discovery/enqueue
   * also require relay:read. Return false for denial and throw for outages.
   */
  authorizeContinuing(query:{principal:string; agent_id:string; action:'read'|'subscribe'|'enqueue'|'pause'|'execute'|'discover'; consentId?:string; subscription?:boolean; binding:Binding; signal:AbortSignal}):Promise<boolean>;
  /** Resolve only the existing separately approved Relay worker delegation.
   * Check requested scopes and exact binding before and after callback; keep
   * the underlying Relay session credential server-side and honor cancellation.
   */
  withAuthorizedRelay<T>(context:Context, policy:{scopes:Scope[];binding:Binding}, callback:(verified:VerifiedRelay)=>Promise<T>):Promise<T>;
  authorizeRead(query:{principal:string; agent_id:string; message:unknown; context:Context; scope:'relay:read'}):Promise<boolean>;
  authorizeRelay(context:Context, policy:{scopes:Scope[];binding:Binding;action?:string}):Promise<{binding:Binding; scopes:Scope[]}>;
  /** Resolve durable continuing ingestion consent independently of request
   * credentials. No silent renewal, new grant, login or account selection.
   */
  resolveIngestionContext(query:{binding:Binding;signal:AbortSignal}):Promise<Context|null>;
}
export interface EventStore {read():unknown; write(state:unknown):void; close():void}
export interface ManagerIdentity {id:string; role:'manager'; workspaceId:string}
export interface ReceiptHooks {
  enabled:true;
  authenticateManager(request:Request,options:{signal:AbortSignal}):Promise<ManagerIdentity|null>;
  authorizeManager(context:{identity:ManagerIdentity;signal:AbortSignal}):Promise<ManagerIdentity>;
  readMetadata(query:unknown):Promise<unknown>;
  authorizeAudit(query:unknown):Promise<boolean>;
  sourcePolicy(query:unknown):Promise<unknown>;
}
export interface EventsConfig {
  enabled:true; origin:string; client:OAuthClient; port?:number; binding:Binding;
  store:EventStore; allowedCallbackHosts:string[];
  messageRead:boolean; messageSend:boolean; ingestion:boolean;
  receipts?:ReceiptHooks; intervalMs?:number;
  /** Local test transport or separately reviewed secure implementation only.
   * Omit to use the existing DNS-pinned allowlisted HTTPS transport.
   */
  transport?:(request:unknown)=>Promise<unknown>;
}

/** Only low-level direct service use accepts authority injection. createRuntime
 * rejects these fields and supplies its concrete provider's hooks and issuer.
 */
export interface EventServiceConfig extends Omit<EventsConfig, 'client'> {
  issuers:string[];
  hooks:EventAuthorityHooks;
}
export interface PrivateMessagingConfig {
  enabled:true; origin:string; port:number; runId:string; client:OAuthClient;
  databasePath:string; allowedCallbackHosts:string[]; intervalMs:number;
  messageRead:true; messageSend:true; ingestion:true;
}

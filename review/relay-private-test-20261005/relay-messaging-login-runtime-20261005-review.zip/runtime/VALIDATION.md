# Local functional validation, 2026-10-05

Node 24.19.0. Changes are confined to the new messaging implementation working
copy. No published archive or immutable baseline was changed. No remote write,
live account linking, key provisioning, database migration, public exposure or
real worker message occurred. Temporary keys/accounts/databases below are local
fixtures only. The unresolved independent review gate remains unchanged; these
functional tests do not constitute security clearance.

## Passed

Runtime suite: **115/115**, zero failures, skips, cancellations or todos.

- **104 bootstrap cases** cover unchanged v1 behavior plus v2 strict JSON shape,
  distinct client/resource/port, exact selected run, all opt-ins, callback policy,
  preexisting exact event schema, malformed state, unsafe files/sidecars, no DB
  creation or chmod, independent exclusive event locking, constructor failure,
  cleanup failure and orderly closure of both DB handles.
- Real v1 default bootstrap → runtime → CLI → browser TLS discovery and SIGTERM.
- Real v2 default bootstrap → runtime → CLI → both resource listeners and
  same-issuer metadata, through a scheduled no-consent cycle with zero Relay
  requests, followed by SIGTERM and both database locks released.
- **Nine low-level event-service cases** cover exact scope metadata/enforcement,
  work-only pause, full-scope ingestion, no-consent idle behavior without Relay
  calls or callbacks, terminal shutdown on a real authority-hook outage, and
  zero post-expiry callback delivery even when continuing consent later permits it.
  Concurrent consent-replacement cases also prove an old request cannot mutate
  work and old ingestion cannot enqueue or ACK using a newer grant. OAuth
  challenge cases verify 401 resource metadata and operation-specific 403
  insufficient-scope challenges while preserving JSON-RPC error IDs.
- Runtime rejects caller-injected messaging hooks and issuer overrides.
- One integrated test uses the actual provider and two actual OAuth client flows
  against the real Edge handler and in-memory PostgreSQL (PGlite):
  - Separate browser and messaging consent, audiences and clients in one cookie
    jar; browser grant survives messaging reconnect/revocation.
  - Cross-audience bearers and raw Relay sessions rejected, with resource
    discovery metadata in the HTTP challenge; narrow scopes receive explicit
    HTTP 403 reauthorization challenges.
  - Unchanged five browser tools and seven modern work/message tools.
  - Explicit private/public notification ingestion and signed callback pings.
  - Subscription expiry matches the actual provider access-token expiry, rather
    than inheriting the event engine’s longer default TTL.
  - Callback subscriptions bind the exact consent grant. A reconnect retires the
    prior callback; delivery resumes only after an explicit fresh subscription.
    The fixture clears only its per-agent cooldown to keep throttling from
    concealing incorrect delivery; actual OAuth grant authorization stays real.
  - Durable enqueue before source ACK, interrupted-ACK retry and deduplication.
  - Fetch plus explicit receipt-based ACK; no source DM read mutation.
  - Private/public same-audience replies, wrong-audience reply rejected.
  - Work-only, read-only and write-only reconnects enforce scope distinctions.
  - Revocation pauses ingestion without any further Relay call while listeners
    and the separate browser connection remain available.
  - No manager credentials or receipt proxy are fabricated.

Commands from the bundle root:

    RELAY_PGLITE_ROOT=/tmp/approved-fixture/node_modules/@electric-sql/pglite node --test runtime/test/*.test.mjs
    node --check runtime/bootstrap.mjs
    node --check runtime/events-service.mjs
    node --check runtime/runtime.mjs
    node --check runtime/serve.mjs
    node --check account-linking/compose.mjs

Dependencies are reused from already installed pinned local packages; this is
not a fresh npm install/audit. The integrated fixture's global fetch admits only
the exact Relay endpoint and routes it into the real local Edge handler/SQL; it
cannot reach the live backend. Callback delivery is mocked, but signing and the
engine's durable state transitions are real. Authority injection exists only in
the explicitly identified low-level unit cases, not the combined runtime case.

## Not established

- Independent source/security clearance or permission to deploy.
- Real ChatGPT registration, account linking, callback handshake, model wakeup
  or tool invocation; real callback DNS, TLS, acceptance and delivery.
- Production worker IDs/run, signing/TLS material or operator database contents.
- A production manager authority, same-origin manager receipt proxy or UI wiring.
- Public HTTPS proxy configuration, supervisor behavior or full process-group
  teardown in a real installation.
- A fresh combined-service Chromium launch/action test. Existing browser
  controller tests are separate from this runtime validation.

Programmatic event stores remain caller-owned. Private JSON bootstrap owns both
open handles and closes the runtime before either database, including failure
paths. It validates before taking a write lock so rejected empty/invalid event
files are not initialized. It revalidates under the retained exclusive lock.

# Relay account-linking implementation: browser and messaging

This is tested source, not a deployed connection. It adds a real, pinned
`oidc-provider@9.12.2` authorization-code flow to the previously prepared Relay
production host at controller commit `b568da1ce0fde90d49a51e73f3ae90cc23c0732a`.
It does not modify the pinned controller or existing `production/` files.


## Messaging extension in this unified bundle

The former browser-only provider now has an explicitly configured second OAuth
client and audience for messaging. Browser-only configuration and its five tools
remain the default. The actual same-provider message hooks are implemented in
`message-authority.mjs`; runtime obtains them directly, never from a JSON hook
module or caller-supplied authentication substitute.

Messaging consent uses sorted subsets of `relay:read relay:work relay:write`,
with `relay:work` required. The messaging resource and client are distinct from
the browser resource/client, while both share the same issuer. Each requires
fresh exact-worker authentication and explicit consent. The provider retains a
short-lived pseudonymous subject only when the verified worker/run is unchanged;
pending logins have independent one-use IDs, and separate clients retain separate
grants. No manager credential is substituted.

`createRelayAccountLinking` accepts an explicit `messaging` object containing
`resource`, full `binding` and its own `client`. It exposes private in-process
`messageHooks` for token authentication, continuing consent, scoped Relay calls,
read/source authorization and ingestion context. The hooks verify actual provider
records plus encrypted immutable scoped grants and the live custom Relay session.
The facade cannot call unrequested actions, expand its declared scope or retain
access after its callback ends. It never exposes the Relay token.

`store.messagingDelegations` implements encrypted put/get/find/destroy by exact
worker/run/client/resource. New explicit consent atomically tombstones its prior
grant for that same binding. Audience/scope changes cannot remap an existing ID.
No schema change or refresh-token model was added. Both request and continuing
consent stop at the same original 15-minute limit. Runtime separately caps event
subscription expiry at that deadline and pauses ingestion when consent is absent.

The source client permits only `messages.capabilities`, `messages.get`,
`messages.send`, `messages.notifications` and `messages.notifications.ack` through
the fixed Relay backend URL. The proposed backend independently enforces public
workspace/private participant-and-manager visibility, explicit notification
recipients, stable-client-ID deduplication and same-audience replies. Source
handoff does not mark a message read or acknowledge it on the agent's behalf.

The real provider-to-events-to-proposed-SQL integration and private JSON bootstrap
are in `runtime/test/`; read the bundle's root validation for current results.
No live credentials, grants, accounts or deployment were configured. The blocked
independent final review remains incomplete and was not retried.

## Browser behavior preserved

- Genuine TLS requests to provider discovery, worker login, explicit consent,
  S256 PKCE authorization-code exchange, introspection and revocation.
- Actual provider token verification through the existing OAuth bridge and
  production host, returning precisely its five browser tools.
- Exactly one configured worker account and agent ID, resolved from a live
  worker login/context. A name such as **dot** never substitutes for backend
  IDs; no manager session, Supabase Auth token or copied human browser profile
  can be selected.
- Fresh sign-in and explicit `browser:control` consent on each authorization.
  Same-browser reconnect uses the provider's standard one-use CSRF-protected
  account-switch continuation, which revokes the previous authority.
- Server-only encrypted durable SQLite provider state and Relay delegation.
  Passwords are never persisted, returned in HTML, or written to logs. The
  user's login UI stores neither Relay nor OAuth access tokens. The existing
  controller separately injects the delegated Relay token into its isolated
  server-side worker browser as required by the unchanged Relay app.
- Authorization code replay is atomic across two SQLite connections. Grant
  tombstones survive restart and cannot be cleared by stale writes. Token,
  subject, client, worker, agent and run mappings remain immutable.
- Every MCP verification, binding resolution, action check and worker-session
  resolution checks the live Relay session. A local revocation committed during
  the remote check is rechecked before returning authority.
- Tokens/delegation last at most **15 minutes**, bounded further by the Relay
  session's original expiry. There are no refresh tokens or silent renewals.
  Reconnection requires fresh sign-in and consent. This deliberately limited
  first version is not an always-on worker messaging connection.

The browser audience enables no direct Relay-message tools or messaging scopes.
The separately consented messaging audience described above does enable them.
The provider also advertises the standard `openid` sign-in scope, which ChatGPT
may request automatically. It returns only a temporary pseudonymous subject in
an ID token. It does not reveal email/name or add any Relay permission; that ID
token is rejected by the browser resource, whose access scope stays browser-only.
Browser actions remain the pinned driver's fixed read-navigation controls and
masked screenshots; arbitrary typing, URLs, scripts and message sending are not
added by this package.

## Files and composition

- `relay-session.mjs`: fixed existing Relay API endpoint, worker-only login and
  strict live context validation. Workspace ID is an operator-selected deployment
  namespace because the current backend has a singleton studio, not a workspace
  ID API. The account/agent IDs and current run come from backend authentication.
- `storage.sql`: **local SQLite schema artifact**. No Supabase/Postgres migration
  is needed for this design, and no remote schema was changed.
- `storage.mjs`: explicit `initializeStorage(db)` and encrypted store factory.
  It does not open a DB or generate keys. `createEncryptedStore` accepts the
  already-open `DatabaseSync`, approved 32-byte key, key ID and bounded options.
  Pass `invalidGrant: () => new errors.InvalidGrant()` from the pinned provider.
- `provider.mjs`: actual protocol configuration, non-JavaScript login/consent
  forms, strict CSRF checks, single submission per interaction, and all six host
  authority/lifecycle hooks. It has no listening side effect. Public PKCE clients
  require one explicitly configured client ID, display name and exact HTTPS
  callback. There is no dynamic registration, wildcard callback or default client.
- `tls-entry.mjs`: bounded **TLS** listener on `127.0.0.1` only. Provider routes
  retain their query strings and secure cookies. MCP routes forbid cookies and
  query strings and always enter the authenticated production host. Host and
  forwarding-header claims are rejected. The listener never trusts a header as
  evidence of TLS.
- `compose.mjs`: `createLinkedRelayService(options)` joins the provider, unchanged
  production host and TLS entry. It takes explicit approved configuration and
  returns `listen`, `close`, `completion`. It does not read credentials, create a
  database, log in, generate keys or listen automatically.

The existing `production/serve.mjs`, `production/http-entry.mjs` and old disabled
nginx template **cannot** serve these account-linking routes unchanged. They use
plain loopback HTTP, reject OAuth query URLs and strip cookies. A final reviewed
runtime entry point and TLS upstream/proxy configuration must use this new
composition. No activation command or filled-in runtime configuration is included.

## Revocation and storage limits

Relay has no push revocation feed. The implementation makes fresh authority
checks on every operation and polls active browser contexts every **5 seconds**.
A remote check has a **4-second deadline**. An idle browser may therefore remain
open until the next completed poll (normally at most roughly 9 seconds, plus
bounded browser cleanup). This is polling, not instantaneous event delivery.
Failures deny the affected lease; cleanup failure marks the host unavailable.
The host and supervisor still own actual Chromium process termination.

Use exactly **one active provider/host process for one private database**. No
overlapping rolling replicas: startup and shutdown revoke every persisted grant
so a previous lease cannot be remapped to fresh process-local context objects.
Provider session/interaction state may survive only as non-authoritative state.
Reauthentication and new consent are still required.

Storage derives separate encryption/index keys from one fixed approved key.
AES-256-GCM binds ciphertext to model, identifier and indexed metadata. A different
key, key ID or bound configuration cannot silently reopen the same database.
File-backed databases require durable journaling and synchronous FULL/EXTRA.
Keep the database, journal/WAL, backups and private profile directories owned by
the dedicated service account with restrictive permissions, on a local filesystem.
The current factory validates SQLite durability, not filesystem ownership; the
operator-owned bootstrap must validate canonical file paths/modes/owners first.

The default store cap is 10,000 records including permanent revocation tombstones.
It fails closed at capacity instead of dropping revocation history. A separately
reviewed rotation/retention plan is required before long-running production use;
do not delete tombstones, change the key ID, or reset the database to make room.

## Verification

Node 24.19.0 was used. The new package has an exact dependency and lockfile.
Install only its locked dependencies with scripts disabled, in a separately
approved execution environment:

```sh
cd account-linking
npm ci --ignore-scripts
npm test
```

The tests use invented worker data, ephemeral local-only TLS/signing/encryption
keys, local TLS sockets and in-memory/temporary SQLite files. They do not contact
the live Relay API, start Chromium, create a real OAuth client/grant, or sign in
the real worker. Test TLS material is removed and is not part of this package.

At the local validation checkpoint:

- The historical browser-only checkpoint passed 57/57 tests. The updated
  account-linking suite passes 87/87; see root `VALIDATION.md` for the full bundle.
- Existing production foundation: 28/28 tests passed.
- Original 34-file controller checksum manifest still passes unchanged.
- Official npm audit returned zero reported vulnerabilities for this locked
  dependency set. This is not a security certification.
- Independent review identified introspection, shutdown and revocation races;
  targeted regressions now pass. The review stopped before final completion,
  and the newer TLS dispatcher/composition lacks completed independent final
  review. Treat that as an explicit deployment gate.

See the accompanying validation record for the final controller baseline result.

## Still needed before a live connection

1. Complete final source review and resource/abuse controls for the selected
   production topology. Validate the single-process model, storage retention,
   key custody, DB/profile permissions, final TLS proxy and service supervision.
2. Resolve the actual **dot worker's immutable account ID and agent ID** through
   authorized backend metadata or a worker-authenticated context. Do not copy
   a manager credential or choose by display name alone.
3. Choose the canonical HTTPS hostname and the actual callback shown by the
   created ChatGPT connection. Verify whether that connection supports this
   pre-registered **public PKCE client (`token_endpoint_auth_method=none`)**.
   Real ChatGPT interoperability is not yet tested; if confidential-client or
   CIMD registration is required, that is additional reviewed implementation.
4. Obtain specific approval for persistent access and key/client configuration.
   The operator must securely provide storage encryption, cookie-signing,
   provider-signing and TLS key material. Do not paste it into chat, source,
   a command-line argument, logs, Library, or a browser tool form filled by an
   assistant. User credential entry requires the secure handoff.
5. Approve the exact server installation, local SQLite schema application,
   service user/config and TLS/public exposure changes. The source does not
   authorize DNS, firewall, account, paid-service or deployment changes.
6. On the VM, install the exact reviewed files and locked dependencies; run the
   full baseline **244/244 mandatory Chromium gate**, these new tests, final
   service/TLS validation and real delegated-worker read-navigation tests.
7. With user approval, complete the worker login/consent and prove actual ChatGPT
   linking, tool invocation, timeout, revocation, reconnect and stop/restart
   cleanup. Keep the public endpoint disabled until required checks pass.

The existing Lightsail host can potentially run the same-host provider and
SQLite store; this code does not require a second paid service. Capacity and
Chromium sandbox compatibility still need measurement on that exact VM.

## Primary contracts checked

- [Pinned provider documentation](https://github.com/panva/node-oidc-provider/blob/v9.12.2/docs/README.md)
- [Pinned adapter interface](https://github.com/panva/node-oidc-provider/blob/v9.12.2/example/my_adapter.js)
- [Pinned opaque-token implementation](https://github.com/panva/node-oidc-provider/blob/v9.12.2/lib/models/formats/opaque.js)
- [Pinned authorization-code exchange](https://github.com/panva/node-oidc-provider/blob/v9.12.2/lib/actions/grants/authorization_code.js)
- [Pinned Relay backend authentication](https://github.com/doublekingwasabi1819-a11y/doublekingwasabi1819-a11y.github.io/blob/b568da1ce0fde90d49a51e73f3ae90cc23c0732a/backend/schema.sql)
- [OpenAI account-linking requirements](https://developers.openai.com/plugins/build/auth)

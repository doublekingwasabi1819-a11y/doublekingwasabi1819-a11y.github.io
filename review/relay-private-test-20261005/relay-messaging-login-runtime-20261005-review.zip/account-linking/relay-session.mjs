// Relay's existing opaque-session API. No Supabase Auth, service-role key,
// manager login, ambient browser credentials, or automatic session renewal.
export const RELAY_ENDPOINT = 'https://mukbnmewwoeweogmcuno.supabase.co/functions/v1/relay';
export const BROWSER_SCOPE = 'browser:control';
const uuid = value => typeof value === 'string' && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(value);
const opaque = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
const plain = value => value && Object.getPrototypeOf(value) === Object.prototype;
export const denied = ({transient = false} = {}) => Object.assign(new Error('The selected Relay worker is unavailable.'), {code: 'AUTH_REQUIRED', transient});
const check = (condition) => {if (!condition) throw denied();};
export function selectedWorker(value) {
  check(plain(value) && Object.keys(value).length === 3 && opaque(value.workspaceId) && uuid(value.accountId) && uuid(value.agentId));
  return Object.freeze({workspaceId: value.workspaceId, accountId: value.accountId.toLowerCase(), agentId: value.agentId.toLowerCase()});
}
export function sameBinding(a, b) {
  return a?.workspaceId === b?.workspaceId && a?.accountId === b?.accountId && a?.agentId === b?.agentId && a?.runId === b?.runId;
}
function worker(user, selected) {
  check(plain(user) && user.role === 'worker' && user.enabled === true &&
    typeof user.id === 'string' && user.id.toLowerCase() === selected.accountId &&
    typeof user.agentId === 'string' && user.agentId.toLowerCase() === selected.agentId);
}
function session(value, selected, now) {
  check(plain(value) && typeof value.token === 'string' && /^[a-f0-9]{64}$/.test(value.token) &&
    Number.isSafeInteger(value.expiresAt) && value.expiresAt > now());
  check(sameBinding(value, {...selected, runId: value.runId}) && opaque(value.runId));
}

/** No calls occur until login/check is explicitly invoked. `fetcher` is a
 * trusted test seam only; live composition uses global fetch to the fixed URL.
 * The configured selected worker must first be resolved from Relay backend
 * account IDs by an authorized operator. A display name such as 'dot' is never
 * an authority or a fallback. Workspace ID is an explicit deployment namespace;
 * the current Relay backend is a singleton studio and has no workspace ID API.
 */
export function createRelaySessionClient({selected, fetcher = fetch, now = Date.now, timeoutMs = 4000} = {}) {
  selected = selectedWorker(selected);
  check(typeof fetcher === 'function' && typeof now === 'function' && Number.isSafeInteger(timeoutMs) && timeoutMs >= 20 && timeoutMs <= 5000);
  async function call(action, data, token, signal) {
    const timeout = AbortSignal.timeout(timeoutMs);
    const abort = signal ? AbortSignal.any([signal, timeout]) : timeout;
    let response, reader, transient = true;
    try {
      abort.throwIfAborted();
      response = await fetcher(RELAY_ENDPOINT, {method: 'POST', redirect: 'error', credentials: 'omit', cache: 'no-store',
        headers: {'content-type': 'application/json', ...(token ? {authorization: `Bearer ${token}`} : {})},
        body: JSON.stringify({action, data}), signal: abort});
      abort.throwIfAborted();
      if (response instanceof Response && response.status !== 200) throw denied({transient: response.status === 429 || response.status >= 500});
      check(response instanceof Response && response.status === 200 && !response.redirected &&
        /^application\/json(?:;|$)/i.test(response.headers.get('content-type') || ''));
      const length = response.headers.get('content-length');
      check(length === null || /^\d+$/.test(length) && Number(length) <= 4_000_000);
      reader = response.body?.getReader(); check(reader);
      let total = 0; const chunks = [];
      while (true) {
        abort.throwIfAborted();
        const part = await reader.read(); if (part.done) break;
        total += part.value.length; check(total <= 4_000_000); chunks.push(part.value);
      }
      abort.throwIfAborted();
      const result = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if (plain(result) && Object.hasOwn(result, 'error')) throw denied({transient: !['AUTH', 'SESSION', 'STALE_SESSION', 'FORBIDDEN', 'DELETED'].includes(result.error?.code)});
      check(plain(result)); return result;
    } catch (error) {if (error?.code === 'AUTH_REQUIRED') throw error; throw denied({transient});}
    finally {if (reader) await reader.cancel().catch(() => {});}
  }
  async function checkSession(value, {signal} = {}) {
    session(value, selected, now);
    const context = await call('context', {}, value.token, signal);
    worker(context.user, selected);
    check(plain(context.actor) && context.actor.owner === false &&
      typeof context.actor.id === 'string' && context.actor.id.toLowerCase() === selected.agentId &&
      context.actor.session === value.runId);
    // The live SQL RPC independently rejects deleted/expired/disabled/stale
    // sessions. Reject mismatching returned board identity as defense in depth.
    check(Array.isArray(context.state?.agents));
    const agents = context.state.agents.filter(agent => agent?.id?.toLowerCase?.() === selected.agentId);
    check(agents.length === 1 && agents[0].enabled === true && agents[0].session === value.runId);
    session(value, selected, now); signal?.throwIfAborted();
    return Object.freeze({workspaceId: selected.workspaceId, accountId: selected.accountId,
      agentId: selected.agentId, runId: value.runId, token: value.token, expiresAt: value.expiresAt});
  }
  async function login({username, password}, {signal} = {}) {
    check(typeof username === 'string' && /^[a-z0-9][a-z0-9._-]{2,39}$/.test(username) &&
      typeof password === 'string' && [...password].length >= 12 && Buffer.byteLength(password) <= 72);
    // Role is fixed in trusted source; never accept it from the form/caller.
    const result = await call('login', {role: 'worker', username, password}, undefined, signal);
    worker(result.user, selected);
    check(typeof result.token === 'string' && /^[a-f0-9]{64}$/.test(result.token));
    check(typeof result.expiresAt === 'string');
    const expiresAt = Date.parse(result.expiresAt);
    check(Number.isSafeInteger(expiresAt) && expiresAt > now() && expiresAt <= now() + 24 * 3600_000 + 5000);
    const context = await call('context', {}, result.token, signal);
    worker(context.user, selected);
    check(plain(context.actor) && context.actor.owner === false && context.actor.id?.toLowerCase?.() === selected.agentId && opaque(context.actor.session));
    // A second check is intentional: never accept a login/context race that
    // silently switches identity or run. Neither password nor context is saved.
    return checkSession({...selected, runId: context.actor.session, token: result.token, expiresAt}, {signal});
  }
  async function message({session: value, action, data}, {signal} = {}) {
    session(value, selected, now);
    check(plain(data));
    const keys = Object.keys(data).sort().join(',');
    if (action === 'messages.capabilities') check(keys === '');
    else if (action === 'messages.get') check(keys === 'messageId' && uuid(data.messageId));
    else if (action === 'messages.notifications') check(keys === 'limit' && Number.isInteger(data.limit) && data.limit >= 1 && data.limit <= 100);
    else if (action === 'messages.notifications.ack') check(keys === 'notificationId' && uuid(data.notificationId));
    else if (action === 'messages.send') check(keys === 'command' && plain(data.command) &&
      data.command.senderId === selected.accountId && data.command.workspaceId === selected.workspaceId);
    else throw denied();
    // The authority facade checks consent/scopes before and after this call.
    // The existing backend independently checks the live opaque worker session
    // and message audience atomically. No arbitrary Relay action is exposed.
    const result = await call(action, data, value.token, signal);
    session(value, selected, now); signal?.throwIfAborted(); return result;
  }
  return Object.freeze({login, check: checkSession, message, selected});
}

import {createHash} from 'node:crypto';
import {denied, sameBinding} from './relay-session.mjs';

export const MESSAGE_SCOPES = Object.freeze(['relay:read', 'relay:work', 'relay:write']);
const plain = value => value && Object.getPrototypeOf(value) === Object.prototype;
const hash = value => createHash('sha256').update(value).digest('hex');
const must = value => {if (!value) throw denied();};
const uuid = value => typeof value === 'string' && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(value);
const scopeList = value => {
  must(typeof value === 'string');
  const result = value.split(' ').sort();
  must(result.includes('relay:work') && new Set(result).size === result.length && result.every(scope => MESSAGE_SCOPES.includes(scope)));
  return result;
};
const includes = (available, needed) => needed.every(scope => available.includes(scope));
const sameScopes = (a, b) => Array.isArray(a) && Array.isArray(b) && JSON.stringify([...a].sort()) === JSON.stringify([...b].sort());

/** Concrete authority for the separately consented message audience. Protocol
 * verification uses the same actual oidc-provider models as account linking;
 * a browser bearer, raw Relay token, or caller-created reference cannot enter.
 * `operation` is the bounded, fixed-endpoint Relay client owned by the provider.
 * Nothing is exposed as an HTTP endpoint or a model-supplied hook.
 */
export function createMessageAuthority({provider, store, issuer, resource, clientId, binding, operation, isClosed, now = Date.now} = {}) {
  if (!provider?.AccessToken || !provider?.Grant || !store?.messagingDelegations || typeof operation !== 'function' || typeof isClosed !== 'function') {
    throw new TypeError('Actual provider models, encrypted grants and the bound Relay client are required.');
  }
  binding = Object.freeze({...binding});
  const grants = store.messagingDelegations;
  const tokenRefs = new Map(), consentRefs = new Map(), known = new WeakMap();
  const active = signal => must(!isClosed() && !signal?.aborted);
  const find = () => grants.find({...binding, clientId, resource});
  function validate(d) {
    must(d && d.resource === resource && d.clientId === clientId && sameBinding(d, binding) &&
      Number.isSafeInteger(d.expiresAt) && d.expiresAt > now() && sameScopes(d.scopes, scopeList(d.scope)));
    return d;
  }
  function sameGrant(a, b) {
    return a && b && a.grantId === b.grantId && a.subject === b.subject && a.clientId === b.clientId &&
      a.resource === b.resource && a.token === b.token && a.expiresAt === b.expiresAt &&
      sameBinding(a, b) && sameScopes(a.scopes, b.scopes);
  }
  async function live(grantId, signal) {
    active(signal);
    const d = validate(grants.get(grantId)), grant = await provider.Grant.find(grantId);
    must(grant && !grant.isExpired && grant.accountId === d.subject && grant.clientId === clientId &&
      sameScopes(grant.getResourceScope(resource).split(' '), d.scopes));
    await operation('check', d, {signal});
    active(signal);
    const latest = validate(grants.get(grantId)); must(sameGrant(d, latest)); return latest;
  }
  function prune() {
    for (const registry of [tokenRefs, consentRefs]) for (const [id, record] of registry) {
      if (record.expiresAt <= now() || !grants.get(record.grantId)) {record.active = false; registry.delete(id);}
    }
  }
  function required(scopes) {
    must(Array.isArray(scopes) && scopes.length <= 3 && new Set(scopes).size === scopes.length && scopes.every(scope => MESSAGE_SCOPES.includes(scope)));
    return [...new Set(['relay:work', ...scopes])];
  }
  async function contextGrant(context, wanted) {
    active(context?.signal);
    must(plain(context) && sameBinding(context.binding, binding));
    const record = known.get(context.reference);
    must(record?.active && context.consentId === hash(record.grantId) && record.expiresAt > now() && includes(record.scopes, required(wanted)));
    if (record.tokenId) {
      const token = await provider.AccessToken.find(record.tokenId);
      must(token?.isValid && token.aud === resource && token.clientId === clientId && token.grantId === record.grantId &&
        token.accountId === record.subject && token.exp * 1000 === record.expiresAt && sameScopes(scopeList(token.scope), record.scopes));
    }
    const d = await live(record.grantId, context.signal);
    must(record.active && record.expiresAt > now() && d.subject === record.subject && includes(d.scopes, record.scopes));
    return {d, record};
  }
  const hooks = {
    async authenticate(request, policy) {
      active(policy?.signal);
      must(request instanceof Request && policy?.resource === resource && Array.isArray(policy.issuers) && policy.issuers.includes(issuer));
      const match = /^Bearer ([A-Za-z0-9_-]{32,128})$/.exec(request.headers.get('authorization') || ''); must(match);
      const raw = match[1], token = await provider.AccessToken.find(raw);
      must(token?.isValid && token.aud === resource && token.clientId === clientId && typeof token.grantId === 'string');
      const scopes = scopeList(token.scope), d = await live(token.grantId, policy.signal);
      must(token.accountId === d.subject && token.exp * 1000 <= d.expiresAt && includes(d.scopes, scopes));
      prune(); const id = hash(raw);
      let record = tokenRefs.get(id);
      if (!record) {
        must(tokenRefs.size < 64);
        record = {active: true, grantId: token.grantId, subject: token.accountId, tokenId: raw, scopes: Object.freeze(scopes),
          expiresAt: token.exp * 1000, reference: Object.freeze({messageLease: id})};
        tokenRefs.set(id, record); known.set(record.reference, record);
      }
      must(record.active && record.grantId === token.grantId && record.subject === token.accountId && record.expiresAt === token.exp * 1000 && sameScopes(record.scopes, scopes));
      active(policy.signal);
      return Object.freeze({principalId: binding.accountId, binding, reference: record.reference, consentId: hash(record.grantId), scopes: record.scopes, expiresAt: record.expiresAt});
    },
    async authorizeContinuing(query) {
      active(query?.signal);
      if (query?.principal !== binding.accountId || query.agent_id !== binding.agentId || !sameBinding(query.binding, binding) ||
        !['read', 'subscribe', 'enqueue', 'pause', 'execute', 'discover'].includes(query.action)) return false;
      const d = find(); if (!d) return false;
      if (query.subscription === true && query.consentId !== hash(d.grantId)) return false;
      const scopes = ['pause', 'execute'].includes(query.action) ? ['relay:work'] : ['relay:work', 'relay:read'];
      if (!includes(d.scopes, scopes)) return false;
      try {await live(d.grantId, query.signal); return true;}
      catch (error) {if (error?.transient || isClosed() || query.signal?.aborted) throw error; return false;}
    },
    async resolveIngestionContext({binding: wanted, signal} = {}) {
      active(signal); must(sameBinding(wanted, binding));
      const found = find();
      if (!found || !includes(found.scopes, MESSAGE_SCOPES)) return null;
      let d;
      try {d = await live(found.grantId, signal);} catch (error) {if (error?.transient || isClosed() || signal?.aborted) throw error; return null;}
      prune(); let record = consentRefs.get(d.grantId);
      if (!record) {
        must(consentRefs.size < 8);
        record = {active: true, grantId: d.grantId, subject: d.subject, scopes: Object.freeze([...d.scopes]), expiresAt: d.expiresAt,
          reference: Object.freeze({messageConsent: hash(d.grantId)})};
        consentRefs.set(d.grantId, record); known.set(record.reference, record);
      }
      return Object.freeze({reference: record.reference, binding, consentId: hash(record.grantId)});
    },
    async authorizeRelay(context, policy) {
      must(plain(policy) && sameBinding(policy.binding, binding));
      const {record} = await contextGrant(context, policy.scopes);
      return Object.freeze({binding, scopes: record.scopes});
    },
    async authorizeRead({principal, agent_id, message, context, scope} = {}) {
      must(principal === binding.accountId && agent_id === binding.agentId && scope === 'relay:read' && plain(message));
      await contextGrant(context, ['relay:read']);
      // The linked work metadata is server-owned. The source read separately
      // enforces database membership; this never trusts a caller's role/name.
      if (message.visibility === 'public') return message.workspaceId === binding.workspaceId;
      if (message.visibility === 'private') return uuid(message.senderId) && uuid(message.recipientId) &&
        message.senderId !== message.recipientId && [message.senderId, message.recipientId].includes(binding.accountId);
      return false;
    },
    async withAuthorizedRelay(context, policy, callback) {
      must(plain(policy) && sameBinding(policy.binding, binding) && typeof callback === 'function');
      const {record} = await contextGrant(context, policy.scopes);
      const allowed = Object.freeze(required(policy.scopes).sort());
      let open = true, called = false;
      const facade = Object.freeze({binding, scopes: allowed, call: async (action, data) => {
        must(open && !called); called = true;
        const actionScopes = action === 'messages.capabilities' ? policy.scopes :
          ['messages.get', 'messages.notifications'].includes(action) ? ['relay:read'] :
          action === 'messages.notifications.ack' ? ['relay:write'] :
          action === 'messages.send' ? (data?.command?.replyToMessageId ? ['relay:read', 'relay:write'] : ['relay:write']) : null;
        must(actionScopes && includes(allowed, required(actionScopes)));
        const {d} = await contextGrant(context, actionScopes);
        const result = await operation('message', {session: d, action, data}, {signal: context.signal});
        await contextGrant(context, actionScopes); must(open); return result;
      }});
      try {
        const result = await callback(facade);
        must(called); await contextGrant(context, policy.scopes); return result;
      } finally {open = false;}
    }
  };
  return Object.freeze(hooks);
}

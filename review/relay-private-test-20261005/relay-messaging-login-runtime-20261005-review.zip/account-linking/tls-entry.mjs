import {createServer} from 'node:https';
import {IncomingMessage} from 'node:http';

const MCP_PATHS = new Set(['/mcp', '/.well-known/oauth-protected-resource/mcp']);
const SINGLES = new Set(['host', 'authorization', 'content-type', 'content-length', 'origin', 'cookie', 'transfer-encoding', 'mcp-protocol-version']);
const blocked = name => name === 'forwarded' || name.startsWith('x-forwarded-') || ['x-real-ip', 'x-original-url', 'x-rewrite-url', 'expect', 'upgrade'].includes(name);
const failure = status => Object.assign(new Error('TLS request unavailable.'), {status});

/** Actual same-host TLS dispatch for account linking and the OAuth MCP host.
 * The caller supplies already-approved TLS keys/certificates. This factory
 * does not listen, read configuration, generate keys, or expose public ports.
 * A reviewed front end must connect using TLS, preserve exact Host, and strip
 * forwarding headers. Never route this provider through production/http-entry.
 */
export function createLoopbackTLSEntry({origin, accountLinking, application, tls, port = 8789} = {}) {
  const base = new URL(origin);
  if (base.origin !== origin || base.protocol !== 'https:' || base.username || base.password ||
    !accountLinking || typeof accountLinking.handle !== 'function' || typeof accountLinking.close !== 'function' ||
    !application || typeof application.fetch !== 'function' || typeof application.close !== 'function' ||
    !tls || !tls.key || !tls.cert || Object.keys(tls).some(key => !['key', 'cert'].includes(key)) ||
    !Number.isInteger(port) || port < 0 || port > 65535) throw new TypeError('Explicit TLS, origin, provider and MCP host are required.');
  const provider = accountLinking.handle.bind(accountLinking), fetch = application.fetch.bind(application);
  const providerClose = accountLinking.close.bind(accountLinking), hostClose = application.close.bind(application);
  const sockets = new Set(), running = new Set();
  let closed = false, started = false, closing, active = 0, failed = false, cancelStartup, finish;
  const completion = new Promise(resolve => {finish = resolve;});
  function reject(res, status) {
    if (res.destroyed) return;
    if (res.headersSent) return res.destroy();
    res.writeHead(status, {'content-type': 'application/json', 'cache-control': 'no-store', 'connection': 'close', 'x-content-type-options': 'nosniff'});
    res.end('{"error":"This connection is unavailable."}');
  }
  async function serve(req, res) {
    if (closed) return reject(res, 503);
    if (active >= 8) return reject(res, 429);
    active++; let timer, replay;
    try {
      if (req.socket.remoteAddress !== '127.0.0.1' || req.socket.encrypted !== true || !['GET', 'POST'].includes(req.method) ||
        typeof req.url !== 'string' || req.url.length > 4096 || !req.url.startsWith('/') || req.url.startsWith('//') || req.url.includes('#')) throw failure(400);
      const url = new URL(req.url, origin);
      if (url.origin !== origin || /(?:%2e|%2f|%5c|\\)/i.test(req.url.split('?')[0]) || url.pathname !== req.url.split('?')[0]) throw failure(400);
      const names = new Set(), headers = new Headers();
      for (let i = 0; i < req.rawHeaders.length; i += 2) {
        const name = req.rawHeaders[i].toLowerCase();
        if (blocked(name) || SINGLES.has(name) && names.has(name)) throw failure(400);
        names.add(name); headers.append(name, req.rawHeaders[i + 1]);
      }
      if (headers.get('host') !== base.host) throw failure(403);
      const isMcp = MCP_PATHS.has(url.pathname), maxBody = isMcp ? 65536 : 16384;
      if (isMcp && (url.search || headers.has('cookie'))) throw failure(400);
      if (headers.has('origin') && headers.get('origin') !== origin) throw failure(403);
      const length = headers.get('content-length'), transfer = headers.get('transfer-encoding');
      if (length !== null && (!/^\d+$/.test(length) || Number(length) > maxBody) || transfer !== null && transfer !== 'chunked') throw failure(413);
      if (req.method === 'GET' && (transfer !== null || length !== null && Number(length) !== 0)) throw failure(400);
      timer = setTimeout(() => {reject(res, 408); req.destroy(); replay?.destroy();}, 45000);
      const parts = []; let bytes = 0;
      for await (const part of req) {bytes += part.length; if (bytes > maxBody) throw failure(413); parts.push(part);}
      if (closed || res.destroyed) throw failure(503);
      const body = Buffer.concat(parts);
      if (!isMcp) {
        // Bound bytes BEFORE Koa/interaction parsers see them. A real
        // IncomingMessage replays them, retaining the actual TLS socket rather
        // than manufacturing security from a forwarded header.
        replay = new IncomingMessage(req.socket);
        for (const name of ['method', 'url', 'httpVersion', 'httpVersionMajor', 'httpVersionMinor', 'rawHeaders']) replay[name] = req[name];
        replay.headers = {...req.headers}; replay.complete = true;
        replay.push(body.length ? body : null); if (body.length) replay.push(null);
        const disconnected = () => {if (!res.writableEnded) replay.destroy();};
        res.once('close', disconnected);
        try {await provider(replay, res);} finally {res.off('close', disconnected);}
        return;
      }
      for (const name of ['connection', 'transfer-encoding', 'content-length']) headers.delete(name);
      const response = await fetch(new Request(`${origin}${url.pathname}`, {method: req.method, headers,
        ...(req.method === 'POST' ? {body} : {})}));
      if (!(response instanceof Response)) throw failure(500);
      const result = [], reader = response.body?.getReader(); let size = 0;
      if (reader) try {
        while (true) {const part = await reader.read(); if (part.done) break; size += part.value.length;
          if (size > 12 * 1024 * 1024) {await reader.cancel(); throw failure(502);} result.push(part.value);}
      } finally {reader.releaseLock();}
      if (closed || res.destroyed) return;
      const output = new Headers(response.headers);
      for (const name of ['connection', 'transfer-encoding', 'content-length', 'set-cookie']) output.delete(name);
      output.set('cache-control', 'no-store'); output.set('x-content-type-options', 'nosniff'); output.set('content-length', String(size));
      res.writeHead(response.status, Object.fromEntries(output)); res.end(Buffer.concat(result));
    } catch (error) {reject(res, [400, 403, 413, 500, 502, 503].includes(error.status) ? error.status : 400);}
    finally {clearTimeout(timer); active--;}
  }
  const server = createServer({...tls, minVersion: 'TLSv1.2', maxHeaderSize: 8192, headersTimeout: 10000,
    requestTimeout: 15000, keepAliveTimeout: 1000, connectionsCheckingInterval: 1000, handshakeTimeout: 10000}, (req, res) => {
    const pending = serve(req, res); running.add(pending); pending.finally(() => running.delete(pending)).catch(() => {});
  });
  server.maxConnections = 16; server.maxRequestsPerSocket = 100;
  server.on('connection', socket => {sockets.add(socket); socket.once('close', () => sockets.delete(socket));});
  server.on('clientError', (_error, socket) => socket.destroy());
  server.on('tlsClientError', () => {});
  server.on('error', () => {});
  server.on('checkContinue', (_req, res) => reject(res, 417));
  server.on('upgrade', (_req, socket) => socket.destroy());
  async function listen() {
    if (closed || started) throw new TypeError('TLS entry is unavailable.'); started = true;
    await new Promise((resolve, reject) => {
      const finish = error => {server.off('error', onError); server.off('listening', onListen); cancelStartup = undefined; error ? reject(error) : resolve();};
      const onError = () => finish(new Error('TLS entry startup failed.')), onListen = () => finish();
      cancelStartup = () => finish(new Error('TLS entry startup cancelled.'));
      server.once('error', onError); server.once('listening', onListen); server.listen(port, '127.0.0.1');
    });
    if (closed) throw new Error('TLS entry startup cancelled.');
    return Object.freeze({address: '127.0.0.1', port: server.address().port, resource: `${origin}/mcp`});
  }
  function close() {
    if (closing) return closing; closed = true; cancelStartup?.();
    closing = Promise.resolve().then(async () => {
      const stop = new Promise(resolve => {server.close(resolve); server.closeIdleConnections();});
      for (const socket of sockets) socket.destroy();
      let timer;
      try {
        const results = await Promise.race([Promise.allSettled([stop, providerClose(), hostClose(), Promise.allSettled([...running])]),
          new Promise((_, reject) => {timer = setTimeout(() => reject(new Error('TLS entry cleanup timed out.')), 12000);})]);
        if (results.some(result => result.status === 'rejected')) throw new Error('TLS entry cleanup failed.');
      } finally {clearTimeout(timer);}
    });
    closing.then(() => finish({ok: !failed}), () => finish({ok: false})); return closing;
  }
  if (application.completion instanceof Promise) application.completion.then(result => {
    if (closed) return; failed = result?.ok !== true || result.reason === 'channel-unavailable'; void close().catch(() => {});
  }, () => {failed = true; void close().catch(() => {});});
  return Object.freeze({listen, close, completion});
}

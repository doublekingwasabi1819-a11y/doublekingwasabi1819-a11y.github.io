-- SOURCE ARTIFACT ONLY. Apply explicitly to a caller-owned, local SQLite DB.
-- No keys, accounts, clients, grants, or deployed migrations are provisioned.
-- All identifier indexes are domain-separated keyed digests. Payloads are AES-GCM.
-- Keep database, journal/WAL and backups on private, durable same-host storage.
-- Never delete revocation tombstones while this store/key can accept old grant IDs.
CREATE TABLE IF NOT EXISTS relay_link_config (
  singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
  version INTEGER NOT NULL CHECK(version = 1),
  key_id TEXT NOT NULL,
  key_check TEXT NOT NULL,
  max_rows INTEGER NOT NULL,
  max_ttl_seconds INTEGER NOT NULL,
  max_payload_bytes INTEGER NOT NULL
) STRICT;
CREATE TABLE IF NOT EXISTS relay_link_records (
  namespace TEXT NOT NULL,
  id_hash TEXT NOT NULL,
  grant_hash TEXT,
  uid_hash TEXT,
  expires_at INTEGER NOT NULL,
  consumed_at INTEGER,
  key_id TEXT NOT NULL,
  nonce BLOB NOT NULL CHECK(length(nonce) = 12),
  ciphertext BLOB NOT NULL,
  tag BLOB NOT NULL CHECK(length(tag) = 16),
  PRIMARY KEY(namespace, id_hash)
) STRICT;
CREATE INDEX IF NOT EXISTS relay_link_expiry ON relay_link_records(expires_at);
CREATE INDEX IF NOT EXISTS relay_link_grant ON relay_link_records(grant_hash)
  WHERE grant_hash IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS relay_link_session_uid
  ON relay_link_records(namespace, uid_hash) WHERE uid_hash IS NOT NULL;
CREATE TABLE IF NOT EXISTS relay_link_revoked_grants (
  grant_hash TEXT PRIMARY KEY,
  revoked_at INTEGER NOT NULL
) STRICT;

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Worker } from 'node:worker_threads';
import { createEncryptedStore, initializeStorage } from '../storage.mjs';

const START = 1_900_000_000_000;
const KEY = Buffer.alloc(32, 81); // Invented fixture bytes, never a deployed key.
const KEY_ID = 'invented-messaging-storage-key';
const ACCOUNT = 'aaaaaaaa-1111-4111-8111-111111111111';
const AGENT = 'bbbbbbbb-2222-4222-8222-222222222222';
const RESOURCE = 'https://messages.example.test/mcp';
const SCOPES = ['relay:read', 'relay:work', 'relay:write'];
const delegation = (extra = {}) => ({
  workspaceId: 'invented-workspace', accountId: ACCOUNT, agentId: AGENT, runId: 'Run_1-X',
  token: 'a'.repeat(64), expiresAt: START + 120000, subject: 'invented-subject',
  clientId: 'invented-message-client', consentedAt: START, resource: RESOURCE,
  scopes: [...SCOPES], ...extra,
});
const binding = (value = delegation()) => Object.fromEntries(
  ['workspaceId', 'accountId', 'agentId', 'runId', 'clientId', 'resource'].map((key) => [key, value[key]]),
);
const browserDelegation = (extra = {}) => {
  const { resource, scopes, ...value } = delegation();
  return { ...value, ...extra };
};
const oidc = (kind, jti, grantId = 'message-grant', extra = {}) => ({
  kind, jti, grantId, accountId: 'invented-subject', clientId: 'invented-message-client',
  exp: START / 1000 + 120, iat: START / 1000,
  ...(kind === 'Grant' ? { resources: { [RESOURCE]: SCOPES.join(' ') } }
    : kind === 'AuthorizationCode' ? { resource: [RESOURCE], scope: `openid ${SCOPES.join(' ')}` }
      : { aud: RESOURCE, scope: SCOPES.join(' ') }),
  ...extra,
});
function fixture(t, options = {}) {
  const db = new DatabaseSync(':memory:');
  t.after(() => db.close());
  initializeStorage(db);
  let time = START;
  const store = createEncryptedStore({ db, key: KEY, keyId: KEY_ID, now: () => time, ...options });
  return { db, store, advance: (ms) => { time += ms; } };
}
const storedCount = (db, table) => db.prepare(`SELECT count(*) AS n FROM ${table}`).get().n;

test('encrypted messaging store returns grant identity and exact scoped worker binding', (t) => {
  const { db, store } = fixture(t);
  const value = delegation();
  store.messagingDelegations.put('message-grant', value);
  const expected = { grantId: 'message-grant', ...value, scope: SCOPES.join(' ') };
  assert.deepEqual(store.messagingDelegations.get('message-grant'), expected);
  assert.deepEqual(store.messagingDelegations.find(binding()), expected);
  assert.equal(store.delegations.get('message-grant'), undefined);
  assert.equal(store.messagingDelegations.get('missing'), undefined);
  const got = store.messagingDelegations.get('message-grant');
  got.scopes.push('browser:control');
  got.token = 'b'.repeat(64);
  assert.deepEqual(store.messagingDelegations.get('message-grant'), expected);
  assert.equal(storedCount(db, 'relay_link_records'), 1);
});

test('messaging scopes are sorted, unique, explicit and require relay:work', (t) => {
  const { store } = fixture(t);
  const valid = [['relay:work'], ['relay:read', 'relay:work'], ['relay:work', 'relay:write'], SCOPES];
  for (const [i, scopes] of valid.entries()) {
    const value = delegation({ scopes, runId: `run-${i}` });
    store.messagingDelegations.put(`g-${i}`, value);
    assert.deepEqual(store.messagingDelegations.get(`g-${i}`).scopes, scopes);
  }
  for (const scopes of [undefined, null, '', 'relay:work', [], ['relay:read'], ['relay:write'], ['browser:control'],
    ['browser:control', 'relay:work'], ['openid', 'relay:work'], ['relay:work', 'relay:work'],
    ['relay:write', 'relay:work'], ['relay:work', 'relay:read'], ['relay:work', 'unknown'], [1, 'relay:work'],
    [, 'relay:work'], ['relay:work', ,]]) {
    assert.throws(() => store.messagingDelegations.put('invalid', delegation({ scopes })), /Invalid messaging scopes/);
  }
  assert.throws(() => store.messagingDelegations.put('invalid', { ...delegation(), scope: 'relay:work' }), /Unsupported delegation property/);
});

test('messaging resource must be canonical HTTPS without credentials, query or fragment', (t) => {
  const { store } = fixture(t);
  for (const resource of [undefined, null, '', 'http://messages.example.test/mcp', 'HTTPS://messages.example.test/mcp',
    'https://MESSAGES.example.test/mcp', 'https://messages.example.test', 'https://messages.example.test:443/mcp',
    'https://messages.example.test/a/../mcp', 'https://messages.example.test/mcp#secret',
    'https://messages.example.test/mcp#', 'https://messages.example.test/mcp?',
    'https://messages.example.test/mcp?token=secret', 'https://user:credential@messages.example.test/mcp',
    'invented-private-credential', ' https://messages.example.test/mcp', 'https://messages.example.test/mcp\n']) {
    assert.throws(() => store.messagingDelegations.put('invalid', delegation({ resource })), (error) => {
      assert.ok(error instanceof TypeError);
      for (const secret of ['credential', 'secret', 'messages.example.test']) assert.ok(!error.message.includes(secret));
      return true;
    });
  }
});

test('messaging lookup uses every exact binding, client and resource component', (t) => {
  const { store } = fixture(t);
  store.messagingDelegations.put('message-grant', delegation());
  for (const change of [{ workspaceId: 'different-workspace' }, { accountId: AGENT }, { agentId: ACCOUNT },
    { runId: 'run_1-X' }, { clientId: 'different-client' }, { resource: 'https://messages.example.test/other-mcp' }]) {
    assert.equal(store.messagingDelegations.find({ ...binding(), ...change }), undefined);
  }
  assert.equal(store.messagingDelegations.find({ ...binding(), accountId: ACCOUNT.toUpperCase(), agentId: AGENT.toUpperCase() }).grantId, 'message-grant');
  for (const change of [{ workspaceId: '' }, { accountId: 'bad' }, { agentId: 'bad' }, { runId: '' },
    { clientId: '' }, { resource: 'http://messages.example.test/mcp' }, { subject: 'invented-subject' }]) {
    assert.throws(() => store.messagingDelegations.find({ ...binding(), ...change }), TypeError);
  }
});

test('same messaging grant accepts only exact repeats and never renews or remaps identity', (t) => {
  const { db, store } = fixture(t);
  const value = delegation();
  store.messagingDelegations.put('message-grant', value);
  const prior = db.prepare('SELECT * FROM relay_link_records').get();
  store.messagingDelegations.put('message-grant', value);
  assert.deepEqual(db.prepare('SELECT * FROM relay_link_records').get(), prior);
  for (const change of [{ workspaceId: 'other' }, { accountId: AGENT }, { agentId: ACCOUNT }, { runId: 'other' },
    { token: 'b'.repeat(64) }, { expiresAt: START + 121000 }, { subject: 'other' }, { clientId: 'other' },
    { consentedAt: START - 1 }, { resource: 'https://other.example.test/mcp' }, { scopes: ['relay:work'] }]) {
    assert.throws(() => store.messagingDelegations.put('message-grant', { ...value, ...change }), { code: 'IMMUTABLE_DELEGATION' });
  }
  assert.deepEqual(db.prepare('SELECT * FROM relay_link_records').get(), prior);
});

test('browser and messaging delegations cannot coexist or convert under one grant ID', async (t) => {
  const { store } = fixture(t);
  store.delegations.put('browser-grant', browserDelegation());
  assert.throws(() => store.messagingDelegations.put('browser-grant', delegation()), { code: 'IMMUTABLE_DELEGATION' });
  store.messagingDelegations.put('message-grant', delegation());
  assert.throws(() => store.delegations.put('message-grant', browserDelegation()), { code: 'IMMUTABLE_DELEGATION' });
  await assert.rejects(new store.Adapter('AccessToken').upsert('browser-message-token', oidc('AccessToken', 'browser-message-token', 'browser-grant'), 120), { code: 'INVALID_GRANT' });
  store.messagingDelegations.destroy('browser-grant');
  assert.throws(() => store.messagingDelegations.put('browser-grant', delegation()), { code: 'INVALID_GRANT' });
  store.delegations.destroy('message-grant');
  assert.throws(() => store.delegations.put('message-grant', browserDelegation()), { code: 'INVALID_GRANT' });
});

test('messaging TTL never exceeds 15 minutes, configured bounds or original consent lifetime', (t) => {
  const { store } = fixture(t, { maxTtlSeconds: 3600 });
  store.messagingDelegations.put('max', delegation({ expiresAt: START + 900000 }));
  for (const change of [{ expiresAt: START + 900001 }, { expiresAt: START }, { expiresAt: Infinity },
    { expiresAt: START + 900000, consentedAt: START - 1 }, { consentedAt: START + 1 }, { consentedAt: START - 900001 }]) {
    assert.throws(() => store.messagingDelegations.put('invalid', delegation(change)), TypeError);
  }
  const shorter = fixture(t, { maxTtlSeconds: 60 });
  assert.throws(() => shorter.store.messagingDelegations.put('too-long', delegation()), /delegation expiry/);
  shorter.store.messagingDelegations.put('short', delegation({ expiresAt: START + 60000 }));
});

test('adapter binds messaging grants, codes and access tokens to exact consent and expiry', async (t) => {
  const { store } = fixture(t);
  store.messagingDelegations.put('message-grant', delegation());
  for (const model of ['Grant', 'AuthorizationCode', 'AccessToken']) {
    const adapter = new store.Adapter(model);
    const id = model === 'Grant' ? 'message-grant' : model;
    const valid = oidc(model, id);
    await adapter.upsert(id, valid, 120);
    assert.deepEqual(await adapter.find(id), valid);
    await adapter.upsert(id, valid, 120);
    for (const extra of [{ accountId: 'other' }, { clientId: 'other' }, { exp: START / 1000 + 121 }]) {
      await assert.rejects(adapter.upsert(id, { ...valid, ...extra }, 121), { code: 'INVALID_GRANT' });
    }
  }
  for (const extra of [{ resources: { [RESOURCE]: 'browser:control' } }, { resources: { [RESOURCE]: 'relay:work' } },
    { resources: { 'https://other.example.test/mcp': SCOPES.join(' ') } },
    { resources: { [RESOURCE]: SCOPES.join(' '), 'https://other.example.test/mcp': SCOPES.join(' ') } }]) {
    await assert.rejects(new store.Adapter('Grant').upsert('message-grant', oidc('Grant', 'message-grant', 'message-grant', extra), 120), { code: 'INVALID_GRANT' });
  }
  for (const extra of [{ aud: 'https://other.example.test/mcp' }, { aud: [RESOURCE, 'https://other.example.test/mcp'] },
    { aud: undefined }, { scope: 'relay:work' }, { scope: `${SCOPES.join(' ')} browser:control` },
    { scope: `openid ${SCOPES.join(' ')}` }, { scope: `${SCOPES.join(' ')} relay:work` }]) {
    await assert.rejects(new store.Adapter('AccessToken').upsert('bad-token', oidc('AccessToken', 'bad-token', 'message-grant', extra), 120), { code: 'INVALID_GRANT' });
  }
  for (const extra of [{ resource: undefined }, { resource: ['https://other.example.test/mcp'] }, { resource: [RESOURCE, RESOURCE] },
    { scope: 'browser:control openid' }, { scope: 'relay:work' }, { scope: `email ${SCOPES.join(' ')}` }]) {
    await assert.rejects(new store.Adapter('AuthorizationCode').upsert('bad-code', oidc('AuthorizationCode', 'bad-code', 'message-grant', extra), 120), { code: 'INVALID_GRANT' });
  }
});

test('new messaging consent checks all earlier grant-linked records, including orphaned tokens', async (t) => {
  const { store } = fixture(t);
  for (const [i, extra] of [{ clientId: 'other' }, { accountId: 'other' }, { aud: 'https://other.example.test/mcp' },
    { scope: 'browser:control' }, { exp: START / 1000 + 121 }].entries()) {
    const id = `orphan-${i}`;
    await new store.Adapter('AccessToken').upsert(id, oidc('AccessToken', id, id, extra), 121);
    assert.throws(() => store.messagingDelegations.put(id, delegation()), { code: 'INVALID_GRANT' });
    assert.equal(store.messagingDelegations.get(id), undefined);
  }
  const grant = new store.Adapter('Grant');
  await grant.upsert('valid-first', oidc('Grant', 'valid-first', 'valid-first'), 120);
  store.messagingDelegations.put('valid-first', delegation());
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'valid-first');
});

test('stored adapter scope and audience identity cannot be changed before or after delegation', async (t) => {
  const { store } = fixture(t);
  const access = new store.Adapter('AccessToken');
  await access.upsert('token', oidc('AccessToken', 'token'), 120);
  for (const extra of [{ scope: 'relay:work' }, { aud: 'https://other.example.test/mcp' }]) {
    await assert.rejects(access.upsert('token', oidc('AccessToken', 'token', 'message-grant', extra), 120), { code: 'INVALID_GRANT' });
  }
  store.messagingDelegations.put('message-grant', delegation());
  assert.deepEqual(await access.find('token'), oidc('AccessToken', 'token'));
});

test('explicit new consent atomically replaces and permanently revokes the prior matching grant', async (t) => {
  const { db, store, advance } = fixture(t);
  store.messagingDelegations.put('old-grant', delegation());
  await new store.Adapter('Grant').upsert('old-grant', oidc('Grant', 'old-grant', 'old-grant'), 120);
  await new store.Adapter('AccessToken').upsert('old-token', oidc('AccessToken', 'old-token', 'old-grant'), 120);
  advance(1000);
  const newer = delegation({ consentedAt: START + 1000, expiresAt: START + 121000, token: 'b'.repeat(64), scopes: ['relay:work'] });
  store.messagingDelegations.put('new-grant', newer);
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'new-grant');
  assert.equal(store.messagingDelegations.get('old-grant'), undefined);
  assert.equal(await new store.Adapter('Grant').find('old-grant'), undefined);
  assert.equal(await new store.Adapter('AccessToken').find('old-token'), undefined);
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 1);
  assert.throws(() => store.messagingDelegations.put('old-grant', newer), { code: 'INVALID_GRANT' });
  await assert.rejects(new store.Adapter('AccessToken').upsert('late-token', oidc('AccessToken', 'late-token', 'old-grant'), 120), { code: 'INVALID_GRANT' });
  assert.throws(() => store.messagingDelegations.put('stale-consent', delegation()), { code: 'INVALID_GRANT' });
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'new-grant');
});

test('different clients, resources and worker bindings keep independent messaging grants', (t) => {
  const { db, store } = fixture(t);
  for (const [i, extra] of [{}, { clientId: 'second-client' }, { resource: 'https://messages.example.test/other' },
    { workspaceId: 'another-workspace' }, { accountId: AGENT }, { agentId: ACCOUNT }, { runId: 'another-run' }].entries()) {
    const value = delegation(extra);
    store.messagingDelegations.put(`grant-${i}`, value);
    assert.equal(store.messagingDelegations.find(binding(value)).grantId, `grant-${i}`);
  }
  assert.equal(storedCount(db, 'relay_link_records'), 7);
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 0);
});

test('replacement transaction rolls back token deletion and tombstone if the new write fails', async (t) => {
  const { db, store } = fixture(t);
  store.messagingDelegations.put('old-grant', delegation());
  await new store.Adapter('AccessToken').upsert('old-token', oidc('AccessToken', 'old-token', 'old-grant'), 120);
  db.exec(`CREATE TRIGGER invented_message_write_failure BEFORE INSERT ON relay_link_records
    WHEN NEW.namespace = 'message-delegation'
    BEGIN SELECT RAISE(ABORT, 'invented write failure'); END;`);
  assert.throws(() => store.messagingDelegations.put('new-grant', delegation()), /invented write failure/);
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'old-grant');
  assert.ok(await new store.Adapter('AccessToken').find('old-token'));
  assert.equal(store.messagingDelegations.get('new-grant'), undefined);
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 0);
  db.exec('DROP TRIGGER invented_message_write_failure');
  store.messagingDelegations.put('new-grant', delegation());
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'new-grant');
});

test('replacement respects tombstone capacity without deleting the existing consent on failure', (t) => {
  const { db, store } = fixture(t, { maxRows: 1 });
  store.messagingDelegations.put('old-grant', delegation());
  assert.throws(() => store.messagingDelegations.put('new-grant', delegation()), { code: 'CAPACITY' });
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'old-grant');
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 0);
  store.messagingDelegations.destroy('old-grant');
  assert.equal(storedCount(db, 'relay_link_records'), 0);
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 1);
});

test('messaging expiry is enforced on both indexes and pruning permanently revokes siblings', async (t) => {
  const { db, store, advance } = fixture(t);
  store.messagingDelegations.put('short', delegation({ expiresAt: START + 1000 }));
  await new store.Adapter('AccessToken').upsert('short-token', oidc('AccessToken', 'short-token', 'short', { exp: START / 1000 + 1 }), 1);
  advance(1000);
  assert.equal(store.messagingDelegations.get('short'), undefined);
  assert.equal(store.messagingDelegations.find(binding()), undefined);
  assert.equal(await new store.Adapter('AccessToken').find('short-token'), undefined);
  assert.equal(store.pruneExpired(), 2);
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 1);
  assert.throws(() => store.messagingDelegations.put('short', delegation()), { code: 'INVALID_GRANT' });
  store.messagingDelegations.put('fresh', delegation({ consentedAt: START + 1000 }));
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'fresh');
});

test('expiry pruning on attempted replacement tombstones the old ID even at capacity', (t) => {
  const { db, store, advance } = fixture(t, { maxRows: 1 });
  store.messagingDelegations.put('old', delegation({ expiresAt: START + 1000 }));
  advance(1000);
  store.pruneExpired();
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 1);
  assert.throws(() => store.messagingDelegations.put('old', delegation()), { code: 'INVALID_GRANT' });
  assert.throws(() => store.messagingDelegations.put('new', delegation()), { code: 'CAPACITY' });
});

test('all grant revocation APIs remove the messaging lookup and share durable tombstones', async (t) => {
  const { db, store } = fixture(t);
  const revoke = [
    (id) => store.messagingDelegations.destroy(id),
    (id) => new store.Adapter('Grant').destroy(id),
    (id) => new store.Adapter('AccessToken').revokeByGrantId(id),
    () => store.revokeAllGrants(),
  ];
  for (const [i, destroy] of revoke.entries()) {
    const id = `grant-${i}`;
    store.messagingDelegations.put(id, delegation());
    await new store.Adapter('AuthorizationCode').upsert(`code-${i}`, oidc('AuthorizationCode', `code-${i}`, id), 120);
    await destroy(id);
    assert.equal(store.messagingDelegations.get(id), undefined);
    assert.equal(store.messagingDelegations.find(binding()), undefined);
    assert.equal(await new store.Adapter('AuthorizationCode').find(`code-${i}`), undefined);
    assert.throws(() => store.messagingDelegations.put(id, delegation()), { code: 'INVALID_GRANT' });
  }
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 4);
});

test('SQLite rows contain only keyed indexes and ciphertext, all lookup metadata is authenticated', (t) => {
  const { db, store } = fixture(t);
  const value = delegation();
  store.messagingDelegations.put('invented-sensitive-grant', value);
  const row = db.prepare('SELECT * FROM relay_link_records').get();
  for (const key of ['id_hash', 'grant_hash', 'uid_hash']) assert.match(row[key], /^[a-f0-9]{64}$/);
  assert.equal(new Set([row.id_hash, row.grant_hash, row.uid_hash]).size, 3);
  assert.equal(row.namespace, 'message-delegation');
  assert.equal(row.nonce.length, 12);
  assert.equal(row.tag.length, 16);
  const raw = JSON.stringify(row);
  for (const secret of ['invented-sensitive-grant', value.token, value.workspaceId, ACCOUNT, AGENT, value.runId,
    value.subject, value.clientId, RESOURCE, ...SCOPES]) assert.ok(!raw.includes(secret));
  db.prepare('UPDATE relay_link_records SET uid_hash = ?').run('0'.repeat(64));
  assert.throws(() => store.messagingDelegations.get('invented-sensitive-grant'), { code: 'INTEGRITY' });
  db.prepare('UPDATE relay_link_records SET uid_hash = ?, expires_at = expires_at + 1').run(row.uid_hash);
  assert.throws(() => store.messagingDelegations.find(binding()), { code: 'INTEGRITY' });
});

test('keyed messaging binding index is stable across stores and separated from session UID indexes', async (t) => {
  const { db, store } = fixture(t);
  store.messagingDelegations.put('message-grant', delegation());
  await new store.Adapter('Session').upsert('session', { uid: JSON.stringify(binding()), kind: 'Session' }, 120);
  const rows = db.prepare('SELECT namespace, uid_hash FROM relay_link_records').all();
  assert.equal(new Set(rows.map((row) => row.uid_hash)).size, 2);
  const second = createEncryptedStore({ db, key: KEY, keyId: KEY_ID, now: () => START });
  assert.equal(second.messagingDelegations.find(binding()).grantId, 'message-grant');
  second.messagingDelegations.put('replacement', delegation());
  assert.equal(store.messagingDelegations.find(binding()).grantId, 'replacement');
  assert.throws(() => store.messagingDelegations.put('message-grant', delegation()), { code: 'INVALID_GRANT' });
});

test('file-backed restart preserves encrypted current binding and permanent replacement/revocation', (t) => {
  const directory = mkdtempSync(join(tmpdir(), 'relay-message-storage-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const path = join(directory, 'invented.sqlite');
  const openStore = () => {
    const db = new DatabaseSync(path, { timeout: 5000 });
    initializeStorage(db);
    return { db, store: createEncryptedStore({ db, key: KEY, keyId: KEY_ID, now: () => START }) };
  };
  const first = openStore();
  first.store.messagingDelegations.put('old-grant', delegation());
  first.store.messagingDelegations.put('current-grant', delegation());
  first.db.close();
  const bytes = readFileSync(path).toString('utf8');
  for (const secret of ['old-grant', 'current-grant', 'a'.repeat(64), RESOURCE, ACCOUNT, 'Run_1-X']) assert.ok(!bytes.includes(secret));
  const second = openStore();
  assert.equal(second.store.messagingDelegations.find(binding()).grantId, 'current-grant');
  assert.throws(() => second.store.messagingDelegations.put('old-grant', delegation()), { code: 'INVALID_GRANT' });
  second.store.messagingDelegations.destroy('current-grant');
  second.db.close();
  const third = openStore();
  t.after(() => third.db.close());
  assert.equal(third.store.messagingDelegations.find(binding()), undefined);
  for (const id of ['old-grant', 'current-grant']) assert.throws(() => third.store.messagingDelegations.put(id, delegation()), { code: 'INVALID_GRANT' });
});

test('independent SQLite writer connections serialize same-binding consent replacement', async (t) => {
  const directory = mkdtempSync(join(tmpdir(), 'relay-message-storage-race-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const path = join(directory, 'invented.sqlite');
  const db = new DatabaseSync(path, { timeout: 5000 });
  t.after(() => db.close());
  initializeStorage(db);
  const store = createEncryptedStore({ db, key: KEY, keyId: KEY_ID, now: () => START });
  const gate = new SharedArrayBuffer(4);
  const code = `
    const { parentPort, workerData } = require('node:worker_threads');
    const { DatabaseSync } = require('node:sqlite');
    (async () => {
      const { createEncryptedStore } = await import(workerData.module);
      const db = new DatabaseSync(workerData.path, { timeout: 5000 });
      const store = createEncryptedStore({ db, key: Buffer.alloc(32, 81), keyId: workerData.keyId, now: () => workerData.start });
      parentPort.postMessage({ ready: true });
      Atomics.wait(new Int32Array(workerData.gate), 0, 0);
      store.messagingDelegations.put(workerData.id, workerData.value);
      db.close();
      parentPort.postMessage({ done: true });
    })().catch(() => { parentPort.postMessage({ failed: true }); process.exitCode = 1; });
  `;
  const workers = ['grant-a', 'grant-b'].map((id) => new Worker(code, { eval: true, workerData: {
    module: new URL('../storage.mjs', import.meta.url).href, path, keyId: KEY_ID, start: START, gate, id, value: delegation(),
  } }));
  t.after(async () => { await Promise.all(workers.map((worker) => worker.terminate())); });
  const ready = workers.map((worker) => new Promise((resolve, reject) => {
    worker.once('error', reject);
    worker.on('message', (message) => { if (message.ready) resolve(); else if (message.failed) reject(new Error('Fixture worker failed')); });
  }));
  const done = workers.map((worker) => new Promise((resolve, reject) => {
    worker.once('error', reject);
    worker.on('message', (message) => { if (message.done) resolve(); else if (message.failed) reject(new Error('Fixture worker failed')); });
  }));
  await Promise.all(ready);
  Atomics.store(new Int32Array(gate), 0, 1);
  Atomics.notify(new Int32Array(gate), 0, 2);
  await Promise.all(done);
  const current = store.messagingDelegations.find(binding());
  const previous = current.grantId === 'grant-a' ? 'grant-b' : 'grant-a';
  assert.equal(storedCount(db, 'relay_link_records'), 1);
  assert.equal(storedCount(db, 'relay_link_revoked_grants'), 1);
  assert.equal(store.messagingDelegations.get(previous), undefined);
  assert.throws(() => store.messagingDelegations.put(previous, delegation()), { code: 'INVALID_GRANT' });
});

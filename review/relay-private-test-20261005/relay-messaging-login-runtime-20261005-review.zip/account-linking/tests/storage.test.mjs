import assert from 'node:assert/strict';
import { test } from 'node:test';
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Worker } from 'node:worker_threads';
import { ALLOWED_MODELS, createEncryptedStore, initializeStorage, StorageError } from '../storage.mjs';

const START = 1_900_000_000_000;
const FIXTURE_KEY = Buffer.alloc(32, 71); // Invented test bytes; never a deployed key.
const keyId = 'invented-test-key';
const ACCOUNT = '11111111-1111-4111-8111-111111111111';
const AGENT = '22222222-2222-4222-8222-222222222222';
const RUN = '33333333-3333-4333-8333-333333333333';
function fixture(t, options = {}) {
  const db = new DatabaseSync(':memory:');
  t.after(() => db.close());
  initializeStorage(db);
  let time = START;
  const store = createEncryptedStore({ db, key: FIXTURE_KEY, keyId, now: () => time, ...options });
  return { db, store, advance: (ms) => { time += ms; } };
}
const payload = (model, id, extra = {}) => ({ jti: id, kind: model, exp: START / 1000 + 120, iat: START / 1000, ...extra });
const delegated = (extra = {}) => ({ workspaceId: 'fixture-workspace', accountId: ACCOUNT, agentId: AGENT, runId: RUN, token: 'a'.repeat(64), expiresAt: START + 120000, subject: 'fixture-linked-subject', clientId: 'fixture-client', consentedAt: START, ...extra });
const tokenPayload = (model, id, grantId = 'grant-one', extra = {}) => payload(model, id, { grantId, accountId: 'fixture-linked-subject', clientId: 'fixture-client', ...extra });

test('factory requires caller-owned initialized DB and fixed 32-byte key', (t) => {
  const db = new DatabaseSync(':memory:');
  t.after(() => db.close());
  assert.throws(() => createEncryptedStore({ db, key: FIXTURE_KEY, keyId }), /no such table/);
  assert.equal(db.prepare("SELECT count(*) n FROM sqlite_master WHERE type='table'").get().n, 0);
  initializeStorage(db);
  assert.throws(() => createEncryptedStore({ db, key: Buffer.alloc(31), keyId }), /32-byte/);
  assert.throws(() => createEncryptedStore({ db, key: FIXTURE_KEY, keyId, maxRows: 0 }), /maxRows/);
  assert.throws(() => createEncryptedStore({ db, key: FIXTURE_KEY, keyId, maxTtlSeconds: Infinity }), /maxTtl/);
  createEncryptedStore({ db, key: FIXTURE_KEY, keyId });
  for (const overrides of [{ key: Buffer.alloc(32, 72) }, { keyId: 'wrong-key-id' }, { maxRows: 3 }]) {
    assert.throws(() => createEncryptedStore({ db, key: FIXTURE_KEY, keyId, ...overrides }), { code: 'CONFIG_MISMATCH' });
  }
  db.exec('BEGIN');
  assert.throws(() => createEncryptedStore({ db, key: FIXTURE_KEY, keyId }), { code: 'TRANSACTION_ACTIVE' });
  db.exec('ROLLBACK');
});

test('only six supported models, strict finite expiry, safe immutable adapter identity', async (t) => {
  const { store } = fixture(t);
  assert.deepEqual(ALLOWED_MODELS, ['Grant', 'Session', 'Interaction', 'AccessToken', 'AuthorizationCode', 'ReplayDetection']);
  for (const unsupported of ['Client', 'RefreshToken', 'DeviceCode', 'PushedAuthorizationRequest', '__proto__']) {
    assert.throws(() => new store.Adapter(unsupported), { code: 'UNSUPPORTED_MODEL' });
  }
  const adapter = new store.Adapter('Grant');
  assert.throws(() => { adapter.model = 'AccessToken'; }, TypeError);
  for (const ttl of [undefined, null, 0, -1, 1.2, Infinity, 901]) {
    await assert.rejects(adapter.upsert('g', payload('Grant', 'g'), ttl));
  }
  await assert.rejects(adapter.upsert('g', payload('Session', 'g'), 120), { code: 'MODEL_MISMATCH' });
  await assert.rejects(adapter.upsert('g', payload('Grant', 'different'), 120), { code: 'ID_MISMATCH' });
  await assert.rejects(adapter.findByUserCode('ignored'), { code: 'UNSUPPORTED_INDEX' });
  await assert.rejects(adapter.findByUid('ignored'), { code: 'UNSUPPORTED_INDEX' });
  await assert.rejects(adapter.consume('ignored'), { code: 'NOT_CONSUMABLE' });
});

test('encrypted round trip preserves extensible provider payloads without plaintext indexed IDs', async (t) => {
  const { db, store } = fixture(t);
  const code = new store.Adapter('AuthorizationCode');
  const data = tokenPayload('AuthorizationCode', 'secret-code-id', 'secret-grant-id', { claims: { private: 'personal-fixture-value' }, codeChallenge: 'invented-PKCE-challenge' });
  await code.upsert('secret-code-id', data, 120);
  assert.deepEqual(await code.find('secret-code-id'), data);
  const row = db.prepare('SELECT * FROM relay_link_records').get();
  assert.match(row.id_hash, /^[a-f0-9]{64}$/);
  assert.match(row.grant_hash, /^[a-f0-9]{64}$/);
  assert.equal(row.nonce.length, 12);
  assert.equal(row.tag.length, 16);
  const plain = JSON.stringify(row);
  for (const secret of ['secret-code-id', 'secret-grant-id', 'personal-fixture-value', 'invented-PKCE-challenge']) assert.ok(!plain.includes(secret));
  const priorCiphertext = Buffer.from(row.ciphertext);
  await code.upsert('secret-code-id', data, 120);
  assert.notDeepEqual(Buffer.from(db.prepare('SELECT ciphertext FROM relay_link_records').get().ciphertext), priorCiphertext);
});

test('AAD rejects ciphertext substitution between IDs and changes to expiry/index metadata', async (t) => {
  const { db, store } = fixture(t);
  const grant = new store.Adapter('Grant');
  await grant.upsert('grant-a', payload('Grant', 'grant-a'), 120);
  await grant.upsert('grant-b', payload('Grant', 'grant-b'), 120);
  const [a, b] = db.prepare('SELECT * FROM relay_link_records ORDER BY id_hash').all();
  db.prepare('UPDATE relay_link_records SET nonce=?, ciphertext=?, tag=? WHERE id_hash=?').run(a.nonce, a.ciphertext, a.tag, b.id_hash);
  const result = await Promise.allSettled([grant.find('grant-a'), grant.find('grant-b')]);
  assert.equal(result.filter((item) => item.status === 'fulfilled').length, 1);
  assert.equal(result.filter((item) => item.status === 'rejected' && item.reason.code === 'INTEGRITY').length, 1);
});

test('ciphertext and expiry tampering fail closed with generic errors', async (t) => {
  const { db, store } = fixture(t);
  const grant = new store.Adapter('Grant');
  await grant.upsert('g', payload('Grant', 'g'), 120);
  db.exec('UPDATE relay_link_records SET expires_at = expires_at + 1');
  await assert.rejects(grant.find('g'), (error) => error instanceof StorageError && error.code === 'INTEGRITY' && !error.message.includes('g:'));
});

test('all lookup paths enforce expiry; TTL cannot extend payload expiration', async (t) => {
  const { store, advance } = fixture(t);
  const session = new store.Adapter('Session');
  await session.upsert('session-1', payload('Session', 'session-1', { uid: 'session-uid', exp: START / 1000 + 1 }), 120);
  assert.ok(await session.findByUid('session-uid'));
  advance(1000);
  assert.equal(await session.find('session-1'), undefined);
  assert.equal(await session.findByUid('session-uid'), undefined);
  await assert.rejects(session.upsert('expired', payload('Session', 'expired', { uid: 'uid', exp: START / 1000 }), 120), { code: 'INVALID_GRANT' });
});

test('Session UID updates and official destroy-before-rotation flow work', async (t) => {
  const { store } = fixture(t);
  const session = new store.Adapter('Session');
  await session.upsert('s1', payload('Session', 's1', { uid: 'old-uid' }), 120);
  await session.upsert('s1', payload('Session', 's1', { uid: 'new-uid' }), 120);
  assert.equal(await session.findByUid('old-uid'), undefined);
  assert.equal((await session.findByUid('new-uid')).jti, 's1');
  await session.destroy('s1');
  await session.upsert('s2', payload('Session', 's2', { uid: 'new-uid' }), 120);
  assert.equal((await session.findByUid('new-uid')).jti, 's2');
});

test('one-use consume returns consumed marker and rejects simultaneous replay; revocation is durable', async (t) => {
  const { db, store } = fixture(t);
  const code = new store.Adapter('AuthorizationCode');
  const grant = new store.Adapter('Grant');
  const access = new store.Adapter('AccessToken');
  await grant.upsert('grant-one', tokenPayload('Grant', 'grant-one'), 120);
  await code.upsert('code', tokenPayload('AuthorizationCode', 'code'), 120);
  const snapshot1 = await code.find('code');
  const snapshot2 = await code.find('code');
  assert.equal(snapshot1.consumed, undefined);
  assert.equal(snapshot2.consumed, undefined);
  await code.consume('code');
  assert.equal((await code.find('code')).consumed, START / 1000);
  await assert.rejects(code.upsert('code', snapshot1, 120), { code: 'INVALID_GRANT' });
  await assert.rejects(code.consume('code'), { code: 'INVALID_GRANT', statusCode: 400 });
  assert.equal(await grant.find('grant-one'), undefined);
  assert.equal(await code.find('code'), undefined);
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_revoked_grants').get().n, 1);
  await assert.rejects(access.upsert('racing-token', tokenPayload('AccessToken', 'racing-token'), 120), { code: 'INVALID_GRANT' });
});

test('parallel promise consumers have exactly one winner, including expired/missing denial', async (t) => {
  const { store, advance } = fixture(t);
  const code = new store.Adapter('AuthorizationCode');
  await code.upsert('code', tokenPayload('AuthorizationCode', 'code'), 120);
  const results = await Promise.allSettled(Array.from({ length: 20 }, () => code.consume('code')));
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
  assert.equal(results.filter((r) => r.status === 'rejected').length, 19);
  await assert.rejects(code.consume('missing'), { code: 'INVALID_GRANT' });
  await code.upsert('expiring', tokenPayload('AuthorizationCode', 'expiring', 'grant-two'), 1);
  advance(1000);
  await assert.rejects(code.consume('expiring'), { code: 'INVALID_GRANT' });
});

test('Grant.destroy and revokeByGrantId atomically revoke tokens and delegation and reject stale upsert', async (t) => {
  const { store, advance } = fixture(t);
  const grant = new store.Adapter('Grant');
  const code = new store.Adapter('AuthorizationCode');
  store.delegations.put('g', delegated());
  await grant.upsert('g', tokenPayload('Grant', 'g', 'g'), 120);
  await code.upsert('c', tokenPayload('AuthorizationCode', 'c', 'g'), 120);
  await grant.destroy('g');
  assert.equal(store.delegations.get('g'), undefined);
  assert.equal(await code.find('c'), undefined);
  assert.equal(await grant.find('g'), undefined);
  await assert.rejects(grant.upsert('g', tokenPayload('Grant', 'g', 'g'), 120), { code: 'INVALID_GRANT' });
  assert.throws(() => store.delegations.put('g', delegated()), { code: 'INVALID_GRANT' });
  advance(121000);
  store.pruneExpired();
  await assert.rejects(code.upsert('late-code', tokenPayload('AuthorizationCode', 'late-code', 'g', { exp: START / 1000 + 300 }), 120), { code: 'INVALID_GRANT' });
  await code.revokeByGrantId('unseen-g');
  await assert.rejects(grant.upsert('unseen-g', payload('Grant', 'unseen-g', { exp: START / 1000 + 300 }), 120), { code: 'INVALID_GRANT' });
});

test('state namespaces are encrypted, bounded, immutable, short lived, and atomically one-use', (t) => {
  const { db, store, advance } = fixture(t);
  for (const name of ['login', 'consent', 'account']) {
    store.state.put(name, 'same-id', { token: 'invented-state-token', purpose: name }, name === 'account' ? 900 : 600);
    assert.equal(store.state.get(name, 'same-id').purpose, name);
    assert.throws(() => store.state.put(name, 'same-id', { token: 'replacement' }, 10), { code: 'STATE_EXISTS' });
    assert.equal(store.state.consume(name, 'same-id').purpose, name);
    assert.equal(store.state.consume(name, 'same-id'), undefined);
    assert.equal(store.state.get(name, 'same-id'), undefined);
    assert.throws(() => store.state.put(name, 'same-id', {}, 10), { code: 'STATE_EXISTS' });
  }
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM relay_link_records').all()).includes('invented-state-token'));
  assert.throws(() => store.state.put('login', 'x', {}, 601), /state TTL/);
  assert.throws(() => store.state.get('arbitrary', 'x'), { code: 'UNSUPPORTED_NAMESPACE' });
  store.state.put('consent', 'expires', { shown: true }, 1);
  advance(1000);
  assert.equal(store.state.consume('consent', 'expires'), undefined);
  store.state.put('login', 'delete', {}, 20);
  store.state.destroy('login', 'delete');
  assert.equal(store.state.get('login', 'delete'), undefined);
});

test('delegation accepts only validated-shape immutable UUID worker binding and browser:control', async (t) => {
  const { db, store } = fixture(t);
  const value = delegated();
  store.delegations.put('g', value);
  const got = store.delegations.get('g');
  assert.equal(got.token, value.token);
  assert.equal(got.subject, value.subject);
  assert.equal(got.scope, 'browser:control');
  assert.deepEqual(got.scopes, ['browser:control']);
  store.delegations.put('g', value); // Only exact idempotent insert is allowed.
  for (const change of [{ token: 'b'.repeat(64) }, { subject: 'other' }, { clientId: 'other' }, { runId: '44444444-4444-4444-8444-444444444444' }]) {
    assert.throws(() => store.delegations.put('g', { ...value, ...change }), { code: 'IMMUTABLE_DELEGATION' });
  }
  for (const change of [{ agentId: 'caller-picked' }, { runId: '' }, { accountId: 'manager' }, { scope: 'admin' }, { expiresAt: START }, { consentedAt: START + 1 }]) {
    assert.throws(() => store.delegations.put('bad', { ...value, ...change }));
  }
  const grant = new store.Adapter('Grant');
  await assert.rejects(grant.upsert('g', tokenPayload('Grant', 'g', 'g', { accountId: 'wrong-subject' }), 120), { code: 'INVALID_GRANT' });
  const access = new store.Adapter('AccessToken');
  await assert.rejects(access.upsert('a', tokenPayload('AccessToken', 'a', 'g', { clientId: 'wrong-client' }), 120), { code: 'INVALID_GRANT' });
  await grant.upsert('already-granted', tokenPayload('Grant', 'already-granted', 'already-granted', { accountId: 'wrong-subject' }), 120);
  assert.throws(() => store.delegations.put('already-granted', value), { code: 'INVALID_GRANT' });
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM relay_link_records').all()).includes(value.token));
});

test('strict capacity includes permanent tombstones, expired records free space, payload size is bounded', async (t) => {
  const { db, store, advance } = fixture(t, { maxRows: 2, maxPayloadBytes: 256 });
  store.state.put('login', 's1', {}, 1);
  store.state.put('login', 's2', {}, 2);
  assert.throws(() => store.state.put('login', 'full', {}, 1), { code: 'CAPACITY' });
  advance(1000);
  store.state.put('login', 'replacement', {}, 1);
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_records').get().n, 2);
  advance(2000);
  store.pruneExpired();
  assert.throws(() => store.state.put('login', 'large', { secret: 'x'.repeat(300) }, 1), { code: 'PAYLOAD_SIZE' });
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_records').get().n, 0);
  const grant = new store.Adapter('Grant');
  await grant.destroy('g1');
  await grant.destroy('g2');
  assert.throws(() => store.state.put('login', 'no-eviction', {}, 1), { code: 'CAPACITY' });
  await assert.rejects(grant.destroy('g3'), { code: 'CAPACITY' });
  await grant.destroy('g1'); // Idempotent revocation works at capacity.
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_revoked_grants').get().n, 2);
});

test('ReplayDetection insertion is atomic and cannot quietly overwrite a prior replay marker', async (t) => {
  const { store } = fixture(t);
  const adapter = new store.Adapter('ReplayDetection');
  const results = await Promise.allSettled([adapter.upsert('r', payload('ReplayDetection', 'r'), 120), adapter.upsert('r', payload('ReplayDetection', 'r'), 120)]);
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
});

test('injected official invalidGrant factory controls replay error type', async (t) => {
  class ExampleInvalidGrant extends Error {}
  const { store } = fixture(t, { invalidGrant: () => new ExampleInvalidGrant('invalid_grant') });
  await assert.rejects(new store.Adapter('AuthorizationCode').consume('missing'), ExampleInvalidGrant);
});

test('file-backed restart preserves payloads, one-use state, encrypted bytes and revocation', async (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'relay-storage-test-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const path = join(dir, 'fixture.sqlite');
  const openStore = () => {
    const db = new DatabaseSync(path, { timeout: 5000 });
    initializeStorage(db);
    return { db, store: createEncryptedStore({ db, key: FIXTURE_KEY, keyId, now: () => START }) };
  };
  let first = openStore();
  first.store.delegations.put('g', delegated());
  first.store.state.put('login', 'l', { secret: 'invented-login-token' }, 60);
  first.store.state.consume('login', 'l');
  await new first.store.Adapter('Grant').destroy('revoked');
  first.db.close();
  const raw = readFileSync(path).toString('utf8');
  assert.ok(!raw.includes('a'.repeat(64)));
  assert.ok(!raw.includes('invented-login-token'));
  const second = openStore();
  t.after(() => second.db.close());
  assert.equal(second.store.delegations.get('g').runId, RUN);
  assert.equal(second.store.state.consume('login', 'l'), undefined);
  await assert.rejects(new second.store.Adapter('Grant').upsert('revoked', payload('Grant', 'revoked'), 120), { code: 'INVALID_GRANT' });
});

test('two independent SQLite connections racing in workers have only one code and state winner', async (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'relay-storage-race-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const path = join(dir, 'fixture.sqlite');
  const db = new DatabaseSync(path, { timeout: 5000 });
  initializeStorage(db);
  const store = createEncryptedStore({ db, key: FIXTURE_KEY, keyId, now: () => START });
  await new store.Adapter('AuthorizationCode').upsert('race-code', tokenPayload('AuthorizationCode', 'race-code'), 120);
  store.state.put('consent', 'race-state', { fixture: true }, 120);
  db.close();
  const gate = new SharedArrayBuffer(4);
  const source = `
    const { parentPort, workerData } = require('node:worker_threads');
    const { DatabaseSync } = require('node:sqlite');
    (async () => {
      const { createEncryptedStore } = await import(workerData.module);
      const db = new DatabaseSync(workerData.path, { timeout: 5000 });
      const store = createEncryptedStore({ db, key: Buffer.alloc(32, 71), keyId: 'invented-test-key', now: () => ${START} });
      const gate = new Int32Array(workerData.gate);
      parentPort.postMessage({ ready: true });
      Atomics.wait(gate, 0, 0);
      let code = false;
      try { await new store.Adapter('AuthorizationCode').consume('race-code'); code = true; } catch (e) { if (e.code !== 'INVALID_GRANT') throw e; }
      const state = Boolean(store.state.consume('consent', 'race-state'));
      db.close();
      parentPort.postMessage({ code, state });
    })().catch((error) => { throw error; });
  `;
  let ready = 0;
  const results = await Promise.all([0, 1].map(() => new Promise((resolve, reject) => {
    const worker = new Worker(source, { eval: true, workerData: { path, gate, module: new URL('../storage.mjs', import.meta.url).href } });
    t.after(() => worker.terminate());
    worker.on('error', reject);
    worker.on('message', (message) => {
      if (message.ready) {
        ready += 1;
        if (ready === 2) { Atomics.store(new Int32Array(gate), 0, 1); Atomics.notify(new Int32Array(gate), 0); }
      } else resolve(message);
    });
  })));
  assert.equal(results.filter((r) => r.code).length, 1);
  assert.equal(results.filter((r) => r.state).length, 1);
} );


test('expired grants and delegations leave permanent tombstones before any attempted remapping', async (t) => {
  const { db, store, advance } = fixture(t);
  store.delegations.put('expired-delegation', delegated({ expiresAt: START + 1000 }));
  const grant = new store.Adapter('Grant');
  await grant.upsert('expired-grant', payload('Grant', 'expired-grant', { exp: START / 1000 + 1 }), 1);
  advance(1000);
  assert.equal(store.delegations.get('expired-delegation'), undefined);
  assert.throws(() => store.delegations.put('expired-delegation', delegated({ consentedAt: START + 1000 })), { code: 'INVALID_GRANT' });
  await assert.rejects(grant.upsert('expired-grant', payload('Grant', 'expired-grant'), 120), { code: 'INVALID_GRANT' });
  store.pruneExpired();
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_revoked_grants').get().n, 2);
  assert.throws(() => store.delegations.put('expired-grant', delegated({ consentedAt: START + 1000 })), { code: 'INVALID_GRANT' });
});

test('expiry tombstones replace existing rows even when storage is at capacity', async (t) => {
  const { db, store, advance } = fixture(t, { maxRows: 1 });
  await new store.Adapter('Grant').upsert('g', payload('Grant', 'g', { exp: START / 1000 + 1 }), 1);
  advance(1000);
  assert.equal(store.pruneExpired(), 1);
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_revoked_grants').get().n, 1);
  assert.throws(() => store.state.put('login', 's', {}, 30), { code: 'CAPACITY' });
});

test('model substitution and consumed-marker reset cannot bypass authenticated metadata', async (t) => {
  const { db, store } = fixture(t);
  const code = new store.Adapter('AuthorizationCode');
  await code.upsert('c', tokenPayload('AuthorizationCode', 'c'), 120);
  await code.consume('c');
  db.exec('UPDATE relay_link_records SET consumed_at = NULL');
  await assert.rejects(code.consume('c'), { code: 'INTEGRITY' });
  await code.destroy('c');
  await code.upsert('c', tokenPayload('AuthorizationCode', 'c'), 120);
  const row = db.prepare('SELECT * FROM relay_link_records').get();
  const interaction = new store.Adapter('Interaction');
  await interaction.upsert('i', payload('Interaction', 'i'), 120);
  db.prepare("UPDATE relay_link_records SET nonce=?, ciphertext=?, tag=? WHERE namespace='oidc:Interaction'").run(row.nonce, row.ciphertext, row.tag);
  await assert.rejects(interaction.find('i'), { code: 'INTEGRITY' });
});


test('Relay binding contract preserves opaque case-sensitive runs and rejects malformed worker tokens', (t) => {
  const { store } = fixture(t);
  store.delegations.put('opaque-run', delegated({ runId: 'Run_ABC-123', accountId: '11111111-1111-0111-0111-111111111111' }));
  assert.equal(store.delegations.get('opaque-run').runId, 'Run_ABC-123');
  for (const change of [{ token: 'A'.repeat(64) }, { token: 'a'.repeat(63) }, { token: 'g'.repeat(64) }, { workspaceId: 'workspace/1' }, { runId: 'run/1' }]) {
    assert.throws(() => store.delegations.put('bad', delegated(change)));
  }
});


test('file-backed database rejects weakened durability rather than changing caller settings', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'relay-storage-durability-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const db = new DatabaseSync(join(dir, 'fixture.sqlite'));
  t.after(() => db.close());
  initializeStorage(db);
  db.exec('PRAGMA synchronous=NORMAL');
  assert.throws(() => createEncryptedStore({ db, key: FIXTURE_KEY, keyId }), { code: 'NON_DURABLE_DATABASE' });
  assert.equal(db.prepare('PRAGMA synchronous').get().synchronous, 1);
  db.exec('PRAGMA synchronous=FULL; PRAGMA journal_mode=MEMORY');
  assert.throws(() => createEncryptedStore({ db, key: FIXTURE_KEY, keyId }), { code: 'NON_DURABLE_DATABASE' });
});


test('bulk lifecycle revocation covers every stored grant including unused/orphaned tokens and retains tombstones', async (t) => {
  const { db, store } = fixture(t);
  const grant = new store.Adapter('Grant');
  const code = new store.Adapter('AuthorizationCode');
  const access = new store.Adapter('AccessToken');
  const interaction = new store.Adapter('Interaction');
  await grant.destroy('already-revoked');
  const originalTombstones = db.prepare('SELECT * FROM relay_link_revoked_grants').all();
  await grant.upsert('g1', tokenPayload('Grant', 'g1', 'g1'), 120);
  store.delegations.put('g1', delegated());
  await code.upsert('c1', tokenPayload('AuthorizationCode', 'c1', 'g1'), 120);
  await access.upsert('unused-token', tokenPayload('AccessToken', 'unused-token', 'g1'), 120);
  store.delegations.put('delegation-only', delegated());
  await access.upsert('orphan-token', tokenPayload('AccessToken', 'orphan-token', 'orphan-grant'), 120);
  await interaction.upsert('i1', payload('Interaction', 'i1', { grantId: 'g1' }), 120);
  await interaction.upsert('i2', payload('Interaction', 'i2', { grantId: 'interaction-only-grant' }), 120);
  await new store.Adapter('Session').upsert('s1', payload('Session', 's1', { uid: 'fixture-uid' }), 120);
  store.state.put('login', 'login1', { fixture: true }, 120);
  assert.equal(store.revokeAllGrants(), 3);
  assert.equal(store.revokeAllGrants(), 0);
  assert.equal(await grant.find('g1'), undefined);
  assert.equal(await code.find('c1'), undefined);
  assert.equal(await access.find('unused-token'), undefined);
  assert.equal(await access.find('orphan-token'), undefined);
  assert.equal((await interaction.find('i1')).grantId, 'g1');
  assert.equal((await interaction.find('i2')).grantId, 'interaction-only-grant');
  assert.equal(store.delegations.get('g1'), undefined);
  assert.equal(store.delegations.get('delegation-only'), undefined);
  assert.ok(store.state.get('login', 'login1'));
  assert.ok(await new store.Adapter('Session').find('s1'));
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_revoked_grants').get().n, 4);
  assert.deepEqual(db.prepare('SELECT * FROM relay_link_revoked_grants WHERE grant_hash=?').all(originalTombstones[0].grant_hash), originalTombstones);
  for (const id of ['g1', 'delegation-only', 'orphan-grant', 'already-revoked']) {
    await assert.rejects(grant.upsert(id, tokenPayload('Grant', id, id), 120), { code: 'INVALID_GRANT' });
    assert.throws(() => store.delegations.put(id, delegated()), { code: 'INVALID_GRANT' });
  }
  // Storage cannot anticipate a never-seen ID: lifecycle gating owns that case.
  await grant.upsert('new-after-restart', tokenPayload('Grant', 'new-after-restart', 'new-after-restart'), 120);
  assert.ok(await grant.find('new-after-restart'));
});

test('bulk revocation works at the row cap and rejects stale in-flight writes from another store instance', async (t) => {
  const { db, store } = fixture(t, { maxRows: 2 });
  const otherStore = createEncryptedStore({ db, key: FIXTURE_KEY, keyId, now: () => START, maxRows: 2 });
  const snapshot = tokenPayload('Grant', 'g1', 'g1');
  await new store.Adapter('Grant').upsert('g1', snapshot, 120);
  await new store.Adapter('Grant').destroy('already-revoked');
  assert.equal(store.revokeAllGrants(), 1);
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_records').get().n, 0);
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_revoked_grants').get().n, 2);
  await assert.rejects(new otherStore.Adapter('Grant').upsert('g1', snapshot, 120), { code: 'INVALID_GRANT' });
  await assert.rejects(new otherStore.Adapter('AccessToken').upsert('late-token', tokenPayload('AccessToken', 'late-token', 'g1'), 120), { code: 'INVALID_GRANT' });
  assert.equal(store.revokeAllGrants(), 0);
});

test('bulk revocation is all-or-nothing if SQLite fails during tombstone insertion', async (t) => {
  const { db, store } = fixture(t);
  const grant = new store.Adapter('Grant');
  for (const id of ['g1', 'g2']) await grant.upsert(id, tokenPayload('Grant', id, id), 120);
  db.exec(`CREATE TRIGGER invented_test_failure BEFORE INSERT ON relay_link_revoked_grants
    WHEN (SELECT count(*) FROM relay_link_revoked_grants) = 1
    BEGIN SELECT RAISE(ABORT, 'invented transaction failure'); END;`);
  assert.throws(() => store.revokeAllGrants(), /invented transaction failure/);
  assert.equal(db.prepare('SELECT count(*) n FROM relay_link_revoked_grants').get().n, 0);
  assert.ok(await grant.find('g1'));
  assert.ok(await grant.find('g2'));
  db.exec('DROP TRIGGER invented_test_failure');
  assert.equal(store.revokeAllGrants(), 2);
  assert.equal(await grant.find('g1'), undefined);
  assert.equal(await grant.find('g2'), undefined);
});

test('bulk lifecycle revocation persists across file-backed restart for never-used OAuth tokens', async (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'relay-storage-bulk-restart-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const path = join(dir, 'fixture.sqlite');
  const firstDb = new DatabaseSync(path, { timeout: 5000 });
  initializeStorage(firstDb);
  const first = createEncryptedStore({ db: firstDb, key: FIXTURE_KEY, keyId, now: () => START });
  first.delegations.put('g', delegated());
  await new first.Adapter('AccessToken').upsert('unused-token', tokenPayload('AccessToken', 'unused-token', 'g'), 120);
  firstDb.close();
  const restartedDb = new DatabaseSync(path, { timeout: 5000 });
  const restarted = createEncryptedStore({ db: restartedDb, key: FIXTURE_KEY, keyId, now: () => START });
  assert.equal(restarted.revokeAllGrants(), 1);
  restartedDb.close();
  const finalDb = new DatabaseSync(path, { timeout: 5000 });
  t.after(() => finalDb.close());
  const final = createEncryptedStore({ db: finalDb, key: FIXTURE_KEY, keyId, now: () => START });
  assert.equal(await new final.Adapter('AccessToken').find('unused-token'), undefined);
  assert.equal(final.delegations.get('g'), undefined);
  assert.throws(() => final.delegations.put('g', delegated()), { code: 'INVALID_GRANT' });
  await assert.rejects(new final.Adapter('Grant').upsert('g', tokenPayload('Grant', 'g', 'g'), 120), { code: 'INVALID_GRANT' });
});


test('account-switch Interaction resumes after old-grant revocation without reviving its authority', async (t) => {
  const { db, store } = fixture(t);
  const grant = new store.Adapter('Grant');
  const code = new store.Adapter('AuthorizationCode');
  const access = new store.Adapter('AccessToken');
  const interaction = new store.Adapter('Interaction');
  await grant.upsert('old-grant', tokenPayload('Grant', 'old-grant', 'old-grant'), 120);
  store.delegations.put('old-grant', delegated());
  await code.upsert('old-code', tokenPayload('AuthorizationCode', 'old-code', 'old-grant'), 120);
  await access.upsert('old-token', tokenPayload('AccessToken', 'old-token', 'old-grant'), 120);
  const pending = payload('Interaction', 'switch-interaction', {
    grantId: 'old-grant', params: { prompt: 'login' }, returnTo: '/authorize/resume/fixture',
  });
  await interaction.upsert('switch-interaction', pending, 120);
  assert.equal(db.prepare("SELECT grant_hash FROM relay_link_records WHERE namespace='oidc:Interaction'").get().grant_hash, null);
  await grant.destroy('old-grant');
  assert.equal(await grant.find('old-grant'), undefined);
  assert.equal(await code.find('old-code'), undefined);
  assert.equal(await access.find('old-token'), undefined);
  assert.equal(store.delegations.get('old-grant'), undefined);
  assert.deepEqual(await interaction.find('switch-interaction'), pending);
  // The library may update the old annotation while completing its resume flow.
  const resumed = { ...pending, result: { login: { accountId: 'new-subject' } } };
  await interaction.upsert('switch-interaction', resumed, 120);
  assert.deepEqual(await interaction.find('switch-interaction'), resumed);
  await code.revokeByGrantId('old-grant');
  assert.deepEqual(await interaction.find('switch-interaction'), resumed);
  await assert.rejects(code.upsert('late-code', tokenPayload('AuthorizationCode', 'late-code', 'old-grant'), 120), { code: 'INVALID_GRANT' });
  await assert.rejects(access.upsert('late-token', tokenPayload('AccessToken', 'late-token', 'old-grant'), 120), { code: 'INVALID_GRANT' });
  await assert.rejects(grant.upsert('old-grant', tokenPayload('Grant', 'old-grant', 'old-grant'), 120), { code: 'INVALID_GRANT' });
  assert.throws(() => store.delegations.put('old-grant', delegated()), { code: 'INVALID_GRANT' });
  await interaction.upsert('switch-interaction', { ...resumed, grantId: 'new-grant' }, 120);
  assert.equal((await interaction.find('switch-interaction')).grantId, 'new-grant');
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {createRelaySessionClient, RELAY_ENDPOINT} from '../relay-session.mjs';
const selected = {workspaceId: 'test-studio', accountId: '11111111-1111-4111-8111-111111111111', agentId: '22222222-2222-4222-8222-222222222222'};
const at = 1800000000000;
const token = 'a'.repeat(64);
const value = {...selected, runId: 'test-run', token, expiresAt: at + 3600000};
const context = () => ({user: {id: selected.accountId, agentId: selected.agentId, role: 'worker', enabled: true},
  actor: {id: selected.agentId, owner: false, session: value.runId},
  state: {agents: [{id: selected.agentId, enabled: true, session: value.runId}]}});
const json = body => new Response(JSON.stringify(body), {headers: {'content-type': 'application/json'}});
function fixture(change = () => {}) {
  const calls = [];
  const client = createRelaySessionClient({selected, now: () => at, fetcher: async (url, options) => {
    calls.push({url, ...options});
    const action = JSON.parse(options.body).action;
    const body = action === 'login' ? {user: context().user, token, expiresAt: new Date(value.expiresAt).toISOString()} : context();
    change(body, action); return json(body);
  }});
  return {client, calls};
}
test('worker login resolves only backend-confirmed exact identity/run and never persists password', async () => {
  const {client, calls} = fixture();
  assert.deepEqual(await client.login({username: 'dot-fixture', password: 'test-only-password'}), value);
  assert.equal(calls.length, 3);
  assert.equal(calls[0].url, RELAY_ENDPOINT);
  assert.equal(calls[0].headers.authorization, undefined);
  assert.deepEqual(JSON.parse(calls[0].body), {action: 'login', data: {role: 'worker', username: 'dot-fixture', password: 'test-only-password'}});
  assert.ok(calls.slice(1).every(call => call.headers.authorization === `Bearer ${token}` && !call.body.includes('password')));
  assert.ok(calls.every(call => call.redirect === 'error' && call.credentials === 'omit'));
});
test('every check calls live context; no successful-result cache', async () => {
  const {client, calls} = fixture(); await client.check(value); await client.check(value);
  assert.equal(calls.length, 2);
});
for (const [name, change] of [
  ['manager', x => {x.user.role = 'manager';}],
  ['disabled', x => {x.user.enabled = false;}],
  ['different account', x => {x.user.id = '33333333-3333-4333-8333-333333333333';}],
  ['different agent', x => {x.user.agentId = '33333333-3333-4333-8333-333333333333';}],
  ['owner actor', x => {x.actor.owner = true;}],
  ['changed run', x => {x.actor.session = 'new-run';}],
  ['disabled board agent', x => {x.state.agents[0].enabled = false;}],
  ['duplicate board agent', x => {x.state.agents.push(x.state.agents[0]);}],
  ['revoked', x => {x.error = {code: 'SESSION', message: token};}]
]) test(`reject ${name} without exposing backend details`, async () => {
  const {client} = fixture(change);
  await assert.rejects(client.check(value), error => error.code === 'AUTH_REQUIRED' && !error.message.includes(token));
});
test('expired/mismatched session and missing explicit account are rejected before transmission', async () => {
  const {client, calls} = fixture();
  await assert.rejects(client.check({...value, expiresAt: at}));
  await assert.rejects(client.check({...value, accountId: '33333333-3333-4333-8333-333333333333'}));
  assert.equal(calls.length, 0);
  assert.throws(() => createRelaySessionClient({selected: {name: 'dot'}}));
});
test('HTTP failure, non-JSON and oversized body deny', async () => {
  for (const response of [new Response('', {status: 401}), new Response('secret'), json({padding: 'x'.repeat(4_000_001)})]) {
    const client = createRelaySessionClient({selected, now: () => at, fetcher: async () => response});
    await assert.rejects(client.check(value));
  }
});
test('cancelled requests cannot accept a late successful result', async () => {
  const abort = new AbortController();
  const client = createRelaySessionClient({selected, now: () => at, fetcher: async () => {abort.abort(); return json(context());}});
  await assert.rejects(client.check(value, {signal: abort.signal}));
});
test('bound message calls use only the fixed backend and their existing server-owned worker session', async () => {
  const calls = [];
  const client = createRelaySessionClient({selected, now: () => at, fetcher: async (url, options) => {calls.push({url, options}); return json({ok: true});}});
  const messageId = '33333333-3333-4333-8333-333333333333';
  assert.deepEqual(await client.message({session: value, action: 'messages.get', data: {messageId}}), {ok: true});
  assert.equal(calls.length, 1); assert.equal(calls[0].url, RELAY_ENDPOINT);
  assert.equal(calls[0].options.headers.authorization, `Bearer ${token}`);
  assert.equal(calls[0].options.redirect, 'error');
  assert.deepEqual(JSON.parse(calls[0].options.body), {action: 'messages.get', data: {messageId}});
  for (const request of [
    {action: 'workers.delete', data: {}}, {action: 'login', data: {}},
    {action: 'messages.get', data: {messageId, accountId: selected.accountId}},
    {action: 'messages.notifications', data: {limit: 101}},
    {action: 'messages.send', data: {command: {senderId: messageId, workspaceId: selected.workspaceId}}}
  ]) await assert.rejects(client.message({session: value, ...request}));
  assert.equal(calls.length, 1);
});
test('Relay authority denial and transport outage remain distinct for continuing consent', async () => {
  for (const [status, transient] of [[401, false], [403, false], [409, false], [429, true], [503, true]]) {
    const client = createRelaySessionClient({selected, now: () => at, fetcher: async () => new Response('{}', {status, headers: {'content-type': 'application/json'}})});
    await assert.rejects(client.check(value), error => error.code === 'AUTH_REQUIRED' && error.transient === transient);
  }
});

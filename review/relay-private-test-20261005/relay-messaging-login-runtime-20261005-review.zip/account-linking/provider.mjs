import {createHash, randomBytes} from 'node:crypto';
import {Provider, errors, interactionPolicy} from 'oidc-provider';
import {BROWSER_SCOPE, createRelaySessionClient, denied, sameBinding, selectedWorker} from './relay-session.mjs';
import {createMessageAuthority, MESSAGE_SCOPES} from './message-authority.mjs';

const plain = value => value && Object.getPrototypeOf(value) === Object.prototype;
const opaque = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
const digest = value => createHash('sha256').update(value).digest('hex');
const nonce = () => randomBytes(32).toString('base64url');
const must = condition => {if (!condition) throw denied();};
const authorizationScopes = (value, target) => {
  if (typeof value !== 'string') return false;
  const scopes = value.split(' ');
  return scopes.includes(target.messaging ? 'relay:work' : BROWSER_SCOPE) && new Set(scopes).size === scopes.length && scopes.every(scope => [...target.scopes, 'openid'].includes(scope));
};
const html = value => String(value).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const headers = {'cache-control': 'no-store', 'pragma': 'no-cache', 'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer', 'content-security-policy': "default-src 'none'; script-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"};
const paths = new Set(['/.well-known/openid-configuration', '/.well-known/oauth-authorization-server', '/auth', '/token', '/jwks', '/token/revocation', '/token/introspection']);
function httpsURL(value, originOnly = false) {
  const parsed = new URL(value);
  if (typeof value !== 'string' || parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.hash || parsed.search ||
    (originOnly ? parsed.origin !== value : parsed.href !== value)) throw new TypeError('Explicit canonical HTTPS configuration is required.');
  return parsed;
}
function send(res, status, message) {
  res.writeHead(status, {...headers, 'content-type': 'text/html; charset=utf-8'});
  res.end(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Relay connection</title><body>${message}</body></html>`);
}
async function form(req) {
  must(/^application\/x-www-form-urlencoded(?:\s*;\s*charset=utf-8)?$/i.test(req.headers['content-type'] || ''));
  const length = req.headers['content-length']; must(length === undefined || /^\d+$/.test(length) && Number(length) <= 4096);
  const pieces = []; let bytes = 0;
  for await (const part of req) {bytes += part.length; must(bytes <= 4096); pieces.push(part);}
  const fields = new URLSearchParams(Buffer.concat(pieces).toString('utf8'));
  const result = Object.create(null);
  for (const [key, value] of fields) {must(!Object.hasOwn(result, key)); result[key] = value;}
  return result;
}

/** Creates real oidc-provider protocol and Relay interaction handlers, but no
 * listeners, keys, client registrations in an external system, or live login.
 * The caller must provide reviewed durable storage and approved pre-existing
 * key material. Never expose `provider` internals or these hooks as RPC methods.
 * Call `handle` only on a genuine TLS Node request; proxy/header trust is disabled.
 */
export function createRelayAccountLinking({origin, selected, client, store, jwks, cookieKeys, relayClient, now = Date.now,
  pollIntervalMs = 5000, messaging} = {}) {
  const url = httpsURL(origin, true), resource = `${origin}/mcp`;
  selected = selectedWorker(selected);
  if (!plain(client) || Object.keys(client).some(key => !['id', 'redirectUri', 'name'].includes(key)) ||
      !opaque(client.id) || typeof client.name !== 'string' || client.name.length < 1 || client.name.length > 100) throw new TypeError('One explicitly registered public PKCE client is required.');
  httpsURL(client.redirectUri);
  client = Object.freeze({...client});
  const targets = new Map([[client.id, Object.freeze({client, resource, scopes: [BROWSER_SCOPE], messaging: false})]]);
  if (messaging !== undefined) {
    if (!plain(messaging) || Object.keys(messaging).sort().join(',') !== 'binding,client,resource' ||
      !plain(messaging.binding) || Object.keys(messaging.binding).sort().join(',') !== 'accountId,agentId,runId,workspaceId' ||
      !sameBinding(messaging.binding, {...selected, runId: messaging.binding.runId}) || !opaque(messaging.binding.runId) ||
      !plain(messaging.client) || Object.keys(messaging.client).sort().join(',') !== 'id,name,redirectUri' ||
      !opaque(messaging.client.id) || messaging.client.id === client.id || typeof messaging.client.name !== 'string' || !messaging.client.name.length || messaging.client.name.length > 100 ||
      !store?.messagingDelegations) throw new TypeError('Messaging requires its exact resource, worker/run and separate explicit OAuth client.');
    const messageURL = httpsURL(messaging.resource);
    httpsURL(messaging.client.redirectUri);
    if (messageURL.origin === origin || messageURL.pathname !== '/mcp') throw new TypeError('Messaging requires a separate canonical HTTPS MCP audience.');
    messaging = Object.freeze({resource: messaging.resource, binding: Object.freeze({...messaging.binding}), client: Object.freeze({...messaging.client})});
    targets.set(messaging.client.id, Object.freeze({client: messaging.client, resource: messaging.resource, scopes: MESSAGE_SCOPES, messaging: true}));
  }
  if (!store || typeof store.Adapter !== 'function' || typeof store.revokeAllGrants !== 'function' || !store.state || !store.delegations ||
      !plain(jwks) || !Array.isArray(jwks.keys) || !jwks.keys.length || jwks.keys.some(key => !plain(key) || !key.d || !key.kid || key.kty !== 'EC' || key.crv !== 'P-256' || key.alg !== 'ES256') ||
      !Array.isArray(cookieKeys) || !cookieKeys.length || cookieKeys.some(key => typeof key !== 'string' || key.length < 64) ||
      typeof now !== 'function' || !Number.isSafeInteger(pollIntervalMs) || pollIntervalMs < 1000 || pollIntervalMs > 5000) throw new TypeError('Reviewed durable storage, existing private ES256/cookie keys, and bounded lifecycle configuration are required.');
  const relay = relayClient || createRelaySessionClient({selected});
  if (typeof relay.login !== 'function' || typeof relay.check !== 'function' || messaging && typeof relay.message !== 'function' || JSON.stringify(relay.selected) !== JSON.stringify(selected)) throw new TypeError('The Relay client must be pinned to the selected worker.');
  const state = store.state, delegations = store.delegations;
  function targetFor(clientId, requestedResource) {
    const target = targets.get(clientId); must(target && (requestedResource === undefined || requestedResource === target.resource)); return target;
  }
  function delegationFor(token) {
    const target = targets.get(token?.clientId);
    if (!target) return undefined;
    const d = (target.messaging ? store.messagingDelegations : delegations).get(token.grantId);
    if (!d || d.clientId !== target.client.id || d.subject !== token.accountId || d.expiresAt <= now() ||
      (target.messaging && (d.resource !== target.resource || !sameBinding(d, messaging.binding)))) return undefined;
    return d;
  }
  // A new process never silently remaps a persisted OAuth lease to fresh host
  // context objects. This service is a single instance for one private DB.
  store.revokeAllGrants();
  let closed = false, closing, subscription, polling;
  const records = new Map(), references = new WeakMap(), contexts = new WeakMap(), handlers = new Set();
  const processAbort = new AbortController();
  async function relayOperation(method, value, {signal} = {}) {
    must(!closed && !signal?.aborted);
    const combined = AbortSignal.any([processAbort.signal, AbortSignal.timeout(4000), ...(signal ? [signal] : [])]);
    let cancel;
    try {
      const result = await Promise.race([Promise.resolve().then(() => {combined.throwIfAborted(); return relay[method](value, {signal: combined});}),
        new Promise((_, reject) => {cancel = () => reject(denied({transient: !closed && !signal?.aborted})); combined.addEventListener('abort', cancel, {once: true}); if (combined.aborted) cancel();})]);
      must(!closed && !combined.aborted); return result;
    } finally {combined.removeEventListener('abort', cancel);}
  }
  class GuardedAdapter extends store.Adapter {
    async upsert(...args) {must(!closed); return super.upsert(...args);}
  }
  const policy = interactionPolicy.base();
  // Require fresh worker authentication and explicit consent each authorization;
  // an existing provider session cannot silently reuse or widen a delegation.
  policy.get('login').checks.add(new interactionPolicy.Check('fresh_worker_login', 'Worker sign-in is required', ctx => !ctx.oidc.result?.login));
  policy.get('consent').checks.add(new interactionPolicy.Check('explicit_browser_consent', 'Explicit browser consent is required', ctx => !ctx.oidc.result?.consent));
  const provider = new Provider(origin, {
    adapter: GuardedAdapter,
    clients: [...targets.values()].map(target => ({client_id: target.client.id, client_name: target.client.name, redirect_uris: [target.client.redirectUri],
      response_types: ['code'], grant_types: ['authorization_code'], token_endpoint_auth_method: 'none',
      scope: `${target.scopes.join(' ')} openid`, application_type: 'web', id_token_signed_response_alg: 'ES256'})),
    jwks: structuredClone(jwks),
    cookies: {keys: [...cookieKeys], long: {httpOnly: true, secure: true, sameSite: 'lax'},
      short: {httpOnly: true, secure: true, sameSite: 'lax'}},
    responseTypes: ['code'], scopes: [BROWSER_SCOPE, ...(messaging ? MESSAGE_SCOPES : [])], clientAuthMethods: ['none'],
    pkce: {required: () => true}, allowOmittingSingleRegisteredRedirectUri: false,
    clockTolerance: 0, acceptQueryParamAccessTokens: false,
    features: {
      devInteractions: {enabled: false}, registration: {enabled: false},
      userinfo: {enabled: false}, rpInitiatedLogout: {enabled: false},
      introspection: {enabled: true, allowedPolicy: async (_ctx, c, token) => {
        if (closed || !targets.has(c.clientId) || token.clientId !== c.clientId) return false;
        const d = delegationFor(token);
        if (!d) return false;
        try {await relayOperation('check', d); return !!delegationFor(token);} catch {return false;}
      }},
      revocation: {enabled: true, allowedPolicy: (_ctx, c, token) => targets.has(c.clientId) && token.clientId === c.clientId},
      resourceIndicators: {enabled: true, defaultResource: (_ctx, c) => targetFor(c.clientId).resource, useGrantedResource: () => true,
        getResourceServerInfo: (_ctx, indicator, c) => {
          const target = targets.get(c.clientId);
          if (!target || indicator !== target.resource) throw new errors.InvalidTarget();
          return {scope: target.scopes.join(' '), audience: target.resource, accessTokenFormat: 'opaque'};
        }}
    },
    interactions: {policy, url: (_ctx, interaction) => `/interaction/${interaction.uid}`},
    ttl: {AccessToken: (_ctx, token) => {
      const d = delegationFor(token);
      if (closed || !d || d.expiresAt <= now() + 1000) throw new errors.InvalidGrant();
      return Math.max(1, Math.min(900, Math.floor((d.expiresAt - now()) / 1000)));
    }, AuthorizationCode: 60, Grant: 900, IdToken: 900, Interaction: 600, Session: 900},
    findAccount: async (_ctx, subject, token) => {
      if (closed) return undefined;
      const pendingId = _ctx?.oidc?.result?.login?.relayLoginId;
      const value = token?.grantId ? delegationFor(token) : ((pendingId ? state.get('login', pendingId) : undefined) || state.get('account', subject));
      if (!value || value.subject !== subject || value.expiresAt <= now() || !sameBinding(value, {...selected, runId: value.runId})) return undefined;
      try {await relayOperation('check', value);} catch {return undefined;}
      return {accountId: subject, claims: async () => ({sub: subject})};
    },
    extraTokenClaims: async (_ctx, token) => {
      // Code exchange must still be inside the same live consented worker lease.
      const d = delegationFor(token);
      if (!d || token.aud !== targets.get(token.clientId)?.resource) throw new errors.InvalidGrant();
      await relayOperation('check', d);
      if (!delegationFor(token)) throw new errors.InvalidGrant();
      return undefined;
    },
    renderError: async ctx => {ctx.type = 'text/html'; ctx.body = '<!doctype html><title>Relay connection</title><p>Connection request could not be completed. Start a new connection.</p>';}
  });
  provider.proxy = false;
  // Avoid library default stderr diagnostics that may include request material.
  provider.removeAllListeners('server_error'); provider.on('server_error', () => {});
  const callback = provider.callback();
  async function liveRecord(record, {signal} = {}) {
    must(!closed && record.active && record.expiresAt > now() && !signal?.aborted);
    const [token, grant] = await Promise.all([provider.AccessToken.find(record.tokenId), provider.Grant.find(record.grantId)]);
    must(token?.isValid && grant && !grant.isExpired && token.clientId === client.id && grant.clientId === client.id &&
      token.accountId === record.subject && grant.accountId === record.subject && token.grantId === record.grantId &&
      token.aud === resource && token.scope === BROWSER_SCOPE && token.exp * 1000 === record.expiresAt);
    const d = delegations.get(record.grantId);
    must(d && d.clientId === client.id && d.subject === record.subject && d.expiresAt >= record.expiresAt && d.scope === BROWSER_SCOPE && sameBinding(d, record.binding));
    await relayOperation('check', d, {signal});
    // A local revocation can commit while the remote Relay check is in flight.
    // Re-read durable authority after that await before returning any binding.
    const latest = delegations.get(record.grantId);
    must(latest && latest.subject === record.subject && latest.clientId === client.id && latest.scope === BROWSER_SCOPE &&
      latest.token === d.token && latest.expiresAt === d.expiresAt && sameBinding(latest, record.binding));
    must(!closed && record.active && record.expiresAt > now() && !signal?.aborted);
    return d;
  }
  async function retire(record) {
    record.active = false;
    if (record.cleanup) return record.cleanup;
    record.cleanup = Promise.resolve().then(async () => {
      delegations.destroy(record.grantId);
      const result = await subscription?.onRevoke(record.context);
      if (!subscription || result?.isError === true) throw denied();
      records.delete(record.context.grantId);
    });
    try {await record.cleanup;} finally {record.cleanup = undefined;}
  }
  function poll() {
    if (closed || !subscription) return Promise.resolve();
    if (polling) return polling;
    polling = Promise.resolve().then(async () => {
      const results = await Promise.allSettled([...records.values()].map(async record => {
        if (record.active) {try {await liveRecord(record, {signal: processAbort.signal});} catch {record.active = false;}}
        if (!record.active) await retire(record);
      }));
      if (results.some(result => result.status === 'rejected') && !closed) subscription?.onUnavailable();
    }).catch(() => {if (!closed) subscription?.onUnavailable();}).finally(() => {polling = undefined;});
    return polling;
  }
  const hooks = Object.freeze({
    async verifyAccessToken(raw, {resource: wanted, issuers, signal} = {}) {
      must(!closed && subscription && wanted === resource && Array.isArray(issuers) && issuers.includes(origin) && typeof raw === 'string' && /^[A-Za-z0-9_-]{32,128}$/.test(raw));
      const token = await provider.AccessToken.find(raw);
      must(token?.isValid && token.clientId === client.id && token.aud === resource && token.scope === BROWSER_SCOPE && opaque(token.grantId) && opaque(token.accountId));
      const id = digest(raw), d = delegations.get(token.grantId);
      must(d && d.subject === token.accountId && d.clientId === client.id && d.scope === BROWSER_SCOPE);
      // Same-browser reconnection revokes the previous provider token first.
      // Retire its old host context now instead of creating a transient ambiguous
      // worker-session match while waiting for the next idle poll.
      for (const prior of [...records.values()]) {
        if (prior.context.grantId === id) continue;
        if (!prior.active || prior.expiresAt <= now() || !(await provider.AccessToken.find(prior.tokenId))?.isValid) await retire(prior);
      }
      must(!closed && !signal?.aborted);
      let record = records.get(id);
      if (!record) {
        must(records.size < 8);
        record = {active: true, tokenId: raw, grantId: token.grantId, subject: token.accountId, expiresAt: token.exp * 1000,
          binding: Object.freeze({workspaceId: d.workspaceId, accountId: d.accountId, agentId: d.agentId, runId: d.runId}),
          context: Object.freeze({grantId: id}), reference: Object.freeze({leaseId: id})};
        // Insert before awaits to preserve object identity under concurrency.
        records.set(id, record); contexts.set(record.context, record); references.set(record.reference, record);
      }
      try {await liveRecord(record, {signal});} catch {record.active = false; void retire(record).catch(() => subscription?.onUnavailable()); throw denied();}
      return {claims: {active: true, iss: origin, sub: record.subject, aud: resource, exp: record.expiresAt / 1000,
        scope: BROWSER_SCOPE, jti: id}, principalId: id, requestContext: record.context};
    },
    async resolveHostReference(identity, {signal} = {}) {
      const record = contexts.get(identity?.requestContext); must(record && identity.scopes?.length === 1 && identity.scopes[0] === BROWSER_SCOPE);
      await liveRecord(record, {signal}); return record.reference;
    },
    async resolveBinding(reference, {signal} = {}) {
      const record = references.get(reference); must(record); await liveRecord(record, {signal}); return record.binding;
    },
    async resolveWorkerSession(binding, {signal} = {}) {
      // Driver asks by binding only. Multiple concurrent consents for one run
      // could imply different Relay credentials, so reject ambiguity outright.
      const matching = [...records.values()].filter(record => record.active && sameBinding(record.binding, binding));
      must(matching.length === 1);
      const d = await liveRecord(matching[0], {signal});
      return {binding: matching[0].binding, role: 'worker', enabled: true, token: d.token,
        expiresAt: new Date(d.expiresAt).toISOString(), scopes: [BROWSER_SCOPE]};
    },
    async authorizeAction(action, reference, {signal} = {}) {
      const record = references.get(reference); must(record && sameBinding(action?.binding, record.binding));
      await liveRecord(record, {signal});
      const args = action.arguments;
      if (!plain(args)) return false;
      if (action.name === 'browser_open') return Object.keys(args).length === 0;
      if (action.name === 'browser_close') return Object.keys(args).length === 1 && opaque(args.session_id);
      if (action.name === 'browser_click') return Object.keys(args).length === 3 && ['session_id', 'observation_id', 'target_id'].every(key => opaque(args[key]));
      return false; // No fill, DM, arbitrary URL, script, or credential actions.
    },
    async subscribeRevocations(onRevoke, {signal, shutdownSignal, onUnavailable} = {}) {
      must(!closed && !subscription && typeof onRevoke === 'function' && typeof onUnavailable === 'function' && !signal?.aborted && !shutdownSignal?.aborted);
      // A local durable store has no remote changefeed. This is explicitly a
      // bounded poller, plus checks on EVERY request and browser operation.
      const timer = setInterval(() => {void poll();}, pollIntervalMs); timer.unref();
      subscription = {onRevoke, onUnavailable, timer};
      const stop = () => {void close().catch(() => {});};
      shutdownSignal?.addEventListener('abort', stop, {once: true});
      return async () => {shutdownSignal?.removeEventListener('abort', stop); await close();};
    }
  });
  function interactionParams(details) {
    const target = targetFor(details.params.client_id, details.params.resource);
    must(details.params.redirect_uri === target.client.redirectUri &&
      details.params.response_type === 'code' && authorizationScopes(details.params.scope, target) &&
      (!details.params.response_mode || details.params.response_mode === 'query') &&
      details.params.code_challenge_method === 'S256' &&
      typeof details.params.code_challenge === 'string' && /^[A-Za-z0-9_-]{43}$/.test(details.params.code_challenge));
    return target;
  }
  function pendingLogin(details, target, consume = false) {
    const id = details.lastSubmission?.login?.relayLoginId;
    must(opaque(id));
    const value = consume ? state.consume('login', id) : state.get('login', id);
    must(value && value.subject === details.session?.accountId && value.clientId === target.client.id &&
      (!target.messaging || sameBinding(value, messaging.binding)));
    return value;
  }
  async function interaction(req, res, uid) {
    const details = await provider.interactionDetails(req, res); must(details.uid === uid); const target = interactionParams(details);
    const scopes = details.params.scope.split(' ').filter(scope => scope !== 'openid').sort();
    const approval = scopes.join(' ');
    if (req.method === 'GET') {
      const csrf = nonce(), id = `${uid}:${digest(csrf)}`;
      state.put('consent', id, {uid, prompt: details.prompt.name, subject: details.session?.accountId || null}, 600);
      const hidden = `<input type="hidden" name="csrf" value="${html(csrf)}">`;
      if (details.prompt.name === 'login') return send(res, 200, `<h1>Connect the selected Relay worker</h1><p>Sign in to the worker account selected by your Relay administrator. Manager accounts cannot connect.</p><p>Account: ${html(selected.accountId)}</p><form method="post">${hidden}<label>Worker username <input name="username" autocomplete="username" required maxlength="40"></label><label>Password <input type="password" name="password" autocomplete="current-password" required maxlength="72"></label><button name="action" value="login">Continue</button><button name="action" value="cancel" formnovalidate>Cancel</button></form>`);
      must(details.prompt.name === 'consent');
      const value = pendingLogin(details, target); await relayOperation('check', value);
      const purpose = target.messaging ? 'use this Relay worker’s messaging connection' : 'control this Relay worker browser';
      const explanation = target.messaging ? [
        scopes.includes('relay:read') ? 'Read messages available to this worker.' : '',
        scopes.includes('relay:write') ? 'Send and reply as this worker in Relay chat history.' : '',
        'Subscribe to selected-recipient pings, fetch linked work and record explicit agent acknowledgments.',
        'Public messages are readable by workspace members. Private messages are readable by the two participants and the manager for audit.',
        'Manager audit access does not add a ping. Messages are not automatically copied into your ChatGPT conversation.',
        'The server may process this worker’s notification outbox during this consent, even when no browser tab is open.'
      ].filter(Boolean).join(' ') : 'Open the worker browser, view its read-navigation controls, take masked screenshots, and close it. No message sending or typing.';
      return send(res, 200, `<h1>Allow ${html(target.client.name)} to ${html(purpose)}?</h1><p>Worker account: ${html(value.accountId)}</p><p>Agent: ${html(value.agentId)}</p><p>Run: ${html(value.runId)}</p><p>Permission: ${html(approval)}. ${html(explanation)} This connection lasts at most 15 minutes and ends if the Relay session expires or is revoked. Reconnection requires new sign-in and consent.</p><form method="post">${hidden}<label><input type="checkbox" name="approve" value="${html(approval)}" required>I approve this worker and these permissions.</label><button name="action" value="consent">Allow</button><button name="action" value="cancel" formnovalidate>Cancel</button></form>`);
    }
    must(req.method === 'POST' && req.headers.origin === origin && (!req.headers['sec-fetch-site'] || req.headers['sec-fetch-site'] === 'same-origin'));
    const body = await form(req);
    must(typeof body.csrf === 'string' && /^[A-Za-z0-9_-]{43}$/.test(body.csrf));
    const proof = state.consume('consent', `${uid}:${digest(body.csrf)}`);
    must(proof && proof.uid === uid && proof.prompt === details.prompt.name && proof.subject === (details.session?.accountId || null));
    // Multiple separately rendered forms still permit only one submission for
    // this provider interaction, atomically across processes/requests.
    state.put('consent', `submitted:${uid}`, {submitted: true}, 600);
    if (body.action === 'cancel') {
      if (details.lastSubmission?.login?.relayLoginId) state.destroy('login', details.lastSubmission.login.relayLoginId);
      return provider.interactionFinished(req, res, {error: 'access_denied'}, {mergeWithLastSubmission: false});
    }
    if (details.prompt.name === 'login') {
      must(body.action === 'login' && Object.keys(body).every(key => ['action', 'csrf', 'username', 'password'].includes(key)));
      const value = await relayOperation('login', {username: body.username, password: body.password});
      body.password = ''; // Never persist credentials or put them in URLs/HTML.
      must(!target.messaging || sameBinding(value, messaging.binding));
      const priorSubject = details.session?.accountId;
      const prior = priorSubject ? state.get('account', priorSubject) : undefined;
      // With two resources, fresh authentication of the exact same worker/run
      // may retain its short-lived pseudonymous subject. Separate client grants
      // remain independent; pending credentials are keyed by a new nonce.
      const subject = messaging && prior?.subject === priorSubject && sameBinding(prior, value) ? priorSubject : nonce();
      const relayLoginId = nonce();
      state.put('login', relayLoginId, {...value, subject, clientId: target.client.id}, Math.max(1, Math.min(600, Math.floor((value.expiresAt - now()) / 1000))));
      return provider.interactionFinished(req, res, {login: {accountId: subject, relayLoginId, remember: false}}, {mergeWithLastSubmission: false});
    }
    must(details.prompt.name === 'consent' && body.action === 'consent' && body.approve === approval &&
      Object.keys(body).every(key => ['action', 'csrf', 'approve'].includes(key)));
    const subject = details.session?.accountId, value = pendingLogin(details, target, true);
    await relayOperation('check', value);
    const expiresAt = Math.floor(Math.min(value.expiresAt, now() + 900000) / 1000) * 1000;
    must(expiresAt - now() >= 5000);
    if (details.grantId) {
      const previous = await provider.Grant.find(details.grantId);
      if (previous) {must(previous.accountId === subject && previous.clientId === target.client.id); await previous.destroy();}
    }
    const grant = new provider.Grant({accountId: subject, clientId: target.client.id, exp: Math.floor(expiresAt / 1000)});
    grant.addOIDCScope(approval);
    // oidc-provider always advertises openid; ChatGPT may request it. It gives
    // only this short-lived random provider subject, never extra Relay scopes.
    if (details.params.scope.split(' ').includes('openid')) grant.addOIDCScope('openid');
    grant.addResourceScope(target.resource, approval);
    const grantId = await grant.save();
    try {
      must(!closed);
      const delegation = {...value, expiresAt, subject, clientId: target.client.id, consentedAt: now()};
      if (target.messaging) store.messagingDelegations.put(grantId, {...delegation, resource: target.resource, scopes});
      else delegations.put(grantId, delegation);
      if (!state.get('account', subject)) state.put('account', subject, {...value, expiresAt, subject, clientId: target.client.id}, Math.max(1, Math.floor((expiresAt - now()) / 1000)));
      return await provider.interactionFinished(req, res, {consent: {grantId}}, {mergeWithLastSubmission: true});
    } catch (error) {await grant.destroy(); throw error;}
  }
  async function serve(req, res) {
    for (const [name, value] of Object.entries(headers)) res.setHeader(name, value);
    if (closed) return send(res, 503, '<p>Connection service is unavailable.</p>');
    try {
      must(req.socket.encrypted === true && req.headers.host === url.host && !Object.keys(req.headers).some(name => name === 'forwarded' || name.startsWith('x-forwarded-')));
      const incoming = new URL(req.url, origin); must(incoming.origin === origin && !incoming.hash && req.url.startsWith('/') && !req.url.startsWith('//'));
      if (incoming.pathname === '/auth') {
        const target = targetFor(incoming.searchParams.get('client_id'), incoming.searchParams.has('resource') ? incoming.searchParams.get('resource') : undefined);
        must(req.method === 'GET' && incoming.searchParams.getAll('client_id').length === 1 && incoming.searchParams.getAll('resource').length <= 1 &&
          incoming.searchParams.getAll('scope').length === 1 && authorizationScopes(incoming.searchParams.get('scope'), target) &&
          (!incoming.searchParams.has('response_mode') || incoming.searchParams.getAll('response_mode').length === 1 && incoming.searchParams.get('response_mode') === 'query'));
      }
      // Standard oidc-provider account-switch continuation, not public logout
      // initiation. The library verifies its signed cookie and one-use xsrf.
      if (incoming.pathname === '/session/end/confirm') {
        must(req.method === 'POST' && !incoming.search && req.headers.origin === origin &&
          (!req.headers['sec-fetch-site'] || req.headers['sec-fetch-site'] === 'same-origin'));
        return await callback(req, res);
      }
      const match = /^\/interaction\/([A-Za-z0-9_-]{1,128})$/.exec(incoming.pathname);
      if (match) {must(!incoming.search); return await interaction(req, res, match[1]);}
      if (!paths.has(incoming.pathname) && !/^\/auth\/[A-Za-z0-9_-]{1,128}$/.test(incoming.pathname)) return send(res, 404, '<p>Endpoint unavailable.</p>');
      await callback(req, res);
    } catch {if (!res.headersSent) send(res, 400, '<p>Connection request could not be completed. Start a new connection.</p>'); else res.end();}
  }
  function handle(req, res) {
    const operation = serve(req, res); handlers.add(operation);
    operation.finally(() => handlers.delete(operation)); return operation;
  }
  function close() {
    if (closing) return closing;
    closed = true;
    closing = Promise.resolve().then(async () => {
      processAbort.abort(); if (subscription) clearInterval(subscription.timer);
      store.revokeAllGrants();
      const results = await Promise.allSettled([...records.values()].map(retire));
      await Promise.allSettled([...handlers]); if (polling) await polling;
      // Catch any already-entered storage write before its lifecycle check.
      store.revokeAllGrants();
      if (results.some(result => result.status === 'rejected')) throw denied();
    });
    return closing;
  }
  const messageHooks = messaging ? createMessageAuthority({provider, store, issuer: origin, resource: messaging.resource,
    clientId: messaging.client.id, binding: messaging.binding, operation: relayOperation, isClosed: () => closed, now}) : undefined;
  return Object.freeze({handle, hooks, close, issuer: origin, resource, ...(messageHooks ? {messageHooks} : {})});
}

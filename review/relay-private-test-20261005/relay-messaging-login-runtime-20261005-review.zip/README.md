# Relay messaging-login runtime: unified local implementation

This complete source bundle supersedes the earlier runtime assembly for private
validation. Its worker messaging authentication is implemented, not a placeholder
hook. Nothing has been deployed, connected to real ChatGPT, or run against real
accounts. The previously blocked final independent review remains an unchanged
public-deployment gate; these functional changes do not retry or clear it.

## Implemented connection

One pinned `oidc-provider@9.12.2` serves two explicit OAuth clients/audiences:

- Browser: the existing five browser tools, with `browser:control` only.
- Messaging: direct work/message tools with separately selected `relay:work`,
  `relay:read` and `relay:write` consent. A browser token cannot enter messaging,
  and a messaging token cannot control the browser.

Both sign in to the exact configured Relay worker account/agent. Messaging also
pins the selected current run. Identity comes from live Relay authentication,
never a name, model argument, manager session or copied human browser credential.
The two clients have separate callback configurations and can coexist in one
provider browser session without replacing one another's grants.

The concrete authority verifies actual provider tokens and durable grants,
checks the live Relay worker/run, enforces scopes and audience, and rechecks
around source calls. The source facade permits only the implemented message
API actions and exposes no Relay credential. Runtime rejects caller-supplied
messaging authentication hooks and issuer overrides.

## What happens to messages

The modern messaging endpoint exposes three work tools plus message fetch,
explicit acknowledgment, send and same-audience reply. It uses the existing
proposed Relay backend contract and durable event engine; the old ten-tool
controller patch is not installed.

- Public messages are readable by workspace members.
- Private messages are readable by the two participants and the manager for
  audit. Audit access alone never adds the manager as a notification recipient.
- The source message and intended notification outbox are committed together.
- The runtime durably queues work before acknowledging source handoff, with
  stable IDs for crash/retry deduplication.
- Pings carry bounded IDs/audience metadata, not full message bodies.
- Full-message fetch, explicit agent acknowledgment, source handoff, callback
  sent and service acceptance remain different events/timestamps.
- Nothing automatically mirrors messages into the user's ChatGPT conversation.

## Exact 15-minute limit

OAuth access and continuing messaging consent expire no later than **15 minutes
after that consent**, or sooner if the underlying Relay session ends. There are
no refresh tokens, background login, automatic renewal or lifetime extensions.
An event subscription's absolute expiry is capped at its authenticated grant's
expiry, even if a client requests the old 24-hour subscription default.

When full-scope consent is absent, expired or revoked, notification ingestion
pauses without reading Relay, acknowledging source notifications, or delivering
callbacks. Login listeners remain available. Queued work is retained. A later
login requires fresh consent and subscription; it cannot silently revive an
expired callback subscription. Subscriptions also carry an opaque exact-consent ID: a
revoked but unexpired old callback cannot resume under a different new grant.
Request-local engine authorization keeps in-flight work bound to its original
consent rather than borrowing newer permission. A real authority outage fails the runtime closed
while preserving the queue/outbox for an authorized restart.

This is therefore a bounded connection, not an unattended always-on messaging
service. Any longer-lived design requires separate discussion and authorization.

## Concrete bootstrap

`runtime/serve.mjs` loads an administrator-controlled private JSON file:

- Version 1 (`runtime/config.example.json`) remains browser-only.
- Version 2 (`runtime/config.messaging.example.json`) explicitly configures both
  resources, the separate messaging client, exact worker run, callback-host
  allowlist and already-provisioned event database. Read/send/ingestion are all
  enabled in this version; there is no fake-authority configuration option.

Examples contain null deployment values and cannot activate a service as-is.
Bootstrap validates private canonical files, ownership/modes, sidecars, exact
existing schemas and exclusive locks. It does not create a database, apply a
schema, generate credentials or obtain a worker login. The provider SQLite schema
is unchanged; messaging records use its existing encrypted generic record table.
The event database must already have the existing `relay_state` schema.

Construction does not listen. Explicit startup opens only two loopback listeners:
TLS for the provider/browser and HTTP for the message resource behind a separately
reviewed HTTPS front end. Both share shutdown; databases close after services.
No DNS, firewall, proxy, systemd, Caddy or public listener changes are supplied as
automatically executable activation script.

## Manager receipt UI and proxy

The prior receipt UI, ledger reader, HTTP route and same-origin proxy factory are
included unchanged, together with their local tests. The remaining deployment
integration is specific: bind `authenticateRelayManager` to current Relay manager
authorization and `readThroughAuthorizedService` to an approved authenticated
server-to-server route, then configure the same-origin receipt endpoint. The
worker JSON bootstrap does not invent those manager credentials or that trust
channel. Do not forward the manager's browser bearer to a Lightsail origin.
See `receipt-ui/README.md` for the existing factories and exact hook contract.

Before publishing the proposed receipt frontend, its new static imports
`receipt-ui.mjs` and `receipt-config.mjs` also need an explicitly reviewed
compatibility addition to the pinned browser driver’s asset allowlist and a new
Chromium validation. That driver is intentionally unchanged in this bundle;
the previous controller baseline does not prove compatibility with this proposed
frontend. Tab-free message tools do not depend on those frontend assets.

## Local validation and limitations

The real integrated fixture uses TLS, the actual provider and both OAuth flows,
the actual proposed Edge handler backed by PGlite, encrypted provider SQLite,
durable event SQLite, source outbox, send/reply capabilities and explicit ACK.
There is no substitute messaging authentication in that combined runtime test.
Only callback transport and the external database/account environment are local
fixtures. Real callback signing and event/state transitions are exercised.

`VALIDATION.md` records final counts and commands. `SOURCE-PROVENANCE.json`
compares this source with the immutable prior assembly; `PACKAGE-SHA256.json`
lists every packaged file. The controller and production foundation are unchanged.
No dependency directories, credentials, databases, private runtime configuration
or generated test keys/certificates are included.

Remaining before live use:

1. Complete the permitted final source/deployment review; the existing block is
   not clearance and was not bypassed.
2. Confirm real worker IDs/run, both ChatGPT clients/callbacks, HTTPS names and
   the exact callback-host allowlist.
3. Obtain specific approval for persistent access, key/client configuration,
   local storage provisioning and the backend's proposed migration/deployment.
4. Configure the reviewed private service/proxy/supervisor and the manager receipt
   trust route; provide secrets through approved secure handling.
5. Verify the exact final source on the VM, actual sandboxed Chromium operation,
   ChatGPT linking/tool discovery/invocation, real webhook challenge/delivery and
   model wakeup, expiry, reconnect, revoke and shutdown.

This bundle is ready for authorized **private fixture validation**, not public
activation. No real messages, clients, accounts, keys or grants were created.

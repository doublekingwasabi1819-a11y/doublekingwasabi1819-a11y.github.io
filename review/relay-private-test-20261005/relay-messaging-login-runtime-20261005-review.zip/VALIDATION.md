# Final local functional validation — 2026-10-05 UTC

Status: worker messaging login and runtime wiring are implemented and locally
tested. The unified package is prepared for authorized private VM fixture
validation. It is not cleared for public deployment. The prior independent
security-review block remains unresolved and was not retried or rephrased.

## Final results

- Runtime suite: **115/115** passed.
- Component suite: **313/313** passed.
- Total across those non-overlapping test files: **428 passed**, zero failures,
  skips, cancellations or todos.
- Component breakdown: 87 account-linking, 28 production-host, 188 event/message,
  and 10 manager-receipt route tests.
- Account-linking includes 48 durable-storage tests (27 browser + 21 messaging),
  23 actual-provider/TLS tests and 16 Relay session/client tests.
- All changed executable JavaScript passes `node --check`.
- The original 34-file controller checksum manifest passes unchanged.
- Controller, production foundation, proposed backend and receipt UI source trees
  are byte-identical to the immutable input assembly. Only account-linking,
  runtime, the event subscription consent boundary and associated docs/tests
  changed. SOURCE-PROVENANCE.json gives exact file-level comparisons.

Node 24.19.0. Dependencies and lockfiles are unchanged and reused from verified
local installations. This pass did not perform a fresh dependency installation
or vulnerability audit. Earlier browser/controller verification is separate;
this is not a fresh combined-service Chromium launch/action test.

## What the integrated test actually runs

Real TLS and oidc-provider login/consent/PKCE for two clients and audiences;
actual authority hooks; real proposed Edge handler and local PGlite SQL; encrypted
provider SQLite; durable event SQLite; canonical public/private message writes,
replies and notification outbox; signed callback generation; full authorized
fetch and explicit agent acknowledgment. Browser and messaging tokens are not
interchangeable. Scope narrowing, revocation, retry/deduplication and independent
browser access are exercised.

No fake messaging authentication is injected into the assembled runtime test.
The database/users, keys and external callback transport are local test fixtures.
The fixture routes fetch into the local Edge handler and cannot reach the live
Relay backend. No real user, worker, provider client/grant, message or deployment
was created. No test keys, credentials or databases are included in this archive.

Expiry tests prove both the 15-minute grant limit and absolute subscription
expiry. Exact-consent tests prove that fresh consent alone cannot reactivate an
old callback and that concurrent requests/ingestion cannot borrow newer consent.
HTTP tests check OAuth discovery challenges and operation-specific insufficient
scope responses. JSON v2 bootstrap tests open only existing private stores,
validate schemas, hold exclusive locks, avoid automatic schema/key creation and
close both databases after orderly runtime teardown.

## Reproduce in an approved private test copy

Use Node 24 and the existing locked component dependencies. If dependencies must
be installed, use their exact lockfiles with scripts disabled under the separately
approved test setup. Do not run the live CLI against production configuration.

From the bundle root, using the verified existing local PGlite package path:

    RELAY_PGLITE_ROOT=/tmp/approved-fixture/node_modules/@electric-sql/pglite node --test runtime/test/*.test.mjs
    node --test production/tests/*.test.mjs account-linking/tests/*.test.mjs relay-events/test/*.test.mjs receipt-ui/event-host/test/*.test.mjs
    (cd controller && sha256sum --check hosting/ubuntu-x64/controller-sha256.txt)

The /tmp path above is a placeholder for the approved fixture installation, not
an instruction to fetch an arbitrary package. Existing unchanged controller
baseline results should not be represented as a new combined-service browser test.

To verify the entire source manifest using only Node built-ins:

    node --input-type=module -e 'import{readFileSync}from"node:fs";import{createHash}from"node:crypto";const m=JSON.parse(readFileSync("PACKAGE-SHA256.json","utf8"));for(const[p,h]of Object.entries(m.files)){if(createHash("sha256").update(readFileSync(p)).digest("hex")!==h)throw Error("Mismatch: "+p)}console.log("Verified",Object.keys(m.files).length,"files")'

The manifest covers every payload file except itself. The outer ZIP checksum is
provided with delivery. Test logs are included under validation/.

## Remaining live gates

- Permitted final review and explicit installation/persistent-access approvals.
- Real worker IDs/run, two client callbacks, HTTPS names, callback allowlist,
  approved key custody and existing stores; no live values are guessed.
- Proposed backend schema/Edge deployment, private service/supervisor and HTTPS
  front ends. Current listeners bind only loopback.
- Actual ChatGPT linking, callback challenge/delivery, wakeup/tool invocation,
  expiry/reconnect/revocation and VM/Chromium verification.
- Bind the included manager receipt proxy/reader/UI factories to approved manager
  authorization and server-to-server transport on the existing Relay API origin.
- Before publishing the proposed receipt frontend, review the browser driver's
  exact allowlist compatibility for receipt-ui.mjs and receipt-config.mjs. The
  pinned controller is unchanged; tab-free message tools do not use these assets.

The default remains 15 minutes with no refresh or automatic renewal. Longer
unattended operation has not been implemented or implicitly authorized.

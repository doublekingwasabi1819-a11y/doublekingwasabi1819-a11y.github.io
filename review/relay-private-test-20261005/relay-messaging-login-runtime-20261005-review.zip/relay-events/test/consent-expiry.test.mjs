import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {SqliteStore} from '../store.mjs';
import {RelayEvents} from '../core.mjs';

function fixture(t) {
  const directory = mkdtempSync(join(tmpdir(), 'relay-consent-expiry-'));
  const store = new SqliteStore(join(directory, 'events.sqlite'));
  t.after(() => {store.close(); rmSync(directory, {recursive: true, force: true});});
  const state = {now: 1800000000000, allowed: true, sent: 0, onChallenge: undefined};
  const engine = new RelayEvents({store, now: () => state.now, authorize: async () => state.allowed, transport: async req => {
    const body = JSON.parse(req.body);
    if (body.type === 'verification') {state.onChallenge?.(); return {status: 200, body: {challenge: body.challenge}};}
    state.sent++; return {status: 200, body: {}};
  }});
  const params = {name: 'relay.work.available', arguments: {agent_id: 'worker'}, delivery: {mode: 'webhook',
    url: 'https://callback.example.invalid/events', secret: 'whsec_' + Buffer.alloc(32, 1).toString('base64')}};
  return {store, state, engine, params};
}
test('trusted absolute consent expiry caps default 24-hour subscription without trusting RPC fields', async t => {
  const f = fixture(t), deadline = f.state.now + 900000;
  const result = await f.engine.subscribe('owner', {...f.params, expiresAt: f.state.now + 86400000}, {expiresAt: deadline});
  assert.equal(Date.parse(result.refreshBefore), deadline);
  assert.equal(Object.values(f.store.read().subscriptions)[0].expires, deadline);
});
test('expiry during callback verification cannot persist a subscription', async t => {
  const f = fixture(t), deadline = f.state.now + 1000;
  f.state.onChallenge = () => {f.state.now += 1001;};
  await assert.rejects(f.engine.subscribe('owner', f.params, {expiresAt: deadline}), error => error.code === -32001);
  assert.equal(Object.keys(f.store.read().subscriptions).length, 0);
});
test('revocation during callback verification cannot persist a subscription', async t => {
  const f = fixture(t); f.state.onChallenge = () => {f.state.allowed = false;};
  await assert.rejects(f.engine.subscribe('owner', f.params, {expiresAt: f.state.now + 900000}), error => error.code === -32001);
  assert.equal(Object.keys(f.store.read().subscriptions).length, 0);
});
test('later permission does not revive an expired callback subscription', async t => {
  const f = fixture(t);
  await f.engine.subscribe('owner', f.params, {expiresAt: f.state.now + 1000});
  await f.engine.enqueue('owner', {agent_id: 'worker', source_id: 'message-one'});
  f.state.now += 1001; f.state.allowed = true;
  assert.equal((await f.engine.tick()).sent, 0); assert.equal(f.state.sent, 0);
  await f.engine.subscribe('owner', f.params, {expiresAt: f.state.now + 900000});
  assert.equal((await f.engine.tick()).sent, 1);
});
test('delivery rechecks the exact stored consent rather than any newer worker permission', async t => {
  const f = fixture(t), oldConsent = 'a'.repeat(64), newConsent = 'b'.repeat(64);
  let current = oldConsent;
  f.engine.authorize = async query => !query.subscription || query.consentId === current;
  await f.engine.subscribe('owner', f.params, {expiresAt: f.state.now + 900000, consentId: oldConsent});
  await f.engine.enqueue('owner', {agent_id: 'worker', source_id: 'message-two'});
  current = newConsent;
  assert.equal((await f.engine.tick()).sent, 0); assert.equal(f.state.sent, 0);
  await f.engine.subscribe('owner', f.params, {expiresAt: f.state.now + 900000, consentId: newConsent});
  assert.equal((await f.engine.tick()).sent, 1);
});
